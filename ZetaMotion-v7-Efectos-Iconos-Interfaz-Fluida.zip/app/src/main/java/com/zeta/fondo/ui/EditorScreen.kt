package com.zeta.fondo.ui

import android.app.Activity
import android.opengl.GLSurfaceView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.ExportState
import com.zeta.fondo.engine.ExportPlanner
import com.zeta.fondo.engine.PreviewRenderer
import com.zeta.fondo.model.Arrow
import com.zeta.fondo.model.EditorTab
import com.zeta.fondo.model.PointN
import com.zeta.fondo.model.Tool
import kotlin.math.hypot

/** Pantalla real del editor: el lienzo tiene prioridad y un solo panel contextual. */
@Composable
fun EditorScreen(vm: AppViewModel) {
    BackHandler(vm.fullscreen) { vm.fullscreen = false }
    BackHandler(!vm.fullscreen) { vm.closeEditor() }
    val meta = vm.meta ?: return
    val context = LocalContext.current
    val view = LocalView.current
    val cfg = LocalConfiguration.current
    val landscape = cfg.screenWidthDp > cfg.screenHeightDp
    var panelOpen by remember(meta.id) { mutableStateOf(false) }
    val panelHeight = (if (cfg.screenHeightDp < 710) 270.dp else 310.dp)

    DisposableEffect(vm.fullscreen, view) {
        val activity = context as? Activity
        if (activity != null) {
            val controller = WindowCompat.getInsetsController(activity.window, view)
            if (vm.fullscreen) {
                controller.hide(WindowInsetsCompat.Type.systemBars())
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else controller.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            (context as? Activity)?.let {
                WindowCompat.getInsetsController(it.window, view).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    val preview: @Composable (Modifier) -> Unit = { modifier ->
        BoxWithConstraints(modifier.background(Color.Black), contentAlignment = Alignment.Center) {
            val boxAspect = if (maxHeight.value > 0f) maxWidth.value / maxHeight.value else 1f
            val imgAspect = meta.w.toFloat() / meta.h
            Box(Modifier.aspectRatio(imgAspect, matchHeightConstraintsFirst = imgAspect < boxAspect)
                .clip(RoundedCornerShape(if (vm.fullscreen) 0.dp else 6.dp))) {
                GlPreview(vm, Modifier.fillMaxSize())
                GuidesOverlay(vm, Modifier.fillMaxSize())
                vm.glError?.let { err ->
                    Box(Modifier.fillMaxSize().background(Night.copy(alpha = .94f)).padding(16.dp)) {
                        SelectionContainer { Text("Error de vista previa:\n$err", color = Ink, fontSize = 13.sp) }
                    }
                }
            }
            if (vm.fullscreen) {
                Row(Modifier.align(Alignment.TopEnd).padding(13.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StudioSmallButton(if (vm.playing) "Pausar" else "Reproducir",
                        if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow) { vm.togglePlay() }
                    StudioSmallButton("Salir", Icons.Filled.FullscreenExit) { vm.fullscreen = false }
                }
            } else {
                Icon(Icons.Filled.Fullscreen, "Pantalla completa", tint = StudioText,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp).size(49.dp)
                        .clip(RoundedCornerShape(15.dp)).background(Night.copy(alpha = .72f))
                        .clickable { vm.fullscreen = true }.padding(11.dp))
            }
        }
    }

    if (landscape) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            preview(Modifier.fillMaxSize())
            if (!vm.fullscreen) {
                StudioSmallButton("Volver", Icons.Filled.ArrowBack,
                    Modifier.align(Alignment.TopStart).padding(10.dp)) { vm.closeEditor() }
                Column(Modifier.align(Alignment.CenterEnd).width(310.dp).fillMaxHeight()
                    .background(StudioPanel.copy(alpha = .98f))) {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                        .padding(6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        mainTabs.forEach { (tab, label, icon) ->
                            StudioButton(label, icon, Modifier.width(70.dp).height(54.dp), tab == vm.tab && panelOpen) {
                                if (vm.tab == tab) panelOpen = !panelOpen
                                else { vm.selectTab(tab); panelOpen = true }
                            }
                        }
                    }
                    if (panelOpen) Inspector(vm, Modifier.weight(1f))
                }
            }
        }
    } else {
        // El mismo GLSurfaceView permanece montado al entrar o salir de pantalla completa.
        // Así se evita el destello negro causado por destruir y recrear la vista OpenGL.
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            preview(Modifier.fillMaxSize())
            if (!vm.fullscreen) {
                Column(Modifier.fillMaxSize()) {
                    StudioEditorTopBar(vm, meta.name)
                    Spacer(Modifier.weight(1f))
                    TransportBar(vm)
                    EditorTabBar(vm, panelOpen) { tab ->
                        if (vm.tab == tab) panelOpen = !panelOpen
                        else { vm.selectTab(tab); panelOpen = true }
                    }
                }
                if (panelOpen) {
                    Box(Modifier.align(Alignment.BottomCenter)
                        .padding(bottom = 58.dp).fillMaxWidth().height(panelHeight)
                        .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                        .background(StudioPanel)) {
                        Inspector(vm, Modifier.fillMaxSize())
                    }
                }
            }
        }
    }
}

@Composable
private fun TransportBar(vm: AppViewModel) {
    Row(Modifier.fillMaxWidth().height(45.dp).background(Night.copy(alpha = .96f))
        .padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
            if (vm.playing) "Pausar" else "Reproducir", tint = StudioText,
            modifier = Modifier.size(38.dp).clip(RoundedCornerShape(11.dp))
                .background(StudioTile).clickable { vm.togglePlay() }.padding(7.dp))
        Slider(value = vm.scrubT,
            onValueChange = { if (vm.playing) vm.togglePlay(); vm.scrubTo(it) },
            valueRange = 0f..0.999f, modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(thumbColor = StudioPurple, activeTrackColor = StudioPink,
                inactiveTrackColor = StudioTile))
        Text("${vm.exportSettings.loopSec}s", color = StudioMuted, fontSize = 11.sp)
        Icon(if (vm.showGuides) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
            "Guías", tint = StudioText, modifier = Modifier.size(38.dp)
                .clip(RoundedCornerShape(11.dp)).clickable { vm.showGuides = !vm.showGuides }.padding(7.dp))
    }
}

@Composable
private fun EditorTabBar(vm: AppViewModel, panelOpen: Boolean, onSelect: (EditorTab) -> Unit) {
    Row(Modifier.fillMaxWidth().height(58.dp).background(StudioPanel)
        .padding(horizontal = 5.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        mainTabs.forEach { (tab, label, icon) ->
            StudioButton(label, icon, Modifier.weight(1f).fillMaxHeight(), vm.tab == tab && panelOpen) { onSelect(tab) }
        }
    }
}

private val mainTabs = listOf(
    Triple(EditorTab.TOOLS, "Animar", Icons.Filled.PlayArrow),
    Triple(EditorTab.MASKS, "Máscaras", Icons.Filled.Brush),
    Triple(EditorTab.EFFECTS, "Efectos", Icons.Filled.AutoAwesome),
    Triple(EditorTab.EXPORT, "Exportar", Icons.Filled.FileUpload)
)

@Composable
private fun Inspector(vm: AppViewModel, modifier: Modifier = Modifier) {
    Box(modifier.background(StudioPanel)) {
        when (vm.tab) {
            EditorTab.TOOLS -> ToolsPanel(vm)
            EditorTab.MASKS -> MasksPanel(vm)
            EditorTab.PRESETS -> EffectsPanel(vm, vm.effectsCategory)
            EditorTab.EFFECTS -> EffectsPanel(vm, vm.effectsCategory)
            EditorTab.MANGA -> EffectsPanel(vm, "Manga")
            EditorTab.CAMERA -> CameraPanel(vm)
            EditorTab.EXPORT -> ExportPanel(vm)
        }
    }
}

@Composable
private fun StudioEditorTopBar(vm: AppViewModel, name: String) {
    Row(Modifier.fillMaxWidth().height(54.dp).background(Night.copy(alpha = .96f)).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Icon(Icons.Filled.ArrowBack, "Atrás", tint = StudioText,
            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(11.dp))
                .clickable { vm.closeEditor() }.padding(8.dp))
        Text(name, color = StudioText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Icon(Icons.Filled.Undo, "Deshacer", tint = if (vm.canUndo) StudioText else StudioMuted,
            modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))
                .clickable(enabled = vm.canUndo) { vm.undo() }.padding(8.dp))
        Icon(Icons.Filled.Redo, "Rehacer", tint = if (vm.canRedo) StudioText else StudioMuted,
            modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))
                .clickable(enabled = vm.canRedo) { vm.redo() }.padding(7.dp))
        // Exportar vive en la barra inferior; no se repite aquí.
    }
}

@Composable
private fun GlPreview(vm: AppViewModel, modifier: Modifier) {
    val context = LocalContext.current
    val view = remember {
        GLSurfaceView(context).apply {
            setEGLContextClientVersion(3)
            preserveEGLContextOnPause = true
            setRenderer(PreviewRenderer(vm.hub, vm.vertSrc, vm.fragSrc))
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> view.onResume()
                Lifecycle.Event.ON_PAUSE -> view.onPause()
                else -> Unit
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose {
            owner.lifecycle.removeObserver(obs)
            view.onPause()
        }
    }
    AndroidView(factory = { view }, modifier = modifier)
}

@Composable
private fun GuidesOverlay(vm: AppViewModel, modifier: Modifier) {
    var dragArrow by remember { mutableStateOf<Arrow?>(null) }
    var cursor by remember { mutableStateOf<Offset?>(null) }

    Canvas(
        modifier.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val w = size.width.toFloat().coerceAtLeast(1f)
                val h = size.height.toFloat().coerceAtLeast(1f)
                val tool = if (vm.playing || vm.exportState is ExportState.Running) Tool.PAN else vm.tool
                var transforming = tool == Tool.PAN
                var drawing = false
                var arrowStart: PointN? = null
                var moved = false
                var lastPos = down.position

                fun uvOf(o: Offset): PointN = vm.screenToUv(o.x / w, o.y / h)

                when {
                    tool == Tool.ARROW -> arrowStart = uvOf(down.position)
                    tool == Tool.ORIGIN -> vm.moveEffectOrigin(uvOf(down.position))
                    tool.isBrush -> {
                        val radiusUv = vm.brushDp.dp.toPx() / (h * vm.viewScale)
                        vm.beginStroke(uvOf(down.position), radiusUv)
                        drawing = true
                        cursor = down.position
                    }
                    else -> Unit
                }
                down.consume()

                while (true) {
                    val event = awaitPointerEvent()
                    val pressed = event.changes.count { it.pressed }
                    if (pressed == 0) break
                    if (pressed >= 2 && !transforming) {
                        transforming = true
                        if (drawing) {
                            vm.cancelStroke()
                            drawing = false
                        }
                        cursor = null
                        arrowStart = null
                        dragArrow = null
                    }
                    if (transforming) {
                        val zoom = event.calculateZoom()
                        val pan = event.calculatePan()
                        val c = event.calculateCentroid(useCurrent = true)
                        if (c.isSpecified) vm.transformView(zoom, pan.x / w, pan.y / h, c.x / w, c.y / h)
                    } else {
                        val ch = event.changes.firstOrNull { it.id == down.id } ?: event.changes.first()
                        val pos = ch.position
                        if ((pos - down.position).getDistance() > 8f) moved = true
                        lastPos = pos
                        val start = arrowStart
                        if (tool == Tool.ORIGIN) {
                            vm.moveEffectOrigin(uvOf(pos))
                        } else if (tool == Tool.ARROW && start != null) {
                            val e = uvOf(pos)
                            dragArrow = Arrow(start.x, start.y, e.x, e.y)
                        } else if (drawing) {
                            vm.continueStroke(uvOf(pos))
                            cursor = pos
                        }
                    }
                    event.changes.forEach { it.consume() }
                }

                if (!transforming) {
                    when (tool) {
                        Tool.ARROW -> {
                            val a = dragArrow
                            if (a != null && hypot(a.x1 - a.x0, a.y1 - a.y0) > 0.008f) vm.addArrow(a)
                        }
                        Tool.ANCHOR -> if (!moved) vm.addAnchor(uvOf(lastPos))
                        Tool.ERASE_GUIDE -> if (!moved) {
                            eraseNearest(vm, lastPos, w, h, 28.dp.toPx())
                        }
                        Tool.FREEZE, Tool.ZONE1, Tool.ZONE2, Tool.MASK -> vm.endStroke()
                        Tool.PAN, Tool.ORIGIN -> Unit
                    }
                } else if (drawing) {
                    vm.endStroke()
                }
                dragArrow = null
                cursor = null
            }
        }
    ) {
        val w = size.width
        val h = size.height
        val s = vm.viewScale
        val vx = vm.viewX
        val vy = vm.viewY
        fun sp(x: Float, y: Float) = Offset((x - vx) * s * w, (y - vy) * s * h)

        if (vm.tab == EditorTab.EXPORT && (vm.exportSettings.framing != 0 || vm.exportSettings.res == 6)) {
            val meta = vm.meta
            if (meta != null) {
                val c = ExportPlanner.cropForSettings(meta.w, meta.h, vm.exportSettings)
                drawCropShade(sp(c[0], c[1]), sp(c[0] + c[2], c[1] + c[3]), size)
            }
        }

        if (vm.showGuides) {
            vm.activeMotionEffect?.let { id ->
                val origin = (vm.settings["$id.origin"] ?: 0f).toInt()
                if (origin == 0) {
                    val pt = sp(vm.settings["$id.originX"] ?: 0.5f, vm.settings["$id.originY"] ?: 0.5f)
                    drawCircle(Peach.copy(alpha = 0.35f), 13.dp.toPx(), pt)
                    drawCircle(Peach, 8.dp.toPx(), pt, style = Stroke(2.dp.toPx()))
                    drawLine(Peach, pt + Offset(-16.dp.toPx(), 0f), pt + Offset(16.dp.toPx(), 0f), strokeWidth = 1.dp.toPx())
                    drawLine(Peach, pt + Offset(0f, -16.dp.toPx()), pt + Offset(0f, 16.dp.toPx()), strokeWidth = 1.dp.toPx())
                }
            }
            for (a in vm.arrows) drawArrowShape(sp(a.x0, a.y0), sp(a.x1, a.y1), Color.White)
            for (p in vm.anchors) drawAnchor(sp(p.x, p.y))
        }
        dragArrow?.let { drawArrowShape(sp(it.x0, it.y0), sp(it.x1, it.y1), Peach) }
        cursor?.let {
            val r = vm.brushDp.dp.toPx()
            drawCircle(Color.Black.copy(alpha = 0.5f), r, it, style = Stroke(3.dp.toPx()))
            drawCircle(Color.White, r, it, style = Stroke(1.5.dp.toPx()))
        }
    }
}

private fun eraseNearest(vm: AppViewModel, pos: Offset, w: Float, h: Float, maxPx: Float) {
    val s = vm.viewScale
    fun sp(x: Float, y: Float) = Offset((x - vm.viewX) * s * w, (y - vm.viewY) * s * h)
    var best = maxPx
    var bestArrow = -1
    var bestAnchor = -1
    vm.anchors.forEachIndexed { i, p ->
        val d = (sp(p.x, p.y) - pos).getDistance()
        if (d < best) {
            best = d
            bestAnchor = i
            bestArrow = -1
        }
    }
    vm.arrows.forEachIndexed { i, a ->
        val d = segDist(pos, sp(a.x0, a.y0), sp(a.x1, a.y1))
        if (d < best) {
            best = d
            bestArrow = i
            bestAnchor = -1
        }
    }
    if (bestArrow >= 0) vm.removeArrowAt(bestArrow)
    else if (bestAnchor >= 0) vm.removeAnchorAt(bestAnchor)
}

private fun segDist(p: Offset, a: Offset, b: Offset): Float {
    val d = b - a
    val l2 = d.x * d.x + d.y * d.y
    var t = if (l2 > 0.0001f) ((p.x - a.x) * d.x + (p.y - a.y) * d.y) / l2 else 0f
    t = t.coerceIn(0f, 1f)
    return (a + d * t - p).getDistance()
}

private fun DrawScope.drawArrowShape(a: Offset, b: Offset, color: Color) {
    val sw = 3.dp.toPx()
    val shadow = Color.Black.copy(alpha = 0.55f)
    drawLine(shadow, a, b, strokeWidth = sw + 3.dp.toPx(), cap = StrokeCap.Round)
    drawLine(color, a, b, strokeWidth = sw, cap = StrokeCap.Round)
    val d = b - a
    val len = d.getDistance()
    if (len > 1f) {
        val ux = -d.x / len
        val uy = -d.y / len
        val hl = 14.dp.toPx()
        val c = 0.866f
        val s = 0.5f
        val l1 = Offset(ux * c - uy * s, ux * s + uy * c) * hl
        val l2 = Offset(ux * c + uy * s, -ux * s + uy * c) * hl
        drawLine(color, b, b + l1, strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(color, b, b + l2, strokeWidth = sw, cap = StrokeCap.Round)
    }
    drawCircle(shadow, 5.5.dp.toPx(), a)
    drawCircle(color, 4.dp.toPx(), a)
}

private fun DrawScope.drawAnchor(p: Offset) {
    drawCircle(Color.Black.copy(alpha = 0.55f), 9.dp.toPx(), p)
    drawCircle(Sky, 7.dp.toPx(), p)
    drawCircle(Color.White, 2.5.dp.toPx(), p)
}

private fun DrawScope.drawCropShade(tl: Offset, br: Offset, full: Size) {
    val shade = Color.Black.copy(alpha = 0.55f)
    // arriba, abajo, izquierda, derecha
    drawRect(shade, Offset(0f, 0f), Size(full.width, tl.y.coerceAtLeast(0f)))
    drawRect(shade, Offset(0f, br.y), Size(full.width, (full.height - br.y).coerceAtLeast(0f)))
    drawRect(shade, Offset(0f, tl.y), Size(tl.x.coerceAtLeast(0f), (br.y - tl.y).coerceAtLeast(0f)))
    drawRect(shade, Offset(br.x, tl.y), Size((full.width - br.x).coerceAtLeast(0f), (br.y - tl.y).coerceAtLeast(0f)))
    drawRect(Peach, tl, Size(br.x - tl.x, br.y - tl.y), style = Stroke(2.dp.toPx()))
}
