package com.zeta.fondo.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.content.ContextCompat
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.ExportState
import com.zeta.fondo.engine.CodecSupport
import com.zeta.fondo.engine.ExportPlanner
import com.zeta.fondo.export.ShareUtil
import com.zeta.fondo.model.*

@Composable
private fun PanelColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp), content = content)
}

private val editTools = listOf(
    Triple(Tool.ARROW, "Ruta", Icons.Filled.Timeline),
    Triple(Tool.ANCHOR, "Ancla", Icons.Filled.PushPin),
    Triple(Tool.FREEZE, "Congelar", Icons.Filled.AcUnit),
    Triple(Tool.ERASE_GUIDE, "Borrar", Icons.Filled.DeleteOutline),
    Triple(Tool.PAN, "Mover", Icons.Filled.PanTool),
    Triple(Tool.ORIGIN, "Origen", Icons.Filled.CenterFocusStrong)
)

@Composable
fun ToolsPanel(vm: AppViewModel) {
    PanelColumn {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Animar", color = StudioText, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f))
            Text(if (vm.playing) "Toca Ruta" else "${vm.arrows.size} rutas · ${vm.anchors.size} anclas",
                color = StudioMuted, fontSize = 12.sp)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            editTools.forEach { (tool, label, icon) ->
                StudioButton(label, icon, Modifier.width(74.dp).height(60.dp), active = vm.tool == tool) {
                    if (vm.playing) vm.togglePlay()
                    vm.tool = tool
                    vm.showGuides = true
                    if (tool == Tool.ORIGIN && vm.activeMotionEffect == null) {
                        vm.message = "Primero selecciona un efecto en Efectos."
                    }
                }
            }
        }
        if (vm.tool == Tool.FREEZE || vm.tool == Tool.ZONE1 || vm.tool == Tool.ZONE2) {
            LabeledSlider("Pincel", vm.brushDp, 6f, 140f, true, suffix = " dp") { vm.brushDp = it }
            SwitchRow("Goma", vm.eraser) { vm.eraser = it }
        } else {
            LabeledSlider("Movimiento", vm.settings["flow.amount"] ?: .35f,
                .05f, 1f, false) { vm.setSetting("flow.amount", it) }
            LabeledSlider("Velocidad", vm.settings["flow.cycles"] ?: 2f,
                1f, 8f, true) { vm.setSetting("flow.cycles", it) }
        }
        if (vm.arrows.isNotEmpty() || vm.anchors.isNotEmpty()) {
            StudioSmallButton("Borrar todas las guías", Icons.Filled.DeleteOutline,
                Modifier.fillMaxWidth()) { vm.clearGuides() }
        }
    }
}

@Composable
fun MasksPanel(vm: AppViewModel) {
    PanelColumn {
        Text("Máscaras", color = StudioText, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            vm.maskNames.forEachIndexed { i, label ->
                StudioChoice(label, vm.selectedMaskLayer == i) {
                    if (vm.playing) vm.togglePlay()
                    vm.selectMask(i)
                }
            }
            StudioSmallButton("Nueva", Icons.Filled.Add) { vm.addMask() }
        }
        val selected = vm.selectedMaskLayer
        if (selected > 0 && selected < vm.maskNames.size) {
            var name by remember(selected) { mutableStateOf(vm.maskNames[selected]) }
            OutlinedTextField(value = name, onValueChange = { name = it; vm.renameMask(selected, it) },
                label = { Text("Nombre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StudioSmallButton("Pintar", Icons.Filled.Brush, Modifier.weight(1f), selected = !vm.eraser) {
                vm.eraser = false
            }
            StudioSmallButton("Borrar", Icons.Filled.DeleteOutline, Modifier.weight(1f), selected = vm.eraser) {
                vm.eraser = true
            }
        }
        LabeledSlider("Pincel", vm.brushDp, 6f, 140f, true, suffix = " dp") { vm.brushDp = it }
        LabeledSlider("Suavizado", vm.feather, 0f, 1f, false) { vm.feather = it }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StudioSmallButton("Rellenar", Icons.Filled.Check, Modifier.weight(1f)) { vm.fillLayer(false) }
            StudioSmallButton("Vaciar", Icons.Filled.Clear, Modifier.weight(1f)) { vm.fillLayer(true) }
        }
        SwitchRow("Ver máscara", vm.showMasks) { vm.toggleMasks() }
    }
}

@Composable
fun CameraPanel(vm: AppViewModel) {
    val def = Effects.all.first { it.id == "cam" }
    PanelColumn {
        Text("Cámara", color = StudioText, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        SwitchRow("Activar", (vm.settings["cam.on"] ?: 0f) > .5f) {
            vm.setSetting("cam.on", if (it) 1f else 0f)
        }
        def.params.forEach { EffectParameter(vm, def, it) }
    }
}

@Composable
fun PresetsPanel(vm: AppViewModel) {
    PanelColumn {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Presets", color = StudioText, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f))
            Text("${Presets.all.size}", color = StudioMuted, fontSize = 13.sp)
        }
        Presets.all.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                row.forEach { p ->
                    Column(Modifier.weight(1f).height(72.dp).clip(RoundedCornerShape(12.dp))
                        .background(StudioTile).clickable { vm.applyPreset(p) }
                        .padding(horizontal = 6.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center) {
                        Icon(if (p.manga) Icons.Filled.MenuBook else Icons.Filled.AutoAwesome,
                            null, tint = StudioPurple, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.height(5.dp))
                        Text(p.name, color = StudioText, fontSize = 10.sp,
                            fontWeight = FontWeight.Medium, maxLines = 2,
                            overflow = TextOverflow.Ellipsis)
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        StudioSmallButton("Quitar efectos", Icons.Filled.Clear, Modifier.fillMaxWidth()) { vm.clearEffects() }
    }
}

private val effectCategory = mapOf(
    "Anime" to setOf("flow", "sway", "sakura", "rays", "energy", "snow", "fog", "leaves", "flies", "runes", "pulse", "comet"),
    "Batalla" to setOf("energy", "electric", "shock", "flash", "focus", "speed", "embers", "ash", "heat", "shards", "pulse", "comet", "runes", "smoke"),
    "Ambiente" to setOf("rain", "snow", "sakura", "stars", "flies", "fog", "ash", "leaves", "embers", "dust", "bubbles", "rays", "glint", "smoke", "shards", "comet"),
    "Cielo" to setOf("drift", "rays", "stars", "rain", "snow", "sakura", "fog", "glint", "comet"),
    "Manga" to setOf("focus", "speed", "tone", "grain", "ink", "flash", "style", "hatch"),
    "Cámara" to setOf("cam"),
    "Todos" to Effects.all.map { it.id }.toSet()
)
private fun effectIcon(id: String): ImageVector = when (id) {
    "flow" -> Icons.Filled.Timeline
    "drift" -> Icons.Filled.CloudQueue
    "speed" -> Icons.Filled.Speed
    "rain" -> Icons.Filled.Grain
    "ripple" -> Icons.Filled.Waves
    "bubbles" -> Icons.Filled.BubbleChart
    "snow" -> Icons.Filled.AcUnit
    "sakura" -> Icons.Filled.LocalFlorist
    "leaves" -> Icons.Filled.Eco
    "stars" -> Icons.Filled.Star
    "flies", "glint" -> Icons.Filled.Flare
    "fog" -> Icons.Filled.Cloud
    "smoke", "ash" -> Icons.Filled.BlurOn
    "rays" -> Icons.Filled.LightMode
    "flash" -> Icons.Filled.FlashOn
    "energy" -> Icons.Filled.AutoAwesome
    "electric" -> Icons.Filled.Bolt
    "shock" -> Icons.Filled.ElectricBolt
    "pulse" -> Icons.Filled.RadioButtonChecked
    "cam" -> Icons.Filled.Videocam
    "focus" -> Icons.Filled.CenterFocusStrong
    "runes" -> Icons.Filled.FilterTiltShift
    "tone" -> Icons.Filled.Contrast
    "grain" -> Icons.Filled.Grain
    "ink" -> Icons.Filled.Brush
    "hatch" -> Icons.Filled.Dehaze
    "heat" -> Icons.Filled.LocalFireDepartment
    "embers" -> Icons.Filled.Whatshot
    "comet" -> Icons.Filled.RocketLaunch
    "shards" -> Icons.Filled.Diamond
    "dust" -> Icons.Filled.ScatterPlot
    "style" -> Icons.Filled.Palette
    "sway" -> Icons.Filled.Park
    else -> Icons.Filled.AutoAwesome
}
private val duplicateIds = setOf("ash", "leaves", "embers", "dust", "bubbles", "electric",
    "focus", "shock", "flash", "tone", "grain", "ink")
private val directionalIds = setOf("rain", "snow", "sakura", "fog", "rays", "energy", "speed", "ash",
    "leaves", "embers", "dust", "bubbles", "electric", "focus", "shock", "comet", "runes",
    "pulse", "smoke", "shards")

@Composable
fun EffectsPanel(vm: AppViewModel, initialCategory: String = "Anime") {
    var category by remember(initialCategory) { mutableStateOf(initialCategory) }
    var selected by remember { mutableStateOf<String?>(null) }
    var advanced by remember(selected) { mutableStateOf(false) }
    val s = vm.settings
    val def = Effects.all.firstOrNull { it.id == selected }
    if (def == null) {
        EffectGrid(vm = vm, category = category,
            onCategory = { category = it; vm.effectsCategory = it },
            onSelect = { id -> selected = id; vm.activeMotionEffect = id })
        return
    }
    PanelColumn {
        StudioSmallButton("Todos los efectos", Icons.Filled.ArrowBack,
            Modifier.fillMaxWidth()) { selected = null; vm.activeMotionEffect = null }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(effectIcon(def.id), null, tint = StudioPurple, modifier = Modifier.size(25.dp))
            Spacer(Modifier.width(8.dp))
            Text(def.title, color = StudioText, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        if (def.toggleable) SwitchRow("Activado", (s["${def.id}.on"] ?: if (def.defaultOn) 1f else 0f) > .5f) {
            vm.setSetting("${def.id}.on", if (it) 1f else 0f)
        }
        val active = !def.toggleable || (s["${def.id}.on"] ?: if (def.defaultOn) 1f else 0f) > .5f
        if (active) {
                when (def.id) {
                    "drift", "ripple", "glint" -> Text("Pinta la Zona 1 en Máscaras", color = StudioMuted, fontSize = 12.sp)
                    "sway", "heat" -> Text("Pinta la Zona 2 en Máscaras", color = StudioMuted, fontSize = 12.sp)
                }
                def.params.filter { it.key != "zone" }.take(if (advanced) Int.MAX_VALUE else 3)
                    .forEach { EffectParameter(vm, def, it) }
                if (def.id in directionalIds) {
                    val origin = (s["${def.id}.origin"] ?: 0f).toInt()
                    Text("Origen", color = StudioText, fontWeight = FontWeight.SemiBold)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Centro", "Arriba", "Abajo", "Izquierda", "Derecha", "↖", "↗", "↙", "↘")
                            .forEachIndexed { i, label ->
                                StudioChoice(label, origin == i) { vm.setMotionOrigin(def.id, i) }
                            }
                    }
                    StudioSmallButton("Marcar origen", Icons.Filled.CenterFocusStrong,
                        Modifier.fillMaxWidth()) {
                        vm.activeMotionEffect = def.id
                        vm.setMotionOrigin(def.id, 0)
                        vm.tool = Tool.ORIGIN
                        vm.showGuides = true
                        if (vm.playing) vm.togglePlay()
                        vm.message = "Toca el punto de origen sobre la imagen; contrae el panel."
                    }
                    if (advanced) MotionDirection(vm, def.id)
                }
                StudioSmallButton(if (advanced) "Menos ajustes" else "Más ajustes", Icons.Filled.Tune,
                    Modifier.fillMaxWidth()) { advanced = !advanced }
                if (advanced) {
                    Text("Máscara", color = StudioText, fontWeight = FontWeight.SemiBold)
                    val layer = (s["${def.id}.mask"] ?: -1f).toInt()
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StudioChoice("Toda", layer == -1) { vm.setEffectMask(def.id, -1) }
                        vm.maskNames.forEachIndexed { i, title ->
                            StudioChoice(title, layer == i) { vm.setEffectMask(def.id, i) }
                        }
                    }
                    if (def.id in duplicateIds) {
                        val copyId = "${def.id}.copy"
                        val on = (s["$copyId.on"] ?: 0f) > .5f
                        SwitchRow("Capa B independiente", on) {
                            vm.setSetting("$copyId.on", if (it) 1f else 0f)
                        }
                        if (on) {
                            def.params.filter { it.key != "zone" }.forEach { param ->
                                val key = "$copyId.${param.key}"
                                val value = s[key] ?: (s["${def.id}.${param.key}"] ?: param.def)
                                if (param.kind == Kind.TOGGLE) SwitchRow(param.label, value > .5f) {
                                    vm.setSetting(key, if (it) 1f else 0f)
                                } else LabeledSlider(param.label, value, param.min, param.max,
                                    param.kind == Kind.INT) { vm.setSetting(key, it) }
                            }
                            if (def.id in directionalIds) {
                                LabeledSlider("Dirección B", s["$copyId.direction"] ?: 0f,
                                    0f, 360f, true, suffix = "°") { vm.setSetting("$copyId.direction", it) }
                                LabeledSlider("Posición X B", s["$copyId.originX"] ?: .5f,
                                    0f, 1f, false) { vm.setSetting("$copyId.originX", it) }
                                LabeledSlider("Posición Y B", s["$copyId.originY"] ?: .5f,
                                    0f, 1f, false) { vm.setSetting("$copyId.originY", it) }
                            }
                            val copyMask = (s["$copyId.mask"] ?: -1f).toInt()
                            Row(Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                StudioChoice("Toda", copyMask == -1) { vm.setSetting("$copyId.mask", -1f) }
                                vm.maskNames.forEachIndexed { i, title ->
                                    StudioChoice(title, copyMask == i) { vm.setSetting("$copyId.mask", i.toFloat()) }
                                }
                            }
                        }
                    }
                }
        }
    }
}

@Composable
private fun EffectGrid(
    vm: AppViewModel,
    category: String,
    onCategory: (String) -> Unit,
    onSelect: (String) -> Unit
) {
    val ids = effectCategory[category] ?: emptySet()
    val ordered = remember(category) {
        Effects.all.filter { it.id in ids }.sortedBy {
            listOf("pulse", "energy", "rain", "fog", "drift", "focus", "embers", "cam")
                .indexOf(it.id).let { rank -> if (rank < 0) 100 else rank }
        }
    }
    Column(Modifier.fillMaxSize().padding(top = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                effectCategory.keys.forEach { name ->
                    StudioChoice(name, name == category,
                        modifier = Modifier.height(40.dp)) { onCategory(name) }
                }
            }
            Spacer(Modifier.width(6.dp))
            Icon(Icons.Filled.AutoDelete, "Quitar todos los efectos", tint = StudioText,
                modifier = Modifier.size(40.dp).clip(RoundedCornerShape(11.dp))
                    .background(StudioTile).clickable { vm.clearEffects() }.padding(9.dp))
        }
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.fillMaxWidth().weight(1f),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(start = 8.dp, end = 8.dp, bottom = 10.dp)
        ) {
            items(ordered, key = { it.id }) { effect ->
                val enabled = (vm.settings["${effect.id}.on"]
                    ?: if (effect.defaultOn) 1f else 0f) > .5f
                Column(Modifier.fillMaxWidth().height(72.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(if (enabled) StudioPurple.copy(alpha = .18f) else StudioTile)
                    .clickable { onSelect(effect.id) }
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center) {
                    Box(Modifier.fillMaxWidth().height(27.dp), contentAlignment = Alignment.Center) {
                        Icon(effectIcon(effect.id), effect.title,
                            tint = if (enabled) StudioPurple else StudioText,
                            modifier = Modifier.size(25.dp))
                        if (enabled) Icon(Icons.Filled.Check, "Activo", tint = StudioText,
                            modifier = Modifier.align(Alignment.TopEnd).size(16.dp)
                                .clip(RoundedCornerShape(50)).background(StudioPurple).padding(2.dp))
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(effect.title, color = StudioText, fontSize = 9.sp,
                        fontWeight = FontWeight.Medium, maxLines = 2,
                        overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun MotionDirection(vm: AppViewModel, id: String) {
    LabeledSlider("Dirección", vm.settings["$id.direction"] ?: 0f,
        0f, 360f, true, suffix = "°") { vm.setSetting("$id.direction", it) }
    LabeledSlider("Origen X", vm.settings["$id.originX"] ?: .5f,
        0f, 1f, false) { vm.setSetting("$id.originX", it) }
    LabeledSlider("Origen Y", vm.settings["$id.originY"] ?: .5f,
        0f, 1f, false) { vm.setSetting("$id.originY", it) }
}

@Composable
private fun EffectParameter(vm: AppViewModel, effect: EffectDef, p: ParamDef) {
    val key = "${effect.id}.${p.key}"
    val value = vm.settings[key] ?: p.def
    if (p.kind == Kind.TOGGLE) SwitchRow(p.label, value > .5f) {
        vm.setSetting(key, if (it) 1f else 0f)
    } else LabeledSlider(p.label, value, p.min, p.max, p.kind == Kind.INT) {
        vm.setSetting(key, it)
    }
}

@Composable
fun ExportPanel(vm: AppViewModel) {
    val ctx = LocalContext.current
    val e = vm.exportSettings
    val meta = vm.meta ?: return
    val state = vm.exportState
    val running = state is ExportState.Running
    var advanced by remember { mutableStateOf(false) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startExport() else vm.message = "No hay permiso para guardar en la Galería."
    }
    fun doExport() {
        if (Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            permission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else vm.startExport()
    }
    PanelColumn {
        Text("Exportar", color = StudioText, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        when (state) {
            is ExportState.Running -> {
                Text("${(state.progress * 100).toInt()}%", color = StudioPurple,
                    fontSize = 22.sp, fontWeight = FontWeight.Bold)
                ProgressBar(state.progress)
                StudioSmallButton("Cancelar", Icons.Filled.Close, Modifier.fillMaxWidth()) { vm.cancelExport() }
            }
            is ExportState.Done -> {
                val r = state.result
                Text("Guardado · ${r.width}×${r.height}", color = StudioText, fontWeight = FontWeight.Bold)
                r.reducedFrom?.let {
                    Text("El teléfono redujo la salida desde $it", color = StudioMuted, fontSize = 13.sp)
                }
                if (!r.isPng && r.file != null) {
                    StudioSmallButton("Compartir vídeo", Icons.Filled.Share, Modifier.fillMaxWidth()) {
                        ShareUtil.shareChooser(ctx, r.file)
                    }
                    StudioSmallButton("Alight Motion", Icons.Filled.Movie, Modifier.fillMaxWidth()) {
                        if (!ShareUtil.sendToAlight(ctx, r.file)) vm.message = "Importa el vídeo desde la Galería."
                    }
                }
                StudioSmallButton("Otra exportación", Icons.Filled.Refresh, Modifier.fillMaxWidth()) {
                    vm.dismissExportResult()
                }
            }
            is ExportState.Failed -> {
                Text("Error: ${state.message}", color = Danger)
                StudioSmallButton("Reintentar", Icons.Filled.Refresh, Modifier.fillMaxWidth()) {
                    vm.dismissExportResult()
                }
            }
            ExportState.Idle -> Unit
        }
        if (!running && state !is ExportState.Done) {
            Text("Resolución", color = StudioText, fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("1080p" to 3, "2K" to 2, "4K" to 1).forEach { (label, index) ->
                    StudioChoice(label, e.res == index, Modifier.weight(1f)) {
                        vm.updateExport(e.copy(res = index))
                    }
                }
            }
            Text("Formato", color = StudioText, fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("MP4", "PNG sec.").forEachIndexed { index, label ->
                    StudioChoice(label, e.format == index, Modifier.weight(1f)) {
                        vm.updateExport(e.copy(format = index))
                    }
                }
            }
            Text("FPS", color = StudioText, fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf(24, 30, 60).forEach { fps ->
                    StudioChoice("$fps", e.fps == fps, Modifier.weight(1f)) {
                        vm.updateExport(e.copy(fps = fps))
                    }
                }
            }
            StudioSmallButton(if (advanced) "Menos ajustes" else "Más ajustes", Icons.Filled.Tune,
                Modifier.fillMaxWidth()) { advanced = !advanced }
            if (advanced) {
                Text("Otros tamaños", color = StudioText)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Original" to 0, "720p" to 4, "QHD" to 5, "Personalizada" to 6).forEach { (name, index) ->
                        StudioChoice(name, e.res == index) { vm.updateExport(e.copy(res = index)) }
                    }
                }
                if (e.res == 6) {
                    LabeledSlider("Ancho", e.customW.toFloat(), 128f, 7680f, true, suffix = "px") {
                        vm.updateExport(e.copy(customW = it.toInt()))
                    }
                    LabeledSlider("Alto", e.customH.toFloat(), 128f, 7680f, true, suffix = "px") {
                        vm.updateExport(e.copy(customH = it.toInt()))
                    }
                }
                Text("Encuadre", color = StudioText)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ExportPlanner.framingLabels.forEachIndexed { i, name ->
                        StudioChoice(name, e.framing == i) { vm.updateExport(e.copy(framing = i)) }
                    }
                }
                if (e.framing != 0 || e.res == 6) {
                    LabeledSlider("Recorte", e.cropPos, 0f, 1f, false) {
                        vm.updateExport(e.copy(cropPos = it))
                    }
                }
                LabeledSlider("Duración", e.loopSec.toFloat(), 2f, 15f, true, suffix = "s") {
                    vm.updateExport(e.copy(loopSec = it.toInt()))
                }
                if (e.format == 0) {
                    LabeledSlider("Repeticiones", e.repeats.toFloat(), 1f, 10f, true) {
                        vm.updateExport(e.copy(repeats = it.toInt()))
                    }
                    Text("Codificador", color = StudioText)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CodecSupport.names.forEachIndexed { i, name ->
                            if (CodecSupport.usable(i)) StudioChoice(name, e.codec == i) {
                                vm.updateExport(e.copy(codec = i))
                            }
                        }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ExportPlanner.qualityLabels.forEachIndexed { i, name ->
                            StudioChoice(name, e.quality == i) { vm.updateExport(e.copy(quality = i)) }
                        }
                    }
                }
                SwitchRow("Solo efectos", e.overlayOnly) { vm.updateExport(e.copy(overlayOnly = it)) }
            }
            val (w, h) = ExportPlanner.targetSize(meta.w, meta.h, e)
            Text("${w}×${h} · ${e.loopSec}s", color = StudioMuted, fontSize = 13.sp)
            StudioPrimary("Exportar", Icons.Filled.FileUpload, Modifier.fillMaxWidth()) { doExport() }
        }
    }
}
