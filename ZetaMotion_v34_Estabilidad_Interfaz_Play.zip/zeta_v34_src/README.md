> **Versión de trabajo actual: v34.** Consulta [README_V34.md](README_V34.md). El historial de versiones antiguas es histórico y su información sobre la firma incrustada ya no aplica a v34.

> **Versión 33 disponible:** ver [README_V33.md](README_V33.md) (mejoras reales de variantes, iconos y cámara 3D simulada).

# Zeta Motion

Código fuente Android de **Zeta Motion v32**, para animar fondos e ilustraciones de anime, manga y manhwa.

Consulta `README_V32.md` para conocer los cambios **implementados**, su alcance real y las pruebas pendientes. Se conserva el historial desde `README_V3.md`.
