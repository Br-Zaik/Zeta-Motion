# Zeta Motion v29

Editor Android especializado en animar fondos anime, manga y manhwa.

Novedad principal: duplicados alineados en la pista inferior, guías magnéticas y una timeline más limpia con un solo cabezal de reproducción.
