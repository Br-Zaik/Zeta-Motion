# Zeta Motion v29 — Duplicado alineado + timeline limpia

Cambios de esta versión:

- **Duplicar exactamente debajo**: la copia conserva inicio, final y todos los ajustes del efecto, y aparece en la primera pista libre inmediatamente inferior. Queda alineada verticalmente con el original.
- **Guías magnéticas** al mover bloques: inicio/final se pegan suavemente a los bordes de otros bloques cuando están cerca y aparece una línea vertical rosa como referencia.
- **Nombres simples en la timeline**: se muestra solo el nombre del efecto (`Viento`, `Profundidad`, `Natural`, `Olas`, etc.), nunca la configuración o sufijos como `2.5D`.
- **Una sola referencia de tiempo cuando hay timeline**: desaparece el slider/círculo morado inferior y el cabezal blanco pasa a ser la referencia. Si todavía no existe timeline, se conserva un scrub mínimo para no perder la posibilidad de buscar en el vídeo.
- **Cabezal interactivo**: puedes tocar una zona libre de la timeline para saltar a ese tiempo y arrastrar directamente la línea blanca para avanzar/retroceder.
- Play/Pausa, duración, Deshacer y Rehacer permanecen abajo sin duplicar el control de tiempo.
- Se mantienen todos los cambios de v28: duplicado con configuración, exportación unificada y zoom optimizado.
- `versionCode 29` / `versionName 29.0.0`.
