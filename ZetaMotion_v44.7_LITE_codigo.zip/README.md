> **Versión actual: v44.7-FINAL-fases0-7 — lee LEEME_V44.md** (cambios, compilación y pruebas).

> **Edición Lite:** solo el código y lo que la app necesita para compilar y funcionar. Sin docs/, tools/ ni checks/ (capturas, comparativas y banco de pruebas): esos están en el ZIP completo v44.7. Las referencias a docs/ del LEEME apuntan a ese ZIP.

# Zeta Motion v35.1 — APK firmado

Antes de instalar lee [LEEME_INSTALACION_ESTABLE.md](LEEME_INSTALACION_ESTABLE.md).

El código conserva los efectos y herramientas de v35.
