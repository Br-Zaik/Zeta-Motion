package com.zeta.fondo.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.model.Keyframes

/**
 * v44 · Rombo de fotograma clave junto a un control.
 * - Vacío: el control no está animado. Tocar = primera clave en el cabezal.
 * - Relleno rosa: hay una clave justo en el cabezal (tocar = quitarla).
 * - Contorno rosa: está animado pero el cabezal está entre claves (tocar = añadir clave aquí).
 * - Mantener pulsado: curva de la clave y borrar la animación.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun KeyDiamond(vm: AppViewModel, key: String) {
    var menu by remember { mutableStateOf(false) }
    @Suppress("UNUSED_VARIABLE") val tick = vm.scrubT   // se redibuja al mover el cabezal
    val animated = vm.keysOf(key).isNotEmpty()
    val onKey = vm.keyAtPlayhead(key) != null
    Box(Modifier.size(40.dp).clip(RoundedCornerShape(20.dp))
        .combinedClickable(onLongClick = { if (animated) menu = true }) { vm.toggleKeyframe(key) },
        contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(18.dp)) {
            val w = size.width; val h = size.height
            val path = Path().apply {
                moveTo(w / 2f, 0f); lineTo(w, h / 2f); lineTo(w / 2f, h); lineTo(0f, h / 2f); close()
            }
            when {
                onKey -> drawPath(path, StudioPink)
                animated -> drawPath(path, StudioPink, style = Stroke(2.dp.toPx()))
                else -> drawPath(path, StudioMuted, style = Stroke(1.5.dp.toPx()))
            }
        }
    }
    if (menu) KeyframeDialog(vm, key) { menu = false }
}

@Composable
private fun KeyframeDialog(vm: AppViewModel, key: String, onDismiss: () -> Unit) {
    val k = vm.keyAtPlayhead(key)
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(StudioPanel).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Fotograma clave", color = StudioText, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            if (k == null) Text("El cabezal no está sobre una clave de este control. Muévelo hasta un rombo de la línea de tiempo para cambiar su curva.",
                color = StudioMuted, fontSize = 12.sp)
            else {
                Text("Cómo se llega desde esta clave a la siguiente:", color = StudioMuted, fontSize = 12.sp)
                Keyframes.curveNames.forEachIndexed { i, name ->
                    SmallChoice(name, k.curve == i) { vm.setKeyCurve(key, i) }
                }
            }
            Box(Modifier.fillMaxWidth().height(42.dp).clip(RoundedCornerShape(11.dp)).background(StudioTile)
                .clickable { vm.clearKeyframes(key); onDismiss() }, contentAlignment = Alignment.Center) {
                Text("Borrar la animación de este control", color = Danger, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Box(Modifier.fillMaxWidth().height(42.dp).clip(RoundedCornerShape(11.dp)).background(StudioTile)
                .clickable(onClick = onDismiss), contentAlignment = Alignment.Center) {
                Text("Listo", color = StudioText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
