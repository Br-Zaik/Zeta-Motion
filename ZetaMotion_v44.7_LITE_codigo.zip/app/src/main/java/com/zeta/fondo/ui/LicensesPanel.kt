package com.zeta.fondo.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import org.json.JSONObject

/** v44 · Ajustes › Licencias: sonidos y modelos incluidos, leídos de sus manifiestos en assets. */
@Composable
fun LicensesPanel(vm: AppViewModel) {
    val ctx = LocalContext.current
    val sounds = remember { readJson(ctx, "sounds/LICENSES.json") }
    val models = remember { readJson(ctx, "models/LICENSES.json") }
    val present = remember { try { ctx.assets.list("models")?.toSet() ?: emptySet() } catch (_: Exception) { emptySet<String>() } }
    Column(Modifier.fillMaxSize()) {
        CapHeader("Licencias") { vm.applyAndClose() }
        PanelScroll {
            Text("Modelos de IA", color = StudioText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            val ms = models?.optJSONArray("modelos")
            if (ms == null || ms.length() == 0) Text("Ningún modelo incluido.", color = StudioMuted, fontSize = 12.sp)
            else for (i in 0 until ms.length()) {
                val m = ms.getJSONObject(i)
                val inApk = m.optString("archivo") in present
                Entry(m.optString("nombre"), "${m.optString("licencia")} · ${m.optString("autor")}",
                    (if (inApk) "Incluido en este APK" else "NO incluido en este APK (se usa el 2.5D manual)") +
                        "\nOrigen: ${m.optString("url")}\nSHA-256: ${m.optString("sha256")}" +
                        (m.optString("nota").takeIf { it.isNotBlank() }?.let { "\n$it" } ?: ""))
            }
            val opt = models?.optJSONArray("opcionales")
            if (opt != null) for (i in 0 until opt.length()) {
                val o = opt.getJSONObject(i)
                Entry(o.optString("nombre"), "${o.optString("licencia")} · ${o.optString("autor")}",
                    "Origen: ${o.optString("url")}\n${o.optString("nota")}")
            }
            // v46: las copias internas de los modelos (ONNX Runtime necesita un archivo) se pueden borrar.
            var copies by remember { mutableStateOf(com.zeta.fondo.engine.OnnxAssets.copiesBytes(ctx)) }
            if (copies > 0) SmallChoice("Liberar ${copies / (1024 * 1024)} MB (copias de los modelos; se recrean al usarlos)", false) {
                com.zeta.fondo.engine.OnnxAssets.clearCopies(ctx); copies = com.zeta.fondo.engine.OnnxAssets.copiesBytes(ctx)
            }
            val libs = models?.optJSONArray("bibliotecas")
            if (libs != null) for (i in 0 until libs.length()) {
                val l = libs.getJSONObject(i)
                Entry(l.optString("nombre"), l.optString("licencia"), l.optString("url"))
            }
            Text("Sonidos", color = StudioText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
            val rec = sounds?.optJSONArray("grabaciones")
            if (rec == null || rec.length() == 0) Text("Grabaciones de terceros incluidas: ninguna.", color = StudioMuted, fontSize = 12.sp)
            else for (i in 0 until rec.length()) {
                val r = rec.getJSONObject(i)
                Entry(r.optString("nombre"), "${r.optString("licencia")} · ${r.optString("autor")}",
                    "Archivo: ${r.optString("archivo")}\nOrigen: ${r.optString("url")}\nSHA-256: ${r.optString("sha256")}\n${r.optString("atribucion")}")
            }
            val syn = sounds?.optJSONArray("sintetizados")
            if (syn != null) Text("${syn.length()} sonidos sintetizados por el código de la app (sin derechos de terceros).",
                color = StudioMuted, fontSize = 12.sp)
            sounds?.optString("motivo_pendientes")?.takeIf { it.isNotBlank() }?.let {
                Text(it, color = StudioMuted, fontSize = 11.sp)
            }
            Text("Tus grabaciones importadas solo se guardan en tu proyecto.", color = StudioMuted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun Entry(title: String, subtitle: String, detail: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(title, color = StudioText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(subtitle, color = StudioMuted, fontSize = 12.sp)
        Text(detail, color = StudioMuted, fontSize = 10.sp, lineHeight = 13.sp)
    }
}

private fun readJson(ctx: android.content.Context, path: String): JSONObject? = try {
    ctx.assets.open(path).bufferedReader().use { JSONObject(it.readText()) }
} catch (_: Exception) { null }
