package com.zeta.fondo.model

/**
 * v44 · Valores con los que un efecto NACE la primera vez que se activa en un proyecto.
 * Solo se aplican si el proyecto no tiene ya esa clave: los proyectos v43 no cambian.
 * Código puro (pruebas JVM).
 */
object EffectDefaults {
    /** Van detrás del personaje si se pintó Proteger (sin Proteger no cambia nada). */
    val behindByDefault = setOf("fog", "clouds3", "aurora", "stars", "birds", "blast", "cloudshadow")

    fun firstActivation(id: String, s: Map<String, Float>): Map<String, Float> = buildMap {
        if (id in behindByDefault && !s.containsKey("$id.behind")) put("$id.behind", 1f)
        // La explosión ya no nace en el centro (sobre la cara): abajo a la derecha.
        if (id == "blast" && !s.containsKey("blast.originX")) { put("blast.originX", .74f); put("blast.originY", .70f) }
        // Efectos nuevos que nacen en un punto concreto (pájaros en el cielo, destello arriba…).
        Wind.defaultOrigin[id]?.let { (x, y) ->
            if (!s.containsKey("$id.originX")) { put("$id.originX", x); put("$id.originY", y) }
        }
    }
}
