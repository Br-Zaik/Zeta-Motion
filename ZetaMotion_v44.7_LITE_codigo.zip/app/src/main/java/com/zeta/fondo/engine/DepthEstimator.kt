package com.zeta.fondo.engine

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.zeta.fondo.diag.ZetaLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.FloatBuffer
import kotlin.coroutines.coroutineContext

/**
 * v45 · Profundidad IA para el 2.5D, en el propio teléfono (sin internet).
 *
 * - Se calcula UNA vez por imagen y se guarda en la carpeta del proyecto (depth.png + depth.txt).
 *   La animación solo lee esa textura: la IA nunca corre por fotograma.
 * - Modelo principal Depth Anything V2 Small (Apache-2.0); si falta o falla (memoria, archivo
 *   dañado), MiDaS v2.1 small (MIT). Un solo modelo cargado a la vez; la sesión se cierra al terminar.
 * - Si no hay ningún modelo en el APK, [available] devuelve vacío y la app usa el 2.5D manual.
 */
class DepthEstimator(private val ctx: Context) {

    data class Model(val id: String, val asset: String, val label: String)
    data class Result(val w: Int, val h: Int, val map: ByteArray, val meta: DepthMath.Meta)

    /** Modelos presentes en este APK, en orden de preferencia. */
    fun available(): List<Model> {
        val files = OnnxAssets.bundled(ctx)
        return MODELS.filter { it.asset in files }
    }

    /** Mapa en caché del proyecto si corresponde a la misma imagen; null si no hay o es de otra imagen. */
    fun loadCached(projectDir: File, imageFile: File): Result? = try {
        val metaFile = File(projectDir, META)
        val png = File(projectDir, PNG)
        val meta = if (metaFile.isFile && png.isFile) DepthMath.Meta.decode(metaFile.readText()) else null
        if (meta == null) null else {
            val argb = inputPixels(imageFile, meta.model)
            if (DepthMath.stamp(argb.first, argb.second, argb.third) != meta.stamp) null
            else {
                val bmp = BitmapFactory.decodeFile(png.path) ?: throw IllegalStateException("depth.png ilegible")
                val px = IntArray(bmp.width * bmp.height)
                bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
                bmp.recycle()
                Result(meta.w, meta.h, ByteArray(px.size) { (px[it] shr 16).toByte() }, meta)
            }
        }
    } catch (e: Throwable) {
        ZetaLog.warn("depth", "caché no válida: ${e.message}")
        null
    }

    /**
     * Calcula el mapa (en un hilo de fondo; cancelable entre etapas). Prueba los modelos en
     * orden y devuelve el primero que funciona. Lanza la última excepción si ninguno sirve.
     */
    suspend fun estimate(projectDir: File, imageFile: File, onStage: (String) -> Unit = {}): Result =
        withContext(Dispatchers.Default) {
            val models = available()
            if (models.isEmpty()) throw IllegalStateException("Este APK no incluye modelos de profundidad")
            var last: Throwable? = null
            for (m in models) {
                coroutineContext.ensureActive()
                try {
                    onStage("Preparando ${m.label}…")
                    val r = run(m, projectDir, imageFile, onStage)
                    save(projectDir, r)
                    return@withContext r
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    // OutOfMemoryError incluido: se intenta el modelo más ligero.
                    last = e
                    ZetaLog.warn("depth", "${m.id} falló: ${e.javaClass.simpleName} ${e.message}")
                    System.gc()
                }
            }
            throw last ?: IllegalStateException("Sin modelo")
        }

    private suspend fun run(m: Model, projectDir: File, imageFile: File, onStage: (String) -> Unit): Result {
        val modelFile = ensureModelFile(m)
        coroutineContext.ensureActive()
        val (argb, w, h) = inputPixels(imageFile, m.id)
        val stamp = DepthMath.stamp(argb, w, h)
        val chw = DepthMath.toChw(argb, w, h)
        val t0 = System.nanoTime()
        onStage("Calculando profundidad (${m.label})…")
        val env = OrtEnvironment.getEnvironment()
        var raw = FloatArray(0)
        var ow = 0
        var oh = 0
        OrtSession.SessionOptions().use { opt ->
            opt.setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(1, 4))
            opt.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            env.createSession(modelFile.path, opt).use { session ->
                val input = session.inputNames.first()
                OnnxTensor.createTensor(env, FloatBuffer.wrap(chw), longArrayOf(1, 3, h.toLong(), w.toLong())).use { tensor ->
                    session.run(mapOf(input to tensor)).use { out ->
                        val t = out[0] as OnnxTensor
                        val shape = t.info.shape
                        oh = shape[shape.size - 2].toInt()
                        ow = shape[shape.size - 1].toInt()
                        val fb = t.floatBuffer
                        raw = FloatArray(fb.remaining())
                        fb.get(raw)
                    }
                }
            }
        }
        coroutineContext.ensureActive()
        if (raw.size != ow * oh) throw IllegalStateException("Salida inesperada ${raw.size} ≠ ${ow}x$oh")
        var map = DepthMath.normalize(raw)
        // MiDaS trabaja en un cuadrado 256x256: se devuelve a la proporción de la imagen.
        val outW: Int; val outH: Int
        if (ow != w || oh != h) {
            val sz = DepthMath.inputSize(w, h, maxOf(ow, oh), 1)
            outW = sz[0]; outH = sz[1]
            map = DepthMath.resize(map, ow, oh, outW, outH)
        } else { outW = ow; outH = oh }
        val ms = (System.nanoTime() - t0) / 1_000_000
        ZetaLog.info("depth", "${m.id} ${w}x$h → ${outW}x$outH en $ms ms")
        val meta = DepthMath.Meta(m.id, outW, outH, stamp, ms, DepthMath.contrast(map))
        return Result(outW, outH, map, meta)
    }

    private fun ensureModelFile(m: Model): File = OnnxAssets.file(ctx, m.asset)

    /** Píxeles de entrada del modelo, decodificados de la imagen original a su tamaño exacto. */
    private fun inputPixels(imageFile: File, modelId: String): Triple<IntArray, Int, Int> {
        val (iw, ih) = BitmapUtil.bounds(imageFile)
        val size = if (modelId == MIDAS) intArrayOf(DepthMath.MIDAS_SIZE, DepthMath.MIDAS_SIZE) else DepthMath.inputSize(iw, ih)
        val src = BitmapUtil.decodeAtMost(imageFile, maxOf(size[0], size[1]) * 2)
        val scaled = Bitmap.createScaledBitmap(src, size[0], size[1], true)
        if (scaled !== src) src.recycle()
        val px = IntArray(size[0] * size[1])
        scaled.getPixels(px, 0, size[0], 0, 0, size[0], size[1])
        scaled.recycle()
        return Triple(px, size[0], size[1])
    }

    private fun save(projectDir: File, r: Result) {
        val px = IntArray(r.map.size) { val v = r.map[it].toInt() and 0xFF; (0xFF shl 24) or (v shl 16) or (v shl 8) or v }
        val bmp = Bitmap.createBitmap(px, r.w, r.h, Bitmap.Config.ARGB_8888)
        val tmp = File(projectDir, "$PNG.tmp")
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        tmp.renameTo(File(projectDir, PNG))
        File(projectDir, META).writeText(r.meta.encode())
    }

    companion object {
        const val DAV2 = "depth_anything_v2_small"
        const val MIDAS = "midas_v21_small"
        const val PNG = "depth.png"
        const val META = "depth.txt"
        val MODELS = listOf(
            Model(DAV2, "depth_anything_v2_vits.onnx", "Depth Anything V2 Small"),
            Model(MIDAS, "midas_v21_small_256.onnx", "MiDaS v2.1 small")
        )
        fun labelOf(id: String) = MODELS.firstOrNull { it.id == id }?.label ?: id

        /** Borra el mapa guardado (p. ej. al reemplazar la imagen del proyecto). */
        fun clear(projectDir: File) {
            File(projectDir, PNG).delete(); File(projectDir, META).delete()
        }
    }
}
