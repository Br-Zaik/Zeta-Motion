package com.zeta.fondo.engine

import com.zeta.fondo.model.Effects
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/** Valores listos para los uniforms del shader. Inmutable: se reemplaza entero. */
class RenderParams(
    val aspect: Float,
    val flow: FloatArray,    // 3
    val drift: FloatArray,   // 2
    val ripple: FloatArray,  // 3
    val glint: FloatArray,   // 3
    val sway: FloatArray,    // 3
    val heat: FloatArray,    // 3
    val rain: FloatArray,    // 4
    val snow: FloatArray,    // 4
    val sakura: FloatArray,  // 4
    val stars: FloatArray,   // 4
    val flies: FloatArray,   // 4
    val fog: FloatArray,     // 4
    val rays: FloatArray,    // 4
    val cam: FloatArray,     // 3
    val mono: Float,
    val snap: Float
) {
    companion object {
        fun from(s: Map<String, Float>, aspect: Float): RenderParams {
            fun v(k: String): Float = s[k] ?: Effects.default(k)
            fun on(id: String): Boolean = v("$id.on") > 0.5f
            fun cyc(id: String): Float = max(1, v("$id.cycles").roundToInt()).toFloat()
            fun v3(id: String, a: String, b: String) =
                floatArrayOf(if (on(id)) v("$id.$a") else 0f, v("$id.$b"), cyc(id))
            fun v4(id: String, a: String, b: String, conv: (Float) -> Float = { it }) =
                floatArrayOf(if (on(id)) v("$id.$a") else 0f, conv(v("$id.$b")), cyc(id), v("$id.zone"))

            val asp = if (aspect > 0f) aspect else 1f
            val drift = if (on("drift")) {
                val a = Math.toRadians(v("drift.dir").toDouble())
                val sp = v("drift.speed")
                floatArrayOf((cos(a) * sp / asp).toFloat(), (-sin(a) * sp).toFloat())
            } else floatArrayOf(0f, 0f)

            return RenderParams(
                aspect = asp,
                flow = floatArrayOf(if (on("flow")) 1f else 0f, v("flow.amount"), cyc("flow")),
                drift = drift,
                ripple = v3("ripple", "amp", "freq"),
                glint = v3("glint", "int", "dens"),
                sway = v3("sway", "amp", "freq"),
                heat = v3("heat", "amp", "freq"),
                rain = v4("rain", "int", "angle") { Math.toRadians(it.toDouble()).toFloat() },
                snow = v4("snow", "int", "size"),
                sakura = v4("sakura", "int", "size"),
                stars = v4("stars", "int", "dens"),
                flies = v4("flies", "int", "dens"),
                fog = v4("fog", "int", "scale"),
                rays = v4("rays", "int", "x"),
                cam = floatArrayOf(
                    if (on("cam")) v("cam.zoom") else 0f,
                    if (on("cam")) v("cam.pan") else 0f,
                    cyc("cam")
                ),
                mono = if (v("style.mono") > 0.5f) 1f else 0f,
                snap = if (v("style.snap") > 0.5f) 1f else 0f
            )
        }
    }
}
