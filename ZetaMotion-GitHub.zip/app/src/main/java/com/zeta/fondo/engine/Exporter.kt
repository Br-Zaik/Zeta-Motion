package com.zeta.fondo.engine

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.opengl.EGLSurface
import android.opengl.GLES30
import android.view.Surface
import com.zeta.fondo.export.Gallery
import com.zeta.fondo.model.ExportSettings
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class ExportCancelled : Exception("Exportación cancelada")

class ExportRequest(
    val imageFile: File,
    val imgW: Int,
    val imgH: Int,
    val name: String,
    val settings: ExportSettings,
    val params: RenderParams,
    val flow: FlowField.Data?,
    val masks: MaskLayers
)

data class ExportResult(
    val isPng: Boolean,
    val file: File?,
    val galleryPath: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val frames: Int,
    val bitrate: Int,
    val rotated: Boolean,
    val reducedFrom: String?
)

object ExportPlanner {
    val resLabels = listOf("Original", "4K", "1440p", "1080p", "720p")
    private val resLong = intArrayOf(0, 3840, 2560, 1920, 1280)
    val framingLabels = listOf("Completo", "9:16", "16:9", "1:1")
    val qualityLabels = listOf("Alta", "Máxima", "Extrema")
    private val bpp = floatArrayOf(0.25f, 0.40f, 0.60f)

    /** Recorte en coordenadas de imagen: [offX, offY, escalaX, escalaY]. */
    fun crop(imgW: Int, imgH: Int, framing: Int, pos: Float): FloatArray {
        val ia = imgW.toFloat() / imgH
        val ta = when (framing) {
            1 -> 9f / 16f
            2 -> 16f / 9f
            3 -> 1f
            else -> ia
        }
        return if (ia > ta + 1e-4f) {
            val sx = ta / ia
            floatArrayOf((1f - sx) * pos, 0f, sx, 1f)
        } else if (ia < ta - 1e-4f) {
            val sy = ia / ta
            floatArrayOf(0f, (1f - sy) * pos, 1f, sy)
        } else {
            floatArrayOf(0f, 0f, 1f, 1f)
        }
    }

    fun even(v: Int): Int = max(16, v - v % 2)

    /** Tamaño pedido (antes de revisar lo que soporta el codificador del teléfono). */
    fun targetSize(imgW: Int, imgH: Int, s: ExportSettings): Pair<Int, Int> {
        val c = crop(imgW, imgH, s.framing, s.cropPos)
        val cw = imgW * c[2]
        val ch = imgH * c[3]
        val longC = max(cw, ch)
        val long = if (s.res == 0) longC else resLong[s.res.coerceIn(0, 4)].toFloat()
        val k = long / longC
        return even((cw * k).roundToInt()) to even((ch * k).roundToInt())
    }

    fun bitrate(w: Int, h: Int, fps: Int, quality: Int): Int {
        val b = w.toDouble() * h * fps * bpp[quality.coerceIn(0, 2)]
        return b.coerceIn(2_000_000.0, 100_000_000.0).toInt()
    }
}

/**
 * Renderiza cada cuadro con el mismo shader de la vista previa, a la resolución
 * de salida, directo a la superficie del codificador H.264 (sin pasar por pantalla).
 * Debe ejecutarse de principio a fin en un solo hilo (bloqueante).
 */
class Exporter(
    private val ctx: Context,
    private val vertSrc: String,
    private val fragSrc: String
) {

    fun run(req: ExportRequest, cancel: AtomicBoolean, progress: (Float) -> Unit): ExportResult =
        if (req.settings.format == 1) runPng(req, cancel, progress) else runVideo(req, cancel, progress)

    private fun alignDown(v: Int, a: Int): Int = max(a, v / a * a)

    private fun sizeOk(vc: MediaCodecInfo.VideoCapabilities, w: Int, h: Int, fps: Int): Boolean =
        try {
            vc.areSizeAndRateSupported(w, h, fps.toDouble())
        } catch (e: Exception) {
            false
        }

    /** Busca el tamaño más grande que el codificador acepta. Devuelve (anchoCod, altoCod, rotado). */
    private fun fitSize(vc: MediaCodecInfo.VideoCapabilities, w0: Int, h0: Int, fps: Int): Triple<Int, Int, Boolean> {
        val wa = max(2, vc.widthAlignment)
        val ha = max(2, vc.heightAlignment)
        var f = 1f
        repeat(80) {
            val w = alignDown((w0 * f).roundToInt(), wa)
            val h = alignDown((h0 * f).roundToInt(), ha)
            if (sizeOk(vc, w, h, fps)) return Triple(w, h, false)
            // Muchos teléfonos codifican 3840x2160 pero no 2160x3840: se guarda en
            // horizontal con marca de rotación (igual que la cámara).
            val rw = alignDown((h0 * f).roundToInt(), wa)
            val rh = alignDown((w0 * f).roundToInt(), ha)
            if (w0 != h0 && sizeOk(vc, rw, rh, fps)) return Triple(rw, rh, true)
            f *= 0.93f
        }
        return Triple(alignDown(1280, wa), alignDown(720, ha), h0 > w0)
    }

    private fun decodeForOutput(req: ExportRequest, dispW: Int, dispH: Int, crop: FloatArray, maxTex: Int): Bitmap {
        val needW = dispW / crop[2]
        val needH = dispH / crop[3]
        val r = max(needW / req.imgW, needH / req.imgH)
        val long = max(req.imgW, req.imgH)
        val target = min(maxTex.toFloat(), long * min(1f, r)).let { ceil(it).toInt() }.coerceAtLeast(256)
        return BitmapUtil.decodeAtMost(req.imageFile, min(target, maxTex))
    }

    private fun uploadAll(gl: FondoGl, req: ExportRequest, bmp: Bitmap) {
        gl.uploadImage(bmp)
        req.flow?.let { gl.uploadFlow(it) }
        synchronized(req.masks.lock) {
            for (i in 0..2) gl.uploadMask(i, req.masks.bitmaps[i])
        }
    }

    // ------------------------------------------------------------------ Vídeo

    private fun makeFormat(w: Int, h: Int, fps: Int, bitrate: Int, profile: MediaCodecInfo.CodecProfileLevel?): MediaFormat =
        MediaFormat.createVideoFormat(MIME, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            if (profile != null) {
                setInteger(MediaFormat.KEY_PROFILE, profile.profile)
                setInteger(MediaFormat.KEY_LEVEL, profile.level)
            }
        }

    private fun runVideo(req: ExportRequest, cancel: AtomicBoolean, progress: (Float) -> Unit): ExportResult {
        val s = req.settings
        val fps = s.fps
        val (reqW, reqH) = ExportPlanner.targetSize(req.imgW, req.imgH, s)
        val crop = ExportPlanner.crop(req.imgW, req.imgH, s.framing, s.cropPos)

        val outDir = File(ctx.cacheDir, "exports")
        outDir.mkdirs()
        outDir.listFiles()?.forEach { it.delete() } // solo guardamos el último
        val fileName = req.name + ".mp4"
        val outFile = File(outDir, fileName)

        val codec = MediaCodec.createEncoderByType(MIME)
        var egl: EglCore? = null
        var eglSurface: EGLSurface? = null
        var inputSurface: Surface? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var muxerStopped = false
        var gl: FondoGl? = null
        var bmp: Bitmap? = null

        try {
            val caps = codec.codecInfo.getCapabilitiesForType(MIME)
            val vc = caps.videoCapabilities
            val (encW, encH, rotate) = fitSize(vc, reqW, reqH, fps)
            val dispW = if (rotate) encH else encW
            val dispH = if (rotate) encW else encH
            val reduced = if (dispW * dispH < reqW * reqH * 0.98f) "${reqW}×$reqH" else null

            var bitrate = ExportPlanner.bitrate(encW, encH, fps, s.quality)
            bitrate = bitrate.coerceIn(vc.bitrateRange.lower, vc.bitrateRange.upper)

            val high = caps.profileLevels
                .filter { it.profile == MediaCodecInfo.CodecProfileLevel.AVCProfileHigh }
                .maxByOrNull { it.level }
            var configured = false
            if (high != null) {
                try {
                    codec.configure(makeFormat(encW, encH, fps, bitrate, high), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    configured = true
                } catch (e: Exception) {
                    codec.reset()
                }
            }
            if (!configured) {
                codec.configure(makeFormat(encW, encH, fps, bitrate, null), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            }

            val surf = codec.createInputSurface()
            inputSurface = surf
            val core = EglCore(true)
            egl = core
            val es = core.createWindowSurface(surf)
            eglSurface = es
            core.makeCurrent(es)

            val g = FondoGl(vertSrc, fragSrc)
            g.init()
            gl = g
            val b = decodeForOutput(req, dispW, dispH, crop, g.maxTextureSize())
            bmp = b
            uploadAll(g, req, b)
            b.recycle()
            bmp = null

            codec.start()
            val mux = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux
            if (rotate) mux.setOrientationHint(90)

            val info = MediaCodec.BufferInfo()
            var track = -1

            fun drain(endOfStream: Boolean) {
                if (endOfStream) codec.signalEndOfInputStream()
                var idle = 0
                while (true) {
                    val idx = codec.dequeueOutputBuffer(info, 10_000)
                    if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!endOfStream) return
                        idle++
                        if (idle > 500) return
                    } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (!muxerStarted) {
                            track = mux.addTrack(codec.outputFormat)
                            mux.start()
                            muxerStarted = true
                        }
                    } else if (idx >= 0) {
                        val buf = codec.getOutputBuffer(idx)
                        val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                        if (buf != null && !isConfig && info.size > 0 && muxerStarted) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            mux.writeSampleData(track, buf, info)
                        }
                        codec.releaseOutputBuffer(idx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                }
            }

            val frames = max(2, s.loopSec * fps)
            val total = frames * s.repeats
            for (i in 0 until total) {
                if (cancel.get()) throw ExportCancelled()
                drain(false)
                val t = (i % frames).toFloat() / frames
                g.draw(req.params, t, encW, encH, crop, false, rotate, false, s.overlayOnly)
                core.setPresentationTime(es, i.toLong() * 1_000_000_000L / fps)
                core.swap(es)
                progress((i + 1f) / total * 0.97f)
            }
            drain(true)
            if (muxerStarted) {
                mux.stop()
                muxerStopped = true
            }
            if (!muxerStarted) throw RuntimeException("El codificador no produjo vídeo")

            progress(0.98f)
            val path = Gallery.saveVideo(ctx, outFile, fileName)
            progress(1f)
            return ExportResult(false, outFile, path, dispW, dispH, fps, total, bitrate, rotate, reduced)
        } catch (e: Throwable) {
            if (e !is ExportCancelled) outFile.delete()
            throw e
        } finally {
            try { codec.stop() } catch (ignored: Exception) { }
            try { codec.release() } catch (ignored: Exception) { }
            try { if (muxerStarted && !muxerStopped) muxer?.stop() } catch (ignored: Exception) { }
            try { muxer?.release() } catch (ignored: Exception) { }
            try { gl?.release() } catch (ignored: Exception) { }
            val core = egl
            val es = eglSurface
            if (core != null) {
                if (es != null) try { core.releaseSurface(es) } catch (ignored: Exception) { }
                try { core.release() } catch (ignored: Exception) { }
            }
            try { inputSurface?.release() } catch (ignored: Exception) { }
            bmp?.recycle()
            if (cancel.get()) outFile.delete()
        }
    }

    // ------------------------------------------------------------------ PNG

    private fun runPng(req: ExportRequest, cancel: AtomicBoolean, progress: (Float) -> Unit): ExportResult {
        val s = req.settings
        var (w, h) = ExportPlanner.targetSize(req.imgW, req.imgH, s)
        val crop = ExportPlanner.crop(req.imgW, req.imgH, s.framing, s.cropPos)
        val core = EglCore(false)
        var pb: EGLSurface? = null
        var gl: FondoGl? = null
        var frameBmp: Bitmap? = null
        val fbo = IntArray(1)
        val colorTex = IntArray(1)
        var reduced: String? = null
        try {
            val p = core.createPbuffer(16, 16)
            pb = p
            core.makeCurrent(p)
            val g = FondoGl(vertSrc, fragSrc)
            g.init()
            gl = g
            val maxTex = g.maxTextureSize()
            if (max(w, h) > maxTex) {
                reduced = "${w}×$h"
                val k = maxTex.toFloat() / max(w, h)
                w = ExportPlanner.even((w * k).toInt())
                h = ExportPlanner.even((h * k).toInt())
            }
            val b = decodeForOutput(req, w, h, crop, maxTex)
            uploadAll(g, req, b)
            b.recycle()

            // Textura de salida + framebuffer
            GLES30.glGenTextures(1, colorTex, 0)
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + 5)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, colorTex[0])
            GLES30.glTexStorage2D(GLES30.GL_TEXTURE_2D, 1, GLES30.GL_RGBA8, w, h)
            GLES30.glGenFramebuffers(1, fbo, 0)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo[0])
            GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, colorTex[0], 0)
            val status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER)
            if (status != GLES30.GL_FRAMEBUFFER_COMPLETE) throw RuntimeException("No se pudo preparar el cuadro ${w}×$h (0x${Integer.toHexString(status)})")

            val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
            val fb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            frameBmp = fb
            val frames = max(2, s.loopSec * s.fps)
            GLES30.glPixelStorei(GLES30.GL_PACK_ALIGNMENT, 1)
            for (i in 0 until frames) {
                if (cancel.get()) throw ExportCancelled()
                val t = i.toFloat() / frames
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo[0])
                g.draw(req.params, t, w, h, crop, true, false, false, s.overlayOnly)
                buf.position(0)
                GLES30.glReadPixels(0, 0, w, h, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf)
                buf.position(0)
                fb.copyPixelsFromBuffer(buf)
                Gallery.savePng(ctx, fb, req.name, String.format(java.util.Locale.US, "frame_%04d.png", i + 1))
                progress((i + 1f) / frames)
            }
            return ExportResult(
                true, null, "Pictures/${Gallery.FOLDER}/${req.name}/", w, h, s.fps, frames, 0, false, reduced
            )
        } finally {
            try {
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
                if (fbo[0] != 0) GLES30.glDeleteFramebuffers(1, fbo, 0)
                if (colorTex[0] != 0) GLES30.glDeleteTextures(1, colorTex, 0)
            } catch (ignored: Exception) { }
            try { gl?.release() } catch (ignored: Exception) { }
            val p = pb
            if (p != null) try { core.releaseSurface(p) } catch (ignored: Exception) { }
            try { core.release() } catch (ignored: Exception) { }
            frameBmp?.recycle()
        }
    }

    companion object {
        const val MIME = MediaFormat.MIMETYPE_VIDEO_AVC
    }
}
