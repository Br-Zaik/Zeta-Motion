package com.zeta.fondo.ui

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.model.EditorTab
import com.zeta.fondo.model.ProjectSummary
import kotlinx.coroutines.launch

/** Inicio v5: acciones grandes; las ilustraciones de proyectos siempre son del usuario. */
@Composable
fun HomeScreen(vm: AppViewModel) {
    var newTab by remember { mutableStateOf(EditorTab.TOOLS) }
    var newCategory by remember { mutableStateOf("Anime") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importImage(uri, newTab, newCategory)
    }
    fun newProject(tab: EditorTab = EditorTab.TOOLS, category: String = "Anime") {
        newTab = tab
        newCategory = category
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }
    fun recentOrImport(tab: EditorTab, category: String = "Anime") {
        val last = vm.projects.firstOrNull()
        if (last != null) vm.openProject(last.id, tab, category) else newProject(tab, category)
    }
    var toDelete by remember { mutableStateOf<ProjectSummary?>(null) }
    val grid = rememberLazyGridState()
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().background(Night)) {
        Row(Modifier.fillMaxWidth().height(65.dp).padding(horizontal = 17.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Zeta", color = StudioText, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(" Motion", color = StudioPurple, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f))
            Icon(Icons.Filled.AddPhotoAlternate, "Importar", tint = StudioText,
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(15.dp))
                    .clickable { newProject() }.padding(10.dp))
        }
        LazyVerticalGrid(columns = GridCells.Fixed(2), state = grid, modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(11.dp), verticalArrangement = Arrangement.spacedBy(11.dp),
            contentPadding = PaddingValues(start = 15.dp, end = 15.dp, bottom = 18.dp)) {
            item(span = { GridItemSpan(2) }) {
                StudioAsset("home_banner.jpg", Modifier.fillMaxWidth().height(146.dp)
                    .clip(RoundedCornerShape(18.dp)))
            }
            item(span = { GridItemSpan(2) }) {
                StudioPrimary("Importar ilustración", Icons.Filled.AddPhotoAlternate,
                    Modifier.fillMaxWidth()) { newProject() }
            }
            item(span = { GridItemSpan(2) }) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    StudioButton("Animar", Icons.Filled.PlayArrow, Modifier.weight(1f).height(82.dp)) { recentOrImport(EditorTab.TOOLS) }
                    StudioButton("Cielo", Icons.Filled.Cloud, Modifier.weight(1f).height(82.dp)) {
                        recentOrImport(EditorTab.EFFECTS, "Cielo")
                    }
                    StudioButton("Efectos", Icons.Filled.AutoAwesome, Modifier.weight(1f).height(82.dp)) { recentOrImport(EditorTab.EFFECTS) }
                    StudioButton("Exportar", Icons.Filled.FileUpload, Modifier.weight(1f).height(82.dp)) { recentOrImport(EditorTab.EXPORT) }
                }
            }
            item(span = { GridItemSpan(2) }) {
                Text("Proyectos", color = StudioText, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 10.dp, bottom = 2.dp))
            }
            if (vm.projects.isEmpty()) item(span = { GridItemSpan(2) }) {
                Box(Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(16.dp))
                    .background(StudioPanel).clickable { newProject() }, contentAlignment = Alignment.Center) {
                    Text("＋  Crear primer proyecto", color = StudioMuted, fontSize = 15.sp)
                }
            }
            items(vm.projects, key = { it.id },
                span = { if (vm.projects.size == 1) GridItemSpan(2) else GridItemSpan(1) }) { p ->
                HomeProject(p, onOpen = { vm.openProject(p.id) }, onDelete = { toDelete = p })
            }
        }
        Row(Modifier.fillMaxWidth().height(65.dp).background(StudioPanel).padding(horizontal = 9.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            StudioButton("Inicio", Icons.Filled.Home, Modifier.weight(1f), active = true) {
                scope.launch { grid.animateScrollToItem(0) }
            }
            StudioButton("Proyectos", Icons.Filled.Folder, Modifier.weight(1f)) {
                scope.launch { grid.animateScrollToItem(4) }
            }
            StudioButton("Crear", Icons.Filled.Add, Modifier.weight(1f)) { newProject() }
        }
    }
    toDelete?.let { p ->
        AlertDialog(onDismissRequest = { toDelete = null },
            title = { Text("¿Borrar proyecto?") },
            text = { Text(p.name) },
            confirmButton = { TextButton(onClick = { vm.deleteProject(p.id); toDelete = null }) {
                Text("Borrar", color = Danger) } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } },
            containerColor = StudioPanel)
    }
}

@Composable
private fun HomeProject(p: ProjectSummary, onOpen: () -> Unit, onDelete: () -> Unit) {
    val bitmap = remember(p.thumb.absolutePath, p.modified) {
        runCatching { BitmapFactory.decodeFile(p.thumb.absolutePath)?.asImageBitmap() }.getOrNull()
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp))
        .background(StudioPanel).clickable(onClick = onOpen)) {
        Box(Modifier.fillMaxWidth().aspectRatio(1.23f).background(StudioTile)) {
            if (bitmap != null) Image(bitmap, p.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Icon(Icons.Filled.MoreVert, "Borrar proyecto", tint = StudioText,
                modifier = Modifier.align(Alignment.TopEnd).padding(5.dp).size(43.dp)
                    .clip(RoundedCornerShape(15.dp)).background(Night.copy(alpha = .75f))
                    .clickable(onClick = onDelete).padding(9.dp))
        }
        Text(p.name, color = StudioText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 10.dp, end = 8.dp, top = 9.dp))
        Text("${p.w}×${p.h}", color = StudioMuted, fontSize = 12.sp,
            modifier = Modifier.padding(start = 10.dp, bottom = 10.dp, top = 2.dp))
    }
}
