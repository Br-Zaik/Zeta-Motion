package com.zeta.fondo.engine

import com.zeta.fondo.model.ImageLayer
import com.zeta.fondo.model.ImageLayers
import com.zeta.fondo.model.LayerFx
import com.zeta.fondo.model.LayerJson
import com.zeta.fondo.model.TextSpec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v44.29 · Efectos y entradas de capa (imágenes y textos), en el mismo paso de dibujo. */
class V4429Test {
    private fun file(rel: String) = listOf(File(rel), File("app/$rel")).first { it.exists() }
    private val base = ImageLayer(id = 1, name = "a", file = "layers/a.png", aspect = 2f)

    @Test fun entrancesStartHiddenAndEndExact() {
        for (type in 1 until LayerFx.inNames.size) {
            val l = base.copy(inType = type, inSec = 1f)
            val start = ImageLayers.frame(l, 0f, 6f, 1920, 1080)
            val end = ImageLayers.frame(l, 2f / 6f, 6f, 1920, 1080)
            val plain = ImageLayers.frame(base, 2f / 6f, 6f, 1920, 1080)
            // Al empezar: no se ve (o no se ha revelado nada); al terminar: igual que sin entrada.
            assertTrue("tipo $type", start.opacity < .01f || start.reveal < .01f)
            assertEquals(plain.x, end.x, 1e-5f); assertEquals(plain.y, end.y, 1e-5f)
            assertEquals(plain.halfW, end.halfW, 1e-3f); assertEquals(plain.opacity, end.opacity, 1e-5f)
            assertEquals(1f, end.reveal, 1e-6f)
        }
        // Con «Tiempo», la entrada empieza cuando empieza la capa.
        val late = base.copy(inType = LayerFx.IN_FADE, inSec = .5f, startSec = 3f, durSec = 2f)
        assertTrue(ImageLayers.frame(late, 3.05f / 6f, 6f, 100, 100).opacity < .5f)
        assertTrue(ImageLayers.frame(late, 3.9f / 6f, 6f, 100, 100).opacity > .95f)
    }

    @Test fun letterByLetterUsesTheLongestLine() {
        val t = base.copy(text = TextSpec("Hola\nmundo  "), inType = LayerFx.IN_TYPE)
        assertEquals(5, LayerFx.revealSteps(t))
        assertEquals(5, ImageLayers.frame(t, .01f, 6f, 100, 100).revealSteps)
        assertEquals(0, ImageLayers.frame(base.copy(inType = LayerFx.IN_TYPE), .01f, 6f, 100, 100).revealSteps)
        assertEquals(0, ImageLayers.frame(t.copy(inType = LayerFx.IN_FADE), .01f, 6f, 100, 100).revealSteps)
    }

    @Test fun savedAndSanitized() {
        val l = base.copy(fx = LayerFx.NEON, fxAmt = .8f, fxCycles = 3, fxColor = 0xFF32D2FF.toInt(),
            inType = LayerFx.IN_ZOOM, inSec = 1.2f)
        val back = LayerJson.fromJson(LayerJson.toJson(listOf(l))).single()
        assertEquals(l.fx, back.fx); assertEquals(l.fxAmt, back.fxAmt, 1e-4f); assertEquals(3, back.fxCycles)
        assertEquals(l.fxColor, back.fxColor); assertEquals(l.inType, back.inType); assertEquals(1.2f, back.inSec, 1e-4f)
        val plain = LayerJson.fromJson(LayerJson.toJson(listOf(base))).single()
        assertEquals(0, plain.fx); assertEquals(0, plain.inType)
        val bad = ImageLayers.sanitize(base.copy(fx = 99, fxAmt = Float.NaN, fxCycles = 50, inType = -3, inSec = 99f))
        assertEquals(LayerFx.names.size - 1, bad.fx); assertEquals(.6f, bad.fxAmt, 0f); assertEquals(8, bad.fxCycles)
        assertEquals(0, bad.inType); assertEquals(LayerFx.IN_MAX, bad.inSec, 0f)
        assertEquals(LayerFx.names.size, LayerFx.help.size)
    }

    @Test fun drawnInTheSameLayerPass() {
        val c = file("src/main/java/com/zeta/fondo/engine/LayerCompositor.kt").readText()
        for (u in listOf("uniform int uFx;", "uniform float uFxT;", "uniform vec3 uFxColor;", "uniform float uReveal;"))
            assertTrue(u, c.contains(u))
        // Vueltas enteras por bucle (empalma) y sin trabajo extra si la capa no tiene efecto.
        assertTrue(c.contains("t.coerceIn(0f, 1f) * layer.fxCycles.coerceIn(1, 8)"))
        assertTrue(c.contains("if (fx != 0) {"))
        // Neón con las mipmaps (sin desenfoque aparte) y sin neblina en el recuadro.
        assertTrue(c.contains("textureLod(uLayer, cuv, lod)") && c.contains("float border = smoothstep"))
        val ui = file("src/main/java/com/zeta/fondo/ui/LayerCropUi.kt").readText()
        assertTrue(ui.contains("QuickButton(\"Efectos\", Icons.Filled.AutoAwesome"))
        val panels = file("src/main/java/com/zeta/fondo/ui/LayerPanels.kt").readText()
        assertTrue(panels.contains("ToolChip(\"Efectos\", Icons.Filled.AutoAwesome, vm.layerFxOpen"))
        assertTrue(file("src/main/java/com/zeta/fondo/ui/EditorTools.kt").readText()
            .contains("vm.layerFxOpen && vm.selectedLayer != null -> LayerFxSheet(vm)"))
        assertTrue(file("src/main/java/com/zeta/fondo/ui/EditorScreen.kt").readText()
            .contains("vm.layerFxOpen -> vm.layerFxOpen = false"))
        // Margen del texto para el halo del neón.
        assertTrue(file("src/main/java/com/zeta/fondo/engine/TextRender.kt").readText().contains("size * .16f"))
    }
}
