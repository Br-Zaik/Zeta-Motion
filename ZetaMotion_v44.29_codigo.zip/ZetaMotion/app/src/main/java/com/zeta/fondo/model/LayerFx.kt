package com.zeta.fondo.model

import kotlin.math.max
import kotlin.math.pow

/**
 * v44.29 · Efectos y entradas de CAPA (imágenes y textos).
 *
 * Optimización: todo se calcula en el mismo paso que ya dibuja cada capa (LayerCompositor), solo
 * dentro de su recuadro. No se vuelve a procesar el fondo ni se multiplica el trabajo por capa;
 * una capa sin efecto cuesta igual que antes. Los efectos cierran el bucle exacto (vueltas enteras
 * por vídeo) y se ven igual en la vista previa y en la exportación.
 *
 * - Efecto ([ImageLayer.fx]): Brillo que pasa, Neón (halo con las mipmaps de la textura: casi
 *   gratis), Ondear, Destellos, Color que cambia.
 * - Entrada ([ImageLayer.inType]) al empezar el tramo de la capa: Aparecer, Deslizar, Zoom,
 *   Letra por letra (en los textos va por letras del renglón más largo).
 */
object LayerFx {
    const val NONE = 0
    const val SHIMMER = 1
    const val NEON = 2
    const val WAVE = 3
    const val SPARKLE = 4
    const val HUE = 5

    val names = listOf("Ninguno", "Brillo que pasa", "Neón", "Ondear", "Destellos", "Color que cambia")
    val help = listOf(
        "La capa se ve tal cual.",
        "Un destello de luz recorre la capa (ideal en textos y logos).",
        "Halo de luz alrededor que late. Mejor en textos y en imágenes recortadas (con transparencia).",
        "La capa se mueve como una bandera o el reflejo en el agua.",
        "Chispitas que se encienden y apagan sobre la capa.",
        "El color va girando poco a poco por todo el arcoíris."
    )

    /** Efectos que usan [ImageLayer.fxColor]. */
    fun usesColor(fx: Int) = fx == SHIMMER || fx == NEON || fx == SPARKLE

    /** Color con el que empieza cada efecto. */
    fun defaultColor(fx: Int): Int = when (fx) {
        NEON -> 0xFFFF2D92.toInt()
        SHIMMER -> 0xFFFFF4D6.toInt()
        else -> TextLayers.WHITE
    }

    const val IN_NONE = 0
    const val IN_FADE = 1
    const val IN_SLIDE = 2
    const val IN_ZOOM = 3
    const val IN_TYPE = 4

    val inNames = listOf("Ninguna", "Aparecer", "Deslizar", "Zoom", "Letra por letra")

    const val IN_MIN = .2f
    const val IN_MAX = 3f

    /** Cómo está la entrada en el segundo [sec]: desplazamiento (0..1 del fondo), escala, alfa y revelado. */
    data class Entrance(val dy: Float = 0f, val scale: Float = 1f, val alpha: Float = 1f, val reveal: Float = 1f)

    private fun easeOut(p: Float) = 1f - (1f - p).pow(3)

    /** Con un poco de rebote al final (Zoom). */
    private fun easeOutBack(p: Float): Float {
        val c1 = 1.4f; val c3 = c1 + 1f
        val q = p - 1f
        return 1f + c3 * q * q * q + c1 * q * q
    }

    fun entrance(layer: ImageLayer, sec: Float, loopSec: Float): Entrance {
        if (layer.inType == IN_NONE) return Entrance()
        val total = loopSec.coerceAtLeast(.1f)
        val start = if (layer.durSec > 0f) layer.startSec.coerceIn(0f, total) else 0f
        val dur = layer.inSec.coerceIn(IN_MIN, IN_MAX)
        val p = ((sec - start) / dur).coerceIn(0f, 1f)
        return when (layer.inType) {
            IN_FADE -> Entrance(alpha = easeOut(p))
            IN_SLIDE -> Entrance(dy = (1f - easeOut(p)) * .08f, alpha = (p * 2.5f).coerceAtMost(1f))
            IN_ZOOM -> Entrance(scale = max(.05f, .55f + .45f * easeOutBack(p)), alpha = (p * 3f).coerceAtMost(1f))
            IN_TYPE -> Entrance(reveal = p)
            else -> Entrance()
        }
    }

    /** Pasos de «Letra por letra»: letras del renglón más largo del texto (0 = barrido suave en imágenes). */
    fun revealSteps(layer: ImageLayer): Int =
        layer.text?.text?.lines()?.maxOfOrNull { it.trimEnd().length }?.coerceIn(0, 200) ?: 0
}
