package com.zeta.fondo.engine

import android.graphics.Bitmap
import com.zeta.fondo.model.Effects

/**
 * Puente entre la interfaz (hilo principal) y el hilo de OpenGL de la vista previa.
 * Todo son referencias @Volatile que se reemplazan enteras: el hilo de OpenGL
 * detecta el cambio comparando identidad y vuelve a subir la textura.
 */
class RenderHub {
    private val revisionCounter = java.util.concurrent.atomic.AtomicLong()
    val revision: Long get() = revisionCounter.get()
    fun invalidate() { revisionCounter.incrementAndGet() }
    @Volatile var image: Bitmap? = null
        set(value) { field = value; invalidate() }
    /** Personaje PNG del efecto Aparición (null = sin personaje). */
    @Volatile var character: Bitmap? = null
        set(value) { field = value; invalidate() }
    /** Proporción ancho/alto del encuadre mostrado; el renderer centra el cuadro sin recrear la superficie. */
    @Volatile var displayAspect = 1f
        set(value) { field = value; invalidate() }
    @Volatile var flow: FlowField.Data? = null
        set(value) { field = value; invalidate() }
    @Volatile var masks: MaskLayers? = null
        set(value) { field = value; invalidate() }
    @Volatile var params: RenderParams = RenderParams.from(Effects.defaults(), 1f)
        set(value) { field = value; invalidate() }

    @Volatile var viewScale = 1f
        set(value) { field = value; invalidate() }
    @Volatile var viewX = 0f
        set(value) { field = value; invalidate() }
    @Volatile var viewY = 0f
        set(value) { field = value; invalidate() }
    @Volatile var showMask = true
        set(value) { field = value; invalidate() }
    @Volatile var activeMask = 0
        set(value) { field = value; invalidate() }
    @Volatile var renderEnabled = true
        set(value) { field = value; invalidate() }

    @Volatile var viewWidth = 1f
    @Volatile var viewHeight = 1f

    @Volatile var onError: ((String) -> Unit)? = null

    @Volatile private var loopSec = 6f
    @Volatile private var playing = true
    @Volatile private var pausedT = 0f
    @Volatile private var startNs = System.nanoTime()

    fun currentT(): Float {
        if (!playing) return pausedT
        val sec = (System.nanoTime() - startNs) / 1e9
        val t = (sec / loopSec) % 1.0
        return if (t < 0) 0f else t.toFloat()
    }

    fun setLoopSec(sec: Float) {
        val t = currentT()
        loopSec = if (sec > 0.5f) sec else 0.5f
        startNs = System.nanoTime() - (t * loopSec * 1e9).toLong()
    }

    fun setPlaying(p: Boolean) {
        if (p == playing) return
        if (!p) {
            pausedT = currentT()
            playing = false
        } else {
            startNs = System.nanoTime() - (pausedT * loopSec * 1e9).toLong()
            playing = true
        }
    }

    fun setPausedT(t: Float) {
        pausedT = t.coerceIn(0f, 0.9999f)
        invalidate()
    }

    fun pausedT(): Float = pausedT
}
