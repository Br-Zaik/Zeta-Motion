package com.zeta.fondo.engine

import android.graphics.Bitmap
import com.zeta.fondo.model.BlendModes
import com.zeta.fondo.model.ImageLayer
import com.zeta.fondo.model.ImageLayers
import com.zeta.fondo.model.LayerFrame
import kotlin.math.max
import kotlin.math.min

/**
 * v44.23 · Miniaturas del panel «Mezcla y opacidad»: el resultado REAL de cada modo con tu fondo
 * y tu capa, recortado alrededor de la capa (Alight Motion enseña una foto de ejemplo; aquí ves
 * tu propia imagen). Se calculan en la CPU con las mismas fórmulas que la GPU.
 */
object BlendThumbs {
    private const val EMPTY = 0xFF15151B.toInt()

    fun render(base: Bitmap, top: Bitmap, layer: ImageLayer, frame: LayerFrame, baseW: Int, baseH: Int, size: Int): List<Bitmap?> {
        val b = scaled(base, 480)
        val t = scaled(top, 256)
        try {
            val bp = IntArray(b.width * b.height).also { b.getPixels(it, 0, b.width, 0, 0, b.width, b.height) }
            val tp = IntArray(t.width * t.height).also { t.getPixels(it, 0, t.width, 0, 0, t.width, t.height) }
            val out = renderArgb(bp, b.width, b.height, tp, t.width, t.height, layer, frame, baseW, baseH, size)
            return out.map { px -> Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888) }
        } finally {
            if (b !== base) b.recycle()
            if (t !== top) t.recycle()
        }
    }

    private fun scaled(src: Bitmap, maxSide: Int): Bitmap {
        val long = max(src.width, src.height)
        if (long <= maxSide) return src
        val k = maxSide.toFloat() / long
        return Bitmap.createScaledBitmap(src, max(1, (src.width * k).toInt()), max(1, (src.height * k).toInt()), true)
    }

    /**
     * Código puro (pruebas JVM): una miniatura de [size]² por modo. [basePix]/[topPix] = ARGB sin
     * premultiplicar (como Bitmap.getPixels).
     */
    fun renderArgb(basePix: IntArray, bw: Int, bh: Int, topPix: IntArray, tw: Int, th: Int,
                   layer: ImageLayer, frame: LayerFrame, baseW: Int, baseH: Int, size: Int): List<IntArray> {
        // Zona: un cuadrado alrededor de la capa (con margen), en píxeles de la imagen base.
        val cs = ImageLayers.corners(frame, baseW, baseH)
        val minX = cs.minOf { it.first } * baseW; val maxX = cs.maxOf { it.first } * baseW
        val minY = cs.minOf { it.second } * baseH; val maxY = cs.maxOf { it.second } * baseH
        val side = max(max(maxX - minX, maxY - minY) * 1.2f, .15f * min(baseW, baseH)).coerceAtMost(4f * max(baseW, baseH))
        val cx = (minX + maxX) / 2f; val cy = (minY + maxY) / 2f
        val n = size * size
        val below = IntArray(n)
        val above = IntArray(n)
        for (j in 0 until size) for (i in 0 until size) {
            val px = cx + ((i + .5f) / size - .5f) * side
            val py = cy + ((j + .5f) / size - .5f) * side
            val u = px / baseW; val v = py / baseH
            val k = j * size + i
            below[k] = if (u in 0f..1f && v in 0f..1f)
                basePix[min(bh - 1, (v * bh).toInt()) * bw + min(bw - 1, (u * bw).toInt())] else EMPTY
            val loc = ImageLayers.localOf(frame, u, v, baseW, baseH)
            above[k] = if (loc == null) 0 else {
                var lu = (loc.first + 1f) / 2f
                val lv = (loc.second + 1f) / 2f
                if (frame.flipX) lu = 1f - lu
                topPix[min(th - 1, (lv * th).toInt()) * tw + min(tw - 1, (lu * tw).toInt())]
            }
        }
        val op = frame.opacity
        return (0 until BlendModes.COUNT).map { mode ->
            IntArray(n) { k -> BlendModes.compositeArgb(mode, below[k], above[k], op) }
        }
    }
}
