package com.zeta.fondo.model

import org.json.JSONArray
import org.json.JSONObject

/** v44.23 · Guardado de las capas de imagen en project.json (lectura tolerante). */
object LayerJson {
    /** Carpeta de las imágenes de las capas dentro del proyecto. */
    const val DIR = "layers"

    fun toJson(layers: List<ImageLayer>): JSONArray {
        val arr = JSONArray()
        for (l in layers) {
            val o = JSONObject()
                .put("id", l.id)
                .put("name", l.name)
                .put("file", l.file)
                .put("aspect", l.aspect.toDouble())
                .put("x", l.x.toDouble())
                .put("y", l.y.toDouble())
                .put("sx", l.sx.toDouble())
                .put("sy", l.sy.toDouble())
                .put("rot", l.rot.toDouble())
                .put("op", l.opacity.toDouble())
                .put("blend", l.blend)
            if (l.hidden) o.put("hidden", true)
            if (l.behind) o.put("behind", true)
            if (l.flipX) o.put("flipX", true)
            if (l.motion != 0) o.put("motion", l.motion).put("mamt", l.motionAmt.toDouble()).put("mcyc", l.motionCycles)
            if (l.durSec > 0f) o.put("start", l.startSec.toDouble()).put("dur", l.durSec.toDouble())
            if (l.keys.isNotEmpty()) {
                val ko = JSONObject()
                for ((k, ks) in l.keys) {
                    if (ks.isEmpty()) continue
                    val a = JSONArray()
                    for (f in Keyframes.encode(ks)) a.put(f.toDouble())
                    ko.put(k, a)
                }
                o.put("keys", ko)
            }
            arr.put(o)
        }
        return arr
    }

    /** Solo nombres de archivo seguros dentro de la carpeta de capas. */
    fun safeFile(f: String): Boolean = f.startsWith("$DIR/") && !f.contains("..") && f.count { it == '/' } == 1 && f.length < 120

    fun fromJson(arr: JSONArray?): List<ImageLayer> {
        if (arr == null) return emptyList()
        val out = ArrayList<ImageLayer>()
        val seen = HashSet<Long>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val file = o.optString("file", "")
            if (!safeFile(file)) continue
            var id = o.optLong("id", i + 1L)
            while (!seen.add(id)) id++
            val keys = LinkedHashMap<String, List<Keyframe>>()
            o.optJSONObject("keys")?.let { ko ->
                val it = ko.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    if (k !in ImageLayers.keyProps) continue
                    val a = ko.optJSONArray(k) ?: continue
                    val list = Keyframes.decode(FloatArray(a.length()) { j -> a.optDouble(j, 0.0).toFloat() })
                    if (list.isNotEmpty()) keys[k] = list
                }
            }
            out += ImageLayers.sanitize(ImageLayer(
                id = id,
                name = o.optString("name", "Imagen ${i + 1}"),
                file = file,
                aspect = o.optDouble("aspect", 1.0).toFloat(),
                x = o.optDouble("x", .5).toFloat(),
                y = o.optDouble("y", .5).toFloat(),
                sx = o.optDouble("sx", .6).toFloat(),
                sy = o.optDouble("sy", o.optDouble("sx", .6)).toFloat(),
                rot = o.optDouble("rot", 0.0).toFloat(),
                opacity = o.optDouble("op", 1.0).toFloat(),
                blend = o.optInt("blend", 0),
                hidden = o.optBoolean("hidden", false),
                behind = o.optBoolean("behind", false),
                flipX = o.optBoolean("flipX", false),
                motion = o.optInt("motion", 0),
                motionAmt = o.optDouble("mamt", .5).toFloat(),
                motionCycles = o.optInt("mcyc", 1),
                startSec = o.optDouble("start", 0.0).toFloat(),
                durSec = o.optDouble("dur", 0.0).toFloat(),
                keys = keys
            ))
        }
        return out
    }
}
