# Zeta Motion

Código fuente Android de **Zeta Motion v31**, especializado en animar fondos e ilustraciones de anime, manga y manhwa.

Consulta `README_V31.md` para conocer las mejoras y las instrucciones de compilación. Se conserva el historial `README_V3.md` a `README_V30.md`.
