package com.zeta.fondo.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.model.*

@Composable
fun SimpleBrushPanel(vm: AppViewModel) {
    Column(Modifier.fillMaxSize().padding(horizontal=8.dp)) {
        Row(Modifier.fillMaxWidth().height(40.dp),verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick={vm.finishEdit(false)}) { Icon(Icons.Default.Close,"Cancelar",tint=StudioText) }
            Text(if(vm.editingEffect==null) "Proteger" else if(vm.editingEffect=="zonemotion") "Pintar movimiento" else "Pintar ${Effects.all.firstOrNull { it.id == vm.editingEffect }?.title ?: "zona"}",color=StudioText,modifier=Modifier.weight(1f))
            TextButton(onClick={if(vm.editingEffect==null) vm.finishEdit(true) else vm.finishPainting()}) { Text("Listo") }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            StudioSmallButton("Pincel",Icons.Default.Brush,Modifier.weight(1f),selected=!vm.eraser){vm.eraser=false}
            StudioSmallButton("Borrador",Icons.Default.AutoFixNormal,Modifier.weight(1f),selected=vm.eraser){vm.eraser=true}
        }
        LabeledSlider("Tamaño",vm.brushDp,6f,140f,true){vm.brushDp=it}
    }
}
@Composable
fun SimpleProtectPanel(vm: AppViewModel) {
    Column(Modifier.fillMaxSize().padding(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            StudioButton("Pintar área",Icons.Default.Shield,Modifier.width(92.dp).height(66.dp)){vm.protect()}
            StudioButton("Fijar punto",Icons.Default.PushPin,Modifier.width(92.dp).height(66.dp),active=vm.tool==Tool.ANCHOR){vm.protectPoints()}
            StudioButton("Borrar punto",Icons.Default.DeleteOutline,Modifier.width(92.dp).height(66.dp),active=vm.tool==Tool.ERASE_GUIDE){vm.protectPoints(true)}
        }
        Text(if(vm.tool==Tool.ANCHOR) "Toca para fijar un punto." else if(vm.tool==Tool.ERASE_GUIDE) "Toca el punto que quieres borrar." else "Pinta un área quieta o fija puntos de apoyo.",color=StudioMuted,fontSize=13.sp)
    }
}
@Composable
fun SimpleSettingsPanel(vm: AppViewModel) {
    val section = vm.settingsSection
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(38.dp),horizontalArrangement=Arrangement.Center) {
            listOf("Color", "Formato", "Audio").forEachIndexed { i,label ->
                TextButton(onClick={ if (i != 1) vm.finishCropEdit(); vm.settingsSection=i }) { Text(label,color=if(section==i) StudioPurple else StudioMuted) }
            }
        }
        Box(Modifier.weight(1f)) { when(section) { 0->ColorPanel(vm);1->CanvasPanel(vm);else->AudioPanel(vm) } }
    }
}

private val elementNames=listOf("Nube","Humo","Pétalos","Brillos","Energía","Niebla")
private val elementIcons=listOf(Icons.Default.Cloud,Icons.Default.BlurOn,Icons.Default.LocalFlorist,
    Icons.Default.AutoAwesome,Icons.Default.Bolt,Icons.Default.CloudQueue)

private val effectCategories = listOf("Rápido", "Todos", "Clima", "Agua y cielo", "Luz", "Anime", "Manga", "Cámara")
private val quickPresetNames = setOf(
    "Fondo con profundidad", "Árbol natural", "Bandera realista", "Pasto al viento", "Cortina suave",
    "Cabello natural", "Ropa al viento", "Cielo vivo", "Lluvia nocturna anime", "Manga respirando",
    "Brisa suave", "Viento fuerte", "Viento de tormenta", "Árbol con brisa", "Árbol viento fuerte",
    "Hojas verdes", "Hojas secas", "Hojas de otoño", "Hojas de Navidad", "Navidad con nieve",
    "Olas suaves", "Olas fuertes", "Mar de tormenta", "Lluvia suave", "Lluvia fuerte",
    "Nieve suave", "Nieve fuerte", "Ventisca", "Nubes suaves", "Niebla baja", "Polvo de luz",
    "Fuego y brasas", "Noche mágica"
)
private val quickGroups = listOf("Todos", "Viento", "Hojas", "Agua", "Clima", "Ambiente", "Anime")
private fun quickGroupOf(name: String): String = when (name) {
    "Brisa suave", "Viento fuerte", "Viento de tormenta", "Árbol con brisa", "Árbol viento fuerte",
    "Bandera realista", "Pasto al viento", "Cabello natural", "Ropa al viento", "Cortina suave" -> "Viento"
    "Hojas verdes", "Hojas secas", "Hojas de otoño", "Hojas de Navidad", "Navidad con nieve" -> "Hojas"
    "Olas suaves", "Olas fuertes", "Mar de tormenta" -> "Agua"
    "Lluvia suave", "Lluvia fuerte", "Nieve suave", "Nieve fuerte", "Ventisca", "Nubes suaves" -> "Clima"
    "Niebla baja", "Polvo de luz", "Fuego y brasas", "Noche mágica" -> "Ambiente"
    else -> "Anime"
}

private fun categoriesOf(id: String): Set<String> = when (id) {
    "rain", "snow", "sakura", "fog", "bolt", "gust", "tornado", "leaves", "dust", "ash", "bubbles" -> setOf("Clima")
    "sky", "water", "drift", "ripple", "glint", "clouds3", "shore", "sunpath", "stars" -> setOf("Agua y cielo")
    "rays", "flies", "embers", "flame", "heat", "eyes", "comet" -> setOf("Luz")
    "energy", "electric", "shock", "pulse", "runes", "shards", "smoke", "dispersion", "cloth", "blink", "sway", "appear", "elements", "mesh", "natural", "parallax" -> setOf("Anime")
    "speed", "focus", "hatch", "tone", "grain", "ink", "style", "flash" -> setOf("Manga")
    "cam", "impact", "parallax" -> setOf("Cámara")
    else -> setOf("Anime")
} + when (id) {
    "gust", "impact", "bolt", "tornado", "shore", "leaves", "rain", "snow" -> setOf("Anime")
    "speed", "focus", "flash" -> setOf("Anime")
    "glint" -> setOf("Luz")
    else -> emptySet()
}


private val directStyleLabels = mapOf(
    "gust" to listOf("Suave", "Normal", "Fuerte", "Tormenta"),
    "shore" to listOf("Suaves", "Medias", "Fuertes", "Tormenta"),
    "leaves" to listOf("Verdes", "Secas", "Otoño", "Navidad"),
    "rain" to listOf("Suave", "Normal", "Fuerte", "Tormenta"),
    "snow" to listOf("Suave", "Normal", "Fuerte", "Ventisca")
)

private fun catalogTitle(id: String, fallback: String): String = when (id) {
    "gust" -> "Viento"
    "shore" -> "Olas"
    "leaves" -> "Hojas"
    "rain" -> "Lluvia"
    "snow" -> "Nieve"
    else -> fallback
}

private val effectOrder = listOf("natural", "parallax", "mesh", "cam", "gust", "appear", "impact", "bolt", "tornado", "clouds3", "shore", "sunpath",
    "sky", "water", "dispersion")

@Composable
fun SimpleEffectsPanel(vm: AppViewModel) {
    val id=vm.editingEffect
    if(id==null) {
        val all=remember { Effects.all.filter{it.id !in setOf("flow","zonemotion")}.sortedBy {
            effectOrder.indexOf(it.id).let { i -> if (i < 0) 100 else i }
        } }
        val category = vm.effectsCategory.takeIf { it in effectCategories } ?: "Todos"
        val shown = remember(category) {
            val list = if (category == "Todos") all else all.filter { category in categoriesOf(it.id) }
            list.map { it.id to catalogTitle(it.id, effectShortTitle(it)) } +
                (if (category == "Todos" || category == "Anime") listOf("elements" to "Elementos") else emptyList())
        }
        val quickPresets = remember { Presets.all.filter { it.name in quickPresetNames } }
        var quickGroup by remember { mutableStateOf("Todos") }
        var stylePickerId by remember { mutableStateOf<String?>(null) }
        val anim = rememberInfiniteTransition(label = "glyphs")
        val time by anim.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "t")
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().height(38.dp).padding(start = 10.dp, end = 4.dp),verticalAlignment=Alignment.CenterVertically) {
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    effectCategories.forEach { c ->
                        val sel = c == category
                        Text(c, color = if (sel) StudioText else StudioMuted, fontSize = 13.sp,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.clip(RoundedCornerShape(10.dp))
                                .background(if (sel) StudioTile else Color.Transparent)
                                .clickable { vm.effectsCategory = c }.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                }
                if (vm.activeEffectsCount > 0) TextButton(onClick={vm.removeAllEffects()}) {
                    Text("Quitar todo", fontSize = 12.sp, color = StudioMuted)
                }
            }
            stylePickerId?.let { sid ->
                val labels = directStyleLabels[sid]
                if (labels != null) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(catalogTitle(sid, sid), color = StudioText, fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(end = 5.dp))
                        Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            labels.forEachIndexed { index, label ->
                                val selectedStyle = (vm.settings["$sid.variant"] ?: 0f).toInt() == index
                                StudioChoice(label, selectedStyle) {
                                    vm.activateEffectStyle(sid, index)
                                }
                            }
                        }
                        Icon(Icons.Default.Close, "Cerrar estilos", tint = StudioMuted,
                            modifier = Modifier.size(28.dp).clickable { stylePickerId = null }.padding(5.dp))
                    }
                }
            }
            if (category == "Rápido") {
                // Familias principales siempre visibles: no hace falta adivinar en qué
                // categoría están Viento, Olas, Hojas, Lluvia o Nieve.
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 7.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("gust", "shore", "leaves", "rain", "snow").forEach { family ->
                        StudioChoice(catalogTitle(family, family), stylePickerId == family) { stylePickerId = family }
                    }
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 7.dp, vertical = 3.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    quickGroups.forEach { group ->
                        StudioChoice(group, quickGroup == group) { quickGroup = group }
                    }
                }
                val visiblePresets = if (quickGroup == "Todos") quickPresets else quickPresets.filter { quickGroupOf(it.name) == quickGroup }
                LazyVerticalGrid(GridCells.Fixed(2), Modifier.weight(1f), contentPadding = PaddingValues(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(visiblePresets, key = { it.name }) { preset ->
                        Column(Modifier.height(82.dp).clip(RoundedCornerShape(12.dp)).background(StudioTile)
                            .clickable { vm.applyPreset(preset) }.padding(8.dp),
                            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(if (preset.manga) Icons.Default.MenuBook else Icons.Default.AutoAwesome, null,
                                tint = StudioPurple, modifier = Modifier.size(25.dp))
                            Spacer(Modifier.height(5.dp))
                            Text(preset.name, color = StudioText, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                                maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                        }
                    }
                }
                Text("Un toque aplica una combinación lista; luego puedes ajustar cada efecto.", color = StudioMuted,
                    fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(bottom = 3.dp), textAlign = TextAlign.Center)
            } else {
                LazyVerticalGrid(GridCells.Fixed(3),Modifier.weight(1f),contentPadding=PaddingValues(6.dp),
                    horizontalArrangement=Arrangement.spacedBy(6.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    items(shown, key={it.first}) { (eid, title) ->
                        val active = if (eid == "elements") (0..3).any { (vm.settings["element$it.on"] ?: 0f) > .5f }
                            else (vm.settings["$eid.on"] ?: 0f) > .5f
                        EffectCard(eid, title, active, { time },
                            onTap = {
                                if (eid in directStyleLabels) stylePickerId = eid
                                else vm.activateOrSelectEffect(eid)
                            },
                            onAdd = { if (eid != "style" && eid != "elements") vm.addEffectClip(eid) },
                            onSettings = { vm.editEffect(eid) })
                    }
                }
                Text("Toca = seleccionar · + = repetir · mantén = ajustar", color = StudioMuted, fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 3.dp), textAlign = TextAlign.Center)
            }
        }
    } else Column(Modifier.fillMaxSize()) {
        val def=Effects.all.firstOrNull{it.id==id}
        Row(Modifier.fillMaxWidth().height(40.dp),verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick={vm.finishEdit(false)}){Icon(Icons.Default.Close,"Cancelar",tint=StudioText)}
            Text(if(id=="elements") "Elementos" else def?.let(::effectShortTitle)?:id,color=StudioText,modifier=Modifier.weight(1f),maxLines=1,fontSize=14.sp)
            TextButton(onClick={vm.finishEdit(true)}){Text("Listo")}
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal=10.dp),
            verticalArrangement=Arrangement.spacedBy(5.dp)) {
            if(id=="elements") ElementsControls(vm)
            else if(def!=null) {
                if (id == "appear") CharacterControls(vm)
                if (id == "parallax") {
                    Text("Profundidad 2.5D: pinta el fondo en azul y el primer plano en verde.",
                        color = StudioMuted, fontSize = 12.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StudioSmallButton(if (vm.maskHasPaint(1)) "Fondo ✓" else "Pintar fondo", Icons.Default.Layers,
                            Modifier.weight(1f)) { vm.paintBuiltinMask(1) }
                        StudioSmallButton(if (vm.maskHasPaint(2)) "Frente ✓" else "Pintar frente", Icons.Default.FilterNone,
                            Modifier.weight(1f)) { vm.paintBuiltinMask(2) }
                    }
                }
                if (id == "natural") {
                    Text("Pinta solo la parte flexible (hojas, tela, cabello, pasto). El tronco, poste, cuerpo o pared se quedan quietos.",
                        color = StudioMuted, fontSize = 12.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StudioSmallButton("Pintar / retocar", Icons.Default.Brush,
                            Modifier.weight(1f)) { vm.paintEffectZone() }
                        StudioSmallButton("Vista previa", Icons.Default.PlayArrow, Modifier.weight(1f)) {
                            if (!vm.isEffectOn("natural")) vm.toggleEffect("natural")
                            if (!vm.playing) vm.togglePlay()
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    val slot=(vm.settings["$id.mask"]?:-2f).toInt()
                    if (id == "natural") {
                        StudioChoice("Pintar zona", slot >= 0) { vm.paintEffectZone() }
                    } else if (id != "appear" && id != "impact" && id != "parallax") {
                        StudioChoice("Toda la imagen",slot==-2){vm.wholeEffectZone()}
                        StudioChoice("Pintar zona",slot>=0){vm.paintEffectZone()}
                    }
                    if (id == "tornado") StudioChoice("Colocar centro", vm.tool == Tool.ORIGIN) { vm.pickOrigin(id) }
                    val active=(vm.settings["$id.on"]?:0f)>.5f
                    StudioChoice(if(active) "Quitar" else "Activar",false){vm.toggleEffect(id)}
                }
                val variants=when(id){
                    "zonemotion"->listOf("Balanceo","Ondulación","Respiración")
                    "sky"->listOf("Día","Atardecer","Noche","Tormenta")
                    "water"->listOf("Ondas","Corriente","Reflejos")
                    "cam"->listOf("Acercar","Alejar","Desplazar","Girar","Temblar")
                    "mesh"->listOf("Ondulación","Respirar","Tela")
                    "natural"->listOf("Árbol","Bandera","Pasto","Cortina","Cabello","Ropa")
                    "gust"->listOf("Brisa","Viento","Fuerte","Tormenta")
                    "leaves"->listOf("Verdes","Secas","Otoño","Navidad")
                    "shore"->listOf("Suaves","Medias","Fuertes","Tormenta")
                    "rain"->listOf("Suave","Normal","Fuerte","Tormenta")
                    "snow"->listOf("Suave","Normal","Fuerte","Ventisca")
                    "dispersion"->listOf("Fragmentos","Pétalos","Polvo")
                    "tornado"->listOf("Remolino","Tornado")
                    "appear"->listOf("Humo","Ráfaga","Destello","Fundido")
                    "clouds3"->listOf("Día","Atardecer","Noche")
                    else->emptyList()
                }
                if(variants.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    variants.forEachIndexed{i,name->
                        val key=if(id=="cam") "cam.mode" else "$id.variant"
                        StudioChoice(name,(vm.settings[key]?:0f).toInt()==i){
                            if (id in setOf("gust", "leaves", "shore", "rain", "snow")) vm.applyEffectStyle(id, i)
                            else if (id == "natural") vm.applyNaturalPreset(i)
                            else vm.setSetting(key,i.toFloat())
                        }
                    }
                }
                if (id == "natural") {
                    val naturalIndex = (vm.settings["natural.variant"] ?: 0f).toInt().coerceIn(0, 5)
                    val naturalTip = listOf(
                        "Árbol: base firme; ramas y hojas se mueven con distinta fase.",
                        "Bandera: lado del poste fijo; el extremo libre ondula más.",
                        "Pasto: raíz fija abajo; cada grupo responde un poco diferente.",
                        "Cortina: parte superior fija; pliegues largos y suaves.",
                        "Cabello: raíz estable; las puntas reaccionan más al viento.",
                        "Ropa: unión al cuerpo firme; tela suelta con movimiento más pesado."
                    )[naturalIndex]
                    Text(naturalTip, color = StudioMuted, fontSize = 11.sp)
                    Text("Borde fijo", color = StudioText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf("Ninguno", "Izquierda", "Derecha", "Abajo", "Arriba").forEachIndexed { index, label ->
                            StudioChoice(label, (vm.settings["natural.anchor"] ?: 3f).toInt() == index) {
                                vm.setSetting("natural.anchor", index.toFloat())
                            }
                        }
                    }
                    Text("El borde fijo evita que una bandera se despegue del poste o que un árbol se mueva desde la raíz.",
                        color = StudioMuted, fontSize = 11.sp)
                }
                if (id == "bolt" && (vm.exportSettings.ambient["thunder"] ?: 0f) <= 0.01f) {
                    StudioSmallButton("Añadir sonido de trueno", Icons.Default.MusicNote, Modifier.fillMaxWidth()) {
                        vm.toggleAmbient("thunder")
                    }
                }
                if (id != "style") EffectTimingControls(vm, id)
                val hiddenTimelineParams = when (id) {
                    "gust" -> setOf("start", "dur")
                    "appear" -> setOf("start", "dur")
                    "impact" -> setOf("start", "cycles")
                    "bolt" -> setOf("cycles")
                    else -> emptySet()
                }
                val params=def.params.filter{ p ->
                    p.key !in listOf("zone","variant","mode","anchor") && p.key !in hiddenTimelineParams &&
                        !(id=="zonemotion" && (vm.settings["zonemotion.variant"]?:0f)>1.5f && p.key=="direction") &&
                        !(id=="cam" && (vm.settings["cam.mode"]?:0f).toInt()!=2 && p.key=="direction")
                }
                params.chunked(2).forEach{ pair ->
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        pair.forEach{p->Box(Modifier.weight(1f)){EffectParameter(vm,def,p)}}
                        if(pair.size==1) Spacer(Modifier.weight(1f))
                    }
                }
                if(id in setOf("rain","snow","sakura","fog","rays","energy","speed","leaves","embers","dust","bubbles","comet","smoke","gust","shore")) {
                    val defAngle = when (id) { "gust" -> 0f; else -> 90f }
                    LabeledSlider("Dirección",vm.settings["$id.direction"]?:defAngle,0f,360f,true,suffix="°"){vm.setSetting("$id.direction",it)}
                }
            }
        }
    }
}

@Composable
private fun EffectCard(id: String, title: String, active: Boolean, time: () -> Float,
                       onTap: () -> Unit, onAdd: () -> Unit, onSettings: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(Modifier.height(74.dp).clip(shape)
        .background(if (active) StudioPurple.copy(alpha = .16f) else StudioTile)
        .then(if (active) Modifier.border(1.5.dp, StudioGradient, shape) else Modifier)
        .pointerInput(id) { detectTapGestures(onTap = { onTap() }, onLongPress = { onSettings() }) }) {
        Column(Modifier.fillMaxSize().padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            EffectGlyph(id, time, active, Modifier.size(32.dp))
            Spacer(Modifier.height(4.dp))
            Text(title, color = if (active) StudioText else StudioText.copy(alpha = .85f), fontSize = 11.sp,
                lineHeight = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium)
        }
        if (active) {
            Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(7.dp).clip(CircleShape).background(StudioPink))
            if (id != "style" && id != "elements") Icon(Icons.Default.Add, "Añadir otra vez", tint = StudioText,
                modifier = Modifier.align(Alignment.TopStart).padding(3.dp).size(25.dp).clip(CircleShape)
                    .background(StudioPurple.copy(alpha = .35f)).clickable(onClick = onAdd).padding(4.dp))
            Icon(Icons.Default.Tune, "Ajustar", tint = StudioText, modifier = Modifier.align(Alignment.BottomEnd)
                .size(26.dp).clip(CircleShape).clickable(onClick = onSettings).padding(5.dp))
        }
    }
}

@Composable
private fun EffectTimingControls(vm: AppViewModel, id: String) {
    if (!vm.isEffectOn(id)) return
    val total = vm.exportSettings.loopSec.toFloat().coerceAtLeast(2f)
    val clips = vm.clipsForEffect(id)

    Text("En el vídeo", color = StudioText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        val whole = clips.any { it.startSec <= .01f && it.durationSec >= total - .02f }
        StudioChoice("Todo el vídeo", whole) { vm.addWholeVideoEffectClip(id) }
        StudioChoice("+ Otra vez", false) { vm.addEffectClip(id) }
    }

    if (clips.isEmpty()) {
        Text("Añade un bloque y colócalo en el segundo que quieras.", color = StudioMuted, fontSize = 11.sp)
        return
    }

    val selected = clips.firstOrNull { it.uid == vm.selectedTimelineClip } ?: clips.first()
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        clips.forEachIndexed { index, clip ->
            val start = String.format(java.util.Locale.US, "%.1f", clip.startSec)
            StudioChoice("${index + 1} · ${start}s", clip.uid == selected.uid) {
                vm.selectTimelineClip(clip.uid)
            }
        }
    }

    val end = (selected.startSec + selected.durationSec).coerceAtMost(total)
    Text(
        "Bloque ${clips.indexOfFirst { it.uid == selected.uid } + 1}  ·  " +
            "${String.format(java.util.Locale.US, "%.1f", selected.startSec)}s → " +
            "${String.format(java.util.Locale.US, "%.1f", end)}s",
        color = StudioMuted, fontSize = 11.sp
    )

    val maxStart = (total - .05f).coerceAtLeast(.05f)
    LabeledSlider("Inicio", selected.startSec, 0f, maxStart, false, suffix = " s") { newStart ->
        val newDur = selected.durationSec.coerceAtMost((total - newStart).coerceAtLeast(.05f))
        vm.setEffectClipTiming(selected.uid, newStart, newDur)
    }
    val maxDur = (total - selected.startSec).coerceAtLeast(.05f)
    LabeledSlider("Duración", selected.durationSec.coerceAtMost(maxDur), .05f, maxDur, false, suffix = " s") { newDur ->
        vm.setEffectClipTiming(selected.uid, selected.startSec, newDur)
    }
    StudioSmallButton("Eliminar este bloque", Icons.Default.DeleteOutline, Modifier.fillMaxWidth()) {
        vm.removeEffectClip(selected.uid)
    }
}

@Composable
private fun CharacterControls(vm: AppViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importCharacter(uri)
    }
    StudioSmallButton(if (vm.hasCharacter) "Cambiar personaje (PNG)" else "Elegir personaje (PNG)",
        Icons.Default.Person, Modifier.fillMaxWidth()) {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }
    Text(if (vm.hasCharacter) "Arrastra, pellizca y gira al personaje directamente sobre la imagen."
        else "Usa un PNG con fondo transparente (recortado en Paint Zeta o Ibis Paint).",
        color = StudioMuted, fontSize = 12.sp)
}

@Composable
private fun ElementsControls(vm: AppViewModel) {
    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
        elementNames.forEachIndexed{i,name->StudioButton(name,elementIcons[i],Modifier.width(75.dp).height(62.dp)){vm.addElement(i)}}
    }
    val slots=(0..3).filter{(vm.settings["element$it.on"]?:0f)>.5f}
    if(slots.isEmpty()) Text("Elige un elemento y colócalo sobre tu imagen.",color=StudioMuted,fontSize=12.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
        slots.forEach { i -> StudioChoice("${i+1} · ${elementNames[(vm.settings["element$i.type"]?:0f).toInt().coerceIn(0,5)]}",vm.selectedElement==i){vm.selectElement(i)} }
    }
    val slot=vm.selectedElement
    if(slot<0 || slot !in slots) return
    val id="element$slot"
    Row(verticalAlignment=Alignment.CenterVertically) {
        Text("Arrastra · pellizca · gira con dos dedos",color=StudioMuted,fontSize=11.sp,modifier=Modifier.weight(1f))
        IconButton(onClick={vm.setSetting("$id.on",0f);vm.selectElement(-1)}){Icon(Icons.Default.DeleteOutline,"Quitar",tint=StudioText)}
    }
    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
        Box(Modifier.weight(1f)){LabeledSlider("Opacidad",vm.settings["$id.opacity"]?:.7f,0f,1f,false){vm.setSetting("$id.opacity",it)}}
        Box(Modifier.weight(1f)){LabeledSlider("Velocidad",vm.settings["$id.cycles"]?:1f,1f,6f,true){vm.setSetting("$id.cycles",it)}}
    }
    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
        Box(Modifier.weight(1f)){LabeledSlider("Tamaño",vm.settings["$id.size"]?:.3f,.04f,1.5f,false){vm.setSetting("$id.size",it)}}
        Box(Modifier.weight(1f)){LabeledSlider("Giro",vm.settings["$id.rotation"]?:0f,-180f,180f,true){vm.setSetting("$id.rotation",it)}}
    }
}
