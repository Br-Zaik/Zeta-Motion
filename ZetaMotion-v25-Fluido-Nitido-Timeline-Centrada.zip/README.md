# Zeta Motion v25

Proyecto fuente Android de Zeta Motion para animar fondos de anime, manga, manhwa e ilustraciones.

La v25 se centra en **fluidez, nitidez y facilidad de uso**: vista previa adaptativa más nítida, respuesta a 60 fps durante gestos, familias Viento/Olas/Hojas/Lluvia/Nieve visibles directamente, Movimiento Natural con comportamiento automático por material, efectos nuevos centrados en la timeline y cuadro de exportación adaptable con botón fijo.

Consulta `README_V25.md` para los cambios. Compila el APK con `.github/workflows/build.yml`.
