package com.zeta.fondo.engine

import android.graphics.Bitmap
import android.opengl.GLES30
import android.opengl.GLUtils
import com.zeta.fondo.model.EffectTimeline
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Dibuja la imagen animada con el shader principal. Se usa igual en la vista
 * previa (GLSurfaceView) y en la exportación (superficie del codificador o FBO),
 * así lo que ves es lo que se exporta.
 * Debe crearse y usarse siempre en el hilo que tiene el contexto OpenGL.
 */
class FondoGl(private val vertSrc: String, private val fragSrc: String) {

    private var program = 0
    private var vao = 0
    private var vbo = 0
    private val tex = IntArray(6) // 0 imagen, 1 flujo, 2 congelar, 3 zona1, 4 zona2
    private val locs = HashMap<String, Int>()
    private var uploadedParams: RenderParams? = null
    private val maskBufs = arrayOfNulls<ByteBuffer>(MaskLayers.MAX_MASKS)
    private var atlasW = 0
    private var atlasH = 0

    private val charTex = IntArray(1)
    var charAspect = 1f
        private set

    var texW = 1
        private set
    var texH = 1
        private set

    fun init() {
        clearErrors()
        program = buildProgram(vertSrc, fragSrc)

        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0)
        vao = ids[0]
        GLES30.glGenBuffers(1, ids, 0)
        vbo = ids[0]
        GLES30.glBindVertexArray(vao)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        val quad = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val fb = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(quad).position(0)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, quad.size * 4, fb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 8, 0)
        GLES30.glBindVertexArray(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)

        GLES30.glGenTextures(6, tex, 0)

        // Texturas por defecto (vacías) para que el shader siempre tenga algo válido
        val px = ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder())
        px.put(byteArrayOf(20, 24, 48, -1)).position(0)
        setupTex(0, false)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, 1, 1, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, px)
        uploadFlowRaw(1, 1, ShortArray(2))
        for (i in 0..2) {
            val z = ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder())
            setupTex(2 + i, false)
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R8, 1, 1, 0, GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, z)
        }
        prepareMasks(4, 4)
        GLES30.glGenTextures(1, charTex, 0)
        uploadCharacter(null)
        checkGl("init")
    }

    private fun setupTex(i: Int, mipmap: Boolean) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + i)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex[i])
        GLES30.glTexParameteri(
            GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER,
            if (mipmap) GLES30.GL_LINEAR_MIPMAP_LINEAR else GLES30.GL_LINEAR
        )
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
    }

    /** Sube la imagen a su resolución real, con mipmaps para reducir sin serrucho. */
    fun uploadImage(bmp: Bitmap) {
        clearErrors()
        setupTex(0, true)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        texW = bmp.width
        texH = bmp.height
        checkGl("uploadImage")
    }

    /** Personaje PNG con transparencia para el efecto Aparición (null = vacío). */
    fun uploadCharacter(bmp: Bitmap?) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE6)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, charTex[0])
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        if (bmp == null || bmp.isRecycled) {
            val z = ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder())
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, 1, 1, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, z)
            charAspect = 1f
        } else {
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
            charAspect = bmp.width.toFloat() / bmp.height.coerceAtLeast(1)
        }
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
    }

    fun uploadFlow(d: FlowField.Data) = uploadFlowRaw(d.w, d.h, d.halfs)

    private fun uploadFlowRaw(w: Int, h: Int, halfs: ShortArray) {
        val buf = ByteBuffer.allocateDirect(halfs.size * 2).order(ByteOrder.nativeOrder())
        buf.asShortBuffer().put(halfs)
        buf.position(0)
        setupTex(1, false)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RG16F, w, h, 0, GLES30.GL_RG, GLES30.GL_HALF_FLOAT, buf)
        checkGl("uploadFlow")
    }

    /** Reserva todas las máscaras en una única textura-array GLES3, sin aumentar las unidades de sampler. */
    fun prepareMasks(w: Int, h: Int): Boolean {
        if (w == atlasW && h == atlasH) return false
        atlasW = w
        atlasH = h
        GLES30.glActiveTexture(GLES30.GL_TEXTURE5)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D_ARRAY, tex[5])
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D_ARRAY, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D_ARRAY, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D_ARRAY, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D_ARRAY, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        val empty = ByteBuffer.allocateDirect(w * h * MaskLayers.MAX_MASKS)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexImage3D(GLES30.GL_TEXTURE_2D_ARRAY, 0, GLES30.GL_R8,
            w, h, MaskLayers.MAX_MASKS, 0, GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, empty)
        checkGl("prepareMasks")
        return true
    }

    /** Sube una capa ALPHA_8, también al atlas de máscaras personalizadas. */
    fun uploadMask(layer: Int, bmp: Bitmap) {
        val size = bmp.rowBytes * bmp.height
        var buf = maskBufs[layer]
        if (buf == null || buf.capacity() != size) {
            buf = ByteBuffer.allocateDirect(size).order(ByteOrder.nativeOrder())
            maskBufs[layer] = buf
        }
        buf!!.position(0)
        bmp.copyPixelsToBuffer(buf)
        buf.position(0)
        prepareMasks(bmp.width, bmp.height)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ROW_LENGTH, bmp.rowBytes)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE5)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D_ARRAY, tex[5])
        GLES30.glTexSubImage3D(GLES30.GL_TEXTURE_2D_ARRAY, 0, 0, 0, layer,
            bmp.width, bmp.height, 1, GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, buf)
        if (layer <= 2) {
            buf.position(0)
            setupTex(2 + layer, false)
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R8, bmp.width, bmp.height, 0,
                GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, buf)
        }
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ROW_LENGTH, 0)
        checkGl("uploadMask")
    }

    private fun loc(name: String): Int = locs.getOrPut(name) { GLES30.glGetUniformLocation(program, name) }

    private fun u3(name: String, a: FloatArray) = GLES30.glUniform3f(loc(name), a[0], a[1], a[2])
    private fun u4(name: String, a: FloatArray) = GLES30.glUniform4f(loc(name), a[0], a[1], a[2], a[3])


    /**
     * Aplica solo los cambios que dependen del tiempo de la nueva línea de tiempo.
     * Los parámetros pesados siguen subiendo únicamente cuando cambia RenderParams.
     */
    private fun uploadTimelineOverrides(p: RenderParams, t: Float) {
        if (p.timeline.isEmpty()) return
        var boltLocal = -1f
        var boltSeed = 0f
        var impactLocal = -1f

        for ((id, clips) in p.timeline) {
            val sample = EffectTimeline.sample(clips, t, p.loopSec)
            val gate = sample.gate
            when (id) {
                "flow" -> GLES30.glUniform3f(loc("uFlow3"), p.flow[0] * gate, p.flow[1], p.flow[2])
                "drift" -> GLES30.glUniform2f(loc("uDrift"), p.drift[0] * gate, p.drift[1] * gate)
                "ripple" -> GLES30.glUniform3f(loc("uRipple"), p.ripple[0] * gate, p.ripple[1], p.ripple[2])
                "glint" -> GLES30.glUniform3f(loc("uGlint"), p.glint[0] * gate, p.glint[1], p.glint[2])
                "sway" -> GLES30.glUniform3f(loc("uSway"), p.sway[0] * gate, p.sway[1], p.sway[2])
                "heat" -> GLES30.glUniform3f(loc("uHeat"), p.heat[0] * gate, p.heat[1], p.heat[2])
                "rain" -> GLES30.glUniform4f(loc("uRain"), p.rain[0] * gate, p.rain[1], p.rain[2], p.rain[3])
                "snow" -> GLES30.glUniform4f(loc("uSnow"), p.snow[0] * gate, p.snow[1], p.snow[2], p.snow[3])
                "sakura" -> GLES30.glUniform4f(loc("uSakura"), p.sakura[0] * gate, p.sakura[1], p.sakura[2], p.sakura[3])
                "stars" -> GLES30.glUniform4f(loc("uStars"), p.stars[0] * gate, p.stars[1], p.stars[2], p.stars[3])
                "flies" -> GLES30.glUniform4f(loc("uFlies"), p.flies[0] * gate, p.flies[1], p.flies[2], p.flies[3])
                "fog" -> GLES30.glUniform4f(loc("uFog"), p.fog[0] * gate, p.fog[1], p.fog[2], p.fog[3])
                "rays" -> GLES30.glUniform4f(loc("uRays"), p.rays[0] * gate, p.rays[1], p.rays[2], p.rays[3])
                "energy" -> GLES30.glUniform4f(loc("uEnergy"), p.energy[0] * gate, p.energy[1], p.energy[2], p.energy[3])
                "speed" -> GLES30.glUniform4f(loc("uSpeed"), p.speed[0] * gate, p.speed[1], p.speed[2], p.speed[3])
                "cam" -> GLES30.glUniform3f(loc("uCam"), p.cam[0] * gate, p.cam[1] * gate, p.cam[2])
                "zonemotion" -> p.studio["uZoneMotion"]?.let { GLES30.glUniform4f(loc("uZoneMotion"), it[0] * gate, it[1], it[2], it[3]) }
                "sky" -> p.studio["uStudioSky"]?.let { GLES30.glUniform4f(loc("uStudioSky"), it[0] * gate, it[1], it[2], it[3]) }
                "water" -> p.studio["uStudioWater"]?.let { GLES30.glUniform4f(loc("uStudioWater"), it[0] * gate, it[1], it[2], it[3]) }
                "dispersion" -> p.studio["uStudioDispersion"]?.let { GLES30.glUniform4f(loc("uStudioDispersion"), it[0] * gate, it[1], it[2], it[3]) }
                "bolt" -> p.studio["uBolt"]?.let {
                    GLES30.glUniform4f(loc("uBolt"), it[0] * gate, it[1], it[2], it[3])
                    if (sample.clip != null && gate > 0f) {
                        boltLocal = sample.localSec
                        boltSeed = (sample.clip.uid % 997L).toFloat()
                    }
                }
                "gust" -> p.studio["uGust"]?.let {
                    // La posición y duración las gobierna cada bloque, no un único start/dur global.
                    GLES30.glUniform4f(loc("uGust"), it[0] * gate, 0f, 1f, it[3])
                }
                "tornado" -> p.studio["uTornado"]?.let { GLES30.glUniform4f(loc("uTornado"), it[0] * gate, it[1], it[2], it[3]) }
                "appear" -> p.studio["uAppear"]?.let {
                    val c = sample.clip
                    val start = c?.let { (it.startSec / p.loopSec).coerceIn(0f, .999f) } ?: it[1]
                    val baseTransition = it[2]
                    val trans = c?.let { clip -> minOf(clip.durationSec / p.loopSec, baseTransition).coerceAtLeast(.02f) } ?: baseTransition
                    GLES30.glUniform4f(loc("uAppear"), it[0] * gate, start, trans, it[3])
                }
                "clouds3" -> p.studio["uClouds3"]?.let { GLES30.glUniform4f(loc("uClouds3"), it[0] * gate, it[1], it[2], it[3]) }
                "shore" -> p.studio["uShore"]?.let { GLES30.glUniform4f(loc("uShore"), it[0] * gate, it[1], it[2], it[3]) }
                "sunpath" -> p.studio["uSunpath"]?.let { GLES30.glUniform4f(loc("uSunpath"), it[0] * gate, it[1], it[2], it[3]) }
                "impact" -> p.studio["uImpact"]?.let {
                    GLES30.glUniform4f(loc("uImpact"), it[0] * gate, it[1], it[2], 1f)
                    if (sample.clip != null && gate > 0f) impactLocal = sample.localSec
                }
                else -> p.extra[id]?.let { GLES30.glUniform4f(loc("uFx${id.replaceFirstChar { ch -> ch.uppercaseChar() }}"), it[0] * gate, it[1], it[2], it[3]) }
            }
        }

        if (p.timeline.containsKey("bolt") || p.timeline.containsKey("impact")) {
            GLES30.glUniform4f(loc("uLoopInfo"), p.loopSec, boltLocal, impactLocal, boltSeed)
        }
    }

    /**
     * view = [offsetX, offsetY, scaleX, scaleY] en coordenadas de imagen.
     * flipY: para leer píxeles con glReadPixels (PNG). rotate: vídeo vertical guardado en horizontal.
     */
    fun draw(
        p: RenderParams, t: Float, vw: Int, vh: Int, view: FloatArray,
        flipY: Boolean, rotate: Boolean, showMask: Boolean, overlayOnly: Boolean,
        activeMask: Int = -1,
        vx0: Int = 0,
        vy0: Int = 0
    ) {
        GLES30.glViewport(vx0, vy0, vw, vh)
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glClearColor(0f, 0f, 0f, 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        GLES30.glUseProgram(program)

        for (i in 0 until 5) {
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + i)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex[i])
        }
        GLES30.glUniform1i(loc("uImage"), 0)
        GLES30.glUniform1i(loc("uFlow"), 1)
        GLES30.glUniform1i(loc("uFreeze"), 2)
        GLES30.glUniform1i(loc("uZone1"), 3)
        GLES30.glUniform1i(loc("uZone2"), 4)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE5)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D_ARRAY, tex[5])
        GLES30.glUniform1i(loc("uMasks"), 5)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE6)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, charTex[0])
        GLES30.glUniform1i(loc("uCharacter"), 6)
        GLES30.glUniform1f(loc("uCharAspect"), charAspect)

        GLES30.glUniform2f(loc("uViewOffset"), view[0], view[1])
        GLES30.glUniform2f(loc("uViewScale"), view[2], view[3])
        GLES30.glUniform1f(loc("uFlipY"), if (flipY) 1f else 0f)
        GLES30.glUniform1f(loc("uRotate"), if (rotate) 1f else 0f)
        GLES30.glUniform1f(loc("uT"), t)
        GLES30.glUniform2f(loc("uTexSize"), texW.toFloat(), texH.toFloat())
        GLES30.glUniform1f(loc("uShowMask"), if (showMask) 1f else 0f)
        GLES30.glUniform1i(loc("uActiveMask"), activeMask)
        GLES30.glUniform1f(loc("uOverlayOnly"), if (overlayOnly) 1f else 0f)
        // Los parámetros son inmutables; no se vuelven a subir decenas de uniforms
        // en cada cuadro cuando únicamente cambia el tiempo de la animación.
        if (uploadedParams !== p) {
        p.studio.forEach { (name, value) -> u4(name, value) }
        GLES30.glUniform1f(loc("uAspect"), p.aspect)
        GLES30.glUniform1f(loc("uMono"), p.mono)
        GLES30.glUniform1f(loc("uPixelSnap"), p.snap)
        u3("uFlow3", p.flow)
        GLES30.glUniform2f(loc("uDrift"), p.drift[0], p.drift[1])
        u3("uRipple", p.ripple)
        u3("uGlint", p.glint)
        u3("uSway", p.sway)
        u3("uHeat", p.heat)
        u4("uRain", p.rain)
        u4("uSnow", p.snow)
        u4("uSakura", p.sakura)
        u4("uStars", p.stars)
        u4("uFlies", p.flies)
        u4("uFog", p.fog)
        u4("uRays", p.rays)
        u4("uEnergy", p.energy)
        u4("uSpeed", p.speed)
        u3("uCam", p.cam)
        p.motion.forEach { (id, value) -> u4("uMotion${id.replaceFirstChar { it.uppercaseChar() }}", value) }
        p.extra.forEach { (id, value) -> u4("uFx${id.replaceFirstChar { it.uppercaseChar() }}", value) }
        p.copyMotion.forEach { (id, value) -> u4("uMotion${id.replaceFirstChar { it.uppercaseChar() }}Copy", value) }
        p.copyExtra.forEach { (id, value) -> u4("uFx${id.replaceFirstChar { it.uppercaseChar() }}Copy", value) }
        p.copyMasks.forEach { (id, mask) ->
            GLES30.glUniform1i(loc("uMask${id.replaceFirstChar { it.uppercaseChar() }}Copy"), mask)
        }
        p.effectMasks.forEach { (id, mask) ->
            GLES30.glUniform1i(loc("uMask${id.replaceFirstChar { it.uppercaseChar() }}"), mask)
        }
        uploadedParams = p
        }
        uploadTimelineOverrides(p, t)

        GLES30.glBindVertexArray(vao)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        GLES30.glBindVertexArray(0)
    }

    fun maxTextureSize(): Int {
        val a = IntArray(1)
        GLES30.glGetIntegerv(GLES30.GL_MAX_TEXTURE_SIZE, a, 0)
        return if (a[0] > 0) a[0] else 2048
    }

    fun release() {
        if (program != 0) GLES30.glDeleteProgram(program)
        GLES30.glDeleteTextures(6, tex, 0)
        GLES30.glDeleteTextures(1, charTex, 0)
        GLES30.glDeleteBuffers(1, intArrayOf(vbo), 0)
        GLES30.glDeleteVertexArrays(1, intArrayOf(vao), 0)
        program = 0
    }

    private fun clearErrors() {
        var guard = 0
        while (GLES30.glGetError() != GLES30.GL_NO_ERROR && guard < 16) guard++
    }

    private fun checkGl(where: String) {
        val e = GLES30.glGetError()
        if (e != GLES30.GL_NO_ERROR) {
            throw RuntimeException("OpenGL error 0x${Integer.toHexString(e)} en $where")
        }
    }

    companion object {
        fun buildProgram(v: String, f: String): Int {
            val vs = compile(GLES30.GL_VERTEX_SHADER, v)
            val fs = compile(GLES30.GL_FRAGMENT_SHADER, f)
            val prog = GLES30.glCreateProgram()
            GLES30.glAttachShader(prog, vs)
            GLES30.glAttachShader(prog, fs)
            GLES30.glLinkProgram(prog)
            val ok = IntArray(1)
            GLES30.glGetProgramiv(prog, GLES30.GL_LINK_STATUS, ok, 0)
            GLES30.glDeleteShader(vs)
            GLES30.glDeleteShader(fs)
            if (ok[0] == 0) {
                val log = GLES30.glGetProgramInfoLog(prog)
                GLES30.glDeleteProgram(prog)
                throw RuntimeException("Error al enlazar shaders: $log")
            }
            return prog
        }

        private fun compile(type: Int, src: String): Int {
            val s = GLES30.glCreateShader(type)
            GLES30.glShaderSource(s, src)
            GLES30.glCompileShader(s)
            val ok = IntArray(1)
            GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) {
                val log = GLES30.glGetShaderInfoLog(s)
                GLES30.glDeleteShader(s)
                val kind = if (type == GLES30.GL_VERTEX_SHADER) "vértices" else "fragmentos"
                throw RuntimeException("Error en el shader de $kind: $log")
            }
            return s
        }
    }
}
