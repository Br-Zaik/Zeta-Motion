# Zeta Motion v35

Animación 2D/2.5D para ilustraciones y fondos. Revisa [README_V35.md](README_V35.md) para nuevas funciones, instrucciones, limitaciones y pruebas.
