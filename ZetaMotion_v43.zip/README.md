> **Versión actual: v43 — lee LEEME_V43.md** (cambios, compilación y pruebas).

# Zeta Motion v35.1 — APK firmado

Antes de instalar lee [LEEME_INSTALACION_ESTABLE.md](LEEME_INSTALACION_ESTABLE.md).

El código conserva los efectos y herramientas de v35.
