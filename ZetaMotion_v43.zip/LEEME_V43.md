# Zeta Motion v43 (versionCode 44 · 43.0.0)

Corrige la línea de tiempo según las capturas de la v42: música más larga que el vídeo, bloques que con zoom terminaban antes de tiempo, y la falta de imán y vibración en la línea blanca.

## Causas encontradas
- **Música más larga que el vídeo:**
  - el botón «+ Agregar música» recibía el «ocupar todo el ancho» de su fila y medía siempre la pantalla entera;
  - el arreglo de la v42 no tenía efecto, y no lo detecté porque aquí no puedo ver la interfaz en marcha.
- **Con zoom, el bloque se cortaba:**
  - un bloque más largo que la pantalla se dibujaba con el ancho de la pantalla;
  - en la captura, «Nieve» (0 a 3,8 s) aparecía terminando en ~2,7 s, por eso no se podía llevar su borde a la línea blanca.
  - Lo mismo pasaba con la pista de música.
- **Imán:**
  - solo existía al mover un bloque, no al recortarlo;
  - su distancia era de 10 píxeles, casi nada en un teléfono;
  - no había vibración.

## Arreglos
- **Medidas reales:** música y bloques miden exactamente lo que dura su tiempo, a cualquier zoom. La parte que queda fuera de la pantalla simplemente no se dibuja, y su final real aparece al desplazarte.
- **Imán como en CapCut**, a 12 dp a cualquier zoom:
  - al recortar un bloque, su borde se pega a la línea blanca, a los bordes de otros bloques y al inicio o final del vídeo;
  - al mover un bloque, se pega igual;
  - al recorrer la línea de tiempo con el dedo, la línea blanca se pega a los bordes de los bloques.
- **Aviso:** cada vez que algo se pega, el teléfono vibra un toque corto y la línea blanca se pone **amarilla** y más gruesa. Para despegarlo, sigue arrastrando.
- La vibración usa la «respuesta táctil» del sistema: si en tu teléfono está apagada en Ajustes › Sonido y vibración, no vibrará, pero la línea amarilla sí se verá.

## Pruebas realizadas (y las que faltan)
- Comprobación de tipos de todo el código Kotlin (sin errores).
- 98 pruebas JVM, todas superadas. Las 3 nuevas usan los números de tu captura (214 px por segundo, pantalla de 576 px, línea a los 2,3 s):
  - el borde se pega a la línea blanca a 13 px y no a 70 px;
  - se pega a los bordes de otros bloques;
  - «Nieve» de 0 a 3,8 s ocupa toda la pantalla (la v42 lo acababa a 372 px);
  - recortado hasta la línea, su final cae justo en el centro.
- El escenario simulado del editor sigue correcto.

**No probado:**
- No se ha compilado con Gradle ni se ha probado en un teléfono.
- Falta comprobar en el teléfono:
  - la vibración;
  - la línea amarilla;
  - el largo de la música y de los bloques con zoom.
