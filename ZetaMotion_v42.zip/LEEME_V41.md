# Zeta Motion v41 (versionCode 42 · 41.0.0)

Corrige la carga lenta con la vista previa negra y el aviso «Zeta Motion no responde», y reorganiza el editor como un editor de vídeo: línea de tiempo que se desplaza bajo un cabezal fijo, barra principal con audio, catálogo de efectos solo con texto, y hojas de Ajustar, Color y Exportar más simples. Se conservan los proyectos guardados y todos los efectos.

## Cómo compilar
- Igual que la v40: GitHub Actions (el flujo ya se llama v41) o `./gradlew assembleDebug` en Android Studio.
- Firma para Google Play: los 4 secretos `ZETA_*`, como en LEEME_V36.md.

## Causa de la carga lenta, la pantalla negra y el «no responde»
- El shader del motor tiene todos los efectos en un único programa muy grande. La v40 lo compilaba en el hilo de dibujo al abrir el editor (alrededor de 1 s en un PC; en teléfonos puede tardar bastante más).
- Mientras tanto la vista previa quedaba negra, y si Android redimensionaba o pausaba la vista en ese momento, el hilo principal esperaba al de dibujo: de ahí el aviso de «no responde».
- Además, una foto con rotación EXIF se guardaba como PNG sin pérdida, y comprimir un PNG de 12 MP tarda varios segundos.

## Arreglos del motor
- **Solo se compila lo que se usa:** cada combinación de efectos encendidos tiene su propia versión del shader (`#ifdef FX_…`). Una versión típica compila unas 8 veces más rápido que el programa completo (0,12 s frente a 1,04 s de media en el PC de pruebas).
- **Compilación en segundo plano:** se hace en un hilo aparte con un contexto OpenGL compartido. La imagen aparece enseguida y, mientras se prepara un efecto nuevo, la vista previa sigue mostrando la imagen.
- **Caché:** las versiones compiladas se guardan en el teléfono (hasta 24), así que la segunda vez abren al instante. Los archivos de versiones anteriores se borran solos.
- **Mismo resultado:** todas las versiones comparten la misma disposición de parámetros, y la exportación usa el mismo shader que la vista previa.
- **Importar fotos giradas:** se guardan como JPEG de calidad 98 (en vez de PNG) y las imágenes de 8K o más se reducen al leerlas para no agotar la memoria.

## Editor
- **Línea de tiempo:**
  - el cabezal (la línea blanca) queda fijo en el centro y lo que se mueve es la línea de tiempo;
  - se arrastra a los lados con inercia y se puede ir antes del inicio y después del final de la imagen;
  - pellizcar cambia el zoom;
  - regla con tiempos, pista de la imagen con miniaturas, pista de audio («+ Agregar música») y pistas de efectos.
- **Pista de la imagen:** se toca para seleccionarla (Duración, Formato, Ajustar, Animar, Proteger, Efectos). Su tirador derecho cambia la duración del vídeo.
- **Barra principal:** Animar, Proteger, Efectos, Audio y Ajustes. Cada barra secundaria tiene «‹» para volver.
- **Bloques de efecto:** se toca un bloque para seleccionarlo y aparecen Ajustar, Mover, Dividir, Duplicar, Sustituir, Delante/Detrás y Eliminar. Se arrastra para moverlo, con tiradores en los dos extremos. Deshacer y rehacer funcionan como en la v40.
- **Tiempo bajo el lienzo:** formato `00:01.5 / 00:06`.

## Efectos
- **Catálogo solo con texto:** las categorías son pestañas de texto subrayadas, sin iconos («Activos n» aparece cuando hay efectos encendidos).
- **Cuadrícula:** «Ninguno» en primer lugar y miniaturas animadas con el nombre debajo.
- **Probar y ajustar:**
  - tocar una miniatura la prueba sobre tu imagen (borde blanco);
  - tocarla otra vez, o tocar «Ajustar» sobre ella, abre sus ajustes;
  - «Ninguno» descarta la prueba;
  - ✓ aplica y vuelve a la línea de tiempo.
- **Ajustar un efecto:**
  - arriba: «‹» (volver al catálogo) o «✕» (descartar), «↺ Restablecer», el nombre del efecto y ✓;
  - debajo, las secciones en texto (Ajustes, Estilo, Color, Tiempo, Zona) y sus controles;
  - si el efecto está seleccionado en la línea de tiempo, Restablecer solo afecta a ese bloque.

## Color (Ajustes › Ajustar)
- Arriba, la fila de ajustes: Brillo, Contraste, Saturación, Tono, Exposición, Nitidez, Viñeta, etc. Un punto rosa marca los que ya cambiaste.
- Abajo, un único deslizador para el ajuste elegido, con su valor (−50…50, o 0…100 en los que solo suben) y un botón para devolver solo ese ajuste a cero.
- «Restablecer» arriba devuelve todo el color a cero.

## Audio
- Se abre con Audio en la barra principal o con «+ Agregar música» en la línea de tiempo.
- Sirve para importar música, recortarla y añadir sonidos de ambiente (igual que antes).

## Exportar
- **Deslizadores con marcas:**
  - Resolución: 720p, 1080p, 2K o 4K. Las que tu teléfono no puede codificar se ven atenuadas;
  - Cuadros por segundo: 24, 25, 30, 50 o 60;
  - Tasa de bits: Alta, Máxima o Extrema.
- **Debajo:** duración, tamaño estimado del archivo y el resumen (resolución · fps · segundos · formato).
- **Opciones avanzadas** (plegadas): QHD, Original, tamaño personalizado, PNG, códec, repeticiones y «solo efectos».
- Los deslizadores de toda la app tienen ahora botón blanco y tramo blanco.

## Pruebas realizadas (y las que faltan)
Hechas en el entorno de desarrollo, sin teléfono:
- Comprobación de tipos de todo el código Kotlin contra las API de Android y Compose (sin errores).
- 95 pruebas JVM, todas superadas, incluidas las nuevas de variantes del shader:
  - la disposición de parámetros coincide con la de un driver OpenGL ES 3 real (Mesa);
  - cada efecto tiene su bloque en el shader;
  - los parámetros piden solo los efectos encendidos.
- Escenario simulado del editor:
  - flujos de la v40: mover, recortar, duplicar, dividir, sustituir, deshacer y rehacer;
  - nuevo flujo del catálogo: probar, Ninguno, Ajustar, Restablecer, ✓ y duración.
- Render con Mesa (OpenGL ES 3 por software) de las 66 versiones del shader. Cada una da los mismos píxeles que el programa completo con el mismo efecto.

**No probado:**
- No se ha compilado con Gradle ni se ha instalado el APK, y no se ha probado en ningún teléfono o emulador.
- Falta comprobar en el teléfono:
  - tiempo de apertura de una imagen;
  - que no aparezca «no responde»;
  - fluidez al arrastrar la línea de tiempo;
  - aspecto de las hojas nuevas;
  - exportación a 25 y 50 fps.
- Si el teléfono no permite el contexto compartido en segundo plano, la app compila en el hilo de dibujo cuando la vista está quieta. Sería más lento, pero sigue funcionando.
