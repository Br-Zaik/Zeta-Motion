"""Zeta Motion v40 · Regresión visual del shader REAL (Mesa/EGL, sin teléfono).

Comprueba humo, fuego y explosión nuevos:
  - el shader compila y enlaza (GLSL ES 3.00);
  - cada forma/variante se ve y es distinta de las demás;
  - el humo y el fuego cierran el bucle sin salto (cuadro 0 == cuadro 1);
  - el humo y la explosión no salen de la zona pintada;
  - intensidad 0 devuelve exactamente la imagen original;
  - la explosión tiene fases (destello, bola, humo residual que se disipa).
Uso:  python3 tools/check_v40_fx.py [imagen.png]   (sin imagen usa una de prueba sintética)
Guarda hojas de contacto en checks/v40_*.png
"""
import math, os, sys
from pathlib import Path
import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent))
from zeta_render import ZetaRenderer

ROOT = Path(__file__).resolve().parents[1]
SHADERS = str(ROOT / 'app/src/main/assets/shaders')
OUT = ROOT / 'checks'
OUT.mkdir(exist_ok=True)
W, H = 192, 320


def synthetic():
    y, x = np.mgrid[0:H, 0:W]
    img = np.zeros((H, W, 3), dtype=np.float32)
    img[..., 0] = 0.55 + 0.35 * (y / H)
    img[..., 1] = 0.70 + 0.20 * (x / W)
    img[..., 2] = 0.95 - 0.25 * (y / H)
    face = ((x - W * .5) / (W * .22)) ** 2 + ((y - H * .45) / (H * .18)) ** 2 < 1
    img[face] = [0.97, 0.88, 0.78]
    img[((x // 8 + y // 8) % 2 == 0) & (y > H * .75)] *= 0.85
    return Image.fromarray((img * 255).astype('uint8'))


src = sys.argv[1] if len(sys.argv) > 1 else synthetic()
r = ZetaRenderer(SHADERS, src, W, H)
print('shader: compila y enlaza', flush=True)
mh, mw = r.img_h // 2, r.img_w // 2
yy, xx = np.mgrid[0:mh, 0:mw]
left = np.where(xx < mw // 2, 255, 0).astype('uint8')
fire_zone = ((((xx / mw - .5) / .25) ** 2 + ((yy / mh - .86) / .06) ** 2) < 1).astype('uint8') * 255
r.set_masks({3: left, 4: fire_zone})
base = r.render(.3).astype(int)
fails = []


def ok(cond, msg):
    print(('  OK  ' if cond else '  FALLO ') + msg, flush=True)
    if not cond:
        fails.append(msg)


def diff(a, b):
    return np.abs(a.astype(int) - b.astype(int))[..., :3]


def motion(name, deg, ox, oy):
    r.put('uMotion' + name, [math.cos(math.radians(deg)), math.sin(math.radians(deg)), ox, oy])


# ---------------------------------------------------------------- humo
print('Humo')
sheet = []
imgs = []
for shape in range(4):
    for fill in (0, 1):
        r.put('uFxSmoke', [0.8, 3, 1, 0]); r.put('uSmokeShape', [shape, .5, .35, fill])
        r.put('uSmokeControl', [0, .95, .55, 1]); motion('Smoke', 270 if shape != 3 else 0, .45, .85)
        a = r.render(.3)
        d = diff(a, base)
        ok(d.mean() > .3, f'forma {shape} {"zona" if fill else "columna"}: visible ({d.mean():.2f})')
        ok(diff(r.render(0.0), r.render(1.0)).max() <= 2, f'forma {shape} {"zona" if fill else "columna"}: bucle sin salto')
        imgs.append(a.astype(int)); sheet.append(a)
ok(all(np.abs(imgs[0] - im).mean() > .2 for im in imgs[2::2]), 'las formas del humo son distintas')
# zona pintada (mitad izquierda) = sin humo a la derecha
r.put('uMaskSmoke', 3); r.put('uSmokeShape', [0, .5, .35, 1]); motion('Smoke', 270, .45, .85)
d = diff(r.render(.3), base)
ok(d[:, W // 2 + 6:].max() == 0 and d[:, :W // 2 - 6].mean() > .2, 'humo limitado a la zona pintada')
r.put('uMaskSmoke', -2)
r.put('uFxSmoke', [0, 3, 1, 0])
ok(np.array_equal(r.render(.3), base.astype('uint8')), 'humo a 0: imagen original intacta')
Image.fromarray(np.concatenate(sheet, axis=1)).save(OUT / 'v40_humo.png')

# ---------------------------------------------------------------- fuego
print('Fuego')
sheet = []
for shape in range(5):
    for zone in (True, False):
        r.put('uFxFlame', [0.9, 1, 2, 0]); r.put('uFlameShape', [shape, .5, .25, .5]); r.put('uFlameExtra', [.6, .3, 0, 0])
        if zone:
            r.put('uMaskFlame', 4); r.put('uFlameBox', [.25, .80, .75, .92])
        else:
            r.put('uMaskFlame', -2); r.put('uFlameBox', [0, 0, 0, 0])
        a = r.render(.3)
        d = diff(a, base)
        ok(d.mean() > .3, f'forma {shape} {"zona" if zone else "imagen"}: visible ({d.mean():.2f})')
        ok(diff(r.render(0.0), r.render(1.0)).max() <= 2, f'forma {shape}: bucle sin salto')
        if not zone:
            ok(d[:int(H * .30)].mean() < 0.6, f'forma {shape}: sin zona no cubre la parte alta de la imagen')
        sheet.append(a)
r.put('uFxFlame', [0, 1, 2, 0])
ok(np.array_equal(r.render(.3), base.astype('uint8')), 'fuego a 0: imagen original intacta')
Image.fromarray(np.concatenate(sheet, axis=1)).save(OUT / 'v40_fuego.png')

# ---------------------------------------------------------------- explosión
print('Explosión')
sheet = []
for shape in range(4):
    r.put('uFxBlast', [0.9, .55, 1, 0]); r.put('uBlastShape', [shape, .8, .7, 0]); r.put('uBlastMore', [0, .65, .5, 0])
    motion('Blast', 0, .5, .45)
    frames = []
    for ph in (.04, .15, .3, .5, .75, .97):
        r.put('uEventPhase', [ph, -1, -1, -1])
        frames.append(r.render(.3))
    amounts = [diff(f, base).mean() for f in frames]
    ok(all(a > .3 for a in amounts[:4]), f'forma {shape}: visible en sus fases {[round(a, 1) for a in amounts]}')
    ok(amounts[-1] < amounts[2], f'forma {shape}: se disipa al final')
    ok(np.abs(frames[1].astype(int) - frames[3].astype(int)).mean() > 1, f'forma {shape}: cambia con el tiempo')
    sheet.append(np.concatenate(frames, axis=0))
r.put('uEventPhase', [.3, -1, -1, -1]); r.put('uBlastShape', [0, .8, .7, 0])
r.put('uMaskBlast', 3); motion('Blast', 0, .25, .45)
d = diff(r.render(.3), base)
ok(d[:, W // 2 + 6:].max() == 0, 'explosión limitada a la zona pintada')
r.put('uMaskBlast', -2)
r.put('uFxBlast', [0, .55, 1, 0]); r.put('uEventPhase', [-1, -1, -1, -1])
ok(np.array_equal(r.render(.3), base.astype('uint8')), 'explosión a 0: imagen original intacta')
Image.fromarray(np.concatenate(sheet, axis=1)).save(OUT / 'v40_explosion.png')

print('\nRESULTADO:', 'TODO CORRECTO' if not fails else f'{len(fails)} fallos')
sys.exit(1 if fails else 0)
