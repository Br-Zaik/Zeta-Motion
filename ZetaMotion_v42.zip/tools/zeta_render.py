"""Render real Zeta Motion shaders (fondo.vert/fondo.frag) headless with Mesa EGL + GLES3.

Uniform block "ZetaParams" is filled through queried std140 offsets, exactly like FondoGl.
Usage:
    r = ZetaRenderer(shader_dir, image_path, W, H)
    r.set_block({'uFxSmoke': [..4], 'uMaskSmoke': -2, ...})
    arr = r.render(t)
"""
import ctypes as C, os
import numpy as np
from PIL import Image

os.environ.setdefault('EGL_PLATFORM', 'surfaceless')
os.environ.setdefault('LIBGL_ALWAYS_SOFTWARE', '1')
E = C.CDLL('libEGL.so.1')
I = C.c_int; U = C.c_uint; P = C.c_void_p; F = C.c_float
E.eglGetProcAddress.restype = P
E.eglGetProcAddress.argtypes = [C.c_char_p]


def _egl(name, rest, args):
    f = getattr(E, name); f.restype = rest; f.argtypes = args; return f


_GL = {}


def _gl(name, rest, args):
    f = C.CFUNCTYPE(rest, *args)(E.eglGetProcAddress(name.encode()))
    _GL[name] = f
    return f


class ZetaRenderer:
    def __init__(self, shader_dir, image, W=256, H=256, masks=None):
        self.W, self.H = W, H
        d = _egl('eglGetDisplay', P, [P])(None)
        ma, mi = I(), I()
        assert _egl('eglInitialize', U, [P, C.POINTER(I), C.POINTER(I)])(d, C.byref(ma), C.byref(mi))
        assert _egl('eglBindAPI', U, [U])(0x30A0)
        attrs = (I * 13)(0x3024, 8, 0x3023, 8, 0x3022, 8, 0x3033, 1, 0x3040, 0x40, 0x3021, 8, 0x3038)
        cfg = P(); n = I()
        assert _egl('eglChooseConfig', U, [P, C.POINTER(I), C.POINTER(P), I, C.POINTER(I)])(d, attrs, C.byref(cfg), 1, C.byref(n))
        surf = _egl('eglCreatePbufferSurface', P, [P, P, C.POINTER(I)])(d, cfg, (I * 5)(0x3057, W, 0x3056, H, 0x3038))
        ctx = _egl('eglCreateContext', P, [P, P, P, C.POINTER(I)])(d, cfg, None, (I * 3)(0x3098, 3, 0x3038))
        assert ctx and _egl('eglMakeCurrent', U, [P, P, P, P])(d, surf, surf, ctx)
        g = {}
        for name, ret, args in [
            ('glCreateShader', U, [U]), ('glShaderSource', None, [U, I, C.POINTER(C.c_char_p), P]),
            ('glCompileShader', None, [U]), ('glGetShaderiv', None, [U, U, C.POINTER(I)]),
            ('glGetShaderInfoLog', None, [U, I, P, P]), ('glCreateProgram', U, []),
            ('glAttachShader', None, [U, U]), ('glLinkProgram', None, [U]),
            ('glGetProgramiv', None, [U, U, C.POINTER(I)]), ('glGetProgramInfoLog', None, [U, I, P, P]),
            ('glUseProgram', None, [U]), ('glGetUniformLocation', I, [U, C.c_char_p]),
            ('glUniform1f', None, [I, F]), ('glUniform1i', None, [I, I]), ('glUniform2f', None, [I, F, F]),
            ('glGenTextures', None, [I, C.POINTER(U)]), ('glBindTexture', None, [U, U]),
            ('glActiveTexture', None, [U]), ('glTexParameteri', None, [U, U, I]),
            ('glTexImage2D', None, [U, I, I, I, I, I, U, U, P]),
            ('glTexImage3D', None, [U, I, I, I, I, I, I, U, U, P]),
            ('glGenerateMipmap', None, [U]),
            ('glGenVertexArrays', None, [I, C.POINTER(U)]), ('glBindVertexArray', None, [U]),
            ('glGenBuffers', None, [I, C.POINTER(U)]), ('glBindBuffer', None, [U, U]),
            ('glBufferData', None, [U, C.c_ssize_t, P, U]), ('glEnableVertexAttribArray', None, [U]),
            ('glVertexAttribPointer', None, [U, I, U, U, I, P]), ('glViewport', None, [I, I, I, I]),
            ('glDrawArrays', None, [U, I, I]), ('glReadPixels', None, [I, I, I, I, U, U, P]),
            ('glGetError', U, []), ('glFinish', None, []), ('glPixelStorei', None, [U, I]),
            ('glGetUniformBlockIndex', U, [U, C.c_char_p]),
            ('glGetActiveUniformBlockiv', None, [U, U, U, C.POINTER(I)]),
            ('glUniformBlockBinding', None, [U, U, U]), ('glBindBufferBase', None, [U, U, U]),
            ('glGetUniformIndices', None, [U, I, C.POINTER(C.c_char_p), C.POINTER(U)]),
            ('glGetActiveUniformsiv', None, [U, I, C.POINTER(U), U, C.POINTER(I)]),
        ]:
            g[name] = _gl(name, ret, args)
        self.g = g
        self.shader_dir = shader_dir
        prog = g['glCreateProgram']()
        for kind, fname in [(0x8B31, 'fondo.vert'), (0x8B30, 'fondo.frag')]:
            sh = g['glCreateShader'](kind)
            src = C.c_char_p(open(os.path.join(shader_dir, fname), 'rb').read())
            g['glShaderSource'](sh, 1, C.byref(src), None)
            g['glCompileShader'](sh)
            ok = I(); g['glGetShaderiv'](sh, 0x8B81, C.byref(ok))
            if not ok.value:
                log = C.create_string_buffer(40000); g['glGetShaderInfoLog'](sh, 40000, None, log)
                raise RuntimeError(fname + ' compile failed:\n' + log.value.decode())
            g['glAttachShader'](prog, sh)
        g['glLinkProgram'](prog)
        ok = I(); g['glGetProgramiv'](prog, 0x8B82, C.byref(ok))
        if not ok.value:
            log = C.create_string_buffer(40000); g['glGetProgramInfoLog'](prog, 40000, None, log)
            raise RuntimeError('link failed:\n' + log.value.decode())
        self.prog = prog
        g['glUseProgram'](prog)
        idx = g['glGetUniformBlockIndex'](prog, b'ZetaParams')
        sz = I(); g['glGetActiveUniformBlockiv'](prog, idx, 0x8A40, C.byref(sz))
        self.block_size = sz.value
        g['glUniformBlockBinding'](prog, idx, 0)
        self.block = bytearray(self.block_size)
        ubo = U(); g['glGenBuffers'](1, C.byref(ubo)); self.ubo = ubo.value
        self.offsets = {}
        # textures
        ids = (U * 4)(); g['glGenTextures'](4, ids); self.tex = list(ids)
        self.set_image(image)
        self.set_masks(masks)
        self._tex2d(1, self.tex[1], np.zeros((4, 4, 2), dtype=np.float32), flow=True)
        self._tex2d(6, self.tex[3], np.zeros((1, 1, 4), dtype=np.uint8))
        for nm, unit in [('uImage', 0), ('uFlow', 1), ('uMasks', 5), ('uCharacter', 6)]:
            g['glUniform1i'](g['glGetUniformLocation'](prog, nm.encode()), unit)
        vao = U(); vbo = U()
        g['glGenVertexArrays'](1, C.byref(vao)); g['glBindVertexArray'](vao)
        g['glGenBuffers'](1, C.byref(vbo)); g['glBindBuffer'](0x8892, vbo)
        quad = np.array([-1, -1, 1, -1, -1, 1, 1, 1], dtype='float32')
        g['glBufferData'](0x8892, quad.nbytes, quad.ctypes.data, 0x88E4)
        g['glEnableVertexAttribArray'](0); g['glVertexAttribPointer'](0, 2, 0x1406, 0, 8, None)
        g['glViewport'](0, 0, W, H)
        self.u1f('uFlipY', 1.0); self.u1f('uRotate', 0.0)
        self.u2f('uViewOffset', 0, 0); self.u2f('uViewScale', 1, 1)
        self.u1f('uShowMask', 0.0); self.u1f('uOverlayOnly', 0.0); self.u1f('uFast', 0.0)
        g['glUniform1i'](g['glGetUniformLocation'](prog, b'uActiveMask'), -1)
        self.defaults()

    # ------------------------------------------------------------------ textures
    def _tex2d(self, unit, tid, arr, flow=False, mip=False):
        g = self.g
        g['glActiveTexture'](0x84C0 + unit); g['glBindTexture'](0x0DE1, tid)
        g['glTexParameteri'](0x0DE1, 0x2801, 0x2703 if mip else 0x2601)
        g['glTexParameteri'](0x0DE1, 0x2800, 0x2601)
        g['glTexParameteri'](0x0DE1, 0x2802, 0x812F); g['glTexParameteri'](0x0DE1, 0x2803, 0x812F)
        g['glPixelStorei'](0x0CF5, 1)
        h, w = arr.shape[:2]
        arr = np.ascontiguousarray(arr)
        if flow:
            g['glTexImage2D'](0x0DE1, 0, 0x822F, w, h, 0, 0x8227, 0x1406, arr.ctypes.data)
        else:
            g['glTexImage2D'](0x0DE1, 0, 0x8058, w, h, 0, 0x1908, 0x1401, arr.ctypes.data)
        if mip:
            g['glGenerateMipmap'](0x0DE1)

    def set_image(self, image):
        im = Image.open(image).convert('RGBA') if isinstance(image, str) else image.convert('RGBA')
        a = np.asarray(im)
        self.img_w, self.img_h = im.size
        self._tex2d(0, self.tex[0], a, mip=True)
        self.aspect = self.img_w / self.img_h
        self.u2f('uTexSize', self.img_w, self.img_h)

    def set_masks(self, masks=None, size=None):
        """masks: dict layer -> uint8 HxW array."""
        g = self.g
        h, w = size or (self.img_h // 2, self.img_w // 2)
        if masks:
            h, w = next(iter(masks.values())).shape
        atlas = np.zeros((12, h, w), dtype='uint8')
        for k, v in (masks or {}).items():
            atlas[k] = v
        g['glActiveTexture'](0x84C0 + 5); g['glBindTexture'](0x8C1A, self.tex[2])
        for p, v in [(0x2801, 0x2601), (0x2800, 0x2601), (0x2802, 0x812F), (0x2803, 0x812F)]:
            g['glTexParameteri'](0x8C1A, p, v)
        g['glPixelStorei'](0x0CF5, 1)
        g['glTexImage3D'](0x8C1A, 0, 0x8229, w, h, 12, 0, 0x1903, 0x1401, np.ascontiguousarray(atlas).ctypes.data)

    # ------------------------------------------------------------------ uniforms
    def u1f(self, n, v):
        self.g['glUniform1f'](self.g['glGetUniformLocation'](self.prog, n.encode()), float(v))

    def u2f(self, n, a, b):
        self.g['glUniform2f'](self.g['glGetUniformLocation'](self.prog, n.encode()), float(a), float(b))

    def member(self, name):
        if name in self.offsets:
            return self.offsets[name]
        g = self.g
        names = (C.c_char_p * 1)(name.encode())
        idx = (U * 1)()
        g['glGetUniformIndices'](self.prog, 1, names, idx)
        if idx[0] == 0xFFFFFFFF:
            self.offsets[name] = None
            return None
        out = I()
        g['glGetActiveUniformsiv'](self.prog, 1, idx, 0x8A3B, C.byref(out)); off = out.value
        g['glGetActiveUniformsiv'](self.prog, 1, idx, 0x8A3C, C.byref(out)); stride = out.value
        g['glGetActiveUniformsiv'](self.prog, 1, idx, 0x8A37, C.byref(out)); typ = out.value
        self.offsets[name] = (off, stride, typ == 0x1404)
        return self.offsets[name]

    def put(self, name, value):
        base, el = name, 0
        if '[' in name:
            base = name[:name.index('[')]
            el = int(name[name.index('[') + 1:-1])
        m = self.member(base) or self.member(base + '[0]')
        if m is None:
            return False
        off, stride, is_int = m
        start = off + el * stride
        vals = value if isinstance(value, (list, tuple, np.ndarray)) else [value]
        for i, v in enumerate(vals):
            if is_int:
                self.block[start + 4 * i:start + 4 * i + 4] = int(v).to_bytes(4, 'little', signed=True)
            else:
                self.block[start + 4 * i:start + 4 * i + 4] = np.float32(v).tobytes()
        return True

    def set_block(self, d):
        missing = [k for k, v in d.items() if not self.put(k, v)]
        return missing

    def defaults(self):
        """Bloque a cero + valores neutros. Las ranuras de máscara se ponen en -2 (toda la imagen)."""
        import re
        self.block = bytearray(self.block_size)
        for name in re.findall(r'int (uMask\w+);', open(os.path.join(self.shader_dir, 'fondo.frag')).read()):
            self.put(name, -2)
        self.put('uAspect', self.aspect)
        self.put('uLoopInfo', [6.0, -1, -1, 0])
        self.put('uEventPhase', [-1, -1, -1, -1]); self.put('uEventPhase2', [-1, -1, -1, -1])
        self.put('uCharAspect', 1.0)

    def render(self, t):
        g = self.g
        self.u1f('uT', t)
        buf = (C.c_ubyte * self.block_size).from_buffer(self.block)
        g['glBindBuffer'](0x8A11, self.ubo)
        g['glBufferData'](0x8A11, self.block_size, C.addressof(buf), 0x88E8)
        g['glBindBufferBase'](0x8A11, 0, self.ubo)
        g['glDrawArrays'](5, 0, 4)
        a = np.zeros((self.H, self.W, 4), dtype='uint8')
        g['glReadPixels'](0, 0, self.W, self.H, 0x1908, 0x1401, a.ctypes.data)
        err = g['glGetError']()
        assert err == 0, hex(err)
        return a[:, :, :3].copy()
