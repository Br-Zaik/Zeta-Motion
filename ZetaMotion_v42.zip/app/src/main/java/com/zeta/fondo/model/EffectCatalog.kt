package com.zeta.fondo.model

/**
 * v38 · Catálogo de efectos por categorías claras (fila de herramientas de Efectos) y
 * secciones del editor de cada efecto. Sin dependencias de Android: se prueba en JVM.
 */
object EffectCatalog {

    /** Herramientas que viven en Animar (no aparecen en el catálogo de Efectos). */
    val animateIds = setOf("flow", "zonemotion", "natural", "parallax", "mesh", "cam")

    val categories = listOf("Populares", "Activos", "Fuego", "Agua", "Clima", "Luz", "Energía",
        "Anime", "Manga", "Escenas", "Todos")

    /** Lo más usado: aparece primero y es lo que ve un principiante. */
    val popular = listOf("smoke", "flame", "rain", "snow", "leaves", "sakura", "fog", "clouds3", "water",
        "blast", "energy", "bolt", "rays", "sparkle", "embers", "slash", "eyes", "gust", "shock", "reveal")

    private val groups: Map<String, List<String>> = mapOf(
        "Fuego" to listOf("flame", "smoke", "embers", "ash", "blast", "heat"),
        "Agua" to listOf("water", "shore", "waterfall", "reflect", "sunpath", "bubbles", "ripple", "glint"),
        "Clima" to listOf("rain", "snow", "sakura", "leaves", "fog", "clouds3", "sky", "gust", "tornado",
            "bolt", "dust", "stars", "drift", "sway"),
        "Luz" to listOf("rays", "sparkle", "bokeh", "lightleak", "flies", "stars", "comet", "eyes", "sunpath"),
        "Energía" to listOf("energy", "electric", "shock", "blackaura", "runes", "pulse", "shards",
            "dispersion", "bolt"),
        "Anime" to listOf("slash", "blood", "reveal", "impact", "flash", "speed", "focus", "elements",
            "appear", "eyes", "blink", "cloth", "energy", "blast"),
        "Manga" to listOf("tone", "grain", "ink", "hatch", "inkdrip", "dramatic", "style", "speed", "focus", "flash")
    )

    /** Ids duplicados de versiones antiguas: solo se muestran si el proyecto ya los usa. */
    private val legacy = Effects.legacyDuplicates

    fun idsFor(category: String, allIds: List<String>, isOn: (String) -> Boolean): List<String> {
        val usable = allIds.filter { it !in animateIds }
        fun visible(id: String) = id !in legacy || isOn(id)
        return when (category) {
            "Populares" -> popular.filter { it in usable || it == "elements" } +
                usable.filter { it !in popular && isOn(it) }
            "Activos" -> usable.filter { isOn(it) }
            "Todos" -> usable.filter { visible(it) } + "elements"
            else -> (groups[category] ?: emptyList()).filter { (it in usable || it == "elements") && visible(it) }
        }.distinct()
    }

    /** Categoría a la que se vuelve si el nombre guardado ya no existe (p. ej. "Útiles"). */
    fun normalize(category: String): String = when (category) {
        in categories -> category
        "Útiles" -> "Populares"
        "Agua y cielo" -> "Agua"
        "Manhwa" -> "Anime"
        else -> "Populares"
    }

    fun groupOf(id: String): List<String> = groups.filterValues { id in it }.keys.toList()

    /** Estilos (variantes) que ofrece cada efecto. */
    fun variants(id: String): List<String> = when (id) {
        "zonemotion" -> listOf("Balanceo", "Ondulación", "Respiración")
        "sky" -> listOf("Día", "Atardecer", "Noche", "Tormenta")
        "water" -> listOf("Ondas", "Corriente", "Reflejos")
        "cam" -> listOf("Acercar", "Alejar", "Desplazar", "Girar", "Temblar", "Órbita 3D", "Latido", "Flotar", "Balanceo")
        "mesh" -> listOf("Ondulación", "Respirar", "Tela")
        "natural" -> listOf("Árbol", "Bandera", "Pasto", "Cortina", "Cabello", "Ropa")
        "gust" -> listOf("Brisa", "Viento", "Fuerte", "Tormenta")
        "leaves" -> listOf("Verdes", "Secas", "Otoño", "Navidad")
        "shore" -> listOf("Suaves", "Medias", "Fuertes", "Tormenta")
        "rain" -> listOf("Suave", "Normal", "Fuerte", "Tormenta")
        "snow" -> listOf("Suave", "Normal", "Fuerte", "Ventisca")
        "dispersion" -> listOf("Fragmentos", "Pétalos", "Polvo")
        "tornado" -> listOf("Remolino", "Tornado")
        "appear" -> listOf("Humo", "Ráfaga", "Destello", "Fundido")
        "clouds3" -> listOf("Día", "Atardecer", "Noche")
        "bokeh" -> listOf("Dorado", "Romántico", "Azul", "Mágico")
        "lightleak" -> listOf("Cálida", "Rosa", "Azul", "Violeta")
        "rays" -> listOf("Suaves", "Contraluz", "Atardecer", "Ventana", "Volumen")
        "sunpath" -> listOf("Dorado", "Atardecer", "Luna", "Destellos")
        "energy" -> listOf("Azul", "Violeta", "Dorado", "Rojo")
        "flame" -> listOf("Fuego", "Azul", "Verde", "Violeta")
        "parallax" -> listOf("Planos", "Órbita 2.5D", "Acercamiento")
        "smoke" -> listOf("Gris", "Negro", "Blanco", "Violeta", "Cálido")
        "blast" -> listOf("Fuego", "Azul", "Violeta", "Oscura")
        "blood" -> listOf("Rojo", "Tinta negra", "Azul manga")
        "slash" -> listOf("Azul", "Blanco", "Dorado", "Rojo")
        "reveal" -> listOf("Sombra", "Niebla", "Oscuro")
        else -> emptyList()
    }

    /** Efectos cuyo estilo aplica un preajuste completo (no solo cambia la variante). */
    val styledPresets = setOf("gust", "leaves", "shore", "rain", "snow")

    /** Efectos que no usan zona pintada propia. */
    private val noZone = setOf("style", "elements", "appear", "impact", "parallax")

    /**
     * Secciones del editor de un efecto, en orden: siempre «Ajustes»; «Estilo» si tiene
     * variantes o formas; «Color» si se puede teñir; «Tiempo» y «Zona» si aplican.
     */
    fun sections(id: String, colorable: Boolean, hasShapes: Boolean): List<String> = buildList {
        add("Ajustes")
        if (variants(id).isNotEmpty() || hasShapes) add("Estilo")
        if (colorable || id == "shore") add("Color")
        if (id != "style" && id != "elements") add("Tiempo")
        if (id !in noZone) add("Zona")
    }
}
