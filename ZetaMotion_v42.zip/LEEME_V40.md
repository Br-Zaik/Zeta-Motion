# Zeta Motion v40 (versionCode 41 · 40.0.0)

Orden y estabilidad del editor como en un editor de vídeo, edición real de los efectos en la línea de tiempo y humo, fuego y explosión rehechos en el motor de render. Se conservan los módulos Animar, Proteger, Efectos y Ajustes, los efectos anteriores y los proyectos guardados.

## Cómo compilar
- Igual que la v39: GitHub Actions (el flujo ya se llama v40) o `./gradlew assembleDebug` en Android Studio.
- Firma para Google Play: los 4 secretos `ZETA_*` (`ZETA_RELEASE_KEYSTORE_BASE64`, `ZETA_KEYSTORE_PASSWORD`, `ZETA_KEY_ALIAS`, `ZETA_KEY_PASSWORD`), como en LEEME_V36.md.

## Causas encontradas en el código de la v39
- **El lienzo cambiaba de tamaño solo:** su alto dependía del estado del panel (contraído, compacto, expandido) y varias herramientas pedían «mostrar opciones», lo que expandía el panel y encogía la imagen con una animación (`EditorLayout`, `EditorScreen`).
- **Controles encima de la imagen:** deshacer, rehacer y reproducir flotaban dentro del lienzo y tapaban parte de la imagen.
- **Efectos «manchas»:** el fuego y la explosión se pintaban con 3 bandas de color planas (cortes duros); el ruido tenía formas cuadradas alineadas con su rejilla; en el humo, cada bocanada tomaba la luz de la «mejor» bocanada, lo que creaba bordes de color duros.
- **Línea de tiempo:** mover y recortar no se podían deshacer, eliminar no tenía deshacer, y un duplicado compartía todos los ajustes con el original (el motor tenía un solo juego de ajustes por efecto).

## Editor
- **Lienzo fijo arriba:** su tamaño solo depende de la pantalla y de la proporción de la imagen. Cambiar de categoría, de herramienta, abrir opciones o seleccionar un efecto ya no lo mueve ni lo redimensiona, y no toca el zoom.
- **Tamaño de la vista previa a elección:** Ajustes › Vista (Compacta, Normal, Grande). Pantalla completa solo con su botón.
- **Debajo del lienzo:** tiempo actual / total (toca para cambiar la duración), reproducir, deshacer y rehacer.
- **Zona de trabajo única:** muestra la línea de tiempo o las opciones de la herramienta, con su propio scroll. Sin rectángulos vacíos ni textos fijos.
- **Hojas de opciones** con botón para cerrarlas y volver a la línea de tiempo. Tocar otra vez la categoría también vuelve.
- **Línea de tiempo:** regla en segundos, pista de la imagen y una pista por capa de efectos, con color por familia.

## Edición de efectos en la línea de tiempo
- **Seleccionar:** tocar un bloque lo resalta y abajo aparecen sus acciones: Ajustar, Mover, Dividir, Duplicar, Sustituir, Delante/Detrás y Eliminar.
- **Mover en el tiempo:**
  - un bloque seleccionado se arrastra directamente; uno sin seleccionar necesita mantener pulsado, así no se mueve por accidente;
  - arrastrar hacia arriba o abajo lo cambia de pista;
  - mientras se arrastra se ven el inicio, el final y la duración, y la vista previa se actualiza;
  - se pega al cabezal y a los bordes de otros bloques.
- **Recortar o alargar:** tiradores en los dos extremos del bloque seleccionado. Duración mínima de 0,1 s, sin pasar del final del vídeo.
- **Duplicar:** crea una copia independiente justo después del original (o antes si no cabe). Se puede mover y cambiar sin tocar el original.
- **Ajustes propios de cada bloque:** con varios bloques del mismo efecto, Ajustar cambia solo el bloque seleccionado (intensidad, tamaño, color, forma, dirección, zona…). La vista previa y la exportación usan los mismos valores.
- **Mover en la imagen** (explosión, humo, energía, corte, salpicadura…): se arrastra el punto de origen. El aro cambia el tamaño y la flecha la dirección. Dos dedos siguen siendo zoom del lienzo. En los efectos que viven en una zona pintada (fuego, agua…), Mover abre su sección Zona.
- **Sustituir:** se elige otro efecto en el catálogo y conserva el tiempo, la pista, la posición y el color.
- **Eliminar:** aparece un aviso con «Deshacer».
- **Deshacer y rehacer** funcionan para mover, recortar, duplicar, dividir, sustituir, eliminar y colocar. ✓ Aplicar en el editor de un efecto se deshace de una sola vez.
- **Catálogo:** tocar un efecto lo previsualiza; ✓ Aplicar lo guarda y ✕ lo revierte por completo.

## Efectos mejorados en el motor (shader real, no solo miniaturas)
- **Humo:** bocanadas con volumen y luz suave. Suben, frenan, se abren en abanico, giran y se deshacen en jirones más transparentes arriba. Ya no hay bordes de color cortados. Las formas Hilos, Tinta manga y Rastrero se conservan.
- **Fuego:**
  - lenguas que se curvan con una rampa de temperatura continua (brasa, color, amarillo, blanco) en vez de 3 bandas planas;
  - resplandor sobre la escena, chispas con halo y aire caliente que ondula la imagen sobre las llamas;
  - los lados de la zona se funden sin bordes rectos.
- **Explosión:**
  - destello, bola de fuego turbulenta en lóbulos, onda de choque rota, chispas y escombros con gravedad, y humo residual;
  - al apagarse, la bola se rompe en bolsas de brasa dentro del humo en vez de encogerse como un disco;
  - Estallido manga: destello blanco y líneas de concentración finas de tinta.
- **Para todos los efectos:** el ruido gira en cada octava, lo que reduce las formas cuadradas alineadas con su rejilla. Las líneas de velocidad y los cometas ya no saltan al repetir el bucle.
- Miniaturas del catálogo de Humo, Fuego y Explosión regeneradas con el motor nuevo.

## Pruebas realmente hechas en este entorno
- **Compilación Android real con Gradle: no fue posible aquí** (el entorno no puede descargar el plugin de Android). La hará GitHub Actions.
- **Tipado de todo el código Kotlin** (app y pruebas) contra imitaciones de las librerías Android y Compose: 0 errores. No equivale a la compilación real; en particular, no comprueba las reglas propias del compilador de Compose.
- **Pruebas unitarias JVM:** 91 correctas, 0 fallidas.
- **Recorrido completo simulado** (Android imitado), todo correcto:
  - aplicar explosión, seleccionar, mover, recortar desde los dos extremos;
  - duplicar, mover el duplicado, moverlo y agrandarlo sobre la imagen;
  - cambiar intensidad y color solo del duplicado;
  - borrar, deshacer y rehacer, dividir y sustituir;
  - ✓ Aplicar y deshacerlo de una vez;
  - en 60 fotogramas, la vista previa y la exportación reciben los mismos valores.
- **Shader** compilado y dibujado con OpenGL ES 3 (Mesa):
  - humo, fuego y explosión, en todas sus formas, sobre una imagen anime en color y una manga en blanco y negro, a lo largo del tiempo;
  - el bucle cierra sin salto, no salen de la zona pintada y con intensidad 0 la imagen queda intacta;
  - los 65 efectos se revisaron para comprobar que el bucle no salta (los únicos cambios en el empalme son el parpadeo de la electricidad y el reinicio de la explosión, que son intencionados).
- Comparación v39 / v40: `checks/v40_comparacion_v39.png`.
- **GitHub:** no se hizo ninguna operación.

## Pendiente de probar en tu teléfono
1. Que GitHub Actions compile y pasen las pruebas.
2. Abrir cada categoría y cada herramienta: el lienzo no se mueve ni cambia de tamaño.
3. Efectos: tocar uno del catálogo, ✕ (se revierte del todo) y ✓.
4. Seleccionar un bloque: moverlo, recortarlo por los dos lados, duplicarlo y mover la copia.
5. Mover y agrandar la explosión o el humo sobre la imagen; dos dedos siguen haciendo zoom.
6. Ajustar solo el duplicado (color, tamaño) y comprobar que el original no cambia.
7. Eliminar → Deshacer; deshacer y rehacer mover y recortar.
8. Humo, fuego y explosión en una imagen manga y en una anime: fluidez en tu teléfono.
9. Exportar un MP4 y compararlo con la vista previa (tiempos y posiciones de cada bloque).
10. Abrir un proyecto de la v39: sus efectos y bloques deben seguir igual.
11. Ajustes › Vista: probar Compacta, Normal y Grande, también en horizontal.
