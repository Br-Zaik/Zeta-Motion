# Zeta Motion v42 (versionCode 43 · 42.0.0)

Vista previa más fluida y con los efectos visibles durante el zoom, línea de tiempo más clara (colores por familia, efectos nuevos en la línea blanca, música del largo del vídeo, Animación como bloque), nuevas animaciones de cámara y un fuego más natural. Se conservan los proyectos guardados.

## Cómo compilar
- Igual que la v41: GitHub Actions (el flujo ya se llama v42) o `./gradlew assembleDebug` en Android Studio.

## Fluidez
- **Los efectos ya no desaparecen al hacer zoom.** Antes, mientras había dos dedos en la pantalla, se dibujaba solo la imagen. Ahora los efectos se ven siempre.
- **Resolución adaptativa:**
  - quieta, la vista previa se dibuja con la calidad completa;
  - al reproducir, hacer zoom o mover un deslizador, la app mide cada pocos cuadros cuánto tarda la GPU del teléfono y baja la resolución lo justo para mantener el ritmo (hasta el 45 %);
  - al soltar, el cuadro se vuelve a dibujar nítido.
  - Si el teléfono no admite el escalado, se dibuja directo como en la v41.
- **Línea de tiempo:** el cabezal ya no hace recomponer toda la línea de tiempo en cada movimiento del dedo; solo se redibuja.
- **Tiempo bajo la vista previa:** al reproducir se actualiza como mucho 10 veces por segundo.

## Línea de tiempo
- **Colores por familia** (también en una franja bajo cada miniatura del catálogo):
  - fuego: rojo;
  - agua: azul;
  - nieve, cielo y nubes: celeste;
  - humo y niebla: gris;
  - energía: morado;
  - luz: dorado;
  - naturaleza: verde;
  - manga: sepia;
  - animaciones de la imagen: rosa.
- **Efecto nuevo en la línea blanca:** un efecto nuevo empieza donde está el cabezal y llega hasta el final; luego se estira o se acorta con sus tiradores. Con el cabezal al inicio cubre todo el vídeo, como antes. Los efectos de un momento (explosión, corte…) siguen naciendo en el cabezal con su duración natural.
- **Música:** la pista «+ Agregar música» mide lo mismo que el vídeo (antes era más larga).
- **Duración del vídeo:** al alargar el vídeo (Animar › Bucle, tocar el tiempo o el tirador de la imagen), los efectos que llegaban al final siguen llegando al final.
- **Animación como bloque:** al dibujar una Ruta en Animar aparece el bloque rosa «Animación». Se puede mover, recortar, dividir o borrar como un efecto, y el movimiento solo ocurre dentro del bloque. Deshacer la ruta quita el bloque.

## Animar: más opciones
- Nuevas animaciones de cámara de un toque en la barra de Animar: **Acercar, Alejar, Latido, Flotar, Balanceo y Temblar**.
- Cada una abre su vista previa con ✓ / ✕; en Ajustar se cambia la fuerza, la velocidad y el estilo.
- La cámara tiene ahora 9 estilos: Acercar, Alejar, Desplazar, Girar, Temblar, Órbita 3D y los nuevos Latido, Flotar y Balanceo.
- Los nuevos movimientos cierran el bucle y siempre hacen el zoom justo para que no se vean bordes.

## Fuego más natural
- **Lenguas más naturales:** antes se veían como rayas estiradas en vertical (proporción 1:4); ahora tienen proporción ≈ 1:2 y se alargan y afinan al subir.
- **Sin efecto «doble»:** las llamas suben de verdad con un ruido que se repite en vertical y cierra el bucle exacto. Antes se mezclaban dos fases y se veían lenguas borrosas.
- **Bordes:** los bordes fríos son rojos y translúcidos, en vez de manchas marrón oscuro.
- Comparación antes/después en el entorno de pruebas: `checks/v42_fuego.png`.

## Pruebas realizadas (y las que faltan)
Hechas en el entorno de desarrollo, sin teléfono:
- Comprobación de tipos de todo el código Kotlin (sin errores).
- 95 pruebas JVM, todas superadas.
- Escenario simulado del editor:
  - flujos anteriores;
  - nuevos: Nieve añadida con el cabezal a la mitad empieza ahí y llega al final;
  - alargar el vídeo a 12 s alarga ese bloque;
  - una ruta crea el bloque Animación y deshacer lo quita;
  - Balanceo activa la cámara con su bloque.
- Shader con Mesa (OpenGL ES 3 por software):
  - compilan las 66 variantes, la completa y la vacía;
  - render de las nuevas cámaras sin bordes vacíos;
  - fuego antes/después.

**No probado:**
- No se ha compilado con Gradle ni se ha probado en un teléfono.
- Falta comprobar en el teléfono:
  - la fluidez real;
  - el zoom con efectos;
  - que la imagen quede nítida al soltar;
  - el aspecto del fuego en la app.
