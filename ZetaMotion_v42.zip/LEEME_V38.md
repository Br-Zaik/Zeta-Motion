# Zeta Motion v38 (versionCode 39 · 38.0.0)

Gratis y sin anuncios. Nueva interfaz basada en la imagen de referencia, zoom corregido desde el primer toque, miniaturas claras y mejores animaciones.

## Cómo compilar
- Abre la carpeta en Android Studio, o súbela a tu repositorio (incluida la carpeta oculta `.github`).
- GitHub Actions: pruebas unitarias → APK + AAB firmados → artefacto **ZetaMotion-v38-APK-AAB**.
- Firma para Google Play: los 4 secretos `ZETA_*` (igual que en LEEME_V36.md).

## 1. Zoom desde el primer momento (corregido)
Causas reales encontradas:
1. **Los gestos solo funcionaban sobre la imagen.** Las franjas negras alrededor no respondían, así que al abrir (imagen pequeña y centrada) muchos pellizcos se perdían. Ahora los gestos cubren **todo el lienzo**.
2. **Al abrir, el shader grande de efectos se compilaba en el hilo de dibujo.** En móviles modestos tarda un momento, y el primer zoom quedaba congelado hasta que terminaba. Ahora:
   - el primer cuadro, el zoom/arrastre con dos dedos y el pincel usan un **shader ligero nuevo** (`lite.frag`, una lectura de textura por píxel), que responde al instante en cualquier teléfono;
   - el shader completo se compila después, en cuanto pasan 300 ms sin tocar la pantalla;
   - si el proyecto tiene efectos, mientras tanto aparece un aviso pequeño: «Preparando efectos…».
3. Durante un pellizco se ve la imagen sin efectos, y los efectos vuelven al soltar. Un simple toque no hace parpadear los efectos.

Dos dedos siempre son zoom y nunca pintan, con cualquier herramienta. El pincel empieza solo cuando el dedo se mueve.

## 2. Interfaz nueva (como la referencia)
- **Arriba:** solo Atrás · Proyecto (carpeta: Guardar, Abrir imagen de Archivos, Mis proyectos) · **Exportar**.
- **Lienzo protagonista**, con esquinas redondeadas y controles flotantes:
  - abajo a la izquierda, **Deshacer** y **Rehacer**;
  - abajo a la derecha, **Play/Pausa**;
  - arriba a la derecha, comparar con el original, pantalla completa y ajustar el zoom.
- **Tamaño fijo del lienzo:** no se agranda ni se achica al cambiar de herramienta o de categoría. Solo cambia si arrastras el asa que hay debajo (la app lo recuerda) o con el botón de pantalla completa.
- **Debajo, de abajo hacia arriba:**
  - las 4 categorías: **Animar · Proteger · Efectos · Ajustes**;
  - una fila compacta de herramientas de la categoría, con icono y texto corto, scroll horizontal y la activa en rosa;
  - el panel con las opciones de la herramienta y la línea de tiempo.

| Categoría | Herramientas |
|---|---|
| Animar | Ruta · Ancla · Eliminar · Congelar · Natural · 2.5D · Ondular · Zona · Cámara · Bucle |
| Proteger | Pincel · Borrador · Rellenar · Vaciar · Ver/Ocultar · Punto fijo · Quitar punto |
| Efectos | Populares · Activos · Fuego · Agua · Clima · Luz · Energía · Anime · Manga · Escenas · Todos |
| Ajustes | Duración · Formato · Color · Audio · Bucle · Fácil/Avanzado |

- En horizontal, las herramientas pasan a una columna lateral.

## 3. Proteger, más directo
Al entrar en Proteger ya estás pintando: un dedo pinta lo que **no** se mueve y dos dedos acercan. En el panel se elige la capa (Proteger · Zona azul · Zona verde · zonas propias · + Nueva), el tamaño y el borde suave. El texto indica si la zona ya está lista.

## 4. Ajustes de cada efecto, organizados
Al tocar un efecto se ve **sobre tu imagen** sin aplicarse:
- **✓ Aplicar** lo confirma y **✕** lo descarta sin dejar rastro;
- **👁** lo oculta o lo muestra.

Mientras lo editas, la fila de herramientas muestra sus secciones:
- **Ajustes:** intensidad, velocidad, tamaño, opacidad y dirección, siempre en ese orden (los controles finos, en Avanzado).
- **Estilo:** variantes (Suave, Tormenta, Otoño…) y formas.
- **Color:** color propio o el de la paleta del estilo.
- **Tiempo:**
  - en los eventos, **Una vez · Repetir · Continuo** con «Cada»;
  - en el resto, «Todo el vídeo» o bloques con inicio y duración.
- **Zona:**
  - «Toda la imagen» o «Pintar zona», origen tocando la imagen, «Detrás del personaje» y zonas ya pintadas;
  - una «!» avisa si le falta la zona.

## 5. Miniaturas claras, sin personajes
- Las 57 miniaturas se volvieron a renderizar con **el mismo shader de la app**, sobre escenas limpias pensadas para cada tipo de efecto:
  - noche con colinas: lluvia, nieve, sakura, estrellas, partículas;
  - cielo de día: nubes, rayos de sol;
  - mar al atardecer: agua, olas, reflejos;
  - escenario oscuro: humo, fuego, explosión, cortes, rayos, ondas;
  - silueta genérica: auras;
  - dos ojos en la oscuridad: ojos brillantes;
  - viñeta manga: tramas y tintas;
  - árbol, pasto y bandera: herramientas de Animar.
- Ahora miden 128 px (antes 96) y ocupan 624 KB en total. La caché guarda 40 tiras, así que al volver a una categoría no se cargan otra vez.

## 6. Animaciones mejoradas en esta versión
- **Lluvia:**
  - estela con cabeza brillante;
  - mezcla que aclara sin lavar los colores;
  - ambiente húmedo sutil;
  - **salpicaduras** en el suelo (anillos que nacen y se apagan).
- **Nieve:** 4 planos de profundidad; los copos cercanos se ven desenfocados (bokeh) y los lejanos, nítidos.
- **Sakura:** pétalo con su muesca, que **gira en 3D** (se estrecha de canto y cambia de tono por el reverso).
- **Nubes:** luz desde arriba calculada con la pendiente de la nube: bordes iluminados y base en sombra, sin coste extra.
- **Rayos de luz:** el haz «respira» con polvo en suspensión.

Todo sigue cerrando el bucle sin saltos (comprobado). Se conservan las mejoras de la v37: humo en columna, fuego con chispas, explosión, partículas con forma, rayos ramificados, agua, onda de choque y viento sobre cabello y ropa.

## 7. Rendimiento
- Los deslizadores ya no recalculan los parámetros del shader en cada evento, sino como mucho una vez por cuadro.
- El reloj de reproducción solo existe mientras se reproduce; en pausa no despierta la CPU 60 veces por segundo.
- El catálogo de efectos solo se recalcula cuando cambia qué efectos están encendidos, no al mover un deslizador.
- Los avisos del lienzo se calculan solo cuando cambian los ajustes o las zonas.
- El zoom y el pincel usan el shader ligero.

## Pruebas realmente realizadas en este entorno
1. **Comprobación de tipos de TODA la app (43 archivos Kotlin):** 0 errores.
   - Las librerías de Android y Compose no se pueden descargar aquí, así que se escribieron imitaciones (*stubs*) de sus funciones y el compilador de Kotlin 1.9.24 revisó todo contra ellas: llamadas, parámetros, tipos y ámbitos (`weight`, `align`…).
   - Se verificó que detecta errores reales introduciendo dos a propósito.
   - **No equivale a compilar con Android Studio:** la compilación real la hará GitHub Actions o Android Studio.
2. **63 pruebas unitarias superadas**, 18 de ellas nuevas:
   - diseño del lienzo: no cambia de tamaño, pantalla completa solo con el botón, horizontal;
   - reglas de gestos: dos dedos nunca pintan, el pincel espera al movimiento;
   - encaje de la imagen idéntico al de OpenGL;
   - catálogo: cada efecto está en una categoría y las herramientas de Animar no se mezclan;
   - secciones del editor;
   - contrato del shader ligero.
3. **Shaders en WebGL2** (mismo lenguaje que OpenGL ES 3):
   - `fondo.frag` y `lite.frag` compilan, enlazan y dibujan;
   - prueba de bucle sin salto superada en lluvia, nieve, sakura, nubes, rayos, humo, fuego, niebla, agua, hojas y brasas.

## Pendiente de comprobar en un teléfono (no se puede aquí)
1. Abrir una imagen desde Archivos y hacer zoom **enseguida**: debe responder desde el primer pellizco, también fuera de la imagen.
2. Pellizcar con el pincel activo: no debe aparecer ninguna marca.
3. El lienzo no cambia de tamaño al cambiar de categoría ni de herramienta; el asa sí lo cambia.
4. Controles flotantes: deshacer, rehacer y play.
5. Proteger: pintar, borrar, cambiar de capa y volver a Animar.
6. Efectos: tocar uno, ✕ lo descarta y ✓ lo aplica; secciones Ajustes, Estilo, Color, Tiempo y Zona.
7. Fluidez de deslizadores y paneles en un móvil económico.
8. Guardar, cerrar, volver a abrir y exportar el MP4.

Si la compilación de GitHub Actions falla, envíame el registro y lo corrijo.
