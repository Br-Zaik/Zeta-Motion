# Zeta Motion v37 (versionCode 38 · 37.0.0)

Gratis y sin anuncios. Corrige los problemas encontrados al probar la v36.

## Cómo compilar
- Sube el contenido de este ZIP a tu repositorio (incluida la carpeta oculta `.github`) o ábrelo en Android Studio.
- GitHub Actions: pruebas unitarias → APK + AAB firmados → artefacto **ZetaMotion-v37-APK-AAB**.
- Firma para Google Play: los 4 secretos `ZETA_*` (igual que en LEEME_V36.md).

## 1. Reproducción (corregido)
- Causa real: `playing` empezaba en `true` en AppViewModel y en RenderHub, y `openProject` forzaba la reproducción. Además, activar un sonido de ambiente iniciaba la reproducción.
- Ahora al abrir una imagen o un proyecto todo queda **pausado en el segundo 0**. Solo el botón Play (centro de la barra superior) reproduce.
- Ajustar un control ya no recoloca el cabezal: antes cada cambio recalculaba el reloj y la reproducción daba pequeños saltos atrás.

## 2. Zoom y gestos (corregido)
- El pincel ya no empieza al tocar: espera a que el dedo se mueva. Si llega un segundo dedo, es zoom y **nunca pinta ni borra por accidente**. Funciona con cualquier herramienta activa.
- Zoom centrado entre los dedos, con dibujo inmediato (sin sondeo).
- Calidad adaptativa: si el teléfono no llega a dibujar los efectos a tiempo durante el gesto (medido en cada cuadro), mientras dura el gesto se muestra solo la imagen. El zoom responde al instante y los efectos vuelven al soltar. Los teléfonos rápidos siguen viendo los efectos.

## 3. Interfaz nueva
- Barra superior compacta: volver · deshacer · rehacer · **Play/Pausa** · modo Fácil/Avanzado · Exportar.
- **La imagen se ajusta al espacio libre**: al abrir un panel se recoloca encima de él en lugar de quedar tapada, con animación suave y sin redimensionar la superficie OpenGL.
- Abajo: línea de tiempo compacta (posición, duración, búsqueda, marcas de los efectos activos y botón para ver los bloques), panel desplegable con asa para cambiar su altura, y 4 categorías: **Animar · Proteger · Efectos · Ajustes**. Tocar otra vez la categoría pliega el panel.
- En horizontal o en tableta, las herramientas pasan a una columna lateral.
- Avisos pequeños bajo la barra superior que no bloquean los toques y desaparecen solos.
- Botones flotantes pequeños sobre la imagen: comparar con el original, pantalla completa y ajustar el zoom.
- Dirección con un **dial visual**: arrastras la flecha, con imán cada 15°.

## 4. Miniaturas reales
- Cada efecto tiene una miniatura animada renderizada con **el mismo shader de la app** (57 tiras de 8 cuadros, 560 KB en total, `assets/thumbs`).
- Se cargan solo las visibles, en RGB_565, con caché LRU, y se animan a ~6 fps con un único reloj compartido.
- **Vista previa sin aplicar**: tocar un efecto abre su edición ya visible sobre tu imagen. ✓ lo aplica y ✕ lo descarta sin dejar rastro.

## 5. Efectos mejorados
- **Humo**: ahora es una columna que nace en el origen, se ensancha, se curva, sus volutas suben de forma continua y se disipa con la distancia. "Llenar toda la zona" conserva el modo anterior. El contorno de la forma Tinta manga ya no se dibuja fuera del humo (error de la v36).
- **Fuego**: chispas que suben, humo opcional sobre las llamas y resplandor. Corregido un salto en el bucle.
- **Explosión**: borde más irregular y opción de empujarla en una dirección.
- **Partículas** con forma propia en lugar de círculos: brasas alargadas que parpadean con halo, hojas que giran y dan la vuelta, polvo luminoso y ceniza irregular.
- **Electricidad**: rayos ramificados en zigzag que cambian a saltos, como en el anime (antes era un anillo).
- **Agua**: ondas por flujo continuo con refracción, brillos y espuma en modo Corriente.
- **Onda de choque**: irregular, con un borde de luz delante y sombra detrás (antes era un anillo perfecto).
- **Viento**: cuando sopla, empuja también el cabello, la ropa y las ramas del Movimiento natural.

## 6. Duración y bucles
- Causa real: `defaultExtraClip()` creaba cada efecto como un bloque de 2 s en el centro del vídeo, por eso parecía que "se apagaban y volvían a empezar".
- Los efectos **ambientales** (humo, fuego, agua, nubes, lluvia, viento…) cubren ahora **todo el vídeo** por defecto. El viento ya no nace como una ráfaga corta.
- Los **eventos** (explosión, salpicadura, corte, revelación, destello, onda, impacto, rayo) tienen 3 modos:
  - **Una vez:** inicio, desarrollo y final dentro de su bloque; nacen en la posición del cabezal.
  - **Repetir:** cada X segundos.
  - **Continuo:** N veces por bucle.
- La fase de cada evento se calcula a partir de la posición del cabezal (`EventMode.phase`). Volver a cualquier punto de la línea de tiempo muestra siempre el mismo cuadro, y la exportación usa el mismo cálculo.

## 7. Máscaras y avisos
- Si un efecto activo no se verá porque **le falta su zona** (o el personaje en Proteger, en el caso del aura), aparece un aviso corto sobre la imagen y en el panel, con un botón que abre directamente el pincel.
- Pincel compacto: pincel, borrador, rellenar, vaciar, tamaño y borde suave. Recordatorio: un dedo pinta y dos dedos acercan.
- Proteger muestra si la zona protegida ya está pintada y qué hace.

## Pruebas realmente realizadas
- **Compilador Kotlin 1.9.24 en este entorno:**
  - Sintaxis de los 52 archivos Kotlin: sin errores.
  - Compilación con tipos de toda la lógica que no depende de Android (efectos, parámetros del shader, reloj del bucle, modos de evento, colores, máscaras, escenas): 45 pruebas unitarias superadas, incluido el contrato Kotlin↔shader.
- **Shader en WebGL2** (mismo lenguaje que OpenGL ES 3):
  - Compila y enlaza; bloque de parámetros de 3,4 KB.
  - Se generaron las miniaturas.
  - Prueba de bucle sin salto superada en humo (columna y zona), hilos, niebla, lluvia, nubes, fuego, aura, movimiento natural, 2.5D, agua, hojas y brasas. La electricidad cambia a saltos a propósito; los eventos reinician a propósito.
- **NO se pudo compilar la parte de Android/Compose** (interfaz, OpenGL, exportación) en este entorno: las librerías de Google no son accesibles desde aquí. Esta versión no se subió a tu GitHub. Al subir el ZIP, GitHub Actions hará la compilación completa: si apareciera algún error, envíame el registro y lo corrijo.

## Pendiente de comprobar en un teléfono
1. Abrir imagen y proyecto: pausado en 0 s.
2. Zoom con dos dedos con y sin pincel; que no aparezcan marcas.
3. Humo durante todo el vídeo; explosión en modo Una vez.
4. Varios efectos a la vez en un móvil económico.
5. Proteger al personaje y animar el fondo.
6. Paneles, miniaturas y catálogo sin congelamientos.
7. Guardar, cerrar y volver a abrir.
8. Exportar MP4 y compararlo con la vista previa.
