# Zeta Motion v39 (versionCode 40 · 39.0.0)

Corrige la auditoría de la v38: menos texto, panel inferior plegable de verdad, apertura de imágenes más rápida, miniaturas más ligeras y explosión mejorada. Se conserva todo el motor de la v38.

## Cómo compilar
- **Android Studio:** abre la carpeta. Ahora incluye el **wrapper de Gradle** (`gradlew`, `gradlew.bat` y `gradle/wrapper/`, Gradle 8.9, el mismo que usa el flujo de GitHub Actions).
- **Terminal:** `./gradlew assembleDebug` (necesita Java 17 o superior e internet la primera vez).
- **Firma para Google Play:** los 4 secretos `ZETA_*` (ver LEEME_V36.md).

## Problemas confirmados en el código de la v38 y su corrección

| Problema de la v38 (archivo) | Corrección en la v39 |
|---|---|
| Bloque fijo de ayuda «Animar la imagen…» con 6 explicaciones (`EditorTools.kt`, AnimatePanel) | Eliminado. Al elegir Ruta, Ancla, Eliminar o Congelar aparece una **indicación corta y temporal** sobre el lienzo, que desaparece en 2,6 s. Mantener pulsada cualquier herramienta muestra su ayuda. Botón **?** al final de la fila con la lista completa. |
| Panel inferior siempre visible, de alturas fijas (`EditorLayout.kt`) | **3 estados**: Contraído (solo el asa) · Compacto (predeterminado: línea de tiempo fina, herramientas y categorías) · Expandido (además, las opciones con scroll). Tocar el asa abre o cierra; deslizar hacia arriba o hacia abajo cambia de estado. Se recuerda entre sesiones y al cambiar de categoría. |
| Textos, timeline y herramientas acumulados | Las opciones solo se muestran si caben (estado expandido, o espacio sobrante bajo una imagen horizontal). La timeline de bloques solo se despliega cuando la pides y se coloca encima de las opciones. Ya no hay párrafos de ayuda fijos. |
| Doble decodificación al importar: caché de 1920 px y luego petición de 2560 px que volvía a decodificar el original (`ProjectStore.create`, `openProject`) | **Una sola decodificación**, al tamaño del teléfono (1600/2048/2560 px, `PreviewSizing`). Esa misma imagen se usa para abrir el editor (0 decodificaciones extra). La miniatura y la caché se escriben **después, en segundo plano**. Las cachés de 1920 px de proyectos antiguos se reutilizan sin re-decodificar. |
| Velo oscuro a pantalla completa al abrir (`MainActivity`) | Velo suave (la pantalla sigue viéndose) y una tarjeta pequeña con «Abriendo imagen…». |
| El shader completo se compila cada vez que se abre el editor | La primera vez se compila como en la v38 (cuando no tocas la pantalla). Después se **guarda ya compilado** (`glProgramBinary`, en la caché de código de la app) y se carga mucho más rápido. Si el driver o la app cambian, se compila de nuevo. El aviso «Preparando efectos…» desaparece en cuanto el shader está listo. |
| Mucho negro alrededor de imágenes horizontales | El lienzo toma la altura que la imagen necesita a todo el ancho. El espacio que sobra se da al panel de opciones. Nunca recorta, nunca deforma y nunca toca el zoom. |
| Miniaturas: una animación infinita a 60 fps además del reloj de 6 fps (`SimpleEditorPanels.kt`) | Solo un reloj lento compartido, leído en la fase de dibujo, sin recomposiciones. Solo existe mientras el catálogo está a la vista (panel abierto) y solo anima las tarjetas visibles. |

## Otros cambios
- **Fila de herramientas** más baja (46 dp, antes 56) con zona táctil suficiente. Los grupos están separados por una línea fina: herramientas de un dedo · animaciones · ajustes globales.
- **Proteger:**
  - nueva herramienta «Opciones»;
  - transparencia de la máscara ajustable, para que no tape la imagen (se recuerda);
  - nada de párrafos.
- **Efectos:** sin textos fijos. Al abrir el catálogo, las opciones se muestran solas si no se veían.
- **Al editar un efecto:**
  - si el panel estaba compacto, se abre solo y vuelve al estado anterior al tocar ✓ o ✕;
  - se quitaron las explicaciones largas de Tiempo, Zona y Cámara.
- **Transición del lienzo:** al plegar o desplegar el panel, el cambio de tamaño se anima en 180 ms. Durante ese momento se usa el shader ligero, para que no dé tirones.
- **Explosión:**
  - la onda de choque ya no es un anillo perfecto: es irregular y está rota en tramos;
  - el humo residual sube y se abre en bocanadas (antes era una rosquilla);
  - miniatura actualizada.
- **Tiempos reales de apertura:** se miden en tu teléfono y se ven en **Ajustes › Duración** («Última apertura · imagen · efectos · 1.er zoom»). También se escriben en el registro con la etiqueta `ZetaPerf`.

## Pruebas realmente hechas en este entorno

| Prueba | Resultado |
|---|---|
| Compilación Android real con Gradle | **No posible aquí.** Lo intenté con Gradle 8.14.3 sin conexión y el plugin de Android no se puede descargar. Lo hará Android Studio o GitHub Actions. |
| Comprobación de tipos de los 44 archivos Kotlin de la app (contra imitaciones de las librerías Android/Compose escritas por mí) | 0 errores. No equivale a la compilación real. |
| Pruebas unitarias | **66 correctas, 0 fallidas**. Las 8 nuevas (`V39Test`) comprueban: estados del panel, que todo cabe en pantalla, poco negro con imágenes horizontales, que ocultar el panel no pone pantalla completa, columna lateral en horizontal y un tamaño único de vista previa. |
| Shaders en WebGL2 (mismo lenguaje que OpenGL ES 3) | `fondo.frag` y `lite.frag` compilan y dibujan (la transparencia de la máscara funciona). Prueba de bucle sin salto superada en lluvia, nieve, sakura, nubes, rayos, humo, fuego, niebla, agua, hojas y brasas. Revisé visualmente la nueva explosión en 6 instantes. |
| Wrapper de Gradle | Generado con Gradle 8.14.3 para la versión 8.9. El `.jar` contiene `GradleWrapperMain`. No se pudo ejecutar porque descargaría Gradle (no hay red aquí). |
| GitHub | **No se hizo ninguna operación**: ni push, ni commits, ni ramas, ni workflows. |

## Pendiente de probar en tu teléfono (no se puede aquí)
1. Importar desde Archivos: anota los tiempos de **Ajustes › Duración** y compáralos con la v38.
2. Primer zoom con dos dedos nada más abrir, también tocando fuera de la imagen.
3. Imágenes horizontal, vertical y cuadrada: sin recortes ni deformación, y la vista no pasa a pantalla completa sola.
4. Asa: tocar, deslizar hacia arriba y hacia abajo. Los 3 estados deben recordarse al cerrar y volver a abrir.
5. Cambiar entre Animar, Proteger, Efectos y Ajustes: sin textos largos y sin que el lienzo cambie de tamaño.
6. Timeline: desplegar los bloques y comprobar que no pisa otros controles.
7. Efectos: vista previa, ✓ y ✕; deslizadores fluidos.
8. Proteger al personaje y aplicar un efecto al fondo; la transparencia de la máscara.
9. Varios efectos → guardar → cerrar → reabrir.
10. Exportar un MP4 y compararlo con la vista previa.
11. Abrir el editor una segunda vez: los efectos deben estar listos antes (shader guardado).
12. Rotar la pantalla, salir y volver de segundo plano, abrir 2 imágenes seguidas.
