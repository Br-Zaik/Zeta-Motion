package com.zeta.fondo.engine

import android.app.ActivityManager
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Binder
import android.os.IBinder
import com.zeta.fondo.diag.ZetaLog
import java.io.File

/**
 * La IA de profundidad corre en un PROCESO APARTE (":ia", ver AndroidManifest).
 *
 * v44.10 · Arreglos del aviso falso «no tiene memoria libre suficiente»:
 * - La app se CONECTA al proceso (bindService con BIND_IMPORTANT): mientras el editor está
 *   en pantalla, Android trata la IA como primer plano y cierra antes otras apps de fondo
 *   para darle RAM. Antes era un servicio suelto, el primero que Android cerraba.
 * - Ya no se adivina el cierre mirando la lista de procesos (fallaba a los 8 s aunque la IA
 *   siguiera calculando). Ahora: aviso de desconexión de Android + latido cada 1,5 s.
 *   La decisión está en [DepthJob.outcome].
 *
 * Comunicación por archivos en la carpeta del proyecto (simple y a prueba de cierres):
 * depth_job.txt = "running:<pid>" | "ok" | "error:<motivo>"; depth_beat.txt = último latido;
 * el mapa queda en depth.png/depth.txt.
 */
class DepthService : Service() {

    /** Solo sirve para que la app pueda conectarse (prioridad + aviso de muerte del proceso). */
    override fun onBind(intent: Intent): IBinder = Binder()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val dir = intent?.getStringExtra(EXTRA_DIR)?.let { File(it) }
        val image = intent?.getStringExtra(EXTRA_IMAGE)?.let { File(it) }
        val level = intent?.getIntExtra(EXTRA_LEVEL, 0) ?: 0
        if (dir == null || image == null || running) { stopSelf(startId); return START_NOT_STICKY }
        running = true
        ModelStore.dir = File(filesDir, "models_dl")
        try { ZetaLog.init(filesDir) } catch (_: Throwable) {}
        val status = File(dir, JOB)
        val beat = File(dir, BEAT)
        status.writeText("${DepthJob.RUNNING}:${android.os.Process.myPid()}")
        val done = java.util.concurrent.atomic.AtomicBoolean(false)
        // Latido: si el proceso muere, deja de actualizarse y la app lo nota aunque Android no avise.
        Thread({
            while (!done.get()) {
                try { beat.writeText(System.currentTimeMillis().toString()) } catch (_: Throwable) {}
                try { Thread.sleep(1500) } catch (_: InterruptedException) { break }
            }
        }, "zeta-ia-latido").apply { isDaemon = true }.start()
        Thread({
            val result = try {
                logMemory(this, "inicio nivel $level")
                val est = DepthEstimator(this).apply { this.level = level }
                kotlinx.coroutines.runBlocking { est.estimate(dir, image) }
                DepthJob.OK
            } catch (e: Throwable) {
                ZetaLog.warn("depth", "proceso IA: ${e.javaClass.simpleName} ${e.message}")
                DepthJob.ERROR + (e.message ?: e.javaClass.simpleName).take(200).replace('\n', ' ')
            }
            done.set(true)
            status.writeText(result)
            stopSelf(startId)
            // Libera TODA la memoria nativa de ONNX Runtime: el proceso :ia termina aquí.
            android.os.Process.killProcess(android.os.Process.myPid())
        }, "zeta-ia").apply { priority = Thread.NORM_PRIORITY - 1 }.start()
        return START_NOT_STICKY
    }

    /** Conexión con el proceso ":ia" de UN cálculo. [died] = Android avisó de que murió. */
    class Handle internal constructor(private val ctx: Context, val dir: File) : ServiceConnection {
        @Volatile var died = false
            private set
        @Volatile private var bound = false
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            try { service?.linkToDeath({ died = true }, 0) } catch (_: Throwable) { died = true }
        }
        override fun onServiceDisconnected(name: ComponentName?) { died = true }
        override fun onBindingDied(name: ComponentName?) { died = true }
        internal fun bind() {
            bound = try {
                ctx.bindService(Intent(ctx, DepthService::class.java), this,
                    Context.BIND_AUTO_CREATE or Context.BIND_IMPORTANT)
            } catch (e: Throwable) { ZetaLog.warn("depth", "bind: ${e.message}"); false }
        }
        /** ms desde el último latido (Long.MAX_VALUE si aún no hay). */
        fun beatAgeMs(): Long = try {
            System.currentTimeMillis() - File(dir, BEAT).readText().trim().toLong()
        } catch (_: Throwable) { Long.MAX_VALUE }
        /** Suelta la conexión: si Android había reiniciado el servicio vacío, se cierra solo. */
        fun release() {
            if (bound) { bound = false; try { ctx.unbindService(this) } catch (_: Throwable) {} }
        }
    }

    companion object {
        const val EXTRA_DIR = "dir"
        const val EXTRA_IMAGE = "image"
        const val EXTRA_LEVEL = "level"
        const val JOB = "depth_job.txt"
        const val BEAT = "depth_beat.txt"
        private const val PROCESS_SUFFIX = ":ia"
        /** Un solo cálculo a la vez dentro del proceso ":ia" (nunca dos modelos en memoria). */
        @Volatile private var running = false

        fun start(ctx: Context, projectDir: File, image: File, level: Int): Handle {
            File(projectDir, JOB).delete()
            File(projectDir, BEAT).delete()
            val h = Handle(ctx.applicationContext, projectDir)
            h.bind()
            ctx.startService(Intent(ctx, DepthService::class.java)
                .putExtra(EXTRA_DIR, projectDir.path).putExtra(EXTRA_IMAGE, image.path).putExtra(EXTRA_LEVEL, level))
            return h
        }

        /** Estado escrito por el proceso :ia (null = aún no empezó). */
        fun status(projectDir: File): String? = File(projectDir, JOB).takeIf { it.isFile }?.readText()?.trim()

        /** Cancelar: se cierra el proceso :ia (es de la propia app, mismo usuario). */
        fun cancel(ctx: Context, projectDir: File, handle: Handle?) {
            val pid = DepthJob.pid(status(projectDir)) ?: try {
                (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).runningAppProcesses
                    ?.firstOrNull { it.processName == ctx.packageName + PROCESS_SUFFIX }?.pid
            } catch (_: Throwable) { null }
            handle?.release()
            if (pid != null && pid != android.os.Process.myPid()) android.os.Process.killProcess(pid)
            File(projectDir, JOB).delete()
            File(projectDir, BEAT).delete()
        }

        /** Nivel de memoria inicial según la RAM TOTAL del teléfono (no el almacenamiento). */
        fun initialLevel(ctx: Context): Int {
            val mi = ActivityManager.MemoryInfo()
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            return DepthJob.initialLevel(mi.totalMem / (1024.0 * 1024 * 1024))
        }

        /** Deja en Diagnóstico la RAM del momento: así se sabe si de verdad faltaba memoria. */
        fun logMemory(ctx: Context, where: String) {
            try {
                val mi = ActivityManager.MemoryInfo()
                (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
                val mb = 1024 * 1024
                ZetaLog.info("depth", "RAM $where: libre ${mi.availMem / mb} MB de ${mi.totalMem / mb} MB" +
                    if (mi.lowMemory) " (memoria baja)" else "")
            } catch (_: Throwable) {}
        }
    }
}
