package com.zeta.fondo.engine

/**
 * v44.10 · Decide cómo terminó el cálculo de profundidad del proceso aparte ":ia".
 * Sin Android (se prueba en la JVM).
 *
 * Antes la app miraba la lista de procesos y, si no veía el proceso ":ia" a los 8 s,
 * lo daba por «cerrado por memoria» aunque siguiera calculando. Eso producía el aviso
 * «tu teléfono no tiene memoria libre suficiente» sin que faltara memoria.
 *
 * Ahora el proceso ":ia" escribe un LATIDO cada ~1,5 s y la app está CONECTADA a él
 * (bindService): Android avisa al instante si ese proceso muere.
 */
object DepthJob {
    const val OK = "ok"
    const val KILLED = "killed"
    const val ERROR = "error:"
    const val RUNNING = "running"

    /** Sin latido durante este tiempo = el proceso ya no existe (o quedó congelado). */
    const val BEAT_TIMEOUT_MS = 20_000L
    /** Tiempo máximo para que el proceso ":ia" arranque y escriba su estado. */
    const val START_TIMEOUT_MS = 30_000L
    const val TOTAL_TIMEOUT_MS = 10 * 60_000L

    /**
     * @param status contenido de depth_job.txt (null = aún no existe)
     * @param disconnected Android avisó de que el proceso ":ia" murió
     * @param beatAgeMs ms desde el último latido (Long.MAX_VALUE si no hay latido)
     * @param waitedMs ms desde que se pidió el cálculo
     * @return [OK], "error:<motivo>", [KILLED] o null (sigue calculando)
     */
    fun outcome(status: String?, disconnected: Boolean, beatAgeMs: Long, waitedMs: Long): String? {
        val st = status?.trim()
        return when {
            st == OK -> OK
            st != null && st.startsWith(ERROR) -> st
            waitedMs > TOTAL_TIMEOUT_MS -> ERROR + "tardó demasiado"
            st == null -> when {
                disconnected -> KILLED
                waitedMs > START_TIMEOUT_MS -> ERROR + "el proceso de IA no arrancó"
                else -> null
            }
            // st = "running[:pid]"
            disconnected -> KILLED
            beatAgeMs > BEAT_TIMEOUT_MS && waitedMs > BEAT_TIMEOUT_MS -> KILLED
            else -> null
        }
    }

    /** PID escrito por el proceso ":ia" («running:1234»), para poder cancelarlo. */
    fun pid(status: String?): Int? = status?.trim()?.takeIf { it.startsWith("$RUNNING:") }
        ?.substringAfter(':')?.toIntOrNull()

    /**
     * Niveles de memoria: 0 = normal (518 px), 1 = ahorro (392 px), 2 = mínimo (266 px),
     * 3 = solo MiDaS (256 px, el modelo más ligero). El 3 solo existe si MiDaS está descargado.
     */
    fun maxLevel(midasInstalled: Boolean): Int = if (midasInstalled) 3 else 2

    /** Nivel inicial según la RAM TOTAL del teléfono (GB). */
    fun initialLevel(totalRamGb: Double): Int = when { totalRamGb >= 7.0 -> 0; totalRamGb >= 4.5 -> 1; else -> 2 }
}
