package com.zeta.fondo.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel

/**
 * v47 · Ajustes › Mejorar imagen: superresolución anime (Real-ESRGAN animevideov3, BSD-3),
 * por baldosas y cancelable. Reversible: el original nunca se modifica; la mejorada solo se
 * usa en la vista previa y al exportar si el interruptor está activo (v44.10). Comparación de la línea fina antes/después.
 */
@Composable
fun SuperResPanel(vm: AppViewModel) {
    Column(Modifier.fillMaxSize()) {
        CapHeader("Mejorar imagen") { vm.applyAndClose() }
        PanelScroll {
            if (!vm.superResAvailable) {
                Text("Este APK no incluye el modelo de mejora.", color = StudioMuted, fontSize = 12.sp)
                return@PanelScroll
            }
            Text("Amplía la imagen x4 (hasta 4096 px) con un modelo para anime: líneas más finas y menos borrosas. " +
                "Se nota sobre todo en imágenes pequeñas o borrosas y al acercar con dos dedos. Tarda; puedes seguir editando.",
                color = StudioMuted, fontSize = 12.sp, lineHeight = 15.sp)
            val has = vm.srFile() != null
            when (val st = vm.srState) {
                is AppViewModel.AiJob.Running -> {
                    LinearProgressIndicator(progress = { vm.srProgress }, modifier = Modifier.fillMaxWidth(), color = StudioPink)
                    Text("${st.stage} ${(vm.srProgress * 100).toInt()} %", color = StudioMuted, fontSize = 11.sp)
                    SmallChoice("Cancelar", false) { vm.cancelEnhance() }
                }
                is AppViewModel.AiJob.Done -> Text(st.text, color = StudioMuted, fontSize = 11.sp)
                is AppViewModel.AiJob.Failed -> AiWarn(st.reason)
                else -> Unit
            }
            if (vm.srState !is AppViewModel.AiJob.Running) {
                if (!has) SmallChoice("Mejorar imagen (IA)", false) { vm.enhanceImage() }
                else {
                    SwitchRow("Usar la imagen mejorada", vm.srEnabled) { vm.setUseEnhanced(it) }
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        SmallChoice("Rehacer", false) { vm.enhanceImage() }
                        SmallChoice("Borrar mejorada (volver al original)", false) { vm.discardEnhanced() }
                    }
                }
            }
            vm.srCompare?.let { (before, after) ->
                Text("Línea fina: antes (original ampliado) · después (IA)", color = StudioMuted, fontSize = 11.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Image(before.asImageBitmap(), "Antes", Modifier.weight(1f).aspectRatio(1f),
                        contentScale = ContentScale.Fit, filterQuality = FilterQuality.None)
                    Image(after.asImageBitmap(), "Después", Modifier.weight(1f).aspectRatio(1f),
                        contentScale = ContentScale.Fit, filterQuality = FilterQuality.None)
                }
            }
            Text(if (vm.srEnabled) "Activa: la ves en la vista previa y se usa al exportar. Apágala para comparar con el original."
                else "Real-ESRGAN (BSD-3), ver Licencias.",
                color = StudioMuted, fontSize = 11.sp, lineHeight = 14.sp)
        }
    }
}
