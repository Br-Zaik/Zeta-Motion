package com.zeta.fondo

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zeta.fondo.engine.BitmapUtil
import com.zeta.fondo.engine.ExportCancelled
import com.zeta.fondo.engine.ExportRequest
import com.zeta.fondo.engine.ExportResult
import com.zeta.fondo.engine.Exporter
import com.zeta.fondo.engine.FlowField
import com.zeta.fondo.engine.MaskLayers
import com.zeta.fondo.engine.RenderHub
import com.zeta.fondo.engine.RenderParams
import com.zeta.fondo.model.Arrow
import com.zeta.fondo.model.EditorTab
import com.zeta.fondo.model.Effects
import com.zeta.fondo.model.ExportSettings
import com.zeta.fondo.model.MaskStroke
import com.zeta.fondo.model.PointN
import com.zeta.fondo.model.Preset
import com.zeta.fondo.model.ProjectMeta
import com.zeta.fondo.model.ProjectStore
import com.zeta.fondo.model.ProjectSummary
import com.zeta.fondo.model.Tool
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.hypot

enum class Screen { HOME, EDITOR }

sealed class ExportState {
    object Idle : ExportState()
    data class Running(val progress: Float) : ExportState()
    data class Done(val result: ExportResult) : ExportState()
    data class Failed(val message: String) : ExportState()
}

private sealed class UndoAction {
    class AddArrow(val arrow: Arrow) : UndoAction()
    class AddAnchor(val point: PointN) : UndoAction()
    class AddStroke(val stroke: MaskStroke) : UndoAction()
    class RemoveArrow(val index: Int, val arrow: Arrow) : UndoAction()
    class RemoveAnchor(val index: Int, val point: PointN) : UndoAction()
    class ClearGuides(val arrows: List<Arrow>, val anchors: List<PointN>) : UndoAction()
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val main = Handler(Looper.getMainLooper())
    private val store = ProjectStore(app)
    val hub = RenderHub()
    val vertSrc: String = app.assets.open("shaders/fondo.vert").bufferedReader().use { it.readText() }
    val fragSrc: String = app.assets.open("shaders/fondo.frag").bufferedReader().use { it.readText() }

    // ---------------- Navegación y avisos
    var screen by mutableStateOf(Screen.HOME)
    var projects by mutableStateOf<List<ProjectSummary>>(emptyList())
    var busy by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)
    var glError by mutableStateOf<String?>(null)

    // ---------------- Proyecto abierto
    var meta by mutableStateOf<ProjectMeta?>(null)
        private set
    val arrows = mutableStateListOf<Arrow>()
    val anchors = mutableStateListOf<PointN>()
    var masks: MaskLayers? = null
        private set
    var maskNames by mutableStateOf<List<String>>(listOf("Congelar", "Zona azul", "Zona verde"))
        private set
    var selectedMaskLayer by mutableStateOf(0)
        private set
    var settings by mutableStateOf(Effects.defaults())
        private set
    var exportSettings by mutableStateOf(ExportSettings())
        private set

    // ---------------- Herramientas
    var tool by mutableStateOf(Tool.ARROW)
    var eraser by mutableStateOf(false)
    var brushDp by mutableFloatStateOf(36f)
    var feather by mutableFloatStateOf(0.35f)
    var showGuides by mutableStateOf(true)
    var showMasks by mutableStateOf(true)
        private set
    var playing by mutableStateOf(true)
        private set
    var scrubT by mutableFloatStateOf(0f)
        private set
    var tab by mutableStateOf(EditorTab.TOOLS)
        private set
    var fullscreen by mutableStateOf(false)
    var activeMotionEffect by mutableStateOf<String?>(null)

    // ---------------- Vista (zoom del editor)
    var viewScale by mutableFloatStateOf(1f)
        private set
    var viewX by mutableFloatStateOf(0f)
        private set
    var viewY by mutableFloatStateOf(0f)
        private set

    // ---------------- Deshacer
    private val undoStack = ArrayList<UndoAction>()
    var canUndo by mutableStateOf(false)
        private set
    private var currentStroke: MaskStroke? = null
    private var flowJob: Job? = null

    // ---------------- Exportación
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
        private set
    private val cancelFlag = AtomicBoolean(false)
    private var lastProgressPost = -1f

    val aspect: Float
        get() = meta?.let { it.w.toFloat() / it.h } ?: 1f

    init {
        hub.onError = { msg -> main.post { glError = msg } }
        refreshProjects()
    }

    // ============================================================ Proyectos

    fun refreshProjects() {
        viewModelScope.launch {
            projects = withContext(Dispatchers.IO) { store.list() }
        }
    }

    fun importImage(uri: Uri) {
        if (busy != null) return
        saveProject()
        busy = "Importando imagen…"
        viewModelScope.launch {
            try {
                val id = withContext(Dispatchers.IO) { store.create(uri) }
                busy = null
                openProject(id)
            } catch (e: Throwable) {
                busy = null
                message = "No se pudo importar: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    fun openProject(id: String) {
        busy = "Abriendo proyecto…"
        viewModelScope.launch {
            try {
                val loaded = withContext(Dispatchers.IO) { store.load(id) }
                val preview: Bitmap = withContext(Dispatchers.IO) {
                    BitmapUtil.decodeAtMost(loaded.meta.imageFile, PREVIEW_MAX)
                }
                val mk = withContext(Dispatchers.Default) {
                    MaskLayers.create(loaded.meta.w, loaded.meta.h).also {
                        it.setAll(loaded.strokes, loaded.maskNames)
                    }
                }
                meta = loaded.meta
                arrows.clear()
                arrows.addAll(loaded.arrows)
                anchors.clear()
                anchors.addAll(loaded.anchors)
                masks = mk
                maskNames = mk.names.toList()
                selectedMaskLayer = 0
                hub.activeMask = 0
                settings = loaded.settings
                exportSettings = loaded.export
                undoStack.clear()
                canUndo = false
                currentStroke = null
                exportState = ExportState.Idle
                glError = null
                resetView()
                tool = Tool.ARROW
                tab = EditorTab.TOOLS
                fullscreen = false
                activeMotionEffect = null
                playing = true
                hub.setPlaying(true)

                hub.image = preview
                hub.masks = mk
                hub.flow = null
                hub.showMask = showMasks
                pushParams()
                recomputeFlow()
                screen = Screen.EDITOR
            } catch (e: Throwable) {
                message = "No se pudo abrir: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                busy = null
            }
        }
    }

    fun saveProject() {
        val m = meta ?: return
        val mk = masks ?: return
        val a = ArrayList(arrows)
        val an = ArrayList(anchors)
        val st = mk.snapshot()
        val labels = mk.names.toList()
        val s = settings
        val ex = exportSettings
        viewModelScope.launch(Dispatchers.IO) {
            try {
                store.save(m, a, an, st, s, ex, labels)
            } catch (e: Exception) {
                main.post { message = "No se pudo guardar el proyecto: ${e.message}" }
            }
        }
    }

    fun closeEditor() {
        if (exportState is ExportState.Running) {
            message = "Espera a que termine la exportación o cancélala."
            return
        }
        fullscreen = false
        saveProject()
        screen = Screen.HOME
        meta = null
        hub.image = null
        refreshProjects()
    }

    fun deleteProject(id: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { store.delete(id) }
            refreshProjects()
        }
    }

    // ============================================================ Efectos

    fun selectTab(t: EditorTab) {
        tab = t
        if (t == EditorTab.MASKS && !tool.isBrush) selectMask(selectedMaskLayer)
        if (t == EditorTab.TOOLS && tool.isBrush) tool = Tool.ARROW
    }

    fun addMask() {
        val mk = masks ?: return
        val i = mk.addLayer("Máscara ${maskNames.size - 2}")
        if (i < 0) { message = "Máximo ${MaskLayers.MAX_MASKS} máscaras para cuidar la memoria del dispositivo."; return }
        maskNames = mk.names.toList()
        selectMask(i)
    }

    fun selectMask(index: Int) {
        if (index !in maskNames.indices) return
        selectedMaskLayer = index
        hub.activeMask = index
        tool = when (index) {
            0 -> Tool.FREEZE
            1 -> Tool.ZONE1
            2 -> Tool.ZONE2
            else -> Tool.MASK
        }
        showMasks = true
        hub.showMask = true
    }

    fun renameMask(index: Int, label: String) {
        val mk = masks ?: return
        mk.renameLayer(index, label)
        maskNames = mk.names.toList()
    }

    fun setEffectMask(id: String, index: Int) {
        setSetting("$id.mask", index.toFloat())
    }

    fun setSetting(key: String, value: Float) {
        settings = settings + (key to value)
        pushParams()
        if (key == "flow.reach") recomputeFlow()
    }

    fun moveEffectOrigin(p: PointN) {
        val id = activeMotionEffect ?: return
        settings = settings + mapOf("$id.origin" to 0f, "$id.originX" to p.x, "$id.originY" to p.y)
        pushParams()
    }

    fun setMotionOrigin(id: String, origin: Int) {
        val angles = floatArrayOf(Float.NaN, 90f, 270f, 0f, 180f, 45f, 135f, 315f, 225f)
        val update = mapOf("$id.origin" to origin.coerceIn(0, 8).toFloat())
        settings = settings + update + (if (origin in 1..8) mapOf("$id.direction" to angles[origin]) else emptyMap())
        pushParams()
    }

    fun applyPreset(p: Preset) {
        settings = settings + p.values
        pushParams()
        message = "${p.emoji} ${p.name}: ${p.hint}"
    }

    fun clearEffects() {
        settings = Effects.allOff(settings)
        pushParams()
    }

    fun updateExport(e: ExportSettings) {
        exportSettings = e
        if (exportState is ExportState.Done || exportState is ExportState.Failed) exportState = ExportState.Idle
        hub.setLoopSec(e.loopSec.toFloat())
    }

    private fun pushParams() {
        hub.params = RenderParams.from(settings, aspect)
        hub.setLoopSec(exportSettings.loopSec.toFloat())
    }

    private fun recomputeFlow() {
        val a = ArrayList(arrows)
        val an = ArrayList(anchors)
        val asp = aspect
        val reach = settings["flow.reach"] ?: Effects.default("flow.reach")
        flowJob?.cancel()
        flowJob = viewModelScope.launch {
            val data: FlowField.Data = withContext(Dispatchers.Default) { FlowField.compute(a, an, asp, reach) }
            hub.flow = data
        }
    }

    // ============================================================ Reproducción

    fun togglePlay() {
        playing = !playing
        hub.setPlaying(playing)
        if (!playing) scrubT = hub.pausedT()
    }

    fun scrubTo(t: Float) {
        scrubT = t
        hub.setPausedT(t)
    }

    fun toggleMasks() {
        showMasks = !showMasks
        hub.showMask = showMasks
    }

    // ============================================================ Vista

    fun resetView() {
        viewScale = 1f
        viewX = 0f
        viewY = 0f
        syncView()
    }

    private fun syncView() {
        hub.viewScale = viewScale
        hub.viewX = viewX
        hub.viewY = viewY
    }

    /** zoom = factor, pan y centroide en fracción del tamaño de la vista. */
    fun transformView(zoom: Float, panX: Float, panY: Float, cx: Float, cy: Float) {
        val s0 = viewScale
        val s1 = (s0 * zoom).coerceIn(1f, 10f)
        val ux = viewX + cx / s0
        val uy = viewY + cy / s0
        val maxOff = 1f - 1f / s1
        viewX = (ux - cx / s1 - panX / s1).coerceIn(0f, maxOff)
        viewY = (uy - cy / s1 - panY / s1).coerceIn(0f, maxOff)
        viewScale = s1
        syncView()
    }

    fun screenToUv(nx: Float, ny: Float): PointN = PointN(
        (viewX + nx / viewScale).coerceIn(0f, 1f),
        (viewY + ny / viewScale).coerceIn(0f, 1f)
    )

    // ============================================================ Edición

    private fun pushUndo(a: UndoAction) {
        undoStack.add(a)
        if (undoStack.size > 200) undoStack.removeAt(0)
        canUndo = true
    }

    fun addArrow(a: Arrow) {
        arrows.add(a)
        pushUndo(UndoAction.AddArrow(a))
        recomputeFlow()
    }

    fun addQuickDirection(direction: Int) {
        val vectors = arrayOf(
            PointN(0f, -0.22f), PointN(0.22f, -0.22f), PointN(0.22f, 0f),
            PointN(0.22f, 0.22f), PointN(0f, 0.22f), PointN(-0.22f, 0.22f),
            PointN(-0.22f, 0f), PointN(-0.22f, -0.22f)
        )
        val v = vectors[direction.coerceIn(0, 7)]
        addArrow(Arrow(0.5f - v.x * 0.5f, 0.5f - v.y * 0.5f, 0.5f + v.x * 0.5f, 0.5f + v.y * 0.5f))
        tool = Tool.ARROW
        message = "Flecha añadida en el centro. Puedes arrastrarla o añadir anclas para delimitar la zona."
    }

    fun addAnchor(p: PointN) {
        anchors.add(p)
        pushUndo(UndoAction.AddAnchor(p))
        recomputeFlow()
    }

    fun removeArrowAt(i: Int) {
        if (i !in arrows.indices) return
        val a = arrows.removeAt(i)
        pushUndo(UndoAction.RemoveArrow(i, a))
        recomputeFlow()
    }

    fun removeAnchorAt(i: Int) {
        if (i !in anchors.indices) return
        val p = anchors.removeAt(i)
        pushUndo(UndoAction.RemoveAnchor(i, p))
        recomputeFlow()
    }

    fun clearGuides() {
        if (arrows.isEmpty() && anchors.isEmpty()) return
        pushUndo(UndoAction.ClearGuides(ArrayList(arrows), ArrayList(anchors)))
        arrows.clear()
        anchors.clear()
        recomputeFlow()
    }

    /** radiusUv: radio del pincel en fracción de la altura de la imagen. */
    fun beginStroke(p: PointN, radiusUv: Float) {
        val mk = masks ?: return
        val layer = if (tool == Tool.MASK) selectedMaskLayer else tool.layer
        if (layer < 0) return
        val s = MaskStroke(layer, radiusUv, feather, eraser)
        s.points.add(p)
        mk.addStroke(s)
        currentStroke = s
        pushUndo(UndoAction.AddStroke(s))
    }

    fun continueStroke(p: PointN) {
        val s = currentStroke ?: return
        val last = s.points.lastOrNull()
        if (last != null && hypot((p.x - last.x).toDouble(), (p.y - last.y).toDouble()) < 0.0015) return
        masks?.extendStroke(s, p)
    }

    fun endStroke() {
        currentStroke = null
    }

    fun cancelStroke() {
        val s = currentStroke ?: return
        currentStroke = null
        masks?.removeStroke(s)
        val last = undoStack.lastOrNull()
        if (last is UndoAction.AddStroke && last.stroke === s) undoStack.removeAt(undoStack.size - 1)
        canUndo = undoStack.isNotEmpty()
    }

    /** Rellena (clear=false) o vacía (clear=true) toda la capa de la herramienta actual. */
    fun fillLayer(clear: Boolean) {
        val mk = masks ?: return
        val layer = if (tool == Tool.MASK) selectedMaskLayer else tool.layer
        if (layer < 0) return
        val s = MaskStroke(layer, 0f, 0f, clear, fill = true)
        mk.addStroke(s)
        pushUndo(UndoAction.AddStroke(s))
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val a = undoStack.removeAt(undoStack.size - 1)
        when (a) {
            is UndoAction.AddArrow -> {
                val i = arrows.lastIndexOf(a.arrow)
                if (i >= 0) arrows.removeAt(i)
                recomputeFlow()
            }
            is UndoAction.AddAnchor -> {
                val i = anchors.lastIndexOf(a.point)
                if (i >= 0) anchors.removeAt(i)
                recomputeFlow()
            }
            is UndoAction.AddStroke -> masks?.removeStroke(a.stroke)
            is UndoAction.RemoveArrow -> {
                arrows.add(a.index.coerceIn(0, arrows.size), a.arrow)
                recomputeFlow()
            }
            is UndoAction.RemoveAnchor -> {
                anchors.add(a.index.coerceIn(0, anchors.size), a.point)
                recomputeFlow()
            }
            is UndoAction.ClearGuides -> {
                arrows.addAll(a.arrows)
                anchors.addAll(a.anchors)
                recomputeFlow()
            }
        }
        canUndo = undoStack.isNotEmpty()
    }

    // ============================================================ Exportar

    fun startExport() {
        val m = meta ?: return
        val mk = masks ?: return
        if (exportState is ExportState.Running) return
        saveProject()
        cancelFlag.set(false)
        lastProgressPost = -1f
        exportState = ExportState.Running(0f)
        hub.renderEnabled = false

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val req = ExportRequest(
            imageFile = m.imageFile,
            imgW = m.w,
            imgH = m.h,
            name = "ZetaMotion_$stamp",
            settings = exportSettings,
            params = RenderParams.from(settings, aspect),
            flow = hub.flow ?: FlowField.compute(ArrayList(arrows), ArrayList(anchors), aspect, settings["flow.reach"] ?: 0.25f),
            masks = mk
        )
        val exporter = Exporter(getApplication<Application>(), vertSrc, fragSrc)
        viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.Default) {
                    exporter.run(req, cancelFlag) { p -> postProgress(p) }
                }
                exportState = ExportState.Done(result)
            } catch (e: ExportCancelled) {
                exportState = ExportState.Idle
                message = "Exportación cancelada."
            } catch (e: OutOfMemoryError) {
                exportState = ExportState.Failed("No hay memoria suficiente para esa resolución. Prueba con una menor.")
            } catch (e: Throwable) {
                exportState = ExportState.Failed(e.message ?: e.toString())
            } finally {
                hub.renderEnabled = true
            }
        }
    }

    private fun postProgress(p: Float) {
        if (p - lastProgressPost < 0.005f && p < 1f) return
        lastProgressPost = p
        main.post {
            if (exportState is ExportState.Running) exportState = ExportState.Running(p)
        }
    }

    fun cancelExport() {
        cancelFlag.set(true)
    }

    fun dismissExportResult() {
        exportState = ExportState.Idle
    }

    override fun onCleared() {
        cancelFlag.set(true)
        super.onCleared()
    }

    companion object {
        const val PREVIEW_MAX = 2048
    }
}
