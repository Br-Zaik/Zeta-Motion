package com.zeta.fondo.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.ExportState
import com.zeta.fondo.engine.ExportPlanner
import com.zeta.fondo.engine.CodecSupport
import com.zeta.fondo.export.ShareUtil
import com.zeta.fondo.model.Effects
import com.zeta.fondo.model.EffectDef
import com.zeta.fondo.model.Kind
import com.zeta.fondo.model.Preset
import com.zeta.fondo.model.Presets
import com.zeta.fondo.model.Tool
import java.util.Locale

@Composable
private fun PanelColumn(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        content()
        Spacer(Modifier.padding(bottom = 12.dp))
    }
}

// ============================================================== Editar

@Composable
fun ToolsPanel(vm: AppViewModel) {
    PanelColumn {
        Text("MOVIMIENTO POR FLECHAS", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Hint("Dibuja flechas sobre cabello, ropa, agua y fondo. Congela el personaje en Máscaras.")
        val quick = intArrayOf(7, 0, 1, 6, -1, 2, 5, 4, 3)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("↖", "↑", "↗", "←", "·", "→", "↙", "↓", "↘").forEachIndexed { i, label ->
                Pill(label, false, compact = true) { if (quick[i] >= 0) vm.addQuickDirection(quick[i]) }
            }
        }
        val tools = listOf(Tool.ARROW, Tool.ANCHOR, Tool.ERASE_GUIDE, Tool.ORIGIN, Tool.PAN)
        PillRow(tools.map { it.label }, tools.indexOf(vm.tool)) { vm.tool = tools[it] }
        Hint(vm.tool.hint)
        Text("${vm.arrows.size} flechas · ${vm.anchors.size} anclas", color = Mist, fontSize = 12.sp)
        if (vm.tool == Tool.ARROW || vm.tool == Tool.ANCHOR || vm.tool == Tool.ERASE_GUIDE) {
            ActionButton("Borrar todas las flechas y anclas", Modifier.fillMaxWidth(), primary = false) { vm.clearGuides() }
        }
        LabeledSlider("Distancia del movimiento", vm.settings["flow.amount"] ?: 0.35f,
            0.05f, 1f, false) { vm.setSetting("flow.amount", it) }
        LabeledSlider("Velocidad", vm.settings["flow.cycles"] ?: 2f,
            1f, 8f, true) { vm.setSetting("flow.cycles", it) }
    }
}

@Composable
fun MasksPanel(vm: AppViewModel) {
    PanelColumn {
        Text("MÁSCARAS DE MOVIMIENTO", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Hint("Congelar mantiene el dibujo quieto. Zona azul se aplica a efectos con la opción 'solo en zona'. Zona verde, al viento/calor de ilustraciones.")
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            vm.maskNames.forEachIndexed { i, label ->
                Pill(label, i == vm.selectedMaskLayer, compact = true) { vm.selectMask(i) }
            }
            Pill("＋ Nueva", false, compact = true) { vm.addMask() }
        }
        val selected = vm.selectedMaskLayer
        if (selected > 0 && selected < vm.maskNames.size) {
            var name by remember(selected) { mutableStateOf(vm.maskNames[selected]) }
            OutlinedTextField(value = name, onValueChange = { name = it; vm.renameMask(selected, it) },
                label = { Text("Nombre de la máscara") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
        Hint(vm.tool.hint)
        LabeledSlider("Grosor pincel", vm.brushDp, 6f, 140f, true, suffix = " dp") { vm.brushDp = it }
        LabeledSlider("Suavizado", vm.feather, 0f, 1f, false) { vm.feather = it }
        SwitchRow("Goma", vm.eraser) { vm.eraser = it }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            ActionButton("Rellenar", Modifier.weight(1f), primary = false) { vm.fillLayer(false) }
            ActionButton("Vaciar", Modifier.weight(1f), primary = false) { vm.fillLayer(true) }
        }
        SwitchRow("Ver máscaras en canvas", vm.showMasks) { vm.toggleMasks() }
        Hint("Crea hasta 12 máscaras nombradas y aplícalas desde la configuración de cada efecto. Sus colores no se exportan.")
    }
}

@Composable
fun CameraPanel(vm: AppViewModel) {
    val c = Effects.all.first { it.id == "cam" }
    PanelColumn {
        Text("CÁMARA DE ANIME", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        SwitchRow("Activar movimiento de cámara", (vm.settings["cam.on"] ?: 0f) > 0.5f) {
            vm.setSetting("cam.on", if (it) 1f else 0f)
        }
        c.params.forEach { EffectParameter(vm, c, it) }
        Hint("Zoom y paneo terminan en el mismo encuadre para que el bucle no salte. Usa las flechas para movimiento de partes.")
        LabeledSlider("Duración", vm.exportSettings.loopSec.toFloat(), 2f, 15f, true, suffix = " s") {
            vm.updateExport(vm.exportSettings.copy(loopSec = it.toInt()))
        }
    }
}

// ============================================================== Presets

@Composable
fun PresetsPanel(vm: AppViewModel) {
    PanelColumn {
        Hint("Los presets se suman a lo que ya tienes. Luego ajusta cada efecto en la pestaña Efectos.")
        Text("Anime a color", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        PresetGrid(Presets.all.filter { !it.manga }) { vm.applyPreset(it) }
        Text("Manga blanco y negro", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        PresetGrid(Presets.all.filter { it.manga }) { vm.applyPreset(it) }
        ActionButton("Quitar todos los efectos", Modifier.fillMaxWidth(), primary = false) { vm.clearEffects() }
    }
}

@Composable
private fun PresetGrid(list: List<Preset>, onPick: (Preset) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        list.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { p ->
                    Row(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Dusk1)
                            .clickable { onPick(p) }
                            .padding(horizontal = 12.dp, vertical = 12.dp)
                    ) {
                        Text(p.emoji, fontSize = 18.sp)
                        Text(
                            p.name,
                            color = Ink,
                            fontSize = 13.sp,
                            maxLines = 2,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

// ============================================================== Efectos

/** Biblioteca compacta + editor contextual. No se despliegan 40 tarjetas gigantes. */
@Composable
fun EffectsPanel(vm: AppViewModel, initialCategory: String = "Anime") {
    val s = vm.settings
    var category by remember(initialCategory) { mutableStateOf(initialCategory) }
    var selected by remember { mutableStateOf<String?>(null) }
    var advanced by remember { mutableStateOf(false) }
    val categories = listOf("Anime", "Ambiente", "Batalla", "Manga", "Movimiento", "Cámara", "Todos")
    val ids = when (category) {
        "Anime" -> setOf("sway", "ripple", "sakura", "rays", "energy", "snow", "fog", "leaves", "flies", "runes", "pulse", "comet")
        "Ambiente" -> setOf("rain", "snow", "sakura", "stars", "flies", "fog", "ash", "leaves", "embers", "dust", "bubbles", "rays", "glint", "smoke", "shards", "comet")
        "Batalla" -> setOf("energy", "electric", "shock", "flash", "focus", "speed", "embers", "ash", "heat", "shards", "pulse", "comet", "runes", "smoke")
        "Manga" -> setOf("focus", "speed", "tone", "grain", "ink", "flash", "style", "hatch")
        "Movimiento" -> setOf("flow", "drift", "ripple", "glint", "sway", "heat")
        "Cámara" -> setOf("cam")
        else -> Effects.all.map { it.id }.toSet()
    }
    val directional = setOf("rain", "snow", "sakura", "fog", "rays", "energy", "speed",
        "ash", "leaves", "embers", "dust", "bubbles", "electric", "focus", "shock", "comet", "runes", "pulse", "smoke", "shards")
    val def = Effects.all.firstOrNull { it.id == selected }
    PanelColumn {
        Text("EFECTOS · ANIME / MANGA", color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            categories.forEach { c -> Pill(c, category == c, compact = true) { category = c; selected = null } }
        }
        Hint("Toca un efecto para configurarlo; pulsa + para añadirlo o desactivarlo.")
        Effects.all.filter { it.id in ids }.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                pair.forEach { e ->
                    val active = !e.toggleable || (s["${e.id}.on"] ?: 0f) > 0.5f
                    Row(Modifier.weight(1f).clip(RoundedCornerShape(13.dp))
                        .background(if (selected == e.id) Dusk2 else Dusk1)
                        .clickable { selected = if (selected == e.id) null else e.id; vm.activeMotionEffect = selected; advanced = false }
                        .padding(horizontal = 9.dp, vertical = 10.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(e.emoji, fontSize = 17.sp)
                        Column(Modifier.weight(1f).padding(start = 5.dp)) {
                            Text(e.title, color = Ink, fontSize = 11.sp, maxLines = 2)
                            Text(if (active) "Activo" else "Toca para ajustar", color = if (active) Sky else Mist, fontSize = 10.sp)
                        }
                        if (e.toggleable) {
                            Text(if (active) "✓" else "+", color = if (active) Sky else Peach, fontSize = 19.sp,
                                modifier = Modifier.clickable {
                                    vm.setSetting("${e.id}.on", if (active) 0f else 1f)
                                    selected = e.id
                                    vm.activeMotionEffect = e.id
                                }.padding(2.dp))
                        }
                    }
                }
                if (pair.size < 2) Spacer(Modifier.weight(1f))
            }
        }
        if (def != null) {
            val on = !def.toggleable || (s["${def.id}.on"] ?: 0f) > 0.5f
            SectionCard("${def.emoji}  ${def.title}") {
                if (def.toggleable) SwitchRow("Activar efecto", on) {
                    vm.setSetting("${def.id}.on", if (it) 1f else 0f)
                }
                if (on) {
                    Hint(def.hint)
                    // Sólo los parámetros de uso inmediato son visibles por defecto.
                    def.params.filter { it.key != "zone" }.forEachIndexed { index, param ->
                        if (advanced || index < 2 || param.key == "cycles") {
                            EffectParameter(vm, def, param)
                        }
                    }
                    if (def.id in directional) MotionControls(vm, def.id, advanced)
                    if (advanced) {
                        Text("Aplicar solamente en", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        val slot = (vm.settings["${def.id}.mask"] ?: -1f).toInt()
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Pill("Auto / toda", slot < 0, compact = true) { vm.setEffectMask(def.id, -1) }
                            vm.maskNames.forEachIndexed { i, name ->
                                Pill(name, slot == i, compact = true) { vm.setEffectMask(def.id, i) }
                            }
                        }
                        def.params.firstOrNull { it.key == "zone" }?.let { p ->
                            val key = "${def.id}.${p.key}"
                            SwitchRow("Solo en zona azul (máscara)", (s[key] ?: p.def) > 0.5f) {
                                vm.setSetting(key, if (it) 1f else 0f)
                            }
                        }
                    }
                    if (def.id in setOf("ash", "leaves", "embers", "dust", "bubbles", "electric",
                            "focus", "shock", "flash", "tone", "grain", "ink")) {
                        val copyId = "${def.id}.copy"
                        val copyOn = (s["$copyId.on"] ?: 0f) > 0.5f
                        SectionCard("◫ Segunda capa independiente") {
                            SwitchRow("Activar segunda instancia", copyOn) {
                                vm.setSetting("$copyId.on", if (it) 1f else 0f)
                            }
                            if (copyOn) {
                                Hint("Cada capa mantiene sus propios valores, posición, dirección y máscara.")
                                def.params.filter { it.key != "zone" }.forEach { param ->
                                    val key = "$copyId.${param.key}"
                                    val value = s[key] ?: (s["${def.id}.${param.key}"] ?: param.def)
                                    if (param.kind == Kind.TOGGLE) SwitchRow(param.label, value > 0.5f) {
                                        vm.setSetting(key, if (it) 1f else 0f)
                                    } else LabeledSlider(param.label, value, param.min, param.max, param.kind == Kind.INT) {
                                        vm.setSetting(key, it)
                                    }
                                }
                                if (def.id in directional) {
                                    val origins = listOf("Centro", "Arriba", "Abajo", "Izquierda", "Derecha", "↖", "↗", "↙", "↘")
                                    val origin = (s["$copyId.origin"] ?: 0f).toInt()
                                    Text("Origen capa B", color = Ink, fontSize = 13.sp)
                                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                        origins.forEachIndexed { index, label ->
                                            Pill(label, origin == index, compact = true) {
                                                vm.setSetting("$copyId.origin", index.toFloat())
                                            }
                                        }
                                    }
                                    LabeledSlider("Dirección capa B", s["$copyId.direction"] ?: 0f,
                                        0f, 360f, true, suffix = "°") { vm.setSetting("$copyId.direction", it) }
                                    LabeledSlider("Origen X capa B", s["$copyId.originX"] ?: 0.5f,
                                        0f, 1f, false) { vm.setSetting("$copyId.originX", it) }
                                    LabeledSlider("Origen Y capa B", s["$copyId.originY"] ?: 0.5f,
                                        0f, 1f, false) { vm.setSetting("$copyId.originY", it) }
                                }
                                Text("Máscara de la capa B", color = Ink, fontSize = 13.sp)
                                val mask = (s["$copyId.mask"] ?: -1f).toInt()
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Pill("Toda", mask < 0, compact = true) { vm.setSetting("$copyId.mask", -1f) }
                                    vm.maskNames.forEachIndexed { i, name ->
                                        Pill(name, mask == i, compact = true) { vm.setSetting("$copyId.mask", i.toFloat()) }
                                    }
                                }
                            }
                        }
                    }
                    ActionButton(if (advanced) "⌃ Menos controles" else "⌄ Ajustes avanzados",
                        Modifier.fillMaxWidth(), primary = false) { advanced = !advanced }
                }
            }
        }
        LabeledSlider("Duración del bucle", vm.exportSettings.loopSec.toFloat(), 2f, 15f, true, suffix = " s") {
            vm.updateExport(vm.exportSettings.copy(loopSec = it.toInt()))
        }
    }
}

@Composable
private fun EffectParameter(vm: AppViewModel, def: EffectDef, p: com.zeta.fondo.model.ParamDef) {
    val key = "${def.id}.${p.key}"
    val value = vm.settings[key] ?: p.def
    if (p.kind == Kind.TOGGLE) SwitchRow(p.label, value > 0.5f) {
        vm.setSetting(key, if (it) 1f else 0f)
    } else LabeledSlider(p.label, value, p.min, p.max, p.kind == Kind.INT) {
        vm.setSetting(key, it)
    }
}

@Composable
private fun MotionControls(vm: AppViewModel, id: String, advanced: Boolean) {
    val origins = listOf("Punto", "Arriba", "Abajo", "Izquierda", "Derecha", "↖", "↗", "↙", "↘")
    val k = "$id.origin"
    val cur = (vm.settings[k] ?: 0f).toInt().coerceIn(0, 8)
    Text("Origen del movimiento", color = Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        origins.forEachIndexed { index, text ->
            Pill(text, index == cur, compact = true) { vm.setMotionOrigin(id, index) }
        }
    }
    val radial = id in setOf("energy", "electric", "focus", "shock", "rays")
    if (!radial) {
    val deg = vm.settings["$id.direction"] ?: when (id) {
        "rain", "snow", "dust" -> 90f
        "ash", "embers", "bubbles" -> 270f
        "sakura", "leaves" -> 135f
        else -> 0f
    }
    Text("Dirección 360°", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        listOf("↖", "↑", "↗", "←", "→", "↙", "↓", "↘").forEachIndexed { i, symbol ->
            val d = listOf(225f, 270f, 315f, 180f, 0f, 135f, 90f, 45f)[i]
            Pill(symbol, kotlin.math.abs(deg - d) < 1f, compact = true) { vm.setSetting("$id.direction", d) }
        }
    }
    LabeledSlider("Ángulo exacto", deg, 0f, 360f, true, suffix = "°") {
        vm.setSetting("$id.direction", it)
    }
    }
    ActionButton("◎ Marcar origen en el dibujo", Modifier.fillMaxWidth(), primary = false) {
        vm.activeMotionEffect = id
        vm.setMotionOrigin(id, 0)
        vm.tool = Tool.ORIGIN
        vm.message = "Toca o arrastra el punto de origen sobre el anime. Oculta el panel para tener más espacio."
    }
    if (advanced && cur == 0) {
        LabeledSlider("Punto X", vm.settings["$id.originX"] ?: 0.5f, 0f, 1f, false) {
            vm.setSetting("$id.originX", it)
        }
        LabeledSlider("Punto Y", vm.settings["$id.originY"] ?: 0.5f, 0f, 1f, false) {
            vm.setSetting("$id.originY", it)
        }
    }
}

// ============================================================== Exportar

@Composable
fun ExportPanel(vm: AppViewModel) {
    val ctx = LocalContext.current
    val e = vm.exportSettings
    val meta = vm.meta ?: return
    val state = vm.exportState
    val running = state is ExportState.Running

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startExport() else vm.message = "Sin permiso de almacenamiento no se puede guardar en la Galería."
    }

    fun doExport() {
        if (Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            vm.startExport()
        }
    }

    PanelColumn {
        when (state) {
            is ExportState.Running -> {
                SectionCard("Exportando… ${(state.progress * 100).toInt()} %") {
                    VSpace(6)
                    ProgressBar(state.progress)
                    VSpace(10)
                    Hint("Puedes dejar la app abierta. En 4K puede tardar varios minutos.")
                    VSpace(8)
                    ActionButton("Cancelar", Modifier.fillMaxWidth(), primary = false) { vm.cancelExport() }
                }
            }
            is ExportState.Done -> {
                val r = state.result
                SectionCard("✅ Listo: ${r.width}×${r.height} · ${r.fps} fps") {
                    VSpace(4)
                    Hint("Guardado en Galería › ${r.galleryPath}")
                    if (r.reducedFrom != null) {
                        Hint("Tu teléfono no codifica ${r.reducedFrom}, así que se ajustó al máximo que acepta.")
                    }
                    if (r.rotated) {
                        Hint("Se guardó en horizontal con marca de rotación (así lo hace la cámara). Se verá vertical.")
                    }
                    if (r.isPng) {
                        Hint("${r.frames} cuadros PNG sin pérdida. Úsalos en un editor que importe secuencias de imágenes.")
                    }
                    val file = r.file
                    if (!r.isPng && file != null) {
                        VSpace(8)
                        ActionButton("🎬  Enviar a Alight Motion", Modifier.fillMaxWidth()) {
                            if (!ShareUtil.sendToAlight(ctx, file)) {
                                vm.message = "Elige Alight Motion en el menú, o ábrelo e importa el vídeo desde la Galería."
                            }
                        }
                        VSpace(8)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ActionButton("Compartir…", Modifier.weight(1f), primary = false) {
                                ShareUtil.shareChooser(ctx, file)
                            }
                            ActionButton("Abrir Alight", Modifier.weight(1f), primary = false) {
                                if (!ShareUtil.openAlight(ctx)) vm.message = "No encontré Alight Motion instalado."
                            }
                        }
                        VSpace(8)
                        Hint("En Alight Motion: + › Media › Video, elige el archivo y déjalo como la capa de más abajo.")
                    }
                    VSpace(8)
                    ActionButton("Exportar otra versión", Modifier.fillMaxWidth(), primary = false) { vm.dismissExportResult() }
                }
            }
            is ExportState.Failed -> {
                SectionCard("⚠️ No se pudo exportar") {
                    VSpace(4)
                    Text(state.message, color = Danger, fontSize = 13.sp)
                    VSpace(6)
                    Hint("Prueba con menos resolución o 30 fps. Si se repite, envíame este mensaje.")
                }
            }
            ExportState.Idle -> Unit
        }

        if (state !is ExportState.Done) {
            Label("Formato")
            PillRow(listOf("🎬 Vídeo MP4", "🖼 Secuencia PNG"), e.format, enabled = !running) {
                vm.updateExport(e.copy(format = it))
            }
            Label("Resolución")
            PillRow(ExportPlanner.resLabels, e.res, enabled = !running) { vm.updateExport(e.copy(res = it)) }
            if (e.res == 6) {
                LabeledSlider("Ancho personalizado", e.customW.toFloat(), 128f, 7680f, true,
                    enabled = !running, suffix = " px") {
                    vm.updateExport(e.copy(customW = it.toInt()))
                }
                LabeledSlider("Alto personalizado", e.customH.toFloat(), 128f, 7680f, true,
                    enabled = !running, suffix = " px") {
                    vm.updateExport(e.copy(customH = it.toInt()))
                }
            }
            if (e.res == 6) Hint("La proporción del tamaño personalizado determina el encuadre; no se estira la ilustración.")
            if (e.res != 6) {
            Label("Encuadre")
            PillRow(
                listOf("Imagen completa", "9:16 vertical", "16:9 horizontal", "1:1 cuadrado"),
                e.framing, enabled = !running
            ) { vm.updateExport(e.copy(framing = it)) }
            }
            if (e.framing != 0 || e.res == 6) {
                LabeledSlider("Posición del recorte", e.cropPos, 0f, 1f, false, enabled = !running) {
                    vm.updateExport(e.copy(cropPos = it))
                }
            }
            Label("Cuadros por segundo")
            PillRow(listOf("24", "30", "60"), listOf(24, 30, 60).indexOf(e.fps).coerceAtLeast(0), enabled = !running) {
                vm.updateExport(e.copy(fps = listOf(24, 30, 60)[it]))
            }
            LabeledSlider("Duración del loop", e.loopSec.toFloat(), 2f, 15f, true, enabled = !running, suffix = " s") {
                vm.updateExport(e.copy(loopSec = it.toInt()))
            }
            if (e.format == 0) {
                LabeledSlider("Repetir el loop", e.repeats.toFloat(), 1f, 10f, true, enabled = !running, suffix = " ×") {
                    vm.updateExport(e.copy(repeats = it.toInt()))
                }
                Label("Codificador disponible en tu dispositivo")
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CodecSupport.names.forEachIndexed { i, name ->
                        if (CodecSupport.usable(i)) Pill(name, e.codec == i, enabled = !running) {
                            vm.updateExport(e.copy(codec = i))
                        }
                    }
                }
                Label("Calidad")
                PillRow(ExportPlanner.qualityLabels, e.quality, enabled = !running) { vm.updateExport(e.copy(quality = it)) }
            }
            SwitchRow("Solo efectos sobre fondo negro", e.overlayOnly, enabled = !running) {
                vm.updateExport(e.copy(overlayOnly = it))
            }
            if (e.overlayOnly) {
                Hint("Exporta solo lluvia, nieve, estrellas, etc. En Alight Motion ponlo encima de tu fondo con fusión Pantalla o Añadir.")
            }

            val (w, h) = ExportPlanner.targetSize(meta.w, meta.h, e)
            val seconds = e.loopSec * (if (e.format == 0) e.repeats else 1)
            val summary = if (e.format == 0) {
                val br = ExportPlanner.bitrate(w, h, e.fps, e.quality)
                val mb = br.toDouble() * seconds / 8.0 / 1_000_000.0
                String.format(
                    Locale.US, "Salida: %d×%d · %d fps · %d s · ~%.0f Mbps · ~%.0f MB",
                    w, h, e.fps, seconds, br / 1_000_000.0, mb
                )
            } else {
                "Salida: ${w}×$h · ${e.loopSec * e.fps} imágenes PNG"
            }
            Text(summary, color = Ink, fontSize = 13.sp)
            val cr = ExportPlanner.cropForSettings(meta.w, meta.h, e)
            if (w > meta.w * cr[2] + 1f || h > meta.h * cr[3] + 1f) {
                Hint("Escalar no crea detalle nuevo. Para nitidez real utiliza una ilustración fuente de alta resolución.")
            }
            ActionButton(if (running) "Exportando…" else "📤  Exportar", Modifier.fillMaxWidth(), enabled = !running) {
                doExport()
            }
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(text, color = Mist, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
}
