package com.zeta.fondo.engine

import com.zeta.fondo.model.Effects
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/** Valores listos para los uniforms del shader. Inmutable: se reemplaza entero. */
class RenderParams(
    val aspect: Float,
    val flow: FloatArray,    // 3
    val drift: FloatArray,   // 2
    val ripple: FloatArray,  // 3
    val glint: FloatArray,   // 3
    val sway: FloatArray,    // 3
    val heat: FloatArray,    // 3
    val rain: FloatArray,    // 4
    val snow: FloatArray,    // 4
    val sakura: FloatArray,  // 4
    val stars: FloatArray,   // 4
    val flies: FloatArray,   // 4
    val fog: FloatArray,     // 4
    val rays: FloatArray,    // 4
    val energy: FloatArray,  // 4
    val speed: FloatArray,   // 4
    val cam: FloatArray,     // 3
    val mono: Float,
    val snap: Float,
    val motion: Map<String, FloatArray>,
    val extra: Map<String, FloatArray>,
    val effectMasks: Map<String, Int>,
    val copyMotion: Map<String, FloatArray>,
    val copyExtra: Map<String, FloatArray>,
    val copyMasks: Map<String, Int>
) {
    companion object {
        fun from(s: Map<String, Float>, aspect: Float): RenderParams {
            fun v(k: String): Float = s[k] ?: Effects.default(k)
            fun on(id: String): Boolean = v("$id.on") > 0.5f
            fun cyc(id: String): Float = max(1, v("$id.cycles").roundToInt()).toFloat()
            fun v3(id: String, a: String, b: String) =
                floatArrayOf(if (on(id)) v("$id.$a") else 0f, v("$id.$b"), cyc(id))
            fun v4(id: String, a: String, b: String, conv: (Float) -> Float = { it }) =
                floatArrayOf(if (on(id)) v("$id.$a") else 0f, conv(v("$id.$b")), cyc(id), v("$id.zone"))

            val asp = if (aspect > 0f) aspect else 1f
            val drift = if (on("drift")) {
                val a = Math.toRadians(v("drift.dir").toDouble())
                val sp = v("drift.speed")
                floatArrayOf((cos(a) * sp / asp).toFloat(), (-sin(a) * sp).toFloat())
            } else floatArrayOf(0f, 0f)

            val directional = listOf("rain", "snow", "sakura", "fog", "rays", "energy", "speed",
                "ash", "leaves", "embers", "dust", "bubbles", "electric", "focus", "shock",
                "comet", "runes", "pulse", "smoke", "shards")
            val defaultsAngle = mapOf("rain" to 90f, "snow" to 90f, "sakura" to 135f,
                "ash" to 270f, "embers" to 270f, "bubbles" to 270f, "dust" to 90f,
                "leaves" to 135f, "fog" to 0f)
            val motion = directional.associateWith { id ->
                val angle = Math.toRadians((s["$id.direction"] ?: defaultsAngle[id] ?: 0f).toDouble())
                val origin = (s["$id.origin"] ?: 0f).toInt()
                val spots = arrayOf(floatArrayOf(0.5f, 0.5f), floatArrayOf(0.5f, 0f),
                    floatArrayOf(0.5f, 1f), floatArrayOf(0f, 0.5f), floatArrayOf(1f, 0.5f),
                    floatArrayOf(0f, 0f), floatArrayOf(1f, 0f), floatArrayOf(0f, 1f),
                    floatArrayOf(1f, 1f))
                val pt = spots[origin.coerceIn(0, 8)]
                if (id == "rays" && !s.containsKey("$id.origin")) {
                    pt[0] = v("rays.x")
                    pt[1] = 0f
                }
                floatArrayOf(cos(angle).toFloat(), sin(angle).toFloat(),
                    (if (origin == 0) s["$id.originX"] ?: pt[0] else pt[0]).coerceIn(0f, 1f),
                    (if (origin == 0) s["$id.originY"] ?: pt[1] else pt[1]).coerceIn(0f, 1f))
            }
            val extras = listOf("ash", "leaves", "embers", "dust", "bubbles", "electric", "focus",
                "shock", "flash", "tone", "grain", "ink", "comet", "runes", "hatch",
                "pulse", "smoke", "shards").associateWith { id ->
                val def = Effects.all.first { it.id == id }
                fun param(key: String): Float = v("$id.$key")
                floatArrayOf(if (on(id)) param("int") else 0f,
                    param(def.params.firstOrNull { it.key != "int" && it.key != "cycles" && it.key != "zone" }?.key ?: "int"),
                    cyc(id), param("zone"))
            }
            // Instancia B: mismo motor, parámetros, máscara, origen y velocidad independientes.
            val copyIds = listOf("ash", "leaves", "embers", "dust", "bubbles", "electric",
                "focus", "shock", "flash", "tone", "grain", "ink")
            val copyExtras = copyIds.associateWith { id ->
                val def = Effects.all.first { it.id == id }
                val prefix = "$id.copy"
                fun param(k: String) = s["$prefix.$k"] ?: v("$id.$k")
                floatArrayOf(if ((s["$prefix.on"] ?: 0f) > 0.5f) param("int") else 0f,
                    param(def.params.firstOrNull { it.key != "int" && it.key != "cycles" && it.key != "zone" }?.key ?: "int"),
                    max(1, param("cycles").roundToInt()).toFloat(), param("zone"))
            }
            val copyMotions = copyIds.filter { it in directional }.associateWith { id ->
                val prefix = "$id.copy"
                val angle = Math.toRadians((s["$prefix.direction"] ?: s["$id.direction"]
                    ?: defaultsAngle[id] ?: 0f).toDouble())
                val origin = (s["$prefix.origin"] ?: 0f).toInt().coerceIn(0, 8)
                val spots = arrayOf(floatArrayOf(0.5f, 0.5f), floatArrayOf(0.5f, 0f),
                    floatArrayOf(0.5f, 1f), floatArrayOf(0f, 0.5f), floatArrayOf(1f, 0.5f),
                    floatArrayOf(0f, 0f), floatArrayOf(1f, 0f), floatArrayOf(0f, 1f),
                    floatArrayOf(1f, 1f))
                val spot = spots[origin]
                floatArrayOf(cos(angle).toFloat(), sin(angle).toFloat(),
                    (if (origin == 0) s["$prefix.originX"] ?: spot[0] else spot[0]).coerceIn(0f, 1f),
                    (if (origin == 0) s["$prefix.originY"] ?: spot[1] else spot[1]).coerceIn(0f, 1f))
            }
            return RenderParams(
                aspect = asp,
                flow = floatArrayOf(if (on("flow")) 1f else 0f, v("flow.amount"), cyc("flow")),
                drift = drift,
                ripple = v3("ripple", "amp", "freq"),
                glint = v3("glint", "int", "dens"),
                sway = v3("sway", "amp", "freq"),
                heat = v3("heat", "amp", "freq"),
                rain = v4("rain", "int", "angle") { Math.toRadians(it.toDouble()).toFloat() },
                snow = v4("snow", "int", "size"),
                sakura = v4("sakura", "int", "size"),
                stars = v4("stars", "int", "dens"),
                flies = v4("flies", "int", "dens"),
                fog = v4("fog", "int", "scale"),
                rays = v4("rays", "int", "x"),
                energy = v4("energy", "int", "dens"),
                speed = v4("speed", "int", "angle"),
                cam = floatArrayOf(
                    if (on("cam")) v("cam.zoom") else 0f,
                    if (on("cam")) v("cam.pan") else 0f,
                    cyc("cam")
                ),
                mono = if (v("style.mono") > 0.5f) 1f else 0f,
                snap = if (v("style.snap") > 0.5f) 1f else 0f,
                motion = motion,
                extra = extras,
                effectMasks = Effects.all.associate { it.id to (s["${it.id}.mask"]?.toInt() ?: -1) },
                copyMotion = copyMotions,
                copyExtra = copyExtras,
                copyMasks = copyIds.associateWith { id -> s["$id.copy.mask"]?.toInt() ?: -1 }
            )
        }
    }
}
