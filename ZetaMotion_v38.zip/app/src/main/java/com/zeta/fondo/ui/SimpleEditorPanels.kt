package com.zeta.fondo.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.model.*

/** Pincel de la zona de un efecto (o Congelar en Animar). Dos dedos siempre hacen zoom. */
@Composable
fun SimpleBrushPanel(vm: AppViewModel) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 10.dp)) {
        Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.finishEdit(false) }) { Icon(Icons.Default.Close, "Descartar", tint = StudioText) }
            Text(when (vm.editingEffect) {
                null -> "Congelar: pinta lo que NO se mueve"
                "zonemotion" -> "Pinta lo que se mueve"
                else -> "Zona de ${Effects.all.firstOrNull { it.id == vm.editingEffect }?.let(::effectShortTitle) ?: "efecto"}"
            }, color = StudioText, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            IconButton(onClick = { if (vm.editingEffect == null) vm.finishEdit(true) else vm.finishPainting() }) {
                Icon(Icons.Default.Check, "Listo", tint = StudioPink)
            }
        }
        if (vm.editingEffect == null) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SmallChoice("Pincel", !vm.eraser) { vm.eraser = false }
            SmallChoice("Borrador", vm.eraser) { vm.eraser = true }
            SmallChoice("Rellenar", false) { vm.fillLayer(false) }
            SmallChoice("Vaciar", false) { vm.fillLayer(true) }
        }
        LabeledSlider("Tamaño", vm.brushDp, 6f, 140f, true) { vm.brushDp = it }
        LabeledSlider("Borde suave", vm.feather, 0f, 1f, false) { vm.feather = it }
        Text("1 dedo pinta · 2 dedos acercan y mueven · ↶ deshace", color = StudioMuted, fontSize = 11.sp)
    }
}

private val elementNames = listOf("Nube", "Humo", "Pétalos", "Brillos", "Energía", "Niebla")
private val elementIcons = listOf(Icons.Default.Cloud, Icons.Default.BlurOn, Icons.Default.LocalFlorist,
    Icons.Default.AutoAwesome, Icons.Default.Bolt, Icons.Default.CloudQueue)

private val categoryIcons: Map<String, ImageVector> = mapOf(
    "Populares" to Icons.Filled.Star, "Activos" to Icons.Filled.CheckCircle,
    "Fuego" to Icons.Filled.LocalFireDepartment, "Agua" to Icons.Filled.Waves, "Clima" to Icons.Filled.Cloud,
    "Luz" to Icons.Filled.LightMode, "Energía" to Icons.Filled.Bolt, "Anime" to Icons.Filled.AutoAwesome,
    "Manga" to Icons.Filled.MenuBook, "Escenas" to Icons.Filled.Movie, "Todos" to Icons.Filled.GridView
)

private fun catalogTitle(id: String): String = when (id) {
    "gust" -> "Viento"
    "shore" -> "Olas"
    "leaves" -> "Hojas"
    "rain" -> "Lluvia"
    "snow" -> "Nieve"
    "elements" -> "Elementos"
    "clouds3" -> "Nubes"
    "blast" -> "Explosión"
    "slash" -> "Corte"
    "reveal" -> "Aparecer"
    "bolt" -> "Relámpago"
    "water" -> "Agua"
    "sky" -> "Cielo"
    else -> Effects.all.firstOrNull { it.id == id }?.let(::effectShortTitle) ?: id
}

/** Efectos cuyo origen se elige tocando o arrastrando sobre la imagen. */
private val originEffects = setOf("tornado", "blast", "blood", "slash", "smoke", "energy", "rays",
    "focus", "speed", "electric", "shock", "runes", "comet", "fog")

/** Capas que se dibujan sobre la imagen y pueden pasar por detrás del personaje. */
private val behindCapable = setOf("smoke", "fog", "rain", "snow", "sakura", "leaves", "embers", "ash", "dust",
    "rays", "energy", "clouds3", "bokeh", "sparkle", "lightleak", "blast", "flame", "electric", "speed",
    "focus", "shock", "comet", "bubbles", "blackaura", "stars", "flies", "sky", "runes", "shards")

private val directionEffects = setOf("rain", "snow", "sakura", "fog", "rays", "energy", "speed", "leaves", "embers",
    "dust", "bubbles", "comet", "smoke", "gust", "shore", "blast", "ash", "electric")

// ------------------------------------------------------------------ Efectos · catálogo

/** Fila de herramientas de Efectos: categorías con icono (Activos muestra cuántos hay). */
@Composable
fun EffectCategoryRow(vm: AppViewModel, modifier: Modifier) {
    val category = EffectCatalog.normalize(vm.effectsCategory)
    val active = vm.activeEffectsCount
    Row(modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
        EffectCatalog.categories.forEach { c ->
            if (c == "Activos" && active == 0) return@forEach
            ToolChip(c, categoryIcons[c] ?: Icons.Filled.AutoAwesome, c == category,
                badge = if (c == "Activos") active.toString() else null) { vm.effectsCategory = c }
        }
    }
}

/** Cuadrícula de efectos de la categoría: miniatura animada real + nombre corto. */
@Composable
fun EffectCatalogPanel(vm: AppViewModel) {
    val category = EffectCatalog.normalize(vm.effectsCategory)
    val thumbTick = rememberThumbTick()
    val anim = rememberInfiniteTransition(label = "glyphs")
    val animatedTime = anim.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "t")
    if (category == "Escenas") {
        val scenes = remember { Presets.scenes }
        LazyVerticalGrid(GridCells.Adaptive(96.dp), Modifier.fillMaxSize(),
            contentPadding = PaddingValues(8.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(scenes, key = { it.name }) { scene ->
                val mainEffect = Presets.sceneMainEffect(scene)
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(StudioTile)
                    .clickable { vm.applyPreset(scene); vm.editEffect(mainEffect) }.padding(3.dp)) {
                    EffectThumb(mainEffect, animate = true, tick = thumbTick, glyphTime = { animatedTime.value },
                        modifier = Modifier.fillMaxWidth().height(58.dp))
                    Text(scene.name, color = StudioText, fontSize = 10.sp, lineHeight = 12.sp, maxLines = 2,
                        textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth().padding(top = 3.dp))
                }
            }
        }
        return
    }
    // La lista solo se recalcula si cambian la categoría o los efectos ENCENDIDOS (no con
    // cada movimiento de un deslizador): menos trabajo al ajustar.
    val onKey by remember { derivedStateOf { EffectSwitches.active(vm.settings).keys.sorted().joinToString(",") } }
    val shown = remember(category, onKey) {
        EffectCatalog.idsFor(category, Effects.all.map { it.id }) { vm.isEffectOn(it) }
    }
    Column(Modifier.fillMaxSize()) {
        if (category == "Activos" && shown.isNotEmpty()) Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 2.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Toca un efecto para ajustarlo", color = StudioMuted, fontSize = 11.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { vm.removeAllEffects() }) { Text("Quitar todos", fontSize = 12.sp, color = StudioMuted) }
        }
        if (shown.isEmpty()) {
            Text("Aún no hay efectos activos. Elige uno en Populares.", color = StudioMuted, fontSize = 12.sp,
                modifier = Modifier.padding(14.dp))
        }
        LazyVerticalGrid(GridCells.Adaptive(78.dp), Modifier.weight(1f), contentPadding = PaddingValues(8.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(shown, key = { it }) { eid ->
                val active = if (eid == "elements") (0..3).any { (vm.settings["element$it.on"] ?: 0f) > .5f }
                    else vm.isEffectOn(eid)
                // Tocar = vista previa REAL sobre tu imagen dentro de una edición: ✓ la
                // aplica y ✕ la descarta sin dejar rastro.
                EffectCard(eid, catalogTitle(eid), active, { animatedTime.value }, thumbTick,
                    onTap = { vm.editEffect(eid) })
            }
        }
    }
}

@Composable
private fun EffectCard(id: String, title: String, active: Boolean, time: () -> Float, tick: () -> Int,
                       onTap: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Column(Modifier.clip(shape)
        .background(if (active) StudioPink.copy(alpha = .16f) else StudioTile)
        .then(if (active) Modifier.border(1.5.dp, StudioPink, shape) else Modifier)
        .clickable(onClick = onTap)
        .padding(3.dp)) {
        Box(Modifier.fillMaxWidth().aspectRatio(1.25f)) {
            EffectThumb(id, animate = true, tick = tick, glyphTime = time, modifier = Modifier.fillMaxSize())
            if (active) Box(Modifier.align(Alignment.TopEnd).padding(4.dp).size(8.dp).clip(CircleShape).background(StudioPink))
        }
        Text(title, color = StudioText, fontSize = 11.sp, lineHeight = 12.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            modifier = Modifier.fillMaxWidth().padding(top = 3.dp, bottom = 1.dp))
    }
}

// ------------------------------------------------------------------ Efectos · editor

private fun sectionsOf(id: String): List<String> =
    EffectCatalog.sections(id, id in Effects.colorable, Effects.shapeLabels.containsKey(id))

private val sectionIcons: Map<String, ImageVector> = mapOf(
    "Ajustes" to Icons.Filled.Tune, "Estilo" to Icons.Filled.Style, "Color" to Icons.Filled.Palette,
    "Tiempo" to Icons.Filled.Schedule, "Zona" to Icons.Filled.Brush
)

/** Al editar un efecto, la fila de herramientas muestra sus secciones. */
@Composable
fun EffectSectionRow(vm: AppViewModel, id: String, modifier: Modifier) {
    val sections = sectionsOf(id)
    val current = vm.effectSection.takeIf { it in sections } ?: "Ajustes"
    val problem = vm.zoneProblem(id)
    Row(modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
        sections.forEach { s ->
            ToolChip(s, sectionIcons[s] ?: Icons.Filled.Tune, s == current,
                badge = if (s == "Zona" && problem != null) "!" else null) { vm.effectSection = s }
        }
    }
}

/** Editor de un efecto: cabecera (✕ descartar · nombre · ✓ aplicar) y la sección elegida. */
@Composable
fun EffectEditorPanel(vm: AppViewModel, id: String) {
    val def = Effects.all.firstOrNull { it.id == id }
    val sections = sectionsOf(id)
    val section = vm.effectSection.takeIf { it in sections } ?: "Ajustes"
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(42.dp).padding(end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.finishEdit(false) }) { Icon(Icons.Default.Close, "Descartar", tint = StudioText) }
            val headerTick = rememberThumbTick()
            EffectThumb(id, animate = true, tick = headerTick, glyphTime = { 0f },
                modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)))
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(catalogTitle(id), color = StudioText, maxLines = 1, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(if (vm.isEffectOn(id) || id == "elements") "Vista previa · ✓ para aplicar" else "Desactivado",
                    color = StudioMuted, fontSize = 10.sp, maxLines = 1)
            }
            if (id != "elements") {
                val on = vm.isEffectOn(id)
                Icon(if (on) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                    if (on) "Ocultar efecto" else "Mostrar efecto", tint = if (on) StudioText else StudioMuted,
                    modifier = Modifier.size(40.dp).clip(CircleShape).clickable { vm.toggleEffect(id) }.padding(9.dp))
            }
            Box(Modifier.padding(start = 2.dp, end = 4.dp).height(32.dp).clip(RoundedCornerShape(10.dp))
                .background(StudioGradient).clickable { vm.finishEdit(true) }.padding(horizontal = 12.dp),
                contentAlignment = Alignment.Center) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Check, null, tint = StudioText, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Aplicar", color = StudioText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)) {
            vm.zoneProblem(id)?.let { problem ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(StudioOrange.copy(alpha = .16f))
                    .clickable { if (id == "energy") vm.protect() else if (id == "parallax") vm.paintBuiltinMask(2) else vm.paintEffectZone() }
                    .padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Brush, null, tint = StudioOrange, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(problem, color = StudioText, fontSize = 12.sp, modifier = Modifier.weight(1f))
                }
            }
            when {
                id == "elements" -> ElementsControls(vm)
                def == null -> Unit
                section == "Ajustes" -> EffectBasics(vm, def)
                section == "Estilo" -> EffectStyle(vm, id)
                section == "Color" -> EffectColor(vm, id)
                section == "Tiempo" -> EffectTimingControls(vm, id)
                section == "Zona" -> EffectZone(vm, id)
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}

/** Ajustes principales: intensidad, velocidad, tamaño, dirección… (los finos en Avanzado). */
@Composable
private fun EffectBasics(vm: AppViewModel, def: EffectDef) {
    val id = def.id
    if (id == "appear") CharacterControls(vm)
    if (id == "parallax") {
        Text("Pinta el fondo (azul) y el primer plano (verde)", color = StudioMuted, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            SmallChoice("Pintar fondo", vm.maskHasPaint(1), dot = Sky) { vm.paintBuiltinMask(1) }
            SmallChoice("Pintar primer plano", vm.maskHasPaint(2), dot = Color(0xFF6BD68A)) { vm.paintBuiltinMask(2) }
        }
    }
    if (id == "natural") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            SmallChoice("Pintar lo que se mueve", vm.maskHasPaint((vm.settings["natural.mask"] ?: 2f).toInt().coerceAtLeast(0))) { vm.paintEffectZone() }
            SmallChoice(if (vm.playing) "Pausar" else "Ver movimiento", vm.playing) {
                if (!vm.isEffectOn("natural")) vm.toggleEffect("natural")
                vm.togglePlay()
            }
        }
        Text("Borde fijo (raíz)", color = StudioMuted, fontSize = 11.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            val anchorIcons = listOf(Icons.Default.Block, Icons.Default.ArrowBack, Icons.Default.ArrowForward,
                Icons.Default.ArrowDownward, Icons.Default.ArrowUpward)
            val anchorLabels = listOf("Sin borde fijo", "Borde izquierdo fijo", "Borde derecho fijo",
                "Borde inferior fijo", "Borde superior fijo")
            anchorIcons.forEachIndexed { index, icon ->
                StudioIconAction(anchorLabels[index], icon, Modifier.weight(1f).height(40.dp),
                    selected = (vm.settings["natural.anchor"] ?: 3f).toInt() == index) {
                    vm.setSetting("natural.anchor", index.toFloat())
                }
            }
        }
    }
    if (id == "bolt" && (vm.exportSettings.ambient["thunder"] ?: 0f) <= 0.01f) {
        SmallChoice("+ Sonido de trueno", false) { vm.toggleAmbient("thunder") }
    }
    val hiddenTimelineParams = when (id) {
        "gust" -> setOf("start", "dur")
        "appear" -> setOf("start", "dur")
        "impact" -> setOf("start", "cycles")
        "bolt" -> setOf("cycles")
        else -> emptySet()
    }
    val params = def.params.filter { p ->
        p.key !in listOf("zone", "variant", "mode", "anchor", "shape") && !(id == "shore" && p.key == "tint") &&
            p.key !in hiddenTimelineParams &&
            (vm.advancedMode || !p.advanced) &&
            !(id == "zonemotion" && (vm.settings["zonemotion.variant"] ?: 0f) > 1.5f && p.key == "direction") &&
            !(id == "cam" && (vm.settings["cam.mode"] ?: 0f).toInt() !in setOf(2, 5) && p.key == "direction")
    }
    // Orden fijo y predecible: intensidad → velocidad → tamaño → el resto.
    val order = listOf("int", "amp", "amount", "opacity", "cycles", "speed", "size", "scale", "dens", "density")
    params.sortedBy { p -> order.indexOf(p.key).let { if (it < 0) 99 else it } }.forEach { p -> EffectParameter(vm, def, p) }
    if (id in directionEffects && def.params.none { it.key == "direction" || it.key == "dir" }) {
        val defAngle = when (id) { "gust", "blast", "fog" -> 0f; "smoke", "ash", "embers", "bubbles" -> 270f; else -> 90f }
        DirectionDial("Dirección", vm.settings["$id.direction"] ?: defAngle) { vm.setSetting("$id.direction", it) }
    }
    if (def.params.any { it.advanced }) SwitchRow(if (vm.advancedMode) "Controles avanzados" else "Mostrar controles avanzados",
        vm.advancedMode) { if (it != vm.advancedMode) vm.toggleAdvancedMode() }
    if (id == "cam" && (vm.settings["cam.mode"] ?: 0f) > 4.5f) {
        Text("Órbita 3D simulada: perspectiva suave que vuelve al inicio del bucle. Mantén poco zoom.",
            color = StudioMuted, fontSize = 11.sp)
    }
}

/** Estilo: variantes (Suave, Tormenta, Otoño…) y formas del efecto. */
@Composable
private fun EffectStyle(vm: AppViewModel, id: String) {
    val variants = EffectCatalog.variants(id)
    if (variants.isNotEmpty()) {
        Text("Estilo", color = StudioMuted, fontSize = 11.sp)
        FlowChoices(variants, (vm.settings[if (id == "cam") "cam.mode" else "$id.variant"] ?: 0f).toInt()) { i ->
            val key = if (id == "cam") "cam.mode" else "$id.variant"
            if (id in EffectCatalog.styledPresets) vm.applyEffectStyle(id, i)
            else if (id == "natural") vm.applyNaturalPreset(i)
            else vm.setSetting(key, i.toFloat())
        }
    }
    Effects.shapeLabels[id]?.let { shapes ->
        Text(Effects.all.first { it.id == id }.params.firstOrNull { it.key == "shape" }?.label ?: "Forma",
            color = StudioMuted, fontSize = 11.sp)
        FlowChoices(shapes, (vm.settings["$id.shape"] ?: 0f).toInt()) { i -> vm.setSetting("$id.shape", i.toFloat()) }
    }
}

/** Opciones en varias filas (sin desplazamiento lateral escondido). */
@Composable
private fun FlowChoices(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    labels.chunked(3).forEachIndexed { row, chunk ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            chunk.forEachIndexed { k, label ->
                val i = row * 3 + k
                Box(Modifier.weight(1f).height(36.dp).clip(RoundedCornerShape(10.dp))
                    .background(if (i == selected) StudioPink else StudioTile)
                    .clickable { onSelect(i) }, contentAlignment = Alignment.Center) {
                    Text(label, color = StudioText, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        fontWeight = if (i == selected) FontWeight.SemiBold else FontWeight.Medium)
                }
            }
            repeat(3 - chunk.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable
private fun EffectColor(vm: AppViewModel, id: String) {
    if (id in Effects.colorable) EffectColorRow(vm, id)
    if (id == "shore") {
        Text("Color de la espuma", color = StudioMuted, fontSize = 11.sp)
        FlowChoices(listOf("Natural", "Turquesa", "Azul", "Atardecer", "Noche"), (vm.settings["shore.tint"] ?: 0f).toInt()) {
            vm.setSetting("shore.tint", it.toFloat())
        }
    }
}

/** Zona: dónde actúa (toda la imagen, zona pintada), origen y si pasa detrás del personaje. */
@Composable
private fun EffectZone(vm: AppViewModel, id: String) {
    val slot = (vm.settings["$id.mask"] ?: -2f).toInt()
    if (id != "natural") {
        Text("Dónde se ve", color = StudioMuted, fontSize = 11.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.weight(1f)) { SmallChoice("Toda la imagen", slot == -2) { vm.wholeEffectZone() } }
            Box(Modifier.weight(1f)) { SmallChoice("Pintar zona", slot >= 0) { vm.paintEffectZone() } }
        }
    } else {
        SmallChoice("Pintar lo que se mueve", true) { vm.paintEffectZone() }
    }
    if (id in originEffects) {
        Text("Origen", color = StudioMuted, fontSize = 11.sp)
        SmallChoice(if (vm.tool == Tool.ORIGIN) "Toca o arrastra sobre la imagen" else "Elegir origen en la imagen",
            vm.tool == Tool.ORIGIN) { vm.pickOrigin(id) }
    }
    if (id in behindCapable) SwitchRow("Detrás del personaje", vm.isBehind(id)) { vm.setBehind(id, it) }
    if (vm.maskNames.size > 1 && id != "natural") {
        Text("Usar una zona ya pintada", color = StudioMuted, fontSize = 11.sp)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            vm.maskNames.drop(1).forEachIndexed { offset, name ->
                val index = offset + 1
                SmallChoice(when (index) { 1 -> "Zona azul"; 2 -> "Zona verde"; else -> name }, slot == index) { vm.setEffectMask(id, index) }
            }
        }
    }
    when (id) {
        "reveal" -> Text("Pinta solo la silueta: el efecto revela lo que ya está en la imagen.", color = StudioMuted, fontSize = 11.sp)
        "smoke" -> Text("Activa «Detrás del personaje» y pinta al personaje en Proteger para que el humo pase por detrás.", color = StudioMuted, fontSize = 11.sp)
    }
}

/** Tiempo: Una vez / Repetir / Continuo para eventos; bloque y duración para el resto. */
@Composable
private fun EffectTimingControls(vm: AppViewModel, id: String) {
    if (!vm.isEffectOn(id)) {
        Text("Activa el efecto (👁) para ajustar su tiempo.", color = StudioMuted, fontSize = 12.sp)
        return
    }
    val total = vm.exportSettings.loopSec.toFloat().coerceAtLeast(2f)
    val clips = vm.clipsForEffect(id)

    if (id in Effects.eventEffects) {
        val mode = vm.eventMode(id)
        Text("Cuándo ocurre", color = StudioMuted, fontSize = 11.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Una vez" to EventMode.ONCE, "Repetir" to EventMode.REPEAT, "Continuo" to EventMode.LOOP).forEach { (label, m) ->
                Box(Modifier.weight(1f)) { SmallChoice(label, mode == m) { vm.setEventMode(id, m) } }
            }
        }
        Text(when (mode) {
            EventMode.ONCE -> "Empieza, se desarrolla y termina dentro de su bloque."
            EventMode.REPEAT -> "Se repite cada cierto tiempo."
            else -> "Se repite sin parar durante el bloque."
        }, color = StudioMuted, fontSize = 11.sp)
        if (mode == EventMode.REPEAT) LabeledSlider("Cada", vm.settings["$id.every"] ?: 2f, .4f,
            total.coerceAtLeast(1f), false, suffix = " s") { vm.setSetting("$id.every", it) }
    } else {
        val whole = clips.any { it.startSec <= .01f && it.durationSec >= total - .02f }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.weight(1f)) { SmallChoice("Todo el vídeo", whole) { vm.addWholeVideoEffectClip(id) } }
            Box(Modifier.weight(1f)) { SmallChoice("+ Otro bloque", false) { vm.addEffectClip(id) } }
        }
    }

    if (clips.isEmpty()) {
        Text("Sin bloques", color = StudioMuted, fontSize = 11.sp)
        return
    }
    val selected = clips.firstOrNull { it.uid == vm.selectedTimelineClip } ?: clips.first()
    if (clips.size > 1) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        clips.forEachIndexed { index, clip ->
            val start = String.format(java.util.Locale.US, "%.1f", clip.startSec)
            SmallChoice("${index + 1} · ${start}s", clip.uid == selected.uid) { vm.selectTimelineClip(clip.uid) }
        }
    }
    val maxStart = (total - .05f).coerceAtLeast(.05f)
    LabeledSlider("Inicio", selected.startSec, 0f, maxStart, false, suffix = " s") { newStart ->
        val newDur = selected.durationSec.coerceAtMost((total - newStart).coerceAtLeast(.05f))
        vm.setEffectClipTiming(selected.uid, newStart, newDur)
    }
    val maxDur = (total - selected.startSec).coerceAtLeast(.05f)
    LabeledSlider("Duración", selected.durationSec.coerceAtMost(maxDur), .05f, maxDur, false, suffix = " s") { newDur ->
        vm.setEffectClipTiming(selected.uid, selected.startSec, newDur)
    }
    if (vm.advancedMode) LabeledSlider("Intensidad del bloque", selected.strength, 0f, 2f, false) { value ->
        vm.setEffectClipStrength(selected.uid, value)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.weight(1f)) { SmallChoice("Duplicar bloque", false) { vm.duplicateEffectClip(selected.uid) } }
        Box(Modifier.weight(1f)) { SmallChoice("Eliminar bloque", false) { vm.removeEffectClip(selected.uid) } }
    }
}

@Composable
private fun CharacterControls(vm: AppViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importCharacter(uri)
    }
    StudioSmallButton(if (vm.hasCharacter) "Cambiar personaje (PNG)" else "Elegir personaje (PNG)",
        Icons.Default.Person, Modifier.fillMaxWidth()) {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }
    Text(if (vm.hasCharacter) "Arrastra, pellizca y gira al personaje directamente sobre la imagen."
        else "Usa un PNG con fondo transparente.",
        color = StudioMuted, fontSize = 12.sp)
}

@Composable
private fun ElementsControls(vm: AppViewModel) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        elementNames.forEachIndexed { i, name -> StudioButton(name, elementIcons[i], Modifier.width(72.dp).height(58.dp)) { vm.addElement(i) } }
    }
    val slots = (0..3).filter { (vm.settings["element$it.on"] ?: 0f) > .5f }
    if (slots.isEmpty()) Text("Elige un elemento y colócalo sobre tu imagen.", color = StudioMuted, fontSize = 12.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        slots.forEach { i -> SmallChoice("${i + 1} · ${elementNames[(vm.settings["element$i.type"] ?: 0f).toInt().coerceIn(0, 5)]}", vm.selectedElement == i) { vm.selectElement(i) } }
    }
    val slot = vm.selectedElement
    if (slot < 0 || slot !in slots) return
    val id = "element$slot"
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Arrastra · pellizca · gira con dos dedos", color = StudioMuted, fontSize = 11.sp, modifier = Modifier.weight(1f))
        IconButton(onClick = { vm.setSetting("$id.on", 0f); vm.selectElement(-1) }) { Icon(Icons.Default.DeleteOutline, "Quitar", tint = StudioText) }
    }
    LabeledSlider("Opacidad", vm.settings["$id.opacity"] ?: .7f, 0f, 1f, false) { vm.setSetting("$id.opacity", it) }
    LabeledSlider("Velocidad", vm.settings["$id.cycles"] ?: 1f, 1f, 6f, true) { vm.setSetting("$id.cycles", it) }
    LabeledSlider("Tamaño", vm.settings["$id.size"] ?: .3f, .04f, 1.5f, false) { vm.setSetting("$id.size", it) }
    LabeledSlider("Giro", vm.settings["$id.rotation"] ?: 0f, -180f, 180f, true) { vm.setSetting("$id.rotation", it) }
}
