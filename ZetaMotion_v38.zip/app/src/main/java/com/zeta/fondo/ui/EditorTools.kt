package com.zeta.fondo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.model.EditorTab
import com.zeta.fondo.model.Tool

/*
 * v38 · Herramientas del editor (fila compacta sobre las categorías) y el panel de cada
 * herramienta. Una sola regla para toda la app:
 *   categoría (abajo) → herramientas (fila) → opciones (panel sobre la fila).
 */

// ------------------------------------------------------------------ Categorías

private data class MainTab(val tab: EditorTab, val label: String, val icon: ImageVector)

private val mainTabs = listOf(
    MainTab(EditorTab.TOOLS, "Animar", Icons.Filled.PlayCircleOutline),
    MainTab(EditorTab.MASKS, "Proteger", Icons.Filled.Shield),
    MainTab(EditorTab.EFFECTS, "Efectos", Icons.Filled.AutoAwesome),
    MainTab(EditorTab.CANVAS, "Ajustes", Icons.Filled.Tune)
)

/** Las 4 categorías: compactas, con un indicador fino bajo la activa. */
@Composable
fun EditorTabBar(vm: AppViewModel, modifier: Modifier) {
    val current = when (vm.tab) {
        EditorTab.TOOLS, EditorTab.MASKS, EditorTab.EFFECTS -> vm.tab
        else -> EditorTab.CANVAS
    }
    Row(modifier.background(Night), verticalAlignment = Alignment.CenterVertically) {
        mainTabs.forEach { t ->
            val selected = current == t.tab
            Column(Modifier.weight(1f).fillMaxHeight().clickable {
                if (!selected) {
                    vm.selectTab(t.tab)
                    // Proteger abre directamente el pincel: pintar lo que no se mueve.
                    if (t.tab == EditorTab.MASKS) vm.protect()
                }
            }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(t.icon, null, tint = if (selected) StudioPink else StudioMuted, modifier = Modifier.size(22.dp))
                Spacer(Modifier.height(2.dp))
                Text(t.label, color = if (selected) StudioPink else StudioMuted, fontSize = 11.sp,
                    maxLines = 1, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
                Spacer(Modifier.height(3.dp))
                Box(Modifier.width(26.dp).height(3.dp).clip(RoundedCornerShape(2.dp))
                    .background(if (selected) StudioPink else Color.Transparent))
            }
        }
    }
}

// ------------------------------------------------------------------ Fila de herramientas

/** Botón de herramienta como en la referencia: icono + texto corto; activo = rosa. */
@Composable
fun ToolChip(label: String, icon: ImageVector, selected: Boolean, modifier: Modifier = Modifier,
             enabled: Boolean = true, badge: String? = null, onClick: () -> Unit) {
    Box(modifier.width(66.dp).fillMaxHeight().clip(RoundedCornerShape(13.dp))
        .background(if (selected) StudioPink else StudioTile)
        .clickable(enabled = enabled, onClick = onClick)) {
        Column(Modifier.fillMaxSize().padding(horizontal = 2.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = if (enabled) StudioText else StudioMuted.copy(alpha = .5f), modifier = Modifier.size(21.dp))
            Spacer(Modifier.height(4.dp))
            Text(label, color = if (enabled) StudioText else StudioMuted.copy(alpha = .5f), fontSize = 11.sp,
                lineHeight = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
        }
        if (badge != null) Text(badge, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).clip(RoundedCornerShape(6.dp))
                .background(if (selected) Night.copy(alpha = .35f) else StudioPink).padding(horizontal = 4.dp))
    }
}

@Composable
private fun ToolRowContainer(modifier: Modifier, content: @Composable RowScope.() -> Unit) {
    Row(modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically,
        content = content)
}

/** Fila compacta con las herramientas de la categoría activa. */
@Composable
fun EditorToolRow(vm: AppViewModel, modifier: Modifier) {
    val editing = vm.editingEffect
    val m = modifier.background(Night)
    when {
        vm.paintingZone && editing != null -> BrushToolRow(vm, m, onDone = { vm.finishPainting() })
        editing != null -> EffectSectionRow(vm, editing, m)
        vm.tab == EditorTab.TOOLS -> AnimateToolRow(vm, m)
        vm.tab == EditorTab.MASKS -> ProtectToolRow(vm, m)
        vm.tab == EditorTab.EFFECTS -> EffectCategoryRow(vm, m)
        else -> SettingsToolRow(vm, m)
    }
}

private val animEffects = listOf(
    Triple("natural", "Natural", Icons.Filled.Air),
    Triple("parallax", "2.5D", Icons.Filled.Layers),
    Triple("mesh", "Ondular", Icons.Filled.Waves),
    Triple("zonemotion", "Zona", Icons.Filled.Gesture),
    Triple("cam", "Cámara", Icons.Filled.Videocam)
)

@Composable
private fun AnimateToolRow(vm: AppViewModel, modifier: Modifier) {
    val freezing = vm.paintingZone && vm.editingEffect == null
    val guide = vm.editingEffect == null && !freezing && vm.animPanel.isEmpty()
    ToolRowContainer(modifier) {
        ToolChip("Ruta", Icons.Filled.Timeline, guide && vm.tool == Tool.ARROW,
            badge = vm.arrows.size.takeIf { it > 0 }?.toString()) { vm.selectGuideTool(Tool.ARROW) }
        ToolChip("Ancla", Icons.Filled.PushPin, guide && vm.tool == Tool.ANCHOR,
            badge = vm.anchors.size.takeIf { it > 0 }?.toString()) { vm.selectGuideTool(Tool.ANCHOR) }
        ToolChip("Eliminar", Icons.Filled.DeleteOutline, guide && vm.tool == Tool.ERASE_GUIDE,
            enabled = vm.arrows.isNotEmpty() || vm.anchors.isNotEmpty()) { vm.selectGuideTool(Tool.ERASE_GUIDE) }
        ToolChip("Congelar", Icons.Filled.AcUnit, freezing) {
            if (freezing) vm.finishEdit(true) else vm.freezeZone()
        }
        animEffects.forEach { (id, label, icon) ->
            ToolChip(label, icon, vm.editingEffect == id, badge = if (vm.isEffectOn(id)) "●" else null) {
                if (id == "zonemotion") vm.editZoneMotion() else vm.editEffect(id)
            }
        }
        ToolChip("Bucle", Icons.Filled.AllInclusive, vm.animPanel == "loop") {
            vm.finishEdit(true)
            vm.animPanel = if (vm.animPanel == "loop") "" else "loop"
        }
    }
}

@Composable
private fun ProtectToolRow(vm: AppViewModel, modifier: Modifier) {
    val painting = vm.paintingZone
    ToolRowContainer(modifier) {
        ToolChip("Pincel", Icons.Filled.Brush, painting && !vm.eraser) {
            if (!painting) vm.protect()
            vm.eraser = false
        }
        ToolChip("Borrador", ZetaEraserIcon, painting && vm.eraser) {
            if (!painting) vm.protect()
            vm.eraser = true
        }
        ToolChip("Rellenar", Icons.Filled.FormatColorFill, false) {
            if (!painting) vm.protect()
            vm.fillLayer(false)
        }
        ToolChip("Vaciar", Icons.Filled.LayersClear, false) {
            if (!painting) vm.protect()
            vm.fillLayer(true)
        }
        ToolChip(if (vm.showMasks) "Ocultar" else "Ver", if (vm.showMasks) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
            false) { vm.toggleMasks() }
        ToolChip("Punto fijo", Icons.Filled.PushPin, !painting && vm.tool == Tool.ANCHOR) { vm.protectPoints() }
        ToolChip("Quitar punto", Icons.Filled.DeleteOutline, !painting && vm.tool == Tool.ERASE_GUIDE,
            enabled = vm.anchors.isNotEmpty()) { vm.protectPoints(true) }
    }
}

/** Pincel de la zona de un efecto: mismas herramientas + Listo. */
@Composable
private fun BrushToolRow(vm: AppViewModel, modifier: Modifier, onDone: () -> Unit) {
    ToolRowContainer(modifier) {
        ToolChip("Pincel", Icons.Filled.Brush, !vm.eraser) { vm.eraser = false }
        ToolChip("Borrador", ZetaEraserIcon, vm.eraser) { vm.eraser = true }
        ToolChip("Rellenar", Icons.Filled.FormatColorFill, false) { vm.fillLayer(false) }
        ToolChip("Vaciar", Icons.Filled.LayersClear, false) { vm.fillLayer(true) }
        ToolChip("Listo", Icons.Filled.Check, true, onClick = onDone)
    }
}

private val settingsTools = listOf(
    Triple(0, "Duración", Icons.Filled.Timer),
    Triple(1, "Formato", Icons.Filled.Crop),
    Triple(2, "Color", Icons.Filled.Palette),
    Triple(3, "Audio", Icons.Filled.MusicNote),
    Triple(4, "Bucle", Icons.Filled.AllInclusive)
)

@Composable
private fun SettingsToolRow(vm: AppViewModel, modifier: Modifier) {
    ToolRowContainer(modifier) {
        settingsTools.forEach { (i, label, icon) ->
            ToolChip(label, icon, vm.settingsSection == i) {
                if (i != 1) vm.finishCropEdit()
                vm.settingsSection = i
            }
        }
        ToolChip(if (vm.advancedMode) "Avanzado" else "Fácil", if (vm.advancedMode) Icons.Filled.Tune else Icons.Filled.AutoFixHigh,
            vm.advancedMode) { vm.toggleAdvancedMode() }
    }
}

// ------------------------------------------------------------------ Panel

/** Opciones de la herramienta elegida (zona entre el lienzo y la fila de herramientas). */
@Composable
fun EditorPanel(vm: AppViewModel) {
    val editing = vm.editingEffect
    Box(Modifier.fillMaxSize().background(StudioPanel)) {
        when {
            vm.paintingZone && editing != null -> SimpleBrushPanel(vm)
            editing != null -> EffectEditorPanel(vm, editing)
            vm.tab == EditorTab.TOOLS -> AnimatePanel(vm)
            vm.tab == EditorTab.MASKS -> ProtectPanel(vm)
            vm.tab == EditorTab.EFFECTS -> EffectCatalogPanel(vm)
            else -> SettingsPanel(vm)
        }
    }
}

@Composable
private fun PanelScroll(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
}

@Composable
private fun PanelTitle(title: String, hint: String? = null) {
    Text(title, color = StudioText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    if (hint != null) Text(hint, color = StudioMuted, fontSize = 12.sp, lineHeight = 15.sp)
}

@Composable
private fun AnimatePanel(vm: AppViewModel) {
    if (vm.animPanel == "loop") { LoopPanel(vm) { vm.animPanel = "" }; return }
    if (vm.paintingZone) { SimpleBrushPanel(vm); return }
    PanelScroll {
        when (vm.tool) {
            Tool.ARROW -> {
                PanelTitle("Ruta", "Arrastra sobre la imagen en la dirección del movimiento: agua, nubes, cabello o humo. Más larga = más movimiento.")
                if (vm.arrows.isNotEmpty()) {
                    LabeledSlider("Movimiento", vm.settings["flow.amount"] ?: .35f, .05f, 1f, false) { vm.setSetting("flow.amount", it) }
                    LabeledSlider("Velocidad", vm.settings["flow.cycles"] ?: 2f, 1f, 8f, true) { vm.setSetting("flow.cycles", it) }
                    StudioSmallButton("Borrar todas las rutas y anclas", Icons.Filled.LayersClear, Modifier.fillMaxWidth()) { vm.clearGuides() }
                }
            }
            Tool.ANCHOR -> {
                PanelTitle("Ancla", "Toca para fijar un punto que no se mueve. Rodea con anclas lo que animas para que el movimiento no se escape.")
                if (vm.anchors.isNotEmpty()) Text("${vm.anchors.size} anclas", color = StudioMuted, fontSize = 12.sp)
            }
            Tool.ERASE_GUIDE -> PanelTitle("Eliminar", "Toca una ruta o un ancla para quitarla. ↶ la recupera.")
            else -> {
                PanelTitle("Animar la imagen", "Elige una herramienta abajo:")
                HelpLine(Icons.Filled.Timeline, "Ruta", "dibuja hacia dónde se mueve el agua, el humo o el pelo")
                HelpLine(Icons.Filled.PushPin, "Ancla", "fija puntos que no deben moverse")
                HelpLine(Icons.Filled.AcUnit, "Congelar", "pinta lo que debe quedarse quieto")
                HelpLine(Icons.Filled.Air, "Natural", "cabello, ropa, árboles y pasto con viento")
                HelpLine(Icons.Filled.Layers, "2.5D", "profundidad entre fondo y personaje")
                HelpLine(Icons.Filled.Videocam, "Cámara", "zoom, giro y desplazamiento suaves")
            }
        }
    }
}

@Composable
private fun HelpLine(icon: ImageVector, title: String, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = StudioPink, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Text(title, color = StudioText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text(" · $text", color = StudioMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/**
 * Proteger: se pinta directamente (un dedo) lo que NO se mueve. Dos dedos hacen zoom.
 * Se puede elegir la capa: personaje, zona azul (agua/cielo), zona verde (árboles) o propias.
 */
@Composable
private fun ProtectPanel(vm: AppViewModel) {
    val painted = remember(vm.maskRevision) { vm.maskHasPaint(0) }
    PanelScroll {
        if (vm.paintingZone) {
            val layer = vm.selectedMaskLayer
            Text(when (layer) {
                0 -> if (painted) "Zona protegida lista · no se deforma y los efectos pueden pasar por detrás."
                    else "Pinta al personaje (o lo que no debe moverse). Solo se animará el resto."
                1 -> "Zona azul: agua o cielo (ondas, brillos, nubes)."
                2 -> "Zona verde: árboles, pasto o fuego (viento y calor)."
                else -> "Zona «${vm.maskNames.getOrNull(layer) ?: ""}» para los efectos que la usen."
            }, color = StudioText, fontSize = 12.sp, lineHeight = 15.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                vm.maskNames.forEachIndexed { i, name ->
                    val label = when (i) { 0 -> "Proteger"; 1 -> "Zona azul"; 2 -> "Zona verde"; else -> name }
                    SmallChoice(label, layer == i, dot = when (i) { 0 -> StudioPink; 1 -> Sky; 2 -> Color(0xFF6BD68A); else -> StudioPurple }) {
                        vm.selectMask(i)
                    }
                }
                SmallChoice("+ Nueva", false) { vm.addMask() }
            }
            LabeledSlider("Tamaño", vm.brushDp, 6f, 140f, true) { vm.brushDp = it }
            LabeledSlider("Borde suave", vm.feather, 0f, 1f, false) { vm.feather = it }
            Text("1 dedo pinta · 2 dedos acercan y mueven · ↶ deshace", color = StudioMuted, fontSize = 11.sp)
        } else {
            when (vm.tool) {
                Tool.ANCHOR -> PanelTitle("Punto fijo", "Toca la imagen para fijar un punto que no se mueve.")
                Tool.ERASE_GUIDE -> PanelTitle("Quitar punto fijo", "Toca un punto para quitarlo.")
                else -> PanelTitle("Proteger", "Pinta lo que NO debe moverse: personajes, casas, rocas…")
            }
            StudioSmallButton("Pintar con el pincel", Icons.Filled.Brush, Modifier.fillMaxWidth()) { vm.protect() }
        }
    }
}

@Composable
fun SmallChoice(label: String, selected: Boolean, dot: Color? = null, onClick: () -> Unit) {
    Row(Modifier.height(34.dp).clip(RoundedCornerShape(10.dp))
        .background(if (selected) StudioPink.copy(alpha = .9f) else StudioTile)
        .clickable(onClick = onClick).padding(horizontal = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        if (dot != null) {
            Box(Modifier.size(8.dp).clip(RoundedCornerShape(4.dp)).background(dot))
            Spacer(Modifier.width(6.dp))
        }
        Text(label, color = StudioText, fontSize = 12.sp, maxLines = 1,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
    }
}

@Composable
private fun SettingsPanel(vm: AppViewModel) {
    when (vm.settingsSection) {
        0 -> DurationPanel(vm)
        1 -> CanvasPanel(vm)
        2 -> ColorPanel(vm)
        3 -> AudioPanel(vm)
        else -> LoopPanel(vm) { vm.settingsSection = 0 }
    }
}

@Composable
private fun DurationPanel(vm: AppViewModel) {
    val e = vm.exportSettings
    PanelScroll {
        PanelTitle("Duración del vídeo", "Los efectos que cubren todo el vídeo se estiran solos.")
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(4, 6, 8, 10, 15, 30).forEach { sec ->
                SmallChoice("${sec}s", e.loopSec == sec) { vm.updateExport(e.copy(loopSec = sec)); vm.saveProject() }
            }
        }
        LabeledSlider("Segundos", e.loopSec.toFloat(), 2f, 60f, true, suffix = " s") {
            vm.updateExport(vm.exportSettings.copy(loopSec = it.toInt()))
        }
        Text("Fotogramas por segundo", color = StudioMuted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(24, 30, 60).forEach { fps ->
                SmallChoice("$fps fps", e.fps == fps) { vm.updateExport(vm.exportSettings.copy(fps = fps)) }
            }
        }
    }
}
