package com.zeta.fondo.model

/**
 * v38 · Medidas del editor (en dp), sin dependencias de Android para poder probarlas.
 *
 * Regla principal: el tamaño del lienzo depende SOLO de la pantalla y de la división que
 * el usuario elige arrastrando el asa. Abrir/cerrar paneles, cambiar de categoría o de
 * herramienta nunca lo agranda ni lo achica. Pantalla completa solo con su botón.
 */
data class EditorLayout(
    val landscape: Boolean,
    val topBar: Float,
    val canvasH: Float,
    val handle: Float,
    val toolRow: Float,
    val panelH: Float,
    val tabBar: Float,
    val sideW: Float
) {
    companion object {
        const val TOP = 48f
        const val HANDLE = 14f
        const val TOOLS = 66f
        const val TABS = 56f
        const val MIN_PANEL = 112f
        const val MIN_CANVAS = 180f
        const val DEFAULT_FRACTION = 0.66f
        const val MIN_FRACTION = 0.40f
        const val MAX_FRACTION = 0.86f

        fun compute(widthDp: Float, heightDp: Float, fraction: Float, fullscreen: Boolean): EditorLayout {
            val w = widthDp.coerceAtLeast(1f)
            val h = heightDp.coerceAtLeast(1f)
            if (fullscreen) return EditorLayout(false, 0f, h, 0f, 0f, 0f, 0f, 0f)
            if (w > h * 1.15f) {
                // Horizontal / tableta: lienzo a la izquierda, herramientas en una columna.
                val side = (w * 0.38f).coerceIn(280f, 400f).coerceAtMost(w * 0.5f)
                val panel = (h - TOOLS - TABS).coerceAtLeast(0f)
                return EditorLayout(true, TOP, (h - TOP).coerceAtLeast(0f), 0f, TOOLS, panel, TABS, side)
            }
            val avail = (h - TOP - HANDLE - TOOLS - TABS).coerceAtLeast(0f)
            val f = fraction.coerceIn(MIN_FRACTION, MAX_FRACTION)
            val maxCanvas = (avail - MIN_PANEL).coerceAtLeast(avail * 0.5f)
            val minCanvas = MIN_CANVAS.coerceAtMost(maxCanvas)
            val canvas = (avail * f).coerceIn(minCanvas, maxCanvas)
            return EditorLayout(false, TOP, canvas, HANDLE, TOOLS, (avail - canvas).coerceAtLeast(0f), TABS, 0f)
        }

        /** Nueva fracción al arrastrar el asa [dragDp] (positivo = hacia abajo = lienzo más alto). */
        fun dragFraction(current: Float, dragDp: Float, heightDp: Float): Float {
            val avail = (heightDp - TOP - HANDLE - TOOLS - TABS).coerceAtLeast(1f)
            return (current + dragDp / avail).coerceIn(MIN_FRACTION, MAX_FRACTION)
        }
    }
}

/** Rectángulo (en píxeles) donde se ve la imagen dentro del lienzo, igual que en OpenGL. */
data class ImageRect(val left: Float, val top: Float, val width: Float, val height: Float) {
    fun normX(x: Float): Float = (x - left) / width.coerceAtLeast(1f)
    fun normY(y: Float): Float = (y - top) / height.coerceAtLeast(1f)
    fun contains(x: Float, y: Float): Boolean = x >= left && y >= top && x <= left + width && y <= top + height

    companion object {
        /** Encaja [aspect] (ancho/alto) centrado en un lienzo de [boxW]×[boxH]. */
        fun fit(boxW: Float, boxH: Float, aspect: Float): ImageRect {
            val bw = boxW.coerceAtLeast(1f)
            val bh = boxH.coerceAtLeast(1f)
            val a = if (aspect > 0.01f) aspect else bw / bh
            return if (bw / bh > a) {
                val w = bh * a
                ImageRect((bw - w) / 2f, 0f, w, bh)
            } else {
                val hh = bw / a
                ImageRect(0f, (bh - hh) / 2f, bw, hh)
            }
        }
    }
}

/**
 * Decide qué hace un toque sobre el lienzo. Dos dedos SIEMPRE son zoom/desplazamiento,
 * aunque esté activo el pincel o cualquier herramienta; un dedo solo pinta o dibuja
 * después de moverse más que [slop] (un toque sin mover = punto).
 */
object GestureRules {
    enum class Mode { WAITING, DRAW, TRANSFORM }

    fun next(mode: Mode, pointers: Int, movedPx: Float, slop: Float, toolDraws: Boolean): Mode = when {
        pointers >= 2 -> Mode.TRANSFORM
        mode == Mode.TRANSFORM -> Mode.TRANSFORM          // al soltar un dedo no empieza a pintar
        !toolDraws -> Mode.TRANSFORM                      // herramienta Mover: un dedo desplaza
        // toolDraws = la herramienta usa un dedo (pincel, flecha, ancla, origen…)
        mode == Mode.WAITING && movedPx > slop -> Mode.DRAW
        else -> mode
    }
}
