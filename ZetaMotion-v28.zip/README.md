# Zeta Motion v28

Editor Android para animar fondos e ilustraciones de anime, manga y manhwa.

Esta versión añade duplicado real de bloques, simplifica la resolución de exportación y elimina el tirón del primer zoom.

Ver `README_V28.md`.
