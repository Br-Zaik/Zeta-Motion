# Zeta Motion v7 — controles compactos y fluidos

- Se eliminó **Presets** de la barra porque repetía la función de **Efectos**.
- La barra queda en cuatro secciones: Animar, Máscaras, Efectos y Exportar.
- Tocar la sección activa abre o cierra su panel; ya no existen flechas adicionales.
- El panel inicia cerrado para mostrar el lienzo completo.
- Los efectos usan una cuadrícula perezosa de cuatro columnas: solo compone los elementos visibles.
- Cada efecto tiene un icono propio y reconocible.
- Tocar un efecto abre sus ajustes, pero no lo activa automáticamente.
- Se agregó un botón de limpieza para apagar todos los efectos acumulados.
- El panel tiene más espacio útil y desplazamiento vertical fluido.
- Se mantienen los 36 efectos procedurales, máscaras, animación y exportación.
- Versión Android: `7.0.0` (`versionCode 7`).
