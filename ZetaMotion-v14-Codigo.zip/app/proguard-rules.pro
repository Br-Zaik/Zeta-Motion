# Sin reglas especiales (minify desactivado).
