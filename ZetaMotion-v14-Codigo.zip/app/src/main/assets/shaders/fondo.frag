#version 300 es
// Fondo Zeta - shader principal.
// Todo el movimiento depende de uT (0..1 = un loop). Cada efecto usa un número
// ENTERO de ciclos por loop, así el último cuadro empalma con el primero.
precision highp float;
precision highp int;

in vec2 vScreen;
out vec4 fragColor;

uniform sampler2D uImage;
uniform sampler2D uFlow;     // RG: vector de flujo (unidades de imagen por ciclo)
uniform sampler2D uFreeze;   // R: congelar
uniform sampler2D uZone1;    // R: zona 1 (agua / cielo)
uniform sampler2D uZone2;    // R: zona 2 (árboles / fuego)
uniform highp sampler2DArray uMasks;
uniform int uActiveMask;


uniform vec2 uViewOffset;
uniform vec2 uViewScale;
uniform float uFlipY;
uniform float uRotate;
uniform float uT;
uniform float uAspect;       // ancho / alto de la imagen
uniform vec2 uTexSize;
uniform float uShowMask;
uniform float uOverlayOnly;
uniform float uMono;
uniform float uPixelSnap;

uniform vec3 uFlow3;   // encendido, distancia, ciclos
uniform vec2 uDrift;   // deriva en zona 1 (uv por ciclo)
uniform vec3 uRipple;  // fuerza, frecuencia, ciclos
uniform vec3 uGlint;   // intensidad, densidad, ciclos
uniform vec3 uSway;    // fuerza, frecuencia, ciclos
uniform vec3 uHeat;    // fuerza, frecuencia, ciclos
uniform vec4 uRain;    // intensidad, ángulo (rad), ciclos, solo zona 1
uniform vec4 uSnow;    // intensidad, tamaño, ciclos, solo zona 1
uniform vec4 uSakura;  // intensidad, tamaño, ciclos, solo zona 1
uniform vec4 uStars;   // intensidad, densidad, ciclos, solo zona 1
uniform vec4 uFlies;   // intensidad, densidad, ciclos, solo zona 1
uniform vec4 uFog;     // intensidad, escala, ciclos, solo zona 1
uniform vec4 uRays;    // intensidad, origen x, ciclos, solo zona 1
uniform vec4 uEnergy;  // intensidad, rayos, ciclos, solo zona 1
uniform vec4 uSpeed;   // intensidad, ángulo, ciclos, solo zona 1
uniform vec4 uStudioSky;
uniform vec4 uStudioWater;
uniform vec4 uStudioDispersion;
uniform vec4 uDispersionMore;
uniform vec4 uCameraMode;
uniform vec4 uLoopControl;
uniform vec4 uZoneMotion;
uniform int uMaskZonemotion;
uniform vec4 uColorA, uColorB, uColorC, uColorD;
uniform vec4 uElementPose[4];
uniform vec4 uElementStyle[4];
uniform int uMaskSky;
uniform int uMaskWater;
uniform int uMaskDispersion;
uniform int uMaskCam;
uniform vec3 uCam;     // zoom, paneo, ciclos

// Dirección (x,y) y origen normalizado (z,w), compartidos por UI/vista previa/export.
uniform vec4 uMotionRain;
uniform vec4 uMotionSnow;
uniform vec4 uMotionSakura;
uniform vec4 uMotionFog;
uniform vec4 uMotionRays;
uniform vec4 uMotionEnergy;
uniform vec4 uMotionSpeed;
uniform vec4 uMotionAsh;
uniform vec4 uMotionLeaves;
uniform vec4 uMotionEmbers;
uniform vec4 uMotionDust;
uniform vec4 uMotionBubbles;
uniform vec4 uMotionElectric;
uniform vec4 uMotionFocus;
uniform vec4 uMotionShock;
uniform vec4 uFxAsh;
uniform vec4 uFxLeaves;
uniform vec4 uFxEmbers;
uniform vec4 uFxDust;
uniform vec4 uFxBubbles;
uniform vec4 uFxElectric;
uniform vec4 uFxFocus;
uniform vec4 uFxShock;
uniform vec4 uFxFlash;
uniform vec4 uFxTone;
uniform vec4 uFxGrain;
uniform vec4 uFxInk;


// Segunda instancia independiente de cada efecto anime/manga.
uniform vec4 uFxAshCopy;
uniform int uMaskAshCopy;
uniform vec4 uFxLeavesCopy;
uniform int uMaskLeavesCopy;
uniform vec4 uFxEmbersCopy;
uniform int uMaskEmbersCopy;
uniform vec4 uFxDustCopy;
uniform int uMaskDustCopy;
uniform vec4 uFxBubblesCopy;
uniform int uMaskBubblesCopy;
uniform vec4 uFxElectricCopy;
uniform int uMaskElectricCopy;
uniform vec4 uFxFocusCopy;
uniform int uMaskFocusCopy;
uniform vec4 uFxShockCopy;
uniform int uMaskShockCopy;
uniform vec4 uFxFlashCopy;
uniform int uMaskFlashCopy;
uniform vec4 uFxToneCopy;
uniform int uMaskToneCopy;
uniform vec4 uFxGrainCopy;
uniform int uMaskGrainCopy;
uniform vec4 uFxInkCopy;
uniform int uMaskInkCopy;
uniform vec4 uMotionAshCopy;
uniform vec4 uMotionLeavesCopy;
uniform vec4 uMotionEmbersCopy;
uniform vec4 uMotionDustCopy;
uniform vec4 uMotionBubblesCopy;
uniform vec4 uMotionElectricCopy;
uniform vec4 uMotionFocusCopy;
uniform vec4 uMotionShockCopy;


// Nuevos efectos procedurales, independientes de servicios externos.
uniform vec4 uFxComet;
uniform int uMaskComet;
uniform vec4 uFxRunes;
uniform int uMaskRunes;
uniform vec4 uFxHatch;
uniform int uMaskHatch;
uniform vec4 uFxPulse;
uniform int uMaskPulse;
uniform vec4 uFxSmoke;
uniform int uMaskSmoke;
uniform vec4 uFxShards;
uniform int uMaskShards;
uniform vec4 uFxFlame;
uniform vec4 uFxEyes;
uniform vec4 uFxBlink;
uniform vec4 uFxCloth;
uniform int uMaskFlame;
uniform int uMaskEyes;
uniform int uMaskBlink;
uniform int uMaskCloth;
uniform vec4 uMotionComet;
uniform vec4 uMotionRunes;
uniform vec4 uMotionPulse;
uniform vec4 uMotionSmoke;
uniform vec4 uMotionShards;

const float TAU = 6.28318530718;
uniform int uMaskFlow;
uniform int uMaskDrift;
uniform int uMaskRipple;
uniform int uMaskGlint;
uniform int uMaskSway;
uniform int uMaskHeat;
uniform int uMaskRain;
uniform int uMaskSnow;
uniform int uMaskSakura;
uniform int uMaskStars;
uniform int uMaskFlies;
uniform int uMaskFog;
uniform int uMaskRays;
uniform int uMaskEnergy;
uniform int uMaskSpeed;
uniform int uMaskAsh;
uniform int uMaskLeaves;
uniform int uMaskEmbers;
uniform int uMaskDust;
uniform int uMaskBubbles;
uniform int uMaskElectric;
uniform int uMaskFocus;
uniform int uMaskShock;
uniform int uMaskFlash;
uniform int uMaskTone;
uniform int uMaskGrain;
uniform int uMaskInk;


float maskValue(vec2 uv, int slot, float fallback, float enabled) {
    if (slot == -2) return 1.0;
    return slot >= 0 ? texture(uMasks, vec3(uv, float(slot))).r : mix(1.0, fallback, enabled);
}

// Hash sin seno (Dave Hoskins, licencia MIT)
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

vec2 hash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy);
}

float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int k = 0; k < 4; k++) {
        v += a * vnoise(p);
        p = p * 2.03 + vec2(17.1, 9.2);
        a *= 0.5;
    }
    return v;
}

float luma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

// 1 cerca de 0, 0 desde e en adelante (suave)
float falloff(float d, float e) {
    return 1.0 - smoothstep(0.0, e, d);
}

vec3 sourcePixel(vec2 q) { return texture(uImage,clamp(q,vec2(0.0),vec2(1.0))).rgb; }
vec3 sampleImg(vec2 q) {
    q=clamp(q,vec2(0.0),vec2(1.0));
    if(uPixelSnap>0.5)q=(floor(q*uTexSize)+0.5)/uTexSize;
    vec3 c=sourcePixel(q);
    if(uColorD.y>0.0){
        vec2 shift=vec2(uColorD.y*0.009,0.0);
        c.r=sourcePixel(q+shift).r;c.b=sourcePixel(q-shift).b;
    }
    if(uColorC.x>0.0){
        vec2 stepUV=1.0/max(uTexSize,vec2(1.0));
        vec3 neighbors=(sourcePixel(q+vec2(stepUV.x,0.0))+sourcePixel(q-vec2(stepUV.x,0.0))+
            sourcePixel(q+vec2(0.0,stepUV.y))+sourcePixel(q-vec2(0.0,stepUV.y)))*0.25;
        c+=uColorC.x*1.6*(c-neighbors);
    }
    if(uColorC.y>0.0){
        vec2 r=vec2(0.0045);
        vec3 glow=(sourcePixel(q+r)+sourcePixel(q-r)+sourcePixel(q+vec2(r.x,-r.y))+sourcePixel(q+vec2(-r.x,r.y)))*0.25;
        c+=glow*smoothstep(0.45,0.9,dot(glow,vec3(0.2126,0.7152,0.0722)))*uColorC.y*0.45;
    }
    return c;
}
// Keep the sampling footprint inside the source. Pin the outermost pixel centers,
// taper the displacement near edges and saturate it smoothly before the limit.
vec2 safeWarp(vec2 uv, vec2 displacement) {
    vec2 halfPixel=0.5/max(uTexSize,vec2(1.0));
    vec2 center=clamp(uv,halfPixel,1.0-halfPixel);
    vec2 room=max(vec2(0.0),min(center-halfPixel,1.0-halfPixel-center));
    vec2 envelope=smoothstep(vec2(0.0),vec2(0.055),room);
    vec2 delta=displacement*envelope;
    delta=delta/(vec2(1.0)+abs(delta)/max(room*0.25,vec2(0.000001)));
    return center+delta;
}
vec3 warpSample(vec2 uv,vec2 displacement){return sampleImg(safeWarp(uv,displacement));}

vec3 gradeColor(vec3 c,vec2 uv){
    c=c*exp2(uColorA.w)+uColorA.x;
    float lum=dot(c,vec3(0.2126,0.7152,0.0722));
    c+=uColorB.z*0.3*(1.0-smoothstep(0.0,0.6,lum));
    c+=uColorB.w*0.3*smoothstep(0.35,1.0,lum);
    c=(c-0.5)*(1.0+uColorA.y)+0.5;
    c+=uColorB.x*vec3(0.12,0.01,-0.12);
    if(abs(uColorB.y)>0.00001){
        vec3 axis=vec3(0.577350269);
        c=c*cos(uColorB.y)+cross(axis,c)*sin(uColorB.y)+axis*dot(axis,c)*(1.0-cos(uColorB.y));
    }
    lum=dot(c,vec3(0.2126,0.7152,0.0722));
    c=mix(vec3(lum),c,1.0+uColorA.z);
    c=mix(c,c*0.75+0.15,uColorD.x);
    c*=1.0-uColorC.z*smoothstep(0.2,0.7,length(uv-0.5))*0.85;
    if(uColorC.w>0.0)c+=(hash12(floor(uv*uTexSize))-0.5)*uColorC.w*0.16;
    return c;
}

// Rota un campo de caída vertical a la dirección elegida en la UI.
// (0,1) conserva el movimiento hacia abajo del shader original.
vec2 oriented(vec2 p, vec4 m) {
    vec2 d = normalize(m.xy + vec2(0.000001));
    vec2 base = p - m.zw * vec2(uAspect, 1.0);
    return vec2(d.y * base.x - d.x * base.y,
                d.x * base.x + d.y * base.y);
}
float emitArea(vec2 p, vec4 m) {
    vec2 d = normalize(m.xy + vec2(0.000001));
    vec2 from = m.zw * vec2(uAspect, 1.0);
    // El punto central conserva cobertura total; un emisor en un borde entra desde ese lado.
    if (distance(m.zw, vec2(0.5)) < 0.001) return 1.0;
    float edge = dot(p - from, d);
    return smoothstep(-0.04, 0.18, edge);
}

// ---------- Lluvia ----------
float rainLayer(vec2 P, float scale, float cyc, float ang, float seed) {
    float ca = cos(ang);
    float sa = sin(ang);
    vec2 R = vec2(ca * P.x + sa * P.y, -sa * P.x + ca * P.y);
    const float N = 6.0;
    vec2 g = vec2(R.x * scale, R.y * scale * 0.25);
    g.y -= uT * cyc * N;
    vec2 id = floor(g);
    vec2 f = fract(g);
    vec2 idp = vec2(id.x, mod(id.y, N)) + seed;
    vec2 h = hash22(idp);
    float on = step(0.45, hash12(idp + 7.13));
    float x = 0.2 + 0.6 * h.x;
    float len = 0.35 + 0.4 * h.y;
    float y0 = (1.0 - len) * hash12(idp + 3.7);
    float w = falloff(abs(f.x - x), 0.08);
    float v = smoothstep(y0, y0 + 0.08, f.y) * (1.0 - smoothstep(y0 + len - 0.12, y0 + len, f.y));
    return w * v * on;
}

// ---------- Nieve ----------
float snowLayer(vec2 P, float scale, float cyc, float size, float seed) {
    const float N = 5.0;
    vec2 g = P * scale;
    g.y -= uT * cyc * N;
    vec2 id = floor(g);
    vec2 f = fract(g);
    vec2 idp = vec2(id.x, mod(id.y, N)) + seed;
    vec2 h = hash22(idp);
    float on = step(0.5, hash12(idp + 1.7));
    float k = 1.0 + floor(h.y * 2.0);
    vec2 c = vec2(0.5 + 0.28 * sin(TAU * (uT * k + h.x)), 0.25 + 0.5 * h.y);
    float r = clamp(size * (0.06 + 0.08 * h.x), 0.02, 0.2);
    float d = length(f - c);
    return (1.0 - smoothstep(r * 0.35, r, d)) * on;
}

// ---------- Pétalos de sakura ----------
vec4 sakuraLayer(vec2 P, float scale, float cyc, float size, float seed) {
    const float N = 6.0;
    vec2 g = P * scale;
    g.y -= uT * cyc * N;
    g.x += uT * cyc * N;
    vec2 id = floor(g);
    vec2 f = fract(g);
    vec2 idp = mod(id, N) + seed;
    vec2 h = hash22(idp);
    float on = step(0.55, hash12(idp + 4.1));
    vec2 c = vec2(0.5 + 0.2 * sin(TAU * (uT + h.x)), 0.5 + 0.15 * cos(TAU * (uT + h.y)));
    float a = TAU * (uT * (1.0 + floor(h.x * 2.0)) + h.y);
    vec2 d = f - c;
    float ca = cos(a);
    float sa = sin(a);
    d = vec2(ca * d.x - sa * d.y, sa * d.x + ca * d.y);
    float r = clamp(size * (0.08 + 0.06 * h.y), 0.03, 0.25);
    d.x /= r;
    d.y /= r * 0.55;
    float e = length(d);
    float petal = (1.0 - smoothstep(0.7, 1.0, e)) * on;
    vec3 col = mix(vec3(1.0, 0.72, 0.82), vec3(1.0, 0.93, 0.96), clamp(0.5 - d.x * 0.5, 0.0, 1.0));
    return vec4(col, petal);
}

// ---------- Estrellas ----------
vec3 starsLayer(vec2 P, float dens, float cyc) {
    vec2 g = P * dens;
    vec2 id = floor(g);
    vec2 f = fract(g);
    vec2 h = hash22(id + 11.3);
    float present = step(0.62, hash12(id + 5.9));
    vec2 c = 0.2 + 0.6 * h;
    float d = length(f - c);
    float big = step(0.93, hash12(id + 2.2));
    float k = cyc * (1.0 + floor(h.x * 3.0));
    float tw = 0.45 + 0.55 * (0.5 + 0.5 * sin(TAU * (uT * k + h.y)));
    float core = falloff(d, 0.06 + 0.05 * big);
    float glow = falloff(d, 0.3) * 0.25;
    vec2 a = abs(f - c);
    float spikes = big * (falloff(a.x, 0.015) * falloff(a.y, 0.35) + falloff(a.y, 0.015) * falloff(a.x, 0.35));
    float s = (core + glow + spikes * 0.7) * tw * present;
    vec3 col = mix(vec3(0.8, 0.88, 1.0), vec3(1.0, 0.95, 0.8), h.x);
    return col * s;
}

// ---------- Luciérnagas ----------
vec3 fliesLayer(vec2 P, float dens, float cyc) {
    vec2 g = P * dens;
    vec2 id = floor(g);
    vec2 f = fract(g);
    vec2 h = hash22(id + 21.7);
    float present = step(0.55, hash12(id + 8.8));
    float kx = cyc * (1.0 + floor(h.x * 2.0));
    float ky = cyc * (1.0 + floor(h.y * 2.0));
    vec2 c = vec2(0.5 + 0.3 * sin(TAU * (uT * kx + h.y)), 0.5 + 0.3 * sin(TAU * (uT * ky + h.x) + 1.3));
    float d = length(f - c);
    float blink = smoothstep(-0.2, 1.0, sin(TAU * (uT * cyc * 2.0 + h.x)));
    float core = falloff(d, 0.035);
    float glow = falloff(d, 0.18);
    return vec3(0.85, 1.0, 0.45) * (core + glow * glow * 0.6) * blink * present;
}

// ---------- Niebla (fundido de dos fases = loop perfecto) ----------
float fogField(vec2 P, float scale, float cyc) {
    float p1 = fract(uT * cyc);
    float p2 = fract(p1 + 0.5);
    float w1 = 1.0 - abs(2.0 * p1 - 1.0);
    vec2 dir = vec2(0.9, 0.12);
    float a = fbm(P * scale + dir * (p1 - 0.5));
    float b = fbm(P * scale + dir * (p2 - 0.5));
    return mix(b, a, w1);
}

// ---------- Rayos de luz ----------
float raysField(vec2 P, float ox, float cyc) {
    vec2 o = uMotionRays.zw * vec2(uAspect, 1.0);
    vec2 v = P - o;
    float ang = atan(v.x, v.y) - atan(uMotionRays.y, uMotionRays.x);
    float ph = TAU * uT * cyc;
    float r = sin(ang * 17.0 + ph) + sin(ang * 29.0 - ph * 2.0 + 1.3) + sin(ang * 9.0 + ph + 2.1);
    r = clamp(r / 3.0 * 0.5 + 0.5, 0.0, 1.0);
    r = r * r * r;
    float fall = exp(-length(v) * 1.3);
    return r * fall;
}

float energyField(vec2 P, float rays, float cyc) {
    vec2 q = P - uMotionEnergy.zw * vec2(uAspect, 1.0);
    float r = length(q);
    float a = atan(q.y, q.x);
    float pulse = 0.55 + 0.45 * sin(TAU * uT * cyc);
    float spokes = pow(0.5 + 0.5 * sin(a * rays + sin(uT * TAU * cyc) * 2.0), 10.0);
    return spokes * (1.0 - smoothstep(0.08, 0.58, r)) * pulse;
}

float speedField(vec2 P, float angle, float cyc) {
    float a = radians(angle);
    float ca = cos(a);
    float sa = sin(a);
    vec2 q = vec2(ca * P.x + sa * P.y, -sa * P.x + ca * P.y);
    vec2 g = q * vec2(9.0, 34.0);
    g.y -= uT * cyc * 8.0;
    float line = smoothstep(0.47, 0.49, fract(g.y));
    float fade = smoothstep(0.0, 0.18, q.y) * (1.0 - smoothstep(0.55, 1.0, q.y));
    return line * fade * (0.35 + 0.65 * hash12(floor(g)));
}

// Procedurales anime/manga: todos usan tiempo periódico para bucles limpios.
float particleDot(vec2 p, float density, float cycles, float size, float seed) {
    const float REP = 6.0;
    vec2 g = p * density;
    g.y -= uT * cycles * REP;
    vec2 id = floor(g);
    vec2 f = fract(g);
    vec2 h = hash22(vec2(id.x, mod(id.y, REP)) + seed);
    vec2 c = vec2(0.2 + 0.6 * h.x, 0.2 + 0.6 * h.y);
    float r = clamp(size * 0.09, 0.018, 0.28);
    return (1.0 - smoothstep(r * 0.4, r, length(f - c))) * step(0.42, hash12(vec2(id.x, mod(id.y, REP)) + seed));
}
float electricArc(vec2 p, vec4 motion, float branches, float cycles) {
    vec2 q = p - motion.zw * vec2(uAspect, 1.0);
    float a = atan(q.y, q.x);
    float r = length(q);
    float segments = floor(a * branches / TAU);
    float wobble = 0.07 * sin(a * 23.0 + segments + TAU * uT * cycles);
    float target = 0.27 + 0.12 * sin(segments * 7.4 + TAU * uT * cycles) + wobble;
    float bolt = 1.0 - smoothstep(0.005, 0.024, abs(r - target));
    return bolt * (1.0 - smoothstep(0.2, 0.8, r));
}
float focusLines(vec2 p, vec4 motion, float density, float cycles) {
    vec2 q = p - motion.zw * vec2(uAspect, 1.0);
    float a = atan(q.y, q.x);
    float r = length(q);
    float index = floor(a / TAU * density);
    float phase = fract(a / TAU * density);
    float spike = (1.0 - smoothstep(0.03, 0.14, min(phase, 1.0-phase)));
    float endR = 0.16 + 0.25 * hash12(vec2(index, 27.1));
    return spike * smoothstep(endR, endR + 0.12, r) *
        (0.7 + 0.3 * sin(TAU * uT * cycles));
}


vec3 studioSky(vec2 uv) {
    float ph=TAU*uT*uStudioSky.y;
    vec2 drift=vec2(cos(ph),sin(ph))*0.28;
    float clouds=smoothstep(0.45,0.78,fbm(uv*vec2(4.0*uAspect,6.0)+drift));
    vec3 top=vec3(0.13,0.44,0.83), bottom=vec3(0.79,0.9,1.0);
    if(uStudioSky.z>0.5){top=vec3(0.32,0.22,0.61);bottom=vec3(1.0,0.59,0.38);}
    if(uStudioSky.z>1.5){top=vec3(0.025,0.035,0.13);bottom=vec3(0.16,0.19,0.37);}
    if(uStudioSky.z>2.5){top=vec3(0.1,0.12,0.2);bottom=vec3(0.4,0.44,0.52);}
    vec3 c=mix(top,bottom,smoothstep(0.0,1.0,uv.y));
    c=mix(c,uStudioSky.z>1.5?bottom:vec3(1.0,0.93,0.92),clouds*0.8);
    if(uStudioSky.z>1.5 && uStudioSky.z<2.5){
        vec2 grid=uv*vec2(uAspect,1.0)*90.0;
        vec2 h=hash22(floor(grid));
        float star=(1.0-smoothstep(0.01,0.09,length(fract(grid)-h)))*step(0.96,h.x);
        c+=star*(0.6+0.4*sin(ph+h.y*TAU));
    }
    if(uStudioSky.z>2.5)c+=pow(max(0.0,sin(ph)),40.0)*0.25;
    return c;
}
vec3 studioDisperse(vec3 base, vec2 uv) {
    float strength=uStudioDispersion.x;
    float phase=0.5-0.5*cos(TAU*uT*uStudioDispersion.y);
    if(strength<0.001 || phase<0.0001) return base;
    float count=max(12.0,uDispersionMore.x);
    vec2 scale=vec2(uAspect,1.0)*count;
    vec2 g=uv*scale;
    vec2 cell=floor(g);
    vec2 direction=vec2(cos(uStudioDispersion.w),sin(uStudioDispersion.w));
    float distance=phase*uDispersionMore.y*1.6;
    float zone=maskValue(uv,uMaskDispersion,0.0,1.0);
    // Local color extrapolation, deliberately no claim of semantic/AI reconstruction.
    vec3 fill=vec3(0.0);float weight=0.0;
    for(int k=0;k<8;k++){
        float a=float(k)*TAU/8.0;
        vec2 q=uv+vec2(cos(a),sin(a))/scale*3.0;
        float w=1.0-maskValue(clamp(q,0.0,1.0),uMaskDispersion,0.0,1.0);
        fill+=sampleImg(q)*w;weight+=w;
    }
    fill=weight>0.01?fill/weight:sampleImg(uv+direction/scale*3.0);
    vec3 c=mix(base,fill,zone*phase*strength);
    // Search around the reverse displacement: only nine candidates per pixel.
    vec2 sourceCell=floor(g-direction*distance);
    for(int y=-1;y<=1;y++) for(int x=-1;x<=1;x++) {
        vec2 id=sourceCell+vec2(float(x),float(y));
        vec2 h=hash22(id+31.2);
        vec2 center=id+0.5+direction*distance+(h-0.5)*phase*0.5;
        vec2 local=g-center;
        float radius=mix(0.49,0.19,phase*strength);
        float shape=1.0-smoothstep(radius-0.04,radius,max(abs(local.x),abs(local.y)));
        if(uStudioDispersion.z>0.5)shape=1.0-smoothstep(radius-0.05,radius,length(local*vec2(1.0,1.5)));
        if(uStudioDispersion.z>1.5)shape=1.0-smoothstep(0.03,0.11,length(local));
        vec2 origin=(id+0.5)/scale;
        float valid=step(0.0,origin.x)*step(origin.x,1.0)*step(0.0,origin.y)*step(origin.y,1.0);
        float area=maskValue(clamp(origin,0.0,1.0),uMaskDispersion,0.0,1.0);
        c=mix(c,sampleImg(origin+local/scale),shape*area*valid*phase*strength);
    }
    return c;
}
vec3 studioElements(vec3 col,vec2 uv) {
    for(int i=0;i<4;i++) {
        vec4 style=uElementStyle[i]; if(style.x<0.001)continue;
        vec4 pose=uElementPose[i];
        vec2 q=(uv-pose.xy)*vec2(uAspect,1.0)/pose.z;
        q=mat2(cos(pose.w),-sin(pose.w),sin(pose.w),cos(pose.w))*q;
        if(max(abs(q.x),abs(q.y))>0.8)continue;
        float phase=TAU*uT*style.z;
        float opacity=0.0;vec3 tint=vec3(0.92,0.95,1.0);
        if(style.y<1.5 || style.y>4.5){
            float n=fbm(q*5.0+vec2(sin(phase),cos(phase))*0.35);
            float edge=1.0-smoothstep(0.15,0.58,length(q*vec2(0.8,1.3)));
            opacity=smoothstep(0.3,0.7,n)*edge;
            if(style.y>0.5 && style.y<1.5)tint=vec3(0.42,0.45,0.52);
            if(style.y>4.5)opacity*=0.55;
        } else if(style.y<3.5) {
            for(int j=0;j<8;j++){
                vec2 h=hash22(vec2(float(j),float(i)+41.0));
                vec2 center=(h-0.5)*0.8+vec2(sin(phase+h.x*TAU),cos(phase+h.y*TAU))*0.1;
                vec2 p=q-center;
                if(style.y<2.5){ opacity+=1.0-smoothstep(0.02,0.065,length(p*vec2(0.7,1.4)));tint=vec3(1.0,0.66,0.81); }
                else {opacity+=(1.0-smoothstep(0.0,0.08,abs(p.x)+abs(p.y)))*(0.6+0.4*sin(phase+h.x*TAU));tint=vec3(1.0,0.94,0.65);}
            }
        } else {
            float r=length(q);float ring=0.29+0.05*sin(phase);
            opacity=exp(-abs(r-ring)*65.0)*(0.8+0.2*sin(atan(q.y,q.x)*3.0+phase));
            tint=vec3(0.48,0.74,1.0);
        }
        col=mix(col,tint,clamp(opacity*style.x,0.0,1.0));
    }
    return col;
}

void main() {
    // Coordenadas de pantalla con origen arriba-izquierda
    vec2 s = vec2(vScreen.x, mix(1.0 - vScreen.y, vScreen.y, uFlipY));
    if (uRotate > 0.5) {
        s = vec2(1.0 - s.y, s.x);
    }

    vec2 uvFrame = uViewOffset + s * uViewScale;
    // Painting uses the original frame: stable coordinates and no expensive effect work.
    if (uShowMask > 0.5 && uActiveMask >= 0) {
        vec3 original=sourcePixel(uvFrame);
        float selected=texture(uMasks,vec3(uvFrame,float(uActiveMask))).r;
        original=mix(original,vec3(0.72,0.39,1.0),selected*0.48);
        original+=(hash12(gl_FragCoord.xy)-0.5)/255.0;
        fragColor=vec4(clamp(original,0.0,1.0),1.0);
        return;
    }


    // Smooth periodic camera; overscan prevents exposed corners during rotation/pan.
    vec2 sc = s;
    if (uCam.x > 0.0 || uCam.y > 0.0) {
        float phase = TAU * uT * uCam.z;
        float wave = 0.5 - 0.5 * cos(phase);
        float mode = uCameraMode.x;
        float zoom = 1.0 + uCam.x * (mode < 0.5 ? wave : 1.0-wave);
        vec2 offset = vec2(0.0);
        float angle = 0.0;
        if (mode > 1.5 && mode < 2.5) { zoom = 1.0 + uCam.x + uCam.y * 0.3; offset.x = sin(phase) * (0.5-0.5/zoom) * uCam.y; }
        if (mode > 2.5 && mode < 3.5) { angle = sin(phase)*uCam.x*0.3; zoom = 1.0 + abs(sin(angle))*max(uAspect,1.0/uAspect)+uCam.x*0.1; }
        if (mode > 3.5) { zoom = 1.0+uCam.x*0.15+uCam.y*0.06; offset = vec2(sin(phase*3.0),sin(phase*5.0))*uCam.y*0.01; }
        vec2 center = (s-0.5)*vec2(uAspect,1.0);
        center = mat2(cos(angle),-sin(angle),sin(angle),cos(angle))*center;
        vec2 moved = center/vec2(uAspect,1.0)/zoom+0.5+offset;
        sc = mix(s,moved,maskValue(uvFrame,uMaskCam,1.0,0.0));
    }
    vec2 uv = uViewOffset + sc * uViewScale;

    float freeze = texture(uFreeze, uv).r;
    float z1 = texture(uZone1, uv).r;
    float z2 = texture(uZone2, uv).r;
    float move = 1.0 - freeze;
    vec2 asp = vec2(1.0 / uAspect, 1.0);
    vec2 P = vec2(uvFrame.x * uAspect, uvFrame.y);
    vec2 Q = vec2(uv.x * uAspect, uv.y);

    vec3 col = vec3(0.0);

    if (uOverlayOnly < 0.5) {
        // Distorsiones
        vec2 d = vec2(0.0);
        if (uRipple.x > 0.0) {
            vec2 q = Q * uRipple.y;
            float ph = TAU * uT * uRipple.z;
            d += vec2(sin(q.y * 1.7 + ph + sin(q.x * 0.9)), cos(q.x * 1.3 - ph + sin(q.y * 1.1))) * uRipple.x * maskValue(uv, uMaskRipple, z1, 1.0);
        }
        if (uSway.x > 0.0) {
            float n = vnoise(Q * uSway.y);
            float ph = TAU * (uT * uSway.z + n);
            float sw = sin(ph) + 0.35 * sin(2.0 * ph + 1.3);
            d += vec2(sw, 0.3 * cos(ph)) * uSway.x * maskValue(uv, uMaskSway, z2, 1.0);
        }
        if (uHeat.x > 0.0) {
            vec2 q = Q * uHeat.y;
            float ph = TAU * uT * uHeat.z;
            d += vec2(sin(q.y * 2.0 + ph + vnoise(q) * 3.0), 0.5 * cos(q.x * 1.5 + ph)) * uHeat.x * maskValue(uv, uMaskHeat, z2, 1.0);
        }
        if (uFxCloth.x > 0.0) {
            float ph = TAU * uT * uFxCloth.z;
            vec2 q = Q * uFxCloth.y;
            vec2 sway = vec2(sin(q.y + ph + 0.4 * sin(q.x)),
                             0.25 * cos(q.x + ph));
            d += sway * uFxCloth.x * maskValue(uv, uMaskCloth, z2, 1.0);
        }
        if(uZoneMotion.x>0.0){
            float zone=maskValue(uv,uMaskZonemotion,0.0,1.0);
            float phase=TAU*uT*uZoneMotion.y;
            vec2 direction=vec2(cos(uZoneMotion.w),sin(uZoneMotion.w));
            vec2 motion=direction*sin(phase)*uZoneMotion.x;
            if(uZoneMotion.z>0.5 && uZoneMotion.z<1.5)
                motion=direction*sin(phase+dot(Q,vec2(-direction.y,direction.x))*18.0)*uZoneMotion.x;
            if(uZoneMotion.z>1.5)
                motion=vec2(0.0,-sin(phase)*uZoneMotion.x*(0.35+0.65*smoothstep(0.0,1.0,uv.y)));
            d+=motion*zone;
        }
        d *= move;

        // Flujo (flechas) + deriva, con fundido de dos fases
        vec2 f = vec2(0.0);
        if (uFlow3.x > 0.5) {
            f += texture(uFlow, uv).rg * uFlow3.y * maskValue(uv, uMaskFlow, z1, 0.0);
        }
        f += uDrift * maskValue(uv, uMaskDrift, z1, 1.0);
        f *= move;

        vec2 base = uv + d * asp;
        if (dot(f, f) > 1e-12) {
            float phase=uT*uFlow3.z+uLoopControl.z;
            if(uLoopControl.x<0.5){
                float p1=fract(phase),p2=fract(p1+0.5);
                float w1=1.0-abs(2.0*p1-1.0);
                float blend=max(0.05,uLoopControl.y);
                if(blend<0.999)w1=smoothstep(0.5-blend*0.5,0.5+blend*0.5,w1);
                col=mix(warpSample(uv,d*asp-f*(p2-0.5)),warpSample(uv,d*asp-f*(p1-0.5)),w1);
            } else if(uLoopControl.x<1.5){
                col=warpSample(uv,d*asp-f*(0.5*sin(TAU*phase)));
            } else {
                col=warpSample(uv,d*asp-f*(0.5-0.5*cos(TAU*phase)));
            }
        } else {
            col = warpSample(uv,d*asp);
        }

        // Brillos en el agua
        if (uGlint.x > 0.0) {
            vec2 g = Q * uGlint.y;
            vec2 id = floor(g);
            vec2 fq = fract(g);
            vec2 h = hash22(id + 4.4);
            vec2 c = 0.2 + 0.6 * h;
            float dd = length((fq - c) * vec2(0.55, 2.2));
            float tw = 0.5 + 0.5 * sin(TAU * (uT * uGlint.z + h.x));
            float gli = falloff(dd, 0.14) * tw * tw * tw * tw * step(0.5, h.y);
            col += vec3(1.0, 0.98, 0.9) * gli * uGlint.x * maskValue(uv, uMaskGlint, z1, 1.0) * move;
        }
    }

    if (uOverlayOnly < 0.5) {
        if(uStudioWater.x>0.0){
            float ph=TAU*uT*uStudioWater.y;
            vec2 dir=vec2(cos(uStudioWater.w),sin(uStudioWater.w));
            vec2 q=uv*vec2(uAspect,1.0);
            float wave=sin(dot(q,dir)*65.0+ph)*cos(dot(q,vec2(-dir.y,dir.x))*21.0-ph);
            vec2 offset=dir*wave*0.008*uStudioWater.x/vec2(uAspect,1.0);
            if(uStudioWater.z>0.5 && uStudioWater.z<1.5)offset=dir*sin(ph+dot(q,dir)*30.0)*0.014*uStudioWater.x/vec2(uAspect,1.0);
            vec3 water=warpSample(uv,offset);
            if(uStudioWater.z>1.5)water+=pow(max(0.0,wave),8.0)*uStudioWater.x*vec3(0.5,0.7,0.85);
            col=mix(col,water,maskValue(uv,uMaskWater,z1,1.0)*move);
        }
        if(uStudioSky.x>0.0)col=mix(col,studioSky(uv),uStudioSky.x*maskValue(uv,uMaskSky,0.0,1.0));
        if(uStudioDispersion.x>0.0)col=studioDisperse(col,uv);
    }
    float bgL = luma(col);

    if (uRays.x > 0.0) {
        float g = maskValue(uv, uMaskRays, z1, uRays.w);
        vec3 rc = mix(vec3(1.0, 0.92, 0.75), vec3(1.0), uMono);
        col += rc * raysField(P, uRays.y, uRays.z) * uRays.x * g;
    }
    if (uEnergy.x > 0.0) {
        float g = maskValue(uv, uMaskEnergy, z1, uEnergy.w);
        vec3 ec = uMono > 0.5 ? vec3(1.0) : vec3(0.28, 0.62, 1.0);
        col += ec * energyField(P, uEnergy.y, uEnergy.z) * uEnergy.x * g;
    }
    if (uSpeed.x > 0.0) {
        float g = maskValue(uv, uMaskSpeed, z1, uSpeed.w);
        vec3 sc = uMono > 0.5 ? vec3(1.0) : vec3(0.95, 0.88, 1.0);
        col += sc * speedField(P - uMotionSpeed.zw * vec2(uAspect, 1.0), degrees(atan(uMotionSpeed.y, uMotionSpeed.x)) - 90.0 + uSpeed.y, uSpeed.z) * uSpeed.x * g;
    }
    if (uStars.x > 0.0) {
        float g = maskValue(uv, uMaskStars, z1, uStars.w);
        vec3 st = starsLayer(P, uStars.y, uStars.z);
        if (uMono > 0.5) {
            st = vec3(luma(st));
        }
        col += st * uStars.x * g;
    }
    if (uFog.x > 0.0) {
        float g = maskValue(uv, uMaskFog, z1, uFog.w);
        float fv = smoothstep(0.3, 0.85, fogField(oriented(P, uMotionFog), uFog.y, uFog.z))
            * emitArea(P, uMotionFog);
        vec3 fc = mix(vec3(0.86, 0.89, 0.95), vec3(1.0), uMono);
        col = mix(col, fc, fv * uFog.x * g);
    }
    if (uRain.x > 0.0) {
        float g = maskValue(uv, uMaskRain, z1, uRain.w);
        float r = rainLayer(oriented(P, uMotionRain), 14.0, uRain.z + 2.0, uRain.y, 1.0)
                + 0.7 * rainLayer(oriented(P, uMotionRain), 24.0, uRain.z + 1.0, uRain.y, 17.0)
                + 0.45 * rainLayer(oriented(P, uMotionRain), 40.0, uRain.z, uRain.y, 41.0);
        vec3 rc = vec3(0.82, 0.88, 1.0);
        if (uMono > 0.5) {
            rc = bgL > 0.55 ? vec3(0.08) : vec3(0.97);
        }
        col = mix(col, rc, clamp(r, 0.0, 1.0) * uRain.x * g * emitArea(P, uMotionRain));
    }
    if (uSnow.x > 0.0) {
        float g = maskValue(uv, uMaskSnow, z1, uSnow.w);
        float sn = snowLayer(oriented(P, uMotionSnow), 10.0, uSnow.z + 1.0, uSnow.y * 1.3, 3.0)
                 + 0.8 * snowLayer(oriented(P, uMotionSnow), 18.0, uSnow.z, uSnow.y, 29.0)
                 + 0.6 * snowLayer(oriented(P, uMotionSnow), 30.0, uSnow.z, uSnow.y * 0.8, 53.0);
        col = mix(col, vec3(1.0), clamp(sn, 0.0, 1.0) * uSnow.x * g * emitArea(P, uMotionSnow));
    }
    if (uSakura.x > 0.0) {
        float g = maskValue(uv, uMaskSakura, z1, uSakura.w);
        vec4 pa = sakuraLayer(oriented(P, uMotionSakura), 5.0, uSakura.z + 1.0, uSakura.y * 1.2, 7.0);
        vec4 pb = sakuraLayer(oriented(P, uMotionSakura), 9.0, uSakura.z, uSakura.y, 61.0);
        vec3 ca = pa.rgb;
        vec3 cb = pb.rgb;
        if (uMono > 0.5) {
            ca = vec3(luma(ca));
            cb = vec3(luma(cb));
        }
        col = mix(col, cb, pb.a * uSakura.x * g * emitArea(P, uMotionSakura));
        col = mix(col, ca, pa.a * uSakura.x * g * emitArea(P, uMotionSakura));
    }
    if (uFlies.x > 0.0) {
        float g = maskValue(uv, uMaskFlies, z1, uFlies.w);
        vec3 fl = fliesLayer(P, uFlies.y, uFlies.z);
        if (uMono > 0.5) {
            fl = vec3(luma(fl));
        }
        col += fl * uFlies.x * g;
    }

    // Partículas de atmósfera con color propio y origen/dirección independientes.
    if (uFxAsh.x > 0.0) {
        float v = particleDot(oriented(P, uMotionAsh), 13.0, uFxAsh.z, uFxAsh.y, 13.0);
        col = mix(col, vec3(0.66), v * uFxAsh.x * maskValue(uv, uMaskAsh, z1, uFxAsh.w) * emitArea(P, uMotionAsh));
    }
    if (uFxLeaves.x > 0.0) {
        float v = particleDot(oriented(P, uMotionLeaves), 7.0, uFxLeaves.z, uFxLeaves.y, 33.0);
        col = mix(col, uMono > 0.5 ? vec3(0.88) : vec3(0.37, 0.84, 0.39),
            v * uFxLeaves.x * maskValue(uv, uMaskLeaves, z1, uFxLeaves.w) * emitArea(P, uMotionLeaves));
    }
    if (uFxEmbers.x > 0.0) {
        float v = particleDot(oriented(P, uMotionEmbers), 17.0, uFxEmbers.z, uFxEmbers.y, 51.0);
        col += (uMono > 0.5 ? vec3(1.0) : vec3(1.0, 0.48, 0.09)) * v * uFxEmbers.x *
            maskValue(uv, uMaskEmbers, z1, uFxEmbers.w) * emitArea(P, uMotionEmbers);
    }
    if (uFxDust.x > 0.0) {
        float v = particleDot(oriented(P, uMotionDust), 14.0, uFxDust.z, uFxDust.y, 71.0);
        col += vec3(0.85, 0.81, 0.73) * v * uFxDust.x * maskValue(uv, uMaskDust, z1, uFxDust.w) * emitArea(P, uMotionDust);
    }
    if (uFxBubbles.x > 0.0) {
        vec2 g = oriented(P, uMotionBubbles) * 10.0;
        g.y -= uT * uFxBubbles.z * 6.0;
        vec2 h = hash22(vec2(floor(g.x), mod(floor(g.y), 6.0)) + 81.0);
        float r = length(fract(g) - (0.2 + 0.6 * h));
        float rim = (1.0 - smoothstep(0.008, 0.025, abs(r - uFxBubbles.y * 0.10))) * step(0.5, h.x);
        col += vec3(0.62, 0.87, 1.0) * rim * uFxBubbles.x *
            maskValue(uv, uMaskBubbles, z1, uFxBubbles.w) * emitArea(P, uMotionBubbles);
    }
    if (uFxElectric.x > 0.0) {
        float v = electricArc(P, uMotionElectric, uFxElectric.y, uFxElectric.z);
        col += (uMono > 0.5 ? vec3(1.0) : vec3(0.27, 0.80, 1.0)) * v * uFxElectric.x * maskValue(uv, uMaskElectric, z1, uFxElectric.w);
    }
    if (uFxFocus.x > 0.0) {
        float v = focusLines(P, uMotionFocus, uFxFocus.y, uFxFocus.z);
        col = mix(col, vec3(uMono > 0.5 ? 0.0 : 0.92), clamp(v*uFxFocus.x*maskValue(uv, uMaskFocus, z1, uFxFocus.w),0.0,1.0));
    }
    if (uFxShock.x > 0.0) {
        float r = length(P - uMotionShock.zw * vec2(uAspect, 1.0));
        float phase = fract(uT * uFxShock.z);
        float ring = (1.0 - smoothstep(uFxShock.y * 0.4, uFxShock.y, abs(r-phase*0.9)))*(1.0-phase);
        col += vec3(0.65, 0.86, 1.0) * ring*uFxShock.x*maskValue(uv, uMaskShock, z1, uFxShock.w);
    }
    if (uFxFlash.x > 0.0) {
        float phase = fract(uT*uFxFlash.z);
        float burst = 1.0 - smoothstep(0.0, uFxFlash.y, phase);
        col = mix(col, vec3(1.0), clamp(burst*uFxFlash.x*maskValue(uv, uMaskFlash, z1, uFxFlash.w),0.0,1.0));
    }
    if (uFxTone.x > 0.0) {
        vec2 grid = fract(P * uFxTone.y);
        float dotTone = 1.0 - smoothstep(0.1, 0.38, length(grid-0.5));
        float pulse = 0.9 + 0.1*sin(TAU*uT*uFxTone.z);
        float k = uFxTone.x*maskValue(uv, uMaskTone, z1, uFxTone.w);
        col = mix(col, vec3(dotTone*0.10 + (1.0-dotTone)*0.98)*pulse, k);
    }
    if (uFxGrain.x > 0.0) {
        float n = hash12(floor(P*uFxGrain.y)+vec2(floor(mod(uT*uFxGrain.z*12.0,12.0)),0.0));
        col += (n-0.5)*uFxGrain.x*maskValue(uv, uMaskGrain, z1, uFxGrain.w);
    }
    if (uFxInk.x > 0.0) {
        float ink = smoothstep(uFxInk.y-0.035,uFxInk.y+0.035,luma(col));
        col = mix(col,vec3(ink),uFxInk.x*maskValue(uv, uMaskInk, z1, uFxInk.w));
    }

    // Instancias B; conserva el orden, las máscaras y los parámetros de cada copia.
    if (uFxAshCopy.x > 0.0) {
        float v = particleDot(oriented(P, uMotionAshCopy), 13.0, uFxAshCopy.z, uFxAshCopy.y, 13.0);
        col = mix(col, vec3(0.66), v * uFxAshCopy.x * maskValue(uv, uMaskAshCopy, z1, uFxAshCopy.w) * emitArea(P, uMotionAshCopy));
    }
    if (uFxLeavesCopy.x > 0.0) {
        float v = particleDot(oriented(P, uMotionLeavesCopy), 7.0, uFxLeavesCopy.z, uFxLeavesCopy.y, 33.0);
        col = mix(col, uMono > 0.5 ? vec3(0.88) : vec3(0.37, 0.84, 0.39),
            v * uFxLeavesCopy.x * maskValue(uv, uMaskLeavesCopy, z1, uFxLeavesCopy.w) * emitArea(P, uMotionLeavesCopy));
    }
    if (uFxEmbersCopy.x > 0.0) {
        float v = particleDot(oriented(P, uMotionEmbersCopy), 17.0, uFxEmbersCopy.z, uFxEmbersCopy.y, 51.0);
        col += (uMono > 0.5 ? vec3(1.0) : vec3(1.0, 0.48, 0.09)) * v * uFxEmbersCopy.x *
            maskValue(uv, uMaskEmbersCopy, z1, uFxEmbersCopy.w) * emitArea(P, uMotionEmbersCopy);
    }
    if (uFxDustCopy.x > 0.0) {
        float v = particleDot(oriented(P, uMotionDustCopy), 14.0, uFxDustCopy.z, uFxDustCopy.y, 71.0);
        col += vec3(0.85, 0.81, 0.73) * v * uFxDustCopy.x * maskValue(uv, uMaskDustCopy, z1, uFxDustCopy.w) * emitArea(P, uMotionDustCopy);
    }
    if (uFxBubblesCopy.x > 0.0) {
        vec2 g = oriented(P, uMotionBubblesCopy) * 10.0;
        g.y -= uT * uFxBubblesCopy.z * 6.0;
        vec2 h = hash22(vec2(floor(g.x), mod(floor(g.y), 6.0)) + 81.0);
        float r = length(fract(g) - (0.2 + 0.6 * h));
        float rim = (1.0 - smoothstep(0.008, 0.025, abs(r - uFxBubblesCopy.y * 0.10))) * step(0.5, h.x);
        col += vec3(0.62, 0.87, 1.0) * rim * uFxBubblesCopy.x *
            maskValue(uv, uMaskBubblesCopy, z1, uFxBubblesCopy.w) * emitArea(P, uMotionBubblesCopy);
    }
    if (uFxElectricCopy.x > 0.0) {
        float v = electricArc(P, uMotionElectricCopy, uFxElectricCopy.y, uFxElectricCopy.z);
        col += (uMono > 0.5 ? vec3(1.0) : vec3(0.27, 0.80, 1.0)) * v * uFxElectricCopy.x * maskValue(uv, uMaskElectricCopy, z1, uFxElectricCopy.w);
    }
    if (uFxFocusCopy.x > 0.0) {
        float v = focusLines(P, uMotionFocusCopy, uFxFocusCopy.y, uFxFocusCopy.z);
        col = mix(col, vec3(uMono > 0.5 ? 0.0 : 0.92), clamp(v*uFxFocusCopy.x*maskValue(uv, uMaskFocusCopy, z1, uFxFocusCopy.w),0.0,1.0));
    }
    if (uFxShockCopy.x > 0.0) {
        float r = length(P - uMotionShockCopy.zw * vec2(uAspect, 1.0));
        float phase = fract(uT * uFxShockCopy.z);
        float ring = (1.0 - smoothstep(uFxShockCopy.y * 0.4, uFxShockCopy.y, abs(r-phase*0.9)))*(1.0-phase);
        col += vec3(0.65, 0.86, 1.0) * ring*uFxShockCopy.x*maskValue(uv, uMaskShockCopy, z1, uFxShockCopy.w);
    }
    if (uFxFlashCopy.x > 0.0) {
        float phase = fract(uT*uFxFlashCopy.z);
        float burst = 1.0 - smoothstep(0.0, uFxFlashCopy.y, phase);
        col = mix(col, vec3(1.0), clamp(burst*uFxFlashCopy.x*maskValue(uv, uMaskFlashCopy, z1, uFxFlashCopy.w),0.0,1.0));
    }
    if (uFxToneCopy.x > 0.0) {
        vec2 grid = fract(P * uFxToneCopy.y);
        float dotTone = 1.0 - smoothstep(0.1, 0.38, length(grid-0.5));
        float pulse = 0.9 + 0.1*sin(TAU*uT*uFxToneCopy.z);
        float k = uFxToneCopy.x*maskValue(uv, uMaskToneCopy, z1, uFxToneCopy.w);
        col = mix(col, vec3(dotTone*0.10 + (1.0-dotTone)*0.98)*pulse, k);
    }
    if (uFxGrainCopy.x > 0.0) {
        float n = hash12(floor(P*uFxGrainCopy.y)+vec2(floor(mod(uT*uFxGrainCopy.z*12.0,12.0)),0.0));
        col += (n-0.5)*uFxGrainCopy.x*maskValue(uv, uMaskGrainCopy, z1, uFxGrainCopy.w);
    }
    if (uFxInkCopy.x > 0.0) {
        float ink = smoothstep(uFxInkCopy.y-0.035,uFxInkCopy.y+0.035,luma(col));
        col = mix(col,vec3(ink),uFxInkCopy.x*maskValue(uv, uMaskInkCopy, z1, uFxInkCopy.w));
    }


    // Segunda familia de efectos: máscara y dirección ajustables en el editor.
    if (uFxComet.x > 0.0) {
        vec2 g = oriented(P, uMotionComet) * vec2(17.0, 7.0);
        g.y -= uT * uFxComet.z * 6.0;
        vec2 id = floor(g), f = fract(g);
        float presence = step(0.87, hash12(vec2(id.x, mod(id.y,6.0))));
        float x = 0.15 + 0.7*hash12(id+7.0);
        float trail = exp(-abs(f.x-x)*105.0) * smoothstep(0.05, 0.3, f.y) * (1.0-smoothstep(0.6,1.0,f.y));
        col += vec3(0.48,0.82,1.0)*trail*presence*uFxComet.y*uFxComet.x*
            maskValue(uv,uMaskComet,z1,uFxComet.w)*emitArea(P,uMotionComet);
    }
    if (uFxRunes.x > 0.0) {
        vec2 q = P-uMotionRunes.zw*vec2(uAspect,1.0);
        float radius = length(q), ang = atan(q.y,q.x)+TAU*uT*uFxRunes.z;
        float r = 0.17*uFxRunes.y;
        float ring = (1.0-smoothstep(0.002,0.009,abs(radius-r)));
        float marks = (1.0-smoothstep(0.01,0.045,abs(radius-r*0.84)))*step(0.7,fract(ang*12.0/TAU));
        float rim = ring + marks;
        col += vec3(0.56,0.79,1.0)*rim*uFxRunes.x*maskValue(uv,uMaskRunes,z1,uFxRunes.w);
    }
    if (uFxHatch.x > 0.0) {
        float lines = abs(fract((P.x+P.y)*uFxHatch.y + uT*uFxHatch.z)-0.5);
        float hatch = (1.0-smoothstep(0.02,0.045,lines));
        col = mix(col, vec3(uMono>0.5?0.0:0.13),hatch*uFxHatch.x*
            maskValue(uv,uMaskHatch,z1,uFxHatch.w));
    }
    if (uFxPulse.x > 0.0) {
        vec2 q=P-uMotionPulse.zw*vec2(uAspect,1.0);
        float d=length(q), phase=fract(uT*uFxPulse.z);
        float rings=0.0;
        for(int k=0;k<3;k++) {
            float r=fract(phase+float(k)/3.0)*0.65;
            rings+= (1.0-smoothstep(uFxPulse.y*0.25,uFxPulse.y,abs(d-r)))*(1.0-r);
        }
        col += vec3(0.52,0.88,1.0)*rings*uFxPulse.x*maskValue(uv,uMaskPulse,z1,uFxPulse.w);
    }
    if (uFxSmoke.x > 0.0) {
        float ph=fract(uT*uFxSmoke.z);
        vec2 q=oriented(P,uMotionSmoke)*uFxSmoke.y;
        float a=fbm(q+vec2(0.0,ph-0.5));
        float b=fbm(q+vec2(0.0,fract(ph+0.5)-0.5));
        float n=mix(b,a,1.0-abs(ph*2.0-1.0));
        float opacity=smoothstep(0.42,0.78,n)*uFxSmoke.x*maskValue(uv,uMaskSmoke,z1,uFxSmoke.w);
        col=mix(col,vec3(0.58,0.63,0.75),opacity*emitArea(P,uMotionSmoke));
    }
    if (uFxShards.x > 0.0) {
        vec2 g=oriented(P,uMotionShards)*9.0;
        g.y-=uT*uFxShards.z*6.0;
        vec2 id=floor(g),f=fract(g);
        vec2 h=hash22(vec2(id.x,mod(id.y,6.0))+34.0);
        vec2 q=f-(0.2+0.6*h);
        float diamond=abs(q.x)+abs(q.y)*1.6;
        float v=1.0-smoothstep(uFxShards.y*0.035,uFxShards.y*0.06,diamond);
        col+=vec3(0.65,0.91,1.0)*v*step(0.62,h.x)*uFxShards.x*
            maskValue(uv,uMaskShards,z1,uFxShards.w)*emitArea(P,uMotionShards);
    }

    // Llamas planas, brillo localizado y cierre de sombra. Solo se calculan activos.
    if (uFxFlame.x > 0.0) {
        vec2 q = P * (10.0 * uFxFlame.y);
        float phase = TAU * uT * uFxFlame.z;
        float wave = sin(q.x * 1.6 + phase + sin(q.y * 0.7));
        float tongues = 0.5 + 0.5 * sin(q.y * 2.3 - phase + wave * 1.8);
        float edge = smoothstep(0.42, 0.78, tongues);
        float area = maskValue(uv, uMaskFlame, z2, 1.0) * move;
        col = mix(col, vec3(1.0, 0.31 + 0.38 * edge, 0.06),
                  clamp((0.24 + 0.55 * edge) * uFxFlame.x * area, 0.0, 1.0));
    }
    if (uFxEyes.x > 0.0) {
        float pulse = 0.65 + 0.35 * sin(TAU * uT * uFxEyes.z);
        float area = maskValue(uv, uMaskEyes, z1, 1.0);
        col += vec3(0.20, 0.68, 1.0) * pulse * uFxEyes.y * uFxEyes.x * area;
    }
    if (uFxBlink.x > 0.0) {
        float phase = fract(uT * uFxBlink.z);
        float width = max(0.02, uFxBlink.y);
        float close = 1.0 - smoothstep(0.0, width, abs(phase - 0.5));
        col *= 1.0 - clamp(close * uFxBlink.x *
            maskValue(uv, uMaskBlink, z1, 1.0), 0.0, 1.0);
    }

    col=studioElements(col,uvFrame);
    col=gradeColor(col,uvFrame);
    // Dither suave para evitar bandas en cielos y degradados
    col += (hash12(gl_FragCoord.xy) - 0.5) / 255.0;
    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
