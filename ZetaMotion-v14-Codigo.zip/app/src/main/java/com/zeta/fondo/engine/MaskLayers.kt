package com.zeta.fondo.engine

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import com.zeta.fondo.model.MaskStroke
import com.zeta.fondo.model.PointN
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Máscaras nombradas de 8 bits (ALPHA_8). Se guardan los trazos para poder deshacer
 * y redibujar. Todo acceso a los bitmaps va dentro de synchronized(lock),
 * porque el hilo de OpenGL los lee para subirlos como textura.
 */
class MaskLayers private constructor(val w: Int, val h: Int) {

    val lock = Any()
    val bitmaps = ArrayList<Bitmap>()
    private val canvases = ArrayList<Canvas>()
    val strokes = ArrayList<ArrayList<MaskStroke>>()
    val versions = ArrayList<Int>()
    val names = ArrayList<String>()
    private var serial = 0

    init {
        listOf("Congelar", "Zona azul", "Zona verde").forEach { addLayer(it) }
    }

    val count: Int get() = bitmaps.size

    fun addLayer(name: String): Int = synchronized(lock) {
        if (count >= MAX_MASKS) return@synchronized -1
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
        bitmaps.add(bmp)
        canvases.add(Canvas(bmp))
        strokes.add(ArrayList())
        versions.add(++serial)
        names.add(name.trim().take(32).ifBlank { "Máscara ${count}" })
        count - 1
    }

    fun renameLayer(index: Int, name: String) = synchronized(lock) {
        if (index in names.indices && index > 0) names[index] = name.trim().take(32).ifBlank { "Máscara $index" }
    }


    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.BLACK
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.BLACK
    }
    private val dstOut = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    private var cachedStroke: MaskStroke? = null
    private var cachedBlur: BlurMaskFilter? = null

    companion object {
        const val MAX_MASKS = 12
        fun create(imgW: Int, imgH: Int, maxSide: Int = 1280): MaskLayers {
            val k = min(1f, maxSide.toFloat() / max(imgW, imgH))
            var w = max(4, (imgW * k).roundToInt())
            val h = max(4, (imgH * k).roundToInt())
            w = (w + 3) / 4 * 4 // ancho múltiplo de 4: filas sin relleno al subir a OpenGL
            return MaskLayers(w, h)
        }
    }

    private fun blurFor(s: MaskStroke): BlurMaskFilter? {
        if (cachedStroke === s) return cachedBlur
        val rPx = s.radius * h
        val blur = rPx * s.feather * 0.9f
        cachedStroke = s
        cachedBlur = if (blur >= 0.5f) BlurMaskFilter(blur, BlurMaskFilter.Blur.NORMAL) else null
        return cachedBlur
    }

    private fun configure(p: Paint, s: MaskStroke) {
        val rPx = s.radius * h
        p.xfermode = if (s.erase) dstOut else null
        p.maskFilter = blurFor(s)
        val blur = rPx * s.feather * 0.9f
        p.strokeWidth = max(1f, rPx * 2f - blur)
    }

    private fun drawDot(s: MaskStroke, pt: PointN) {
        configure(dotPaint, s)
        val r = max(0.5f, dotPaint.strokeWidth / 2f)
        canvases[s.layer].drawCircle(pt.x * w, pt.y * h, r, dotPaint)
    }

    private fun drawFull(s: MaskStroke) {
        val c = canvases[s.layer]
        if (s.fill) {
            dotPaint.maskFilter = null
            dotPaint.xfermode = if (s.erase) dstOut else null
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), dotPaint)
            return
        }
        if (s.points.isEmpty()) return
        if (s.points.size == 1) {
            drawDot(s, s.points[0])
            return
        }
        configure(linePaint, s)
        val path = Path()
        path.moveTo(s.points[0].x * w, s.points[0].y * h)
        for (i in 1 until s.points.size) path.lineTo(s.points[i].x * w, s.points[i].y * h)
        c.drawPath(path, linePaint)
    }

    fun addStroke(s: MaskStroke) {
        synchronized(lock) {
            strokes[s.layer].add(s)
            drawFull(s)
            versions[s.layer] = ++serial
        }
    }

    fun extendStroke(s: MaskStroke, pt: PointN) {
        synchronized(lock) {
            val last = s.points.lastOrNull()
            s.points.add(pt)
            if (last == null) {
                drawDot(s, pt)
            } else {
                configure(linePaint, s)
                canvases[s.layer].drawLine(last.x * w, last.y * h, pt.x * w, pt.y * h, linePaint)
            }
            versions[s.layer] = ++serial
        }
    }

    fun removeStroke(s: MaskStroke) {
        synchronized(lock) {
            strokes[s.layer].remove(s)
            redraw(s.layer)
        }
    }

    fun setAll(list: List<MaskStroke>, labels: List<String> = emptyList()) {
        synchronized(lock) {
            val required = (list.maxOfOrNull { it.layer + 1 } ?: 3)
                .coerceAtLeast(labels.size).coerceIn(3, MAX_MASKS)
            while (count > required) {
                bitmaps.removeAt(count - 1).recycle()
                canvases.removeAt(canvases.lastIndex); strokes.removeAt(strokes.lastIndex)
                versions.removeAt(versions.lastIndex); names.removeAt(names.lastIndex)
            }
            while (count < required) addLayer(labels.getOrElse(count) { "Máscara $count" })
            labels.take(MAX_MASKS).forEachIndexed { i, name ->
                names[i] = name.take(32).ifBlank { "Máscara $i" }
            }
            for (i in bitmaps.indices) strokes[i].clear()
            for (s in list) if (s.layer in bitmaps.indices) strokes[s.layer].add(s)
            for (i in bitmaps.indices) redraw(i)
        }
    }

    /** Copia de todos los trazos (para guardar el proyecto). */
    fun snapshot(): List<MaskStroke> {
        synchronized(lock) {
            val out = ArrayList<MaskStroke>()
            for (i in bitmaps.indices) {
                for (s in strokes[i]) {
                    val c = MaskStroke(s.layer, s.radius, s.feather, s.erase, s.fill)
                    c.points.addAll(s.points)
                    out.add(c)
                }
            }
            return out
        }
    }

    private fun redraw(layer: Int) {
        bitmaps[layer].eraseColor(Color.TRANSPARENT)
        for (s in strokes[layer]) drawFull(s)
        versions[layer] = ++serial
    }
}
