package com.zeta.fondo.ui

import android.app.Activity
import android.opengl.GLSurfaceView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.ui.window.Dialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.ExportState
import com.zeta.fondo.engine.ExportPlanner
import com.zeta.fondo.engine.PreviewRenderer
import com.zeta.fondo.model.Arrow
import com.zeta.fondo.model.EditorTab
import com.zeta.fondo.model.PointN
import com.zeta.fondo.model.Tool
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.hypot

/** El tamaño del lienzo depende de la pantalla, nunca del panel seleccionado. */
@Composable
fun EditorScreen(vm: AppViewModel) {
    val meta = vm.meta ?: return
    var exportOpen by remember(meta.id) { mutableStateOf(false) }
    BackHandler(!exportOpen) {
        when {
            vm.fullscreen -> vm.fullscreen = false
            vm.paintingZone && vm.editingEffect != null -> vm.finishPainting()
            vm.editingEffect != null || vm.paintingZone -> vm.finishEdit(false)
            else -> vm.closeEditor()
        }
    }
    val context = LocalContext.current
    val rootView = LocalView.current
    val owner = LocalLifecycleOwner.current
    val audio = remember(meta.id) { com.zeta.fondo.engine.ImportedAudioPreview(context.applicationContext, vm.hub) { message ->
        android.os.Handler(android.os.Looper.getMainLooper()).post { vm.message = message }
    } }
    val audioSettings = vm.exportSettings
    val audioPlaying = vm.playing && vm.exportState !is ExportState.Running && vm.busy == null
    SideEffect {
        audio.update(java.io.File(meta.dir, com.zeta.fondo.engine.ImportedAudio.FILE_NAME),
            audioSettings, audioPlaying)
    }
    DisposableEffect(audio, owner) {
        audio.setForeground(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED))
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) audio.setForeground(false)
            if (event == Lifecycle.Event.ON_RESUME) audio.setForeground(true)
        }
        owner.lifecycle.addObserver(observer)
        audio.start()
        onDispose { owner.lifecycle.removeObserver(observer); audio.close() }
    }
    val fullScreen = vm.fullscreen
    SideEffect {
        (context as? Activity)?.let {
            val controller = WindowCompat.getInsetsController(it.window, rootView)
            if (fullScreen) {
                controller.hide(WindowInsetsCompat.Type.systemBars())
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }
    DisposableEffect(rootView) {
        onDispose { (context as? Activity)?.let { WindowCompat.getInsetsController(it.window, rootView)
            .show(WindowInsetsCompat.Type.systemBars()) } }
    }
    BoxWithConstraints(Modifier.fillMaxSize().background(Night)) {
        val wide = maxWidth > maxHeight
        val top = if (vm.fullscreen) 0.dp else 52.dp
        val transport = if (vm.fullscreen) 0.dp else 44.dp
        val tabs = 58.dp
        // Esta reserva permanece idéntica al abrir efectos, controles, audio o formato.
        val dock = (maxHeight * .29f).coerceIn(176.dp, 232.dp)
        val side = if (wide && !vm.fullscreen) (maxWidth * .42f).coerceIn(270.dp, 360.dp) else 0.dp
        val canvasW = maxWidth - side
        val canvasH = (maxHeight - top - transport -
            if (!wide && !vm.fullscreen) dock + tabs else 0.dp).coerceAtLeast(80.dp)
        EditorCanvas(vm, Modifier.offset(y = top).width(canvasW).height(canvasH))
        if (!vm.fullscreen) {
            StudioEditorTopBar(vm, meta.name, Modifier.fillMaxWidth().height(top)) { vm.finishEdit(true); exportOpen = true }
            Box(Modifier.offset(y = top + canvasH).width(canvasW).height(transport)) {
                TransportBar(vm) { vm.settingsSection = 1; vm.selectTab(EditorTab.CANVAS) }
            }
            Column(Modifier.offset(x = if (wide) canvasW else 0.dp,
                y = if (wide) top else top + canvasH + transport)
                .width(if (wide) side else maxWidth)
                .height(if (wide) maxHeight - top else dock + tabs)
                .background(StudioPanel)) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (vm.paintingZone) SimpleBrushPanel(vm) else when (vm.tab) {
                        EditorTab.TOOLS -> ToolsPanel(vm)
                        EditorTab.MASKS -> SimpleProtectPanel(vm)
                        EditorTab.CANVAS, EditorTab.AUDIO -> SimpleSettingsPanel(vm)
                        else -> SimpleEffectsPanel(vm)
                    }
                }
                EditorTabBar(vm, Modifier.height(tabs)) { tab ->
                    vm.selectTab(tab)
                }
            }
        }
    }
    if (exportOpen) {
        Dialog(onDismissRequest = { if (vm.exportState !is ExportState.Running) exportOpen = false }) {
            Column(Modifier.fillMaxWidth().fillMaxHeight(.82f).clip(RoundedCornerShape(16.dp))
                .background(StudioPanel)) {
                Row(Modifier.fillMaxWidth().height(44.dp).padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("Exportación", color = StudioText, fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f))
                    Icon(Icons.Filled.Close, "Cerrar", tint = StudioText, modifier = Modifier.size(44.dp)
                        .clickable(enabled = vm.exportState !is ExportState.Running) { exportOpen = false }.padding(11.dp))
                }
                Box(Modifier.weight(1f)) { ExportPanel(vm) }
            }
        }
    }
}

@Composable
private fun EditorCanvas(vm: AppViewModel, modifier: Modifier) {
    BoxWithConstraints(modifier.background(Color.Black), contentAlignment = Alignment.Center) {
        val boxAspect = maxWidth.value / maxHeight.value.coerceAtLeast(1f)
        val imageAspect = vm.previewAspect
        Box(Modifier.aspectRatio(imageAspect, matchHeightConstraintsFirst = imageAspect < boxAspect)) {
            // Un único punto de montaje: ningún cambio de herramienta recrea la superficie.
            GlPreview(vm, Modifier.fillMaxSize())
            if (vm.editingEffect == "elements" && vm.selectedElement >= 0 && !vm.fullscreen)
                ElementOverlay(vm, Modifier.fillMaxSize())
            else GuidesOverlay(vm, Modifier.fillMaxSize())
            vm.glError?.let { error ->
                Box(Modifier.fillMaxSize().background(Night).padding(12.dp)) {
                    SelectionContainer { Text(error, color = StudioText, fontSize = 12.sp) }
                }
            }
        }
        Row(Modifier.align(Alignment.BottomEnd).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            if (vm.fullscreen) Icon(if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                "Reproducir o pausar", tint = StudioText, modifier = Modifier.size(44.dp)
                    .clip(RoundedCornerShape(10.dp)).background(Night.copy(alpha = .8f))
                    .clickable { vm.togglePlay() }.padding(10.dp))
            Icon(if (vm.fullscreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                "Pantalla completa", tint = StudioText, modifier = Modifier.size(44.dp)
                    .clip(RoundedCornerShape(10.dp)).background(Night.copy(alpha = .8f))
                    .clickable { vm.fullscreen = !vm.fullscreen }.padding(10.dp))
        }
        if (vm.viewScale > 1.01f) Icon(Icons.Filled.CenterFocusWeak, "Restablecer zoom", tint = StudioText,
            modifier = Modifier.align(Alignment.BottomStart).padding(6.dp).size(44.dp)
                .clip(RoundedCornerShape(10.dp)).background(Night.copy(alpha = .8f))
                .clickable { vm.resetView() }.padding(10.dp))
    }
}

@Composable
private fun TransportBar(vm: AppViewModel, onDuration: () -> Unit) {
    // El reloj solo recompone esta barra; no invalida lienzo ni catálogo de efectos.
    var position by remember { mutableFloatStateOf(vm.scrubT) }
    LaunchedEffect(vm.playing, vm.scrubT) {
        if (!vm.playing) position = vm.scrubT
        else while (true) { position = vm.hub.currentT(); kotlinx.coroutines.delay(100) }
    }
    Row(Modifier.fillMaxSize().background(Night).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
            "Reproducir o pausar", tint = StudioText, modifier = Modifier.size(44.dp)
                .clickable { vm.togglePlay() }.padding(10.dp))
        Slider(value = position.coerceIn(0f, .999f), onValueChange = {
            if (vm.playing) vm.togglePlay()
            vm.scrubTo(it); position = it
        }, valueRange = 0f.. .999f, modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(thumbColor = StudioPurple, activeTrackColor = StudioPurple,
                inactiveTrackColor = StudioTile))
        Text("${vm.exportSettings.loopSec}s", color = StudioText, fontSize = 12.sp,
            modifier = Modifier.clickable(onClick = onDuration).padding(horizontal = 8.dp, vertical = 12.dp))
        Icon(Icons.Filled.Undo, "Deshacer", tint = if (vm.canUndo) StudioText else StudioMuted,
            modifier = Modifier.size(40.dp).clickable(enabled = vm.canUndo) { vm.undo() }.padding(9.dp))
        Icon(Icons.Filled.Redo, "Rehacer", tint = if (vm.canRedo) StudioText else StudioMuted,
            modifier = Modifier.size(40.dp).clickable(enabled = vm.canRedo) { vm.redo() }.padding(9.dp))
    }
}

private val mainTabs = listOf(
    Triple(EditorTab.TOOLS, "Animar", Icons.Filled.Timeline),
    Triple(EditorTab.MASKS, "Proteger", Icons.Filled.Shield),
    Triple(EditorTab.EFFECTS, "Efectos", Icons.Filled.AutoAwesome),
    Triple(EditorTab.CANVAS, "Ajustes", Icons.Filled.Tune)
)

@Composable
private fun EditorTabBar(vm: AppViewModel, modifier: Modifier, onSelect: (EditorTab) -> Unit) {
    Row(modifier.fillMaxWidth().background(Night).padding(horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically) {
        mainTabs.forEach { (tab, label, icon) ->
            Column(Modifier.weight(1f).fillMaxHeight().clickable { onSelect(tab) }.padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(icon, null, tint = if (vm.tab == tab) StudioPurple else StudioText, modifier = Modifier.size(22.dp))
                Spacer(Modifier.height(3.dp))
                Text(label, color = if (vm.tab == tab) StudioPurple else StudioText, fontSize = 11.sp,
                    maxLines = 1, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun StudioEditorTopBar(vm: AppViewModel, name: String, modifier: Modifier, onExport: () -> Unit) {
    Row(modifier.background(Night).padding(horizontal = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.ArrowBack, "Volver", tint = StudioText, modifier = Modifier.size(44.dp)
            .clickable { vm.closeEditor() }.padding(10.dp))
        Text(name, color = StudioText, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(end = 8.dp))
        Text("Exportar", color = StudioText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.clip(RoundedCornerShape(9.dp)).background(StudioPurple)
                .clickable(onClick = onExport).padding(horizontal = 13.dp, vertical = 11.dp))
    }
}

@Composable
private fun GlPreview(vm: AppViewModel, modifier: Modifier) {
    val context = LocalContext.current
    val view = remember {
        GLSurfaceView(context).apply {
            setEGLContextClientVersion(3)
            preserveEGLContextOnPause = true
            setRenderer(PreviewRenderer(vm.hub, vm.vertSrc, vm.fragSrc))
            renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        }
    }
    if (android.os.Build.VERSION.SDK_INT >= 28) {
        val magnifier = remember(view) { android.widget.Magnifier(view) }
        val cursor = vm.brushCursor
        LaunchedEffect(cursor, vm.paintingZone) {
            if (cursor != null && vm.paintingZone) magnifier.show(cursor.x.coerceIn(0f,1f) * view.width, cursor.y.coerceIn(0f,1f) * view.height)
            else magnifier.dismiss()
        }
        DisposableEffect(magnifier) { onDispose { magnifier.dismiss() } }
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, view) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) { view.onResume(); view.requestRender() }
            if (event == Lifecycle.Event.ON_PAUSE) view.onPause()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); view.onPause() }
    }
    // Solo solicita cuadros cuando hay animación o interacción, a un máximo de 30 fps.
    // El shader no se recompila al tocar las herramientas.
    LaunchedEffect(view) {
        var lastRevision = -1L
        var lastMaskVersion = 0
        while (true) {
            val maskVersion = vm.hub.masks?.let { synchronized(it.lock) { it.versions.hashCode() } } ?: 0
            if (owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) && vm.hub.renderEnabled &&
                (vm.playing || lastRevision != vm.hub.revision || maskVersion != lastMaskVersion)) {
                lastRevision = vm.hub.revision
                lastMaskVersion = maskVersion
                view.requestRender()
            }
            kotlinx.coroutines.delay(33)
        }
    }
    SideEffect { view.requestRender() }
    AndroidView(factory = { view }, modifier = modifier)
}

@Composable
private fun GuidesOverlay(vm: AppViewModel, modifier: Modifier) {
    var dragArrow by remember { mutableStateOf<Arrow?>(null) }
    var cursor by remember { mutableStateOf<Offset?>(null) }

    Canvas(
        modifier.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val w = size.width.toFloat().coerceAtLeast(1f)
                val h = size.height.toFloat().coerceAtLeast(1f)
                val tool = if (vm.playing || vm.fullscreen || !vm.showGuides || vm.exportState is ExportState.Running) Tool.PAN else vm.tool
                var transforming = tool == Tool.PAN
                var drawing = false
                var arrowStart: PointN? = null
                var moved = false
                var lastPos = down.position

                fun uvOf(o: Offset): PointN = vm.screenToUv(o.x / w, o.y / h)

                when {
                    tool == Tool.ARROW -> arrowStart = uvOf(down.position)
                    tool == Tool.ORIGIN -> vm.moveEffectOrigin(uvOf(down.position))
                    tool.isBrush -> {
                        val radiusUv = vm.brushDp.dp.toPx() * vm.cropH / (h * vm.viewScale)
                        vm.beginStroke(uvOf(down.position), radiusUv)
                        drawing = true
                        cursor = down.position
                        vm.brushCursor = PointN(down.position.x/w, down.position.y/h)
                    }
                    else -> Unit
                }
                down.consume()

                while (true) {
                    val event = awaitPointerEvent()
                    val pressed = event.changes.count { it.pressed }
                    if (pressed == 0) break
                    if (pressed >= 2 && !transforming) {
                        transforming = true
                        if (drawing) {
                            vm.cancelStroke()
                            drawing = false
                        }
                        cursor = null
                vm.brushCursor = null
                        arrowStart = null
                        dragArrow = null
                    }
                    if (transforming) {
                        val zoom = event.calculateZoom()
                        val pan = event.calculatePan()
                        val c = event.calculateCentroid(useCurrent = true)
                        if (c.isSpecified) vm.transformView(zoom, pan.x / w, pan.y / h, c.x / w, c.y / h)
                    } else {
                        val ch = event.changes.firstOrNull { it.id == down.id } ?: event.changes.first()
                        val pos = ch.position
                        if ((pos - down.position).getDistance() > 8f) moved = true
                        lastPos = pos
                        val start = arrowStart
                        if (tool == Tool.ORIGIN) {
                            vm.moveEffectOrigin(uvOf(pos))
                        } else if (tool == Tool.ARROW && start != null) {
                            val e = uvOf(pos)
                            dragArrow = Arrow(start.x, start.y, e.x, e.y)
                        } else if (drawing) {
                            vm.continueStroke(uvOf(pos))
                            cursor = pos
                            vm.brushCursor = PointN(pos.x/w, pos.y/h)
                        }
                    }
                    event.changes.forEach { it.consume() }
                }

                if (!transforming) {
                    when (tool) {
                        Tool.ARROW -> {
                            val a = dragArrow
                            if (a != null && hypot(a.x1 - a.x0, a.y1 - a.y0) > 0.008f) vm.addArrow(a)
                        }
                        Tool.ANCHOR -> if (!moved) vm.addAnchor(uvOf(lastPos))
                        Tool.ERASE_GUIDE -> if (!moved) {
                            eraseNearest(vm, lastPos, w, h, 28.dp.toPx())
                        }
                        Tool.FREEZE, Tool.ZONE1, Tool.ZONE2, Tool.MASK -> vm.endStroke()
                        Tool.PAN, Tool.ORIGIN -> Unit
                    }
                } else if (drawing) {
                    vm.endStroke()
                }
                dragArrow = null
                cursor = null
                vm.brushCursor = null
            }
        }
    ) {
        val w = size.width
        val h = size.height
        val s = vm.viewScale
        val vx = vm.viewX
        val vy = vm.viewY
        fun sp(x: Float, y: Float) = Offset((x - vx) * s * w / vm.cropW, (y - vy) * s * h / vm.cropH)

        if (vm.showGuides && !vm.playing && !vm.fullscreen && !vm.paintingZone) {
            vm.activeMotionEffect?.let { id ->
                val origin = (vm.settings["$id.origin"] ?: 0f).toInt()
                if (origin == 0) {
                    val pt = sp(vm.settings["$id.originX"] ?: 0.5f, vm.settings["$id.originY"] ?: 0.5f)
                    drawCircle(Peach.copy(alpha = 0.35f), 13.dp.toPx(), pt)
                    drawCircle(Peach, 8.dp.toPx(), pt, style = Stroke(2.dp.toPx()))
                    drawLine(Peach, pt + Offset(-16.dp.toPx(), 0f), pt + Offset(16.dp.toPx(), 0f), strokeWidth = 1.dp.toPx())
                    drawLine(Peach, pt + Offset(0f, -16.dp.toPx()), pt + Offset(0f, 16.dp.toPx()), strokeWidth = 1.dp.toPx())
                }
            }
            for (a in vm.arrows) drawArrowShape(sp(a.x0, a.y0), sp(a.x1, a.y1), Color.White)
            for (p in vm.anchors) drawAnchor(sp(p.x, p.y))
        }
        dragArrow?.let { drawArrowShape(sp(it.x0, it.y0), sp(it.x1, it.y1), Peach) }
        cursor?.let {
            val r = vm.brushDp.dp.toPx()
            drawCircle(Color.Black.copy(alpha = 0.5f), r, it, style = Stroke(3.dp.toPx()))
            drawCircle(Color.White, r, it, style = Stroke(1.5.dp.toPx()))
        }
    }
}

private fun eraseNearest(vm: AppViewModel, pos: Offset, w: Float, h: Float, maxPx: Float) {
    val s = vm.viewScale
    fun sp(x: Float, y: Float) = Offset((x - vm.viewX) * s * w / vm.cropW, (y - vm.viewY) * s * h / vm.cropH)
    var best = maxPx
    var bestArrow = -1
    var bestAnchor = -1
    if (vm.tab == EditorTab.MASKS) vm.anchors.forEachIndexed { i, p ->
        val d = (sp(p.x, p.y) - pos).getDistance()
        if (d < best) {
            best = d
            bestAnchor = i
            bestArrow = -1
        }
    }
    if (vm.tab != EditorTab.MASKS) vm.arrows.forEachIndexed { i, a ->
        val d = segDist(pos, sp(a.x0, a.y0), sp(a.x1, a.y1))
        if (d < best) {
            best = d
            bestArrow = i
            bestAnchor = -1
        }
    }
    if (bestArrow >= 0) vm.removeArrowAt(bestArrow)
    else if (bestAnchor >= 0) vm.removeAnchorAt(bestAnchor)
}

private fun segDist(p: Offset, a: Offset, b: Offset): Float {
    val d = b - a
    val l2 = d.x * d.x + d.y * d.y
    var t = if (l2 > 0.0001f) ((p.x - a.x) * d.x + (p.y - a.y) * d.y) / l2 else 0f
    t = t.coerceIn(0f, 1f)
    return (a + d * t - p).getDistance()
}

private fun DrawScope.drawArrowShape(a: Offset, b: Offset, color: Color) {
    val sw = 3.dp.toPx()
    val shadow = Color.Black.copy(alpha = 0.55f)
    drawLine(shadow, a, b, strokeWidth = sw + 3.dp.toPx(), cap = StrokeCap.Round)
    drawLine(color, a, b, strokeWidth = sw, cap = StrokeCap.Round)
    val d = b - a
    val len = d.getDistance()
    if (len > 1f) {
        val ux = -d.x / len
        val uy = -d.y / len
        val hl = 14.dp.toPx()
        val c = 0.866f
        val s = 0.5f
        val l1 = Offset(ux * c - uy * s, ux * s + uy * c) * hl
        val l2 = Offset(ux * c + uy * s, -ux * s + uy * c) * hl
        drawLine(color, b, b + l1, strokeWidth = sw, cap = StrokeCap.Round)
        drawLine(color, b, b + l2, strokeWidth = sw, cap = StrokeCap.Round)
    }
    drawCircle(shadow, 5.5.dp.toPx(), a)
    drawCircle(color, 4.dp.toPx(), a)
}

private fun DrawScope.drawAnchor(p: Offset) {
    drawCircle(Color.Black.copy(alpha = 0.55f), 9.dp.toPx(), p)
    drawCircle(Sky, 7.dp.toPx(), p)
    drawCircle(Color.White, 2.5.dp.toPx(), p)
}

private fun DrawScope.drawCropShade(tl: Offset, br: Offset, full: Size) {
    val shade = Color.Black.copy(alpha = 0.55f)
    // arriba, abajo, izquierda, derecha
    drawRect(shade, Offset(0f, 0f), Size(full.width, tl.y.coerceAtLeast(0f)))
    drawRect(shade, Offset(0f, br.y), Size(full.width, (full.height - br.y).coerceAtLeast(0f)))
    drawRect(shade, Offset(0f, tl.y), Size(tl.x.coerceAtLeast(0f), (br.y - tl.y).coerceAtLeast(0f)))
    drawRect(shade, Offset(br.x, tl.y), Size((full.width - br.x).coerceAtLeast(0f), (br.y - tl.y).coerceAtLeast(0f)))
    drawRect(Peach, tl, Size(br.x - tl.x, br.y - tl.y), style = Stroke(2.dp.toPx()))
}

@Composable
private fun ElementOverlay(vm: AppViewModel, modifier: Modifier) {
    Canvas(modifier.pointerInput(vm.selectedElement) {
        detectTransformGestures { _, pan, zoom, rotation ->
            vm.transformElement(pan.x / size.width * vm.cropW / vm.viewScale,
                pan.y / size.height * vm.cropH / vm.viewScale, zoom, rotation)
        }
    }) {
        val id = "element${vm.selectedElement}"
        val x = ((vm.settings["$id.x"] ?: .5f) - vm.viewX) * size.width * vm.viewScale / vm.cropW
        val y = ((vm.settings["$id.y"] ?: .5f) - vm.viewY) * size.height * vm.viewScale / vm.cropH
        val h = (vm.settings["$id.size"] ?: .3f) * size.height * vm.viewScale / vm.cropH
        drawCircle(StudioPurple, 5.dp.toPx(), Offset(x,y))
        rotate(vm.settings["$id.rotation"] ?: 0f, Offset(x,y)) {
            drawRect(StudioPurple, Offset(x-h/2,y-h/2), Size(h,h), style=Stroke(1.dp.toPx()))
        }
    }
}
