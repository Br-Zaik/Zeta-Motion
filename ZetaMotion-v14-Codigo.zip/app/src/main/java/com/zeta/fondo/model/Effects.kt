package com.zeta.fondo.model

enum class Kind { FLOAT, INT, TOGGLE }

data class ParamDef(
    val key: String,
    val label: String,
    val min: Float,
    val max: Float,
    val def: Float,
    val kind: Kind = Kind.FLOAT
)

data class EffectDef(
    val id: String,
    val emoji: String,
    val title: String,
    val hint: String,
    val params: List<ParamDef>,
    val toggleable: Boolean = true,
    val defaultOn: Boolean = false
)

object Effects {

    private fun p(key: String, label: String, min: Float, max: Float, def: Float, kind: Kind = Kind.FLOAT) =
        ParamDef(key, label, min, max, def, kind)

    private fun zone(def: Float = 0f) = p("zone", "Solo dentro de la Zona 1 (azul)", 0f, 1f, def, Kind.TOGGLE)

    val all: List<EffectDef> = listOf(
        EffectDef("zonemotion", "", "Movimiento por zona", "Pinta lo que se mueve", listOf(
            p("int", "Fuerza", 0f, .035f, .008f),p("cycles", "Velocidad", 1f, 8f, 1f, Kind.INT),
            p("variant", "Tipo", 0f, 2f, 0f, Kind.INT),p("direction", "Dirección", 0f, 360f, 0f, Kind.INT))),
        EffectDef("sky", "", "Cielo", "Pinta el cielo", listOf(
            p("int", "Intensidad", 0f, 1f, .7f), p("cycles", "Velocidad", 1f, 5f, 1f, Kind.INT),
            p("variant", "Estilo", 0f, 3f, 0f, Kind.INT))),
        EffectDef("water", "", "Agua", "Pinta el agua", listOf(
            p("int", "Intensidad", 0f, 1f, .4f), p("cycles", "Velocidad", 1f, 6f, 1f, Kind.INT),
            p("variant", "Estilo", 0f, 2f, 0f, Kind.INT), p("direction", "Dirección", 0f, 360f, 0f, Kind.INT))),
        EffectDef("dispersion", "", "Dispersión", "Pinta la zona que se fragmenta", listOf(
            p("int", "Intensidad", 0f, 1f, .7f), p("cycles", "Velocidad", 1f, 5f, 1f, Kind.INT),
            p("size", "Tamaño", 12f, 60f, 28f, Kind.INT), p("direction", "Dirección", 0f, 360f, 0f, Kind.INT),
            p("distance", "Distancia", 0f, 1f, .7f), p("variant", "Forma", 0f, 2f, 0f, Kind.INT))),
        EffectDef(
            "flow", "➡️", "Flechas de movimiento",
            "Mueve lo que marques con la herramienta Flechas. La velocidad también cambia la deriva de nubes.",
            listOf(
                p("amount", "Distancia del movimiento", 0.05f, 1f, 0.35f),
                p("cycles", "Velocidad (ciclos por loop)", 1f, 8f, 2f, Kind.INT),
                p("reach", "Alcance de cada flecha", 0.05f, 1f, 0.25f)
            ),
            defaultOn = true
        ),
        EffectDef(
            "drift", "☁️", "Deriva de nubes (Zona 1)",
            "Desplaza todo lo pintado en Zona 1 en una dirección. Ideal para cielos y nubes. 0° = derecha, 90° = arriba.",
            listOf(
                p("dir", "Dirección (grados)", 0f, 360f, 0f, Kind.INT),
                p("speed", "Distancia", 0.005f, 0.3f, 0.05f)
            )
        ),
        EffectDef(
            "ripple", "🌊", "Ondas de agua (Zona 1)",
            "Ondulación suave del agua pintada en Zona 1.",
            listOf(
                p("amp", "Fuerza", 0.0005f, 0.012f, 0.003f),
                p("freq", "Tamaño de ondas (más = pequeñas)", 5f, 120f, 40f),
                p("cycles", "Velocidad", 1f, 8f, 2f, Kind.INT)
            )
        ),
        EffectDef(
            "glint", "✨", "Brillos en el agua (Zona 1)",
            "Destellos que aparecen y desaparecen sobre el agua.",
            listOf(
                p("int", "Intensidad", 0f, 2f, 0.8f),
                p("dens", "Densidad", 10f, 200f, 70f),
                p("cycles", "Velocidad", 1f, 8f, 3f, Kind.INT)
            )
        ),
        EffectDef(
            "sway", "🌳", "Viento en árboles (Zona 2)",
            "Balanceo de follaje y hierba pintados en Zona 2. Congela troncos y personajes.",
            listOf(
                p("amp", "Fuerza", 0.0005f, 0.015f, 0.004f),
                p("freq", "Tamaño de ramas (más = pequeñas)", 1f, 30f, 6f),
                p("cycles", "Velocidad", 1f, 6f, 2f, Kind.INT)
            )
        ),
        EffectDef(
            "heat", "♨️", "Calor (Zona 2)",
            "Distorsión de aire caliente; para ver llamas usa Llamas dibujadas.",
            listOf(
                p("amp", "Intensidad", 0.0005f, 0.01f, 0.002f),
                p("freq", "Detalle", 5f, 80f, 30f),
                p("cycles", "Velocidad", 1f, 8f, 3f, Kind.INT)
            )
        ),
        EffectDef(
            "rain", "🌧️", "Lluvia",
            "Tres capas de gotas a distinta velocidad para dar profundidad.",
            listOf(
                p("int", "Intensidad", 0f, 1f, 0.7f),
                p("angle", "Inclinación", -40f, 40f, 10f, Kind.INT),
                p("cycles", "Velocidad", 1f, 16f, 6f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "snow", "❄️", "Nieve",
            "Copos que caen balanceándose.",
            listOf(
                p("int", "Intensidad", 0f, 1f, 0.9f),
                p("size", "Tamaño de copos", 0.3f, 3f, 1f),
                p("cycles", "Velocidad", 1f, 8f, 2f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "sakura", "🌸", "Pétalos de sakura",
            "Pétalos rosados que caen girando.",
            listOf(
                p("int", "Intensidad", 0f, 1f, 0.9f),
                p("size", "Tamaño de pétalos", 0.3f, 3f, 1f),
                p("cycles", "Velocidad", 1f, 6f, 1f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "stars", "⭐", "Estrellas que titilan",
            "Pinta el cielo en Zona 1 para que las estrellas solo salgan ahí.",
            listOf(
                p("int", "Intensidad", 0f, 2f, 1f),
                p("dens", "Cantidad", 10f, 150f, 45f),
                p("cycles", "Velocidad del titileo", 1f, 8f, 3f, Kind.INT),
                zone(1f)
            )
        ),
        EffectDef(
            "flies", "💫", "Luciérnagas",
            "Puntos de luz que flotan y parpadean.",
            listOf(
                p("int", "Intensidad", 0f, 2f, 1f),
                p("dens", "Cantidad (más = más pequeñas)", 2f, 20f, 6f),
                p("cycles", "Velocidad", 1f, 4f, 1f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "fog", "🌫️", "Niebla",
            "Bruma suave que se desplaza.",
            listOf(
                p("int", "Intensidad", 0f, 1f, 0.35f),
                p("scale", "Tamaño (más = más fina)", 0.5f, 10f, 3f),
                p("cycles", "Velocidad", 1f, 4f, 1f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "rays", "☀️", "Rayos de luz",
            "Haces de luz que bajan desde arriba de la imagen.",
            listOf(
                p("int", "Intensidad", 0f, 1.5f, 0.4f),
                p("x", "Origen horizontal", 0f, 1f, 0.3f),
                p("cycles", "Velocidad", 1f, 4f, 1f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "energy", "⚡", "Aura de energía anime",
            "Pulso luminoso radial para poderes, ojos y escenas de combate.",
            listOf(
                p("int", "Intensidad", 0f, 2f, 0.8f),
                p("dens", "Rayos", 4f, 40f, 14f, Kind.INT),
                p("cycles", "Velocidad", 1f, 8f, 2f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "speed", "💨", "Líneas de velocidad manga",
            "Líneas direccionales para carreras, golpes y escenas dinámicas.",
            listOf(
                p("int", "Intensidad", 0f, 1.5f, 0.65f),
                p("angle", "Dirección", -180f, 180f, 0f, Kind.INT),
                p("cycles", "Velocidad", 1f, 10f, 4f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "cam", "🎥", "Cámara lenta (zoom y paneo)",
            "Acercamiento o paneo suave que vuelve al inicio al final del loop.",
            listOf(
                p("zoom", "Zoom", 0f, 0.3f, 0.06f),
                p("pan", "Paneo lateral", 0f, 1f, 0f),
                p("cycles", "Velocidad", 1f, 4f, 1f, Kind.INT)
            )
        ),

        // Nuevas capas procedurales anime/manga: trabajan sin IA ni descargas.
        EffectDef("comet", "☄", "Cometas de luz", "Estelas diagonales que atraviesan la escena.", listOf(
            p("int", "Intensidad", 0f, 1.5f, 0.8f), p("size", "Longitud", 0.3f, 2.5f, 1f),
            p("cycles", "Velocidad", 1f, 10f, 2f, Kind.INT), zone()
        )),
        EffectDef("runes", "✧", "Círculo mágico", "Anillos y glifos geométricos giratorios para magia.", listOf(
            p("int", "Brillo", 0f, 2f, 0.8f), p("size", "Radio", 0.2f, 2f, 1f),
            p("cycles", "Giros", 1f, 6f, 1f, Kind.INT), zone()
        )),
        EffectDef("hatch", "▨", "Rayado manga", "Líneas diagonales de sombreado animado.", listOf(
            p("int", "Intensidad", 0f, 1f, 0.5f), p("size", "Densidad", 30f, 260f, 120f),
            p("cycles", "Desplazamiento", 1f, 8f, 1f, Kind.INT), zone()
        )),
        EffectDef("pulse", "◎", "Anillos de poder", "Varios anillos concéntricos desde un punto.", listOf(
            p("int", "Brillo", 0f, 2f, 0.8f), p("size", "Grosor", 0.005f, 0.06f, 0.02f),
            p("cycles", "Pulsos", 1f, 8f, 2f, Kind.INT), zone()
        )),
        EffectDef("smoke", "♨", "Humo estilizado", "Nubes procedurales móviles para combate o magia.", listOf(
            p("int", "Opacidad", 0f, 1f, 0.4f), p("size", "Escala", 0.5f, 9f, 3f),
            p("cycles", "Velocidad", 1f, 6f, 1f, Kind.INT), zone()
        )),
        EffectDef("shards", "◇", "Fragmentos de cristal", "Fragmentos geométricos que caen y brillan.", listOf(
            p("int", "Intensidad", 0f, 1.5f, 0.8f), p("size", "Tamaño", 0.3f, 2.5f, 1f),
            p("cycles", "Velocidad", 1f, 10f, 2f, Kind.INT), zone()
        )),

        // Efectos procedurales originales: sin stickers ni fotografías reales.
        EffectDef("ash", "◈", "Cenizas flotantes", "Partículas grises de combate o incendio.", listOf(
            p("int", "Cantidad", 0f, 1.5f, 0.7f), p("size", "Tamaño", 0.3f, 2.5f, 1f),
            p("cycles", "Velocidad", 1f, 10f, 2f, Kind.INT), zone()
        )),
        EffectDef("leaves", "🍃", "Hojas al viento", "Hojas de ilustración que cruzan la escena.", listOf(
            p("int", "Cantidad", 0f, 1.5f, 0.85f), p("size", "Tamaño", 0.3f, 2.5f, 1f),
            p("cycles", "Velocidad", 1f, 10f, 2f, Kind.INT), zone()
        )),
        EffectDef("embers", "✴", "Brasas / chispas", "Partículas incandescentes que ascienden.", listOf(
            p("int", "Cantidad", 0f, 1.5f, 0.8f), p("size", "Tamaño", 0.3f, 2.5f, 1f),
            p("cycles", "Velocidad", 1f, 10f, 3f, Kind.INT), zone()
        )),
        EffectDef("dust", "·", "Polvo / motas", "Polvo iluminado para planos anime tranquilos.", listOf(
            p("int", "Cantidad", 0f, 1.5f, 0.5f), p("size", "Tamaño", 0.3f, 2.5f, 1f),
            p("cycles", "Velocidad", 1f, 10f, 1f, Kind.INT), zone()
        )),
        EffectDef("bubbles", "◌", "Burbujas", "Burbujas bajo agua y escenarios mágicos.", listOf(
            p("int", "Cantidad", 0f, 1.5f, 0.7f), p("size", "Tamaño", 0.3f, 2.5f, 1f),
            p("cycles", "Velocidad", 1f, 10f, 2f, Kind.INT), zone()
        )),
        EffectDef("electric", "ϟ", "Electricidad anime", "Rayos dibujados alrededor del punto elegido.", listOf(
            p("int", "Intensidad", 0f, 2f, 0.8f),
            p("dens", "Ramificaciones", 5f, 35f, 16f),
            p("cycles", "Velocidad", 1f, 12f, 4f, Kind.INT), zone()
        )),
        EffectDef("focus", "◎", "Líneas de enfoque", "Líneas manga convergentes al punto de fuga.", listOf(
            p("int", "Intensidad", 0f, 1.5f, 0.7f),
            p("dens", "Cantidad", 15f, 90f, 46f),
            p("cycles", "Velocidad", 1f, 10f, 3f, Kind.INT), zone()
        )),
        EffectDef("shock", "◉", "Onda de choque", "Anillo expansivo de impacto en loop.", listOf(
            p("int", "Intensidad", 0f, 2f, 0.75f),
            p("width", "Grosor", 0.005f, 0.10f, 0.024f),
            p("cycles", "Velocidad", 1f, 6f, 1f, Kind.INT), zone()
        )),
        EffectDef("flash", "✷", "Destello de impacto", "Flash rítmico de pelea o transición manga.", listOf(
            p("int", "Intensidad", 0f, 1f, 0.7f),
            p("width", "Duración del flash", 0.01f, 0.5f, 0.12f),
            p("cycles", "Repeticiones", 1f, 8f, 2f, Kind.INT), zone()
        )),
        EffectDef("tone", "▦", "Screentone animado", "Trama de semitonos para manga en blanco y negro.", listOf(
            p("int", "Intensidad", 0f, 1f, 0.65f),
            p("dens", "Densidad", 60f, 320f, 150f),
            p("cycles", "Pulsación", 1f, 8f, 1f, Kind.INT), zone()
        )),
        EffectDef("grain", "▥", "Papel manga", "Textura original de impresión, sin fotografía.", listOf(
            p("int", "Intensidad", 0f, 0.6f, 0.15f),
            p("dens", "Tamaño de grano", 100f, 700f, 360f),
            p("cycles", "Movimiento", 1f, 10f, 1f, Kind.INT), zone()
        )),
        EffectDef("ink", "◩", "Tinta / alto contraste", "Sombras duras estilo viñeta manga.", listOf(
            p("int", "Intensidad", 0f, 1f, 0.8f),
            p("threshold", "Umbral", 0.1f, 0.9f, 0.48f),
            p("cycles", "Pulsación", 1f, 8f, 1f, Kind.INT), zone()
        )),
        // Efectos nuevos: todos trabajan con las máscaras existentes, sin imágenes externas.
        EffectDef("flame", "🔥", "Llamas dibujadas (Zona 2)",
            "Pinta en verde las zonas donde deben aparecer llamas ilustradas.", listOf(
                p("int", "Intensidad", 0f, 1.5f, 0.7f),
                p("size", "Altura", 0.3f, 2.5f, 1f),
                p("cycles", "Velocidad", 1f, 8f, 2f, Kind.INT)
            )),
        EffectDef("eyes", "👁️", "Brillo de ojos (Zona 1)",
            "Pinta en azul solo los ojos o el objeto que debe brillar.", listOf(
                p("int", "Intensidad", 0f, 2f, 0.9f),
                p("size", "Pulso", 0.2f, 1.5f, 0.7f),
                p("cycles", "Velocidad", 1f, 8f, 2f, Kind.INT)
            )),
        EffectDef("blink", "◉", "Parpadeo de sombra (Zona 1)",
            "Pinta en azul los ojos. El efecto oscurece la zona en un cierre rítmico; no reconstruye párpados.", listOf(
                p("int", "Cierre", 0f, 1f, 0.85f),
                p("size", "Duración", 0.05f, 0.4f, 0.14f),
                p("cycles", "Parpadeos", 1f, 6f, 1f, Kind.INT)
            )),
        EffectDef("cloth", "〰", "Pelo y ropa (Zona 2)",
            "Pinta en verde mechones o tela; congela rostro y cuerpo.", listOf(
                p("int", "Movimiento", 0f, 0.02f, 0.005f),
                p("size", "Ondulación", 2f, 30f, 9f),
                p("cycles", "Velocidad", 1f, 6f, 2f, Kind.INT)
            )),
        EffectDef(
            "style", "🖋️", "Estilo manga",
            "Para páginas en blanco y negro con tramas.",
            listOf(
                p("mono", "Efectos en blanco y negro", 0f, 1f, 0f, Kind.TOGGLE),
                p("snap", "Píxel exacto (protege las tramas)", 0f, 1f, 0f, Kind.TOGGLE)
            ),
            toggleable = false
        )
    )

    private val defaultsMap: Map<String, Float> by lazy {
        val m = LinkedHashMap<String, Float>()
        for (e in all) {
            if (e.toggleable) m["${e.id}.on"] = if (e.defaultOn) 1f else 0f
            for (p in e.params) m["${e.id}.${p.key}"] = p.def
        }
        m
    }

    fun defaults(): Map<String, Float> = defaultsMap

    fun default(key: String): Float = defaultsMap[key] ?: 0f

    /** Apaga todos los efectos menos las flechas. */
    fun allOff(current: Map<String, Float>): Map<String, Float> {
        val m = HashMap(current)
        for (e in all) {
            if (e.toggleable && e.id != "flow") m["${e.id}.on"] = 0f
            m["${e.id}.copy.on"] = 0f
        }
        m["style.mono"] = 0f
        m["style.snap"] = 0f
        return m
    }
}
