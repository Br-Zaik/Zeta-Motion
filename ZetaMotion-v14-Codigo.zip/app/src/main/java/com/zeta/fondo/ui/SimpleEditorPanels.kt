package com.zeta.fondo.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.model.*

@Composable
fun SimpleBrushPanel(vm: AppViewModel) {
    Column(Modifier.fillMaxSize().padding(horizontal=8.dp)) {
        Row(Modifier.fillMaxWidth().height(40.dp),verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick={vm.finishEdit(false)}) { Icon(Icons.Default.Close,"Cancelar",tint=StudioText) }
            Text(if(vm.editingEffect==null) "Proteger" else if(vm.editingEffect=="zonemotion") "Pintar movimiento" else "Pintar ${Effects.all.firstOrNull { it.id == vm.editingEffect }?.title ?: "zona"}",color=StudioText,modifier=Modifier.weight(1f))
            TextButton(onClick={if(vm.editingEffect==null) vm.finishEdit(true) else vm.finishPainting()}) { Text("Listo") }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            StudioSmallButton("Pincel",Icons.Default.Brush,Modifier.weight(1f),selected=!vm.eraser){vm.eraser=false}
            StudioSmallButton("Borrador",Icons.Default.AutoFixNormal,Modifier.weight(1f),selected=vm.eraser){vm.eraser=true}
        }
        LabeledSlider("Tamaño",vm.brushDp,6f,140f,true){vm.brushDp=it}
    }
}
@Composable
fun SimpleProtectPanel(vm: AppViewModel) {
    Column(Modifier.fillMaxSize().padding(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            StudioButton("Pintar área",Icons.Default.Shield,Modifier.width(92.dp).height(66.dp)){vm.protect()}
            StudioButton("Fijar punto",Icons.Default.PushPin,Modifier.width(92.dp).height(66.dp),active=vm.tool==Tool.ANCHOR){vm.protectPoints()}
            StudioButton("Borrar punto",Icons.Default.DeleteOutline,Modifier.width(92.dp).height(66.dp),active=vm.tool==Tool.ERASE_GUIDE){vm.protectPoints(true)}
        }
        Text(if(vm.tool==Tool.ANCHOR) "Toca para fijar un punto." else if(vm.tool==Tool.ERASE_GUIDE) "Toca el punto que quieres borrar." else "Pinta un área quieta o fija puntos de apoyo.",color=StudioMuted,fontSize=13.sp)
    }
}
@Composable
fun SimpleSettingsPanel(vm: AppViewModel) {
    val section = vm.settingsSection
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(38.dp),horizontalArrangement=Arrangement.Center) {
            listOf("Color", "Formato", "Audio").forEachIndexed { i,label ->
                TextButton(onClick={vm.settingsSection=i}) { Text(label,color=if(section==i) StudioPurple else StudioMuted) }
            }
        }
        Box(Modifier.weight(1f)) { when(section) { 0->ColorPanel(vm);1->CanvasPanel(vm);else->AudioPanel(vm) } }
    }
}

private val elementNames=listOf("Nube","Humo","Pétalos","Brillos","Energía","Niebla")
private val elementIcons=listOf(Icons.Default.Cloud,Icons.Default.BlurOn,Icons.Default.LocalFlorist,
    Icons.Default.AutoAwesome,Icons.Default.Bolt,Icons.Default.CloudQueue)

@Composable
fun SimpleEffectsPanel(vm: AppViewModel) {
    val id=vm.editingEffect
    if(id==null) {
        val effects=remember { Effects.all.filter{it.id !in setOf("flow","zonemotion")}.sortedBy {
            when(it.id){"sky"->0;"water"->1;"cam"->2;"dispersion"->3;else->5}
        } }
        Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(40.dp).padding(horizontal=10.dp),verticalAlignment=Alignment.CenterVertically) {
            Text("Efectos",color=StudioText,modifier=Modifier.weight(1f))
            TextButton(onClick={vm.removeAllEffects()},enabled=vm.activeEffectsCount>0) { Text("Quitar todos (${vm.activeEffectsCount})") }
        }
        LazyVerticalGrid(GridCells.Fixed(3),Modifier.weight(1f),contentPadding=PaddingValues(6.dp),
            horizontalArrangement=Arrangement.spacedBy(5.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
            item { StudioButton("Elementos",Icons.Default.Layers,Modifier.height(66.dp)){vm.editEffect("elements")} }
            items(effects,key={it.id}) { def ->
                StudioButton(effectShortTitle(def),effectIcon(def.id),Modifier.height(66.dp),
                    active=(vm.settings["${def.id}.on"]?:0f)>.5f){vm.editEffect(def.id)}
            }
        }
        }
    } else Column(Modifier.fillMaxSize()) {
        val def=Effects.all.firstOrNull{it.id==id}
        Row(Modifier.fillMaxWidth().height(40.dp),verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick={vm.finishEdit(false)}){Icon(Icons.Default.Close,"Cancelar",tint=StudioText)}
            Text(if(id=="elements") "Elementos" else def?.let(::effectShortTitle)?:id,color=StudioText,modifier=Modifier.weight(1f),maxLines=1,fontSize=14.sp)
            TextButton(onClick={vm.finishEdit(true)}){Text("Listo")}
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal=10.dp),
            verticalArrangement=Arrangement.spacedBy(5.dp)) {
            if(id=="elements") ElementsControls(vm)
            else if(def!=null) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    val slot=(vm.settings["$id.mask"]?:-2f).toInt()
                    StudioChoice("Toda la imagen",slot==-2){vm.wholeEffectZone()}
                    StudioChoice("Pintar zona",slot>=0){vm.paintEffectZone()}
                    val active=(vm.settings["$id.on"]?:0f)>.5f
                    StudioChoice(if(active) "Quitar" else "Activar",false){vm.setSetting("$id.on",if(active)0f else 1f)}
                }
                val variants=when(id){
                    "zonemotion"->listOf("Balanceo","Ondulación","Respiración")
                    "sky"->listOf("Día","Atardecer","Noche","Tormenta")
                    "water"->listOf("Ondas","Corriente","Reflejos")
                    "cam"->listOf("Acercar","Alejar","Desplazar","Girar","Temblar")
                    "dispersion"->listOf("Fragmentos","Pétalos","Polvo")
                    else->emptyList()
                }
                if(variants.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    variants.forEachIndexed{i,name->
                        val key=if(id=="cam") "cam.mode" else "$id.variant"
                        StudioChoice(name,(vm.settings[key]?:0f).toInt()==i){vm.setSetting(key,i.toFloat())}
                    }
                }
                val params=def.params.filter{it.key!in listOf("zone","variant","mode") && !(id=="zonemotion" && (vm.settings["zonemotion.variant"]?:0f)>1.5f && it.key=="direction")}
                params.chunked(2).forEach{ pair ->
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        pair.forEach{p->Box(Modifier.weight(1f)){EffectParameter(vm,def,p)}}
                        if(pair.size==1) Spacer(Modifier.weight(1f))
                    }
                }
                if(id in setOf("rain","snow","sakura","fog","rays","energy","speed","leaves","embers","dust","bubbles","comet","smoke")) {
                    LabeledSlider("Dirección",vm.settings["$id.direction"]?:90f,0f,360f,true,suffix="°"){vm.setSetting("$id.direction",it)}
                }
            }
        }
    }
}
@Composable
private fun ElementsControls(vm: AppViewModel) {
    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
        elementNames.forEachIndexed{i,name->StudioButton(name,elementIcons[i],Modifier.width(75.dp).height(62.dp)){vm.addElement(i)}}
    }
    val slots=(0..3).filter{(vm.settings["element$it.on"]?:0f)>.5f}
    if(slots.isEmpty()) Text("Elige un elemento y colócalo sobre tu imagen.",color=StudioMuted,fontSize=12.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
        slots.forEach { i -> StudioChoice("${i+1} · ${elementNames[(vm.settings["element$i.type"]?:0f).toInt().coerceIn(0,5)]}",vm.selectedElement==i){vm.selectElement(i)} }
    }
    val slot=vm.selectedElement
    if(slot<0 || slot !in slots) return
    val id="element$slot"
    Row(verticalAlignment=Alignment.CenterVertically) {
        Text("Arrastra · pellizca · gira con dos dedos",color=StudioMuted,fontSize=11.sp,modifier=Modifier.weight(1f))
        IconButton(onClick={vm.setSetting("$id.on",0f);vm.selectElement(-1)}){Icon(Icons.Default.DeleteOutline,"Quitar",tint=StudioText)}
    }
    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
        Box(Modifier.weight(1f)){LabeledSlider("Opacidad",vm.settings["$id.opacity"]?:.7f,0f,1f,false){vm.setSetting("$id.opacity",it)}}
        Box(Modifier.weight(1f)){LabeledSlider("Velocidad",vm.settings["$id.cycles"]?:1f,1f,6f,true){vm.setSetting("$id.cycles",it)}}
    }
    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
        Box(Modifier.weight(1f)){LabeledSlider("Tamaño",vm.settings["$id.size"]?:.3f,.04f,1.5f,false){vm.setSetting("$id.size",it)}}
        Box(Modifier.weight(1f)){LabeledSlider("Giro",vm.settings["$id.rotation"]?:0f,-180f,180f,true){vm.setSetting("$id.rotation",it)}}
    }
}
