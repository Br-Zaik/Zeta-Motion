package com.zeta.fondo.engine

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.zeta.fondo.model.ExportSettings
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

class ImportedAudioPreview(context: android.content.Context, private val hub: RenderHub, private val onError: (String) -> Unit) {
    private val manager = context.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
    @Volatile private var hasFocus = false
    private val focusRequest = android.media.AudioFocusRequest.Builder(android.media.AudioManager.AUDIOFOCUS_GAIN)
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
        .setOnAudioFocusChangeListener({ change -> hasFocus = change == android.media.AudioManager.AUDIOFOCUS_GAIN },
            android.os.Handler(android.os.Looper.getMainLooper())).build()
    private data class State(val file: File, val settings: ExportSettings, val playing: Boolean)
    @Volatile private var state: State? = null
    @Volatile private var foreground = true
    private val running = AtomicBoolean(true)
    fun update(file: File, settings: ExportSettings, playing: Boolean) { state = State(file, settings, playing) }
    fun setForeground(value: Boolean) { foreground = value }
    private val thread = Thread {
        var track: AudioTrack? = null
        var reader: PcmReader? = null
        var loaded: ExportSettings? = null
        var loadedStamp = 0L
        var active = false
        var cursor = 0L
        var base = 0L
        var failedStamp: String? = null
        var focusRequested = false
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO)
        try {
            while (running.get()) {
                val current = state
                val s = current?.settings
                if (s == null || !foreground || !current.playing || !s.audioEnabled || s.audioName.isBlank() || s.soundVolume <= 0f) {
                    if (active) { track?.pause(); track?.flush(); active = false }
                    if (focusRequested) { manager.abandonAudioFocusRequest(focusRequest); focusRequested = false; hasFocus = false }
                    Thread.sleep(40)
                    continue
                }
                if (!focusRequested) {
                    hasFocus = manager.requestAudioFocus(focusRequest) == android.media.AudioManager.AUDIOFOCUS_REQUEST_GRANTED
                    focusRequested = true
                }
                if (!hasFocus) {
                    if (active) { track?.pause(); track?.flush(); active = false }
                    Thread.sleep(40); continue
                }
                val key = "${current.file}:${current.file.lastModified()}:$s"
                if (failedStamp == key) { Thread.sleep(100); continue }
                try {
                    val stamp = current.file.lastModified()
                    if (loaded?.audioRate != s.audioRate || loaded?.audioChannels != s.audioChannels || loaded?.audioFrames != s.audioFrames || stamp != loadedStamp) {
                        track?.release(); track = null; reader?.close(); reader = null; active = false
                        reader = PcmReader(current.file, s)
                        val mask = if (s.audioChannels == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
                        val size = AudioTrack.getMinBufferSize(s.audioRate, mask, AudioFormat.ENCODING_PCM_16BIT)
                        require(size > 0) { "Formato de reproducción no compatible" }
                        track = AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                            .setAudioFormat(AudioFormat.Builder().setSampleRate(s.audioRate).setChannelMask(mask)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                            .setBufferSizeInBytes(maxOf(size, 4096)).setTransferMode(AudioTrack.MODE_STREAM).build()
                        loaded = s; loadedStamp = stamp
                    }
                    reader!!.update(s)
                    val audio = track!!
                    val loop = s.loopSec.toLong() * s.audioRate
                    val target = (hub.currentT() * loop).toLong()
                    val played = (base + (audio.playbackHeadPosition.toLong() and 0xffffffffL)) % loop
                    val diff = abs(target - played)
                    if (!active || minOf(diff, loop - diff) > s.audioRate / 5) {
                        audio.pause(); audio.flush()
                        cursor = target; base = target
                        audio.play(); active = true
                    }
                    val bytes = reader!!.read(cursor, 1024)
                    var offset = 0
                    while (offset < bytes.size && running.get()) {
                        val n = audio.write(bytes, offset, bytes.size - offset, AudioTrack.WRITE_BLOCKING)
                        check(n > 0) { "No se pudo reproducir el audio" }
                        offset += n
                    }
                    cursor += 1024
                } catch (e: Exception) {
                    track?.release(); track = null; reader?.close(); reader = null
                    loaded = null; active = false; failedStamp = key
                    onError("Audio: ${e.message ?: "no se pudo reproducir"}")
                }
            }
        } catch (_: InterruptedException) {
        } finally {
            manager.abandonAudioFocusRequest(focusRequest)
            track?.release(); reader?.close()
        }
    }.apply { name = "ZetaImportedAudio"; isDaemon = true }
    fun start() = thread.start()
    fun close() { running.set(false); thread.interrupt() }
}
