# Zeta Motion v6 — interfaz limpia y fija

Esta versión reorganiza la interfaz sin reemplazar el motor de animación, las máscaras, los 36 efectos procedurales ni la exportación.

## Cambios principales

- Inicio simplificado: una sola acción **Importar** y cuadrícula de proyectos.
- Eliminados el banner y todos los JPG decorativos incluidos en la APK.
- Efectos y presets mostrados con iconos compactos, sin fotografías de muestra.
- Los 36 efectos del motor continúan disponibles, incluido el filtro **Todos**.
- Visor del editor estable: el panel inferior se superpone y ya no cambia su tamaño.
- Panel de ajustes con altura fija; se abre y se cierra únicamente con la flecha.
- Botones y textos reducidos para aprovechar mejor pantallas pequeñas.
- **Exportar** aparece una sola vez, en la barra inferior.
- La vista OpenGL se conserva al entrar en pantalla completa para evitar el destello negro.
- Versión Android: `6.0.0` (`versionCode 6`).

## Compilación

Sube el contenido del ZIP a GitHub y ejecuta **Compilar APK Zeta Motion** desde la pestaña Actions. El APK firmado se entrega en el artefacto `ZetaMotion-APK`.
