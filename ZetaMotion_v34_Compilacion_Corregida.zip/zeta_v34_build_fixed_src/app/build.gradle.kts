plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.zeta.fondo"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.zeta.fondo"
        minSdk = 26
        targetSdk = 36
        versionCode = 34
        versionName = "34.0.0"
    }

    // Nunca incluir contraseñas o el almacén privado de firmas en el código público.
    // Para actualizar instalaciones firmadas con la v33, proporcionar LA MISMA clave
    // mediante variables seguras en CI, sin publicarla ni regenerarla.
    val keystorePath = System.getenv("ZETA_KEYSTORE_PATH")
    val keystorePassword = System.getenv("ZETA_KEYSTORE_PASSWORD")
    val signingAlias = System.getenv("ZETA_KEY_ALIAS")
    val signingPassword = System.getenv("ZETA_KEY_PASSWORD")
    val hasReleaseSigning = listOf(keystorePath, keystorePassword, signingAlias, signingPassword)
        .all { !it.isNullOrBlank() }

    signingConfigs {
        if (hasReleaseSigning) {
            create("zetaRelease") {
                storeFile = file(keystorePath!!)
                storePassword = keystorePassword!!
                keyAlias = signingAlias!!
                keyPassword = signingPassword!!
            }
        }
    }

    buildTypes {
        debug {
            // Android usa su keystore debug privada del equipo (no es la firma v33).
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            if (hasReleaseSigning) signingConfig = signingConfigs.getByName("zetaRelease")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.0")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
