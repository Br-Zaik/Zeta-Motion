# Zeta Motion v34 — corrección de configuración de compilación (APK)

Se preserva el código de funciones/efectos de v34, sin alterar formatos ni IDs. Este ZIP contiene el código fuente Android.

## Ajustes

- Android Gradle Plugin 8.10.1 + Gradle 8.11.1 (compatibles).
- Actualizado el plugin de Kotlin 1.9.24 a Kotlin 2.2.21 para tener un conjunto de versiones compatible con AGP 8.10.1 / Gradle 8.11.1.
- Añadido `org.jetbrains.kotlin.plugin.compose` 2.2.21, que es el compilador Compose requerido con Kotlin 2.x; eliminado `composeOptions.kotlinCompilerExtensionVersion=1.5.14`.
- Se mantiene `compileSdk=36` y `targetSdk=36`; GitHub Actions instala de forma explícita Android SDK 36 y build-tools 36.0.0.
- La tarea de GitHub Actions genera primero el APK debug, luego lanza tests y después el AAB. Conserva el APK aun si falla una fase posterior.
- Los logs quedan como artefacto descargable siempre que la ejecución llegue a la parte de compilación.
- Se mantienen las medidas de privacidad de firma del ZIP anterior (NO se incluye archivo JKS).

## Límites de comprobación

Los cambios corrigen incompatibilidades de configuración verificadas con la tabla oficial de Kotlin y Android. **No se ha compilado el APK aquí**: este entorno no tiene Android SDK, Gradle ni acceso a repositorios de Maven. Por tanto no es posible garantizar que no quede otro error de compilación. El log de GitHub no estaba disponible; se priorizaron problemas comprobables de la configuración.

## Aviso de instalación

El APK debug de GitHub usará firma de pruebas y normalmente NO actualiza encima de una versión antigua firmada con otra clave. Antes de desinstalar la app anterior, guarda tus proyectos. Para una distribución firmada y actualizable, utiliza la misma clave privada en un proceso CI seguro, nunca dentro de un repositorio público.
