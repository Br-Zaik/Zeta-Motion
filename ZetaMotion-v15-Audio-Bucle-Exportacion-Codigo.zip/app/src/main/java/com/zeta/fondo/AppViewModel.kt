package com.zeta.fondo

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zeta.fondo.engine.BitmapUtil
import com.zeta.fondo.engine.ExportCancelled
import com.zeta.fondo.engine.ExportRequest
import com.zeta.fondo.engine.ExportPlanner
import com.zeta.fondo.engine.ExportResult
import com.zeta.fondo.engine.Exporter
import com.zeta.fondo.engine.FlowField
import com.zeta.fondo.engine.MaskLayers
import com.zeta.fondo.engine.RenderHub
import com.zeta.fondo.engine.RenderParams
import com.zeta.fondo.model.Arrow
import com.zeta.fondo.model.EditorTab
import com.zeta.fondo.model.Effects
import com.zeta.fondo.model.ExportSettings
import com.zeta.fondo.model.MaskStroke
import com.zeta.fondo.model.PointN
import com.zeta.fondo.model.Preset
import com.zeta.fondo.model.ProjectMeta
import com.zeta.fondo.model.ProjectStore
import com.zeta.fondo.model.ProjectSummary
import com.zeta.fondo.model.Tool
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.hypot

enum class Screen { HOME, EDITOR }

sealed class ExportState {
    object Idle : ExportState()
    data class Running(val progress: Float) : ExportState()
    data class Done(val result: ExportResult) : ExportState()
    data class Failed(val message: String) : ExportState()
}

private sealed class UndoAction {
    class EffectSwitches(val before: Map<String, Float>, val after: Map<String, Float>) : UndoAction()
    class AddArrow(val arrow: Arrow) : UndoAction()
    class AddAnchor(val point: PointN) : UndoAction()
    class AddStroke(val stroke: MaskStroke) : UndoAction()
    class RemoveArrow(val index: Int, val arrow: Arrow) : UndoAction()
    class RemoveAnchor(val index: Int, val point: PointN) : UndoAction()
    class ClearGuides(val arrows: List<Arrow>, val anchors: List<PointN>) : UndoAction()
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val main = Handler(Looper.getMainLooper())
    private val store = ProjectStore(app)
    private val saveMutex = Mutex()
    val hub = RenderHub()
    val vertSrc: String = app.assets.open("shaders/fondo.vert").bufferedReader().use { it.readText() }
    val fragSrc: String = app.assets.open("shaders/fondo.frag").bufferedReader().use { it.readText() }

    // ---------------- Navegación y avisos
    var screen by mutableStateOf(Screen.HOME)
    var projects by mutableStateOf<List<ProjectSummary>>(emptyList())
    var busy by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)
    var glError by mutableStateOf<String?>(null)

    // ---------------- Proyecto abierto
    var meta by mutableStateOf<ProjectMeta?>(null)
        private set
    val arrows = mutableStateListOf<Arrow>()
    val anchors = mutableStateListOf<PointN>()
    var masks: MaskLayers? = null
        private set
    var maskNames by mutableStateOf<List<String>>(listOf("Congelar", "Zona azul", "Zona verde"))
        private set
    var selectedMaskLayer by mutableStateOf(0)
        private set
    var settings by mutableStateOf(Effects.defaults())
        private set
    var exportSettings by mutableStateOf(ExportSettings())
        private set

    // ---------------- Herramientas
    var tool by mutableStateOf(Tool.PAN)
    var eraser by mutableStateOf(false)
    var brushDp by mutableFloatStateOf(36f)
    var feather by mutableFloatStateOf(0.35f)
    var showGuides by mutableStateOf(false)
    var showMasks by mutableStateOf(true)
        private set
    var playing by mutableStateOf(true)
        private set
    var scrubT by mutableFloatStateOf(0f)
        private set
    var tab by mutableStateOf(EditorTab.TOOLS)
        private set
    var settingsSection by mutableStateOf(0)
    var fullscreen by mutableStateOf(false)
    var activeMotionEffect by mutableStateOf<String?>(null)
    var effectsCategory by mutableStateOf("Anime")

    var editingEffect by mutableStateOf<String?>(null)
        private set
    var paintingZone by mutableStateOf(false)
        private set
    var selectedElement by mutableStateOf(-1)
        private set
    var brushCursor by mutableStateOf<PointN?>(null)
    private data class EditSnapshot(val settings: Map<String, Float>, val strokes: List<MaskStroke>,
        val names: List<String>, val arrows: List<Arrow>, val anchors: List<PointN>, val undo: List<UndoAction>, val redo: List<UndoAction>)
    private var editSnapshot: EditSnapshot? = null
    private fun beginEdit() {
        if (editSnapshot != null) return
        endStroke()
        val mk = masks ?: return
        editSnapshot = EditSnapshot(settings.toMap(), synchronized(mk.lock) { mk.strokes.flatten().toList() },
            mk.names.toList(), arrows.toList(), anchors.toList(), undoStack.toList(), redoStack.toList())
    }
    fun editEffect(id: String) {
        finishEdit(true); beginEdit(); editingEffect = id; tab = EditorTab.EFFECTS
        val firstLocalEffect = id in setOf("sky", "water", "dispersion", "zonemotion") && !settings.containsKey("$id.ownedMask") && !settings.containsKey("$id.mask")
        if (id != "elements") {
            setSetting("$id.on", 1f)
            if (!settings.containsKey("$id.mask")) {
                val legacy = when {
                    id in setOf("sway", "heat", "flame", "cloth") -> 2
                    id in setOf("drift", "ripple", "glint", "eyes", "blink") -> 1
                    (settings["$id.zone"] ?: 0f) > .5f -> 1
                    else -> -2
                }
                val used = masks?.strokes?.getOrNull(legacy)?.isNotEmpty() == true
                setSetting("$id.mask", if (used) legacy.toFloat() else -2f)
            }
        }
        if (firstLocalEffect) paintEffectZone()
    }
    fun finishEdit(commit: Boolean) {
        endStroke()
        val saved = editSnapshot
        if (!commit && saved != null) {
            settings = saved.settings
            arrows.clear(); arrows.addAll(saved.arrows)
            anchors.clear(); anchors.addAll(saved.anchors); recomputeFlow()
            masks?.setAll(saved.strokes, saved.names)
            maskNames = masks?.names?.toList() ?: saved.names
            undoStack.clear(); undoStack.addAll(saved.undo)
            redoStack.clear(); redoStack.addAll(saved.redo)
            canUndo = undoStack.isNotEmpty(); canRedo = redoStack.isNotEmpty(); pushParams()
        }
        editSnapshot = null; editingEffect = null; paintingZone = false; selectedElement = -1; brushCursor = null
        tool = Tool.PAN; showGuides = false; hub.showMask = false
        if (commit && saved != null) saveProject()
    }
    fun paintEffectZone() {
        val id = editingEffect ?: return
        val mk = masks ?: return
        var layer = (settings["$id.ownedMask"] ?: -1f).toInt()
        if (layer !in 3 until mk.count) {
            layer = mk.addLayer(Effects.all.firstOrNull { it.id == id }?.title ?: id)
            if (layer < 0) { message = "Límite de nueve zonas independientes por proyecto."; return }
            setSetting("$id.ownedMask", layer.toFloat())
            // Migrate an existing zone without altering the zones used by other effects.
            val previous = (settings["$id.mask"] ?: -1f).toInt()
            if (previous in 0 until layer) {
                val copy = mk.snapshot().filter { it.layer == previous }.map { old ->
                    MaskStroke(layer, old.radius, old.feather, old.erase, old.fill).also { it.points.addAll(old.points) }
                }
                copy.forEach { mk.addStroke(it) }
            }
        }
        maskNames = mk.names.toList(); setEffectMask(id, layer)
        if (playing) togglePlay()
        selectMask(layer); eraser = false; paintingZone = true; showGuides = true
    }
    fun wholeEffectZone() { editingEffect?.let { setEffectMask(it, -2) } }
    fun finishPainting() { endStroke(); paintingZone = false; brushCursor = null; tool = Tool.PAN; showGuides = false; hub.showMask = false }
    fun protect() {
        finishEdit(true); beginEdit(); tab = EditorTab.MASKS
        if (playing) togglePlay()
        selectMask(0); eraser = false; showGuides = true; paintingZone = true
    }
    fun addElement(type: Int) {
        val slot = (0..3).firstOrNull { (settings["element$it.on"] ?: 0f) < .5f }
        if (slot == null) { message = "Hasta cuatro elementos simultáneos."; return }
        settings = settings + mapOf("element$slot.on" to 1f, "element$slot.type" to type.toFloat(),
            "element$slot.x" to .5f, "element$slot.y" to .5f, "element$slot.size" to .3f,
            "element$slot.rotation" to 0f, "element$slot.opacity" to .7f, "element$slot.cycles" to 1f)
        selectedElement = slot; pushParams()
    }
    fun selectElement(slot: Int) { selectedElement = slot }
    fun transformElement(dx: Float, dy: Float, zoom: Float, rotation: Float) {
        val id = "element$selectedElement"
        if (selectedElement < 0) return
        settings = settings + mapOf("$id.x" to ((settings["$id.x"] ?: .5f) + dx).coerceIn(0f,1f),
            "$id.y" to ((settings["$id.y"] ?: .5f) + dy).coerceIn(0f,1f),
            "$id.size" to ((settings["$id.size"] ?: .3f) * zoom).coerceIn(.04f, 1.5f),
            "$id.rotation" to ((((settings["$id.rotation"] ?: 0f) + rotation + 540f) % 360f) - 180f))
        pushParams()
    }

    // ---------------- Vista (zoom del editor)
    var viewScale by mutableFloatStateOf(1f)
        private set
    var viewX by mutableFloatStateOf(0f)
        private set
    var viewY by mutableFloatStateOf(0f)
        private set
    var cropW by mutableFloatStateOf(1f)
        private set
    var cropH by mutableFloatStateOf(1f)
        private set
    private var cropX = 0f
    private var cropY = 0f
    val previewAspect: Float get() = aspect * cropW / cropH

    // ---------------- Deshacer
    private val undoStack = ArrayList<UndoAction>()
    private val redoStack = ArrayList<UndoAction>()
    var canUndo by mutableStateOf(false)
    var canRedo by mutableStateOf(false)
        private set
    private var currentStroke: MaskStroke? = null
    private var flowJob: Job? = null

    // ---------------- Exportación
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
        private set
    private val cancelFlag = AtomicBoolean(false)
    private var lastProgressPost = -1f

    val aspect: Float
        get() = meta?.let { it.w.toFloat() / it.h } ?: 1f

    init {
        hub.onError = { msg -> main.post { glError = msg } }
        refreshProjects()
    }

    // ============================================================ Proyectos

    fun refreshProjects() {
        viewModelScope.launch {
            projects = withContext(Dispatchers.IO) { store.list() }
        }
    }

    fun importImage(uri: Uri, initialTab: EditorTab = EditorTab.TOOLS, initialCategory: String = "Anime") {
        if (busy != null) return
        saveProject()
        busy = "Importando imagen…"
        viewModelScope.launch {
            try {
                val id = withContext(Dispatchers.IO) { store.create(uri) }
                busy = null
                openProject(id, initialTab, initialCategory)
            } catch (e: Throwable) {
                busy = null
                message = "No se pudo importar: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    fun importAudio(uri: Uri) {
        val project = meta ?: return
        if (busy != null || exportState is ExportState.Running) return
        if (playing) togglePlay()
        busy = "Importando audio…"
        viewModelScope.launch {
            try {
                val decoded = withContext(Dispatchers.IO) {
                    val temp = java.io.File(project.dir, "audio-import.tmp")
                    val result = com.zeta.fondo.engine.ImportedAudio.decode(getApplication(), uri, temp)
                    java.nio.file.Files.move(temp.toPath(), java.io.File(project.dir,
                        com.zeta.fondo.engine.ImportedAudio.FILE_NAME).toPath(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING)
                    result
                }
                updateExport(exportSettings.copy(audioName = decoded.name, audioRate = decoded.rate,
                    audioChannels = decoded.channels, audioFrames = decoded.frames,
                    audioStartFrame = 0L, audioEnabled = true, soundVolume = 1f))
                saveProject()
            } catch (e: Exception) {
                message = "No se pudo importar el audio: ${e.message}"
            } finally { busy = null }
        }
    }

    fun removeAudio() {
        if (playing) togglePlay()
        updateExport(exportSettings.copy(audioName = "", audioFrames = 0L, audioStartFrame = 0L, audioEnabled = false))
        saveProject()
    }

    fun openProject(id: String, initialTab: EditorTab = EditorTab.TOOLS, initialCategory: String = "Anime") {
        busy = "Abriendo proyecto…"
        viewModelScope.launch {
            try {
                val loaded = withContext(Dispatchers.IO) { store.load(id) }
                val preview: Bitmap = withContext(Dispatchers.IO) {
                    BitmapUtil.decodeAtMost(loaded.meta.imageFile, PREVIEW_MAX)
                }
                val mk = withContext(Dispatchers.Default) {
                    MaskLayers.create(loaded.meta.w, loaded.meta.h).also {
                        it.setAll(loaded.strokes, loaded.maskNames)
                    }
                }
                editSnapshot = null; editingEffect = null; paintingZone = false; selectedElement = -1; brushCursor = null
                meta = loaded.meta
                arrows.clear()
                arrows.addAll(loaded.arrows)
                anchors.clear()
                anchors.addAll(loaded.anchors)
                masks = mk
                maskNames = mk.names.toList()
                selectedMaskLayer = 0
                hub.activeMask = 0
                settings = loaded.settings
                exportSettings = loaded.export
                undoStack.clear()
                redoStack.clear()
                canUndo = false
                canRedo = false
                currentStroke = null
                exportState = ExportState.Idle
                glError = null
                resetView()
                tool = Tool.PAN
                showGuides = false
                effectsCategory = initialCategory
                tab = initialTab
                fullscreen = false
                activeMotionEffect = null
                playing = true
                hub.setPlaying(true)
                if (initialTab == EditorTab.MASKS) {
                    selectMask(0)
                    playing = false
                    hub.setPlaying(false)
                }

                hub.image = preview
                hub.masks = mk
                hub.flow = null
                hub.showMask = showMasks && !playing
                pushParams()
                recomputeFlow()
                screen = Screen.EDITOR
            } catch (e: Throwable) {
                message = "No se pudo abrir: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                busy = null
            }
        }
    }

    fun saveProject() {
        val m = meta ?: return
        val mk = masks ?: return
        val a = ArrayList(editSnapshot?.arrows ?: arrows)
        val an = ArrayList(editSnapshot?.anchors ?: anchors)
        val st = editSnapshot?.strokes ?: mk.snapshot()
        val labels = editSnapshot?.names ?: mk.names.toList()
        val s = editSnapshot?.settings ?: settings
        val ex = exportSettings
        viewModelScope.launch {
            saveMutex.withLock {
                try { withContext(Dispatchers.IO) { store.save(m, a, an, st, s, ex, labels) } }
                catch (e: Exception) { message = "No se pudo guardar el proyecto: ${e.message}" }
            }
        }
    }

    fun closeEditor() {
        if (busy != null) return
        if (exportState is ExportState.Running) {
            message = "Espera a que termine la exportación o cancélala."
            return
        }
        fullscreen = false
        finishEdit(true)
        saveProject()
        screen = Screen.HOME
        meta = null
        hub.image = null
        refreshProjects()
    }

    fun deleteProject(id: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { store.delete(id) }
            refreshProjects()
        }
    }

    // ============================================================ Efectos

    fun selectTab(t: EditorTab) {
        finishEdit(true)
        tab = t
        if (t == EditorTab.MASKS && playing) togglePlay()
        showGuides = !playing && (t == EditorTab.TOOLS || t == EditorTab.MASKS)
        hub.showMask = false
    }

    fun protectPoints(erase: Boolean = false) {
        finishEdit(true); tab = EditorTab.MASKS
        if (playing) togglePlay()
        tool = if (erase) Tool.ERASE_GUIDE else Tool.ANCHOR
        showGuides = true; hub.showMask = false
    }

    fun editZoneMotion() { editEffect("zonemotion"); tab = EditorTab.TOOLS }

    val activeEffectsCount: Int get() = com.zeta.fondo.model.EffectSwitches.active(settings).size
    fun removeAllEffects() {
        finishEdit(true)
        val before = com.zeta.fondo.model.EffectSwitches.active(settings)
        if (before.isEmpty()) return
        val after = com.zeta.fondo.model.EffectSwitches.disabled(settings)
        settings = settings + after
        pushUndo(UndoAction.EffectSwitches(before, after)); pushParams(); saveProject()
    }

    fun addMask() {
        val mk = masks ?: return
        val i = mk.addLayer("Máscara ${maskNames.size - 2}")
        if (i < 0) { message = "Máximo ${MaskLayers.MAX_MASKS} máscaras para cuidar la memoria del dispositivo."; return }
        maskNames = mk.names.toList()
        selectMask(i)
    }

    fun selectMask(index: Int) {
        if (index !in maskNames.indices) return
        selectedMaskLayer = index
        hub.activeMask = index
        tool = when (index) {
            0 -> Tool.FREEZE
            1 -> Tool.ZONE1
            2 -> Tool.ZONE2
            else -> Tool.MASK
        }
        showMasks = true
        hub.showMask = true
    }

    fun renameMask(index: Int, label: String) {
        val mk = masks ?: return
        mk.renameLayer(index, label)
        maskNames = mk.names.toList()
    }

    fun setEffectMask(id: String, index: Int) {
        setSetting("$id.mask", index.toFloat())
    }

    fun resetColor() {
        settings = settings.filterKeys { !it.startsWith("adjust.") }
        pushParams()
    }

    fun setSetting(key: String, value: Float) {
        settings = settings + (key to value)
        pushParams()
        if (key == "flow.reach") recomputeFlow()
    }

    fun moveEffectOrigin(p: PointN) {
        val id = activeMotionEffect ?: return
        settings = settings + mapOf("$id.origin" to 0f, "$id.originX" to p.x, "$id.originY" to p.y)
        pushParams()
    }

    fun setMotionOrigin(id: String, origin: Int) {
        val angles = floatArrayOf(Float.NaN, 90f, 270f, 0f, 180f, 45f, 135f, 315f, 225f)
        val update = mapOf("$id.origin" to origin.coerceIn(0, 8).toFloat())
        settings = settings + update + (if (origin in 1..8) mapOf("$id.direction" to angles[origin]) else emptyMap())
        pushParams()
    }

    fun applyPreset(p: Preset) {
        settings = settings + p.values
        pushParams()
        message = "${p.emoji} ${p.name} aplicado"
    }

    fun clearEffects() {
        settings = Effects.allOff(settings)
        pushParams()
    }

    fun updateExport(e: ExportSettings) {
        val old = exportSettings
        exportSettings = e
        if (old.framing != e.framing || old.cropPos != e.cropPos || old.res != e.res ||
            old.customW != e.customW || old.customH != e.customH) resetView()
        if (exportState is ExportState.Done || exportState is ExportState.Failed) exportState = ExportState.Idle
        hub.setLoopSec(e.loopSec.toFloat())
    }

    private fun pushParams() {
        hub.params = RenderParams.from(settings, aspect)
        hub.setLoopSec(exportSettings.loopSec.toFloat())
    }

    private fun recomputeFlow() {
        val a = ArrayList(arrows)
        val an = ArrayList(anchors)
        val asp = aspect
        val reach = settings["flow.reach"] ?: Effects.default("flow.reach")
        flowJob?.cancel()
        flowJob = viewModelScope.launch {
            val data: FlowField.Data = withContext(Dispatchers.Default) { FlowField.compute(a, an, asp, reach) }
            hub.flow = data
        }
    }

    // ============================================================ Reproducción

    fun togglePlay() {
        if (paintingZone) finishPainting()
        playing = !playing
        hub.setPlaying(playing)
        if (!playing) scrubT = hub.pausedT()
        showGuides = !playing && (tab == EditorTab.MASKS || (tab == EditorTab.TOOLS && tool != Tool.PAN))
        hub.showMask = showMasks && !playing && tool.isBrush
    }

    fun scrubTo(t: Float) {
        scrubT = t
        hub.setPausedT(t)
    }

    fun toggleMasks() {
        showMasks = !showMasks
        hub.showMask = showMasks && !playing
    }

    // ============================================================ Vista

    fun resetView() {
        val m = meta
        val crop = if (m != null) ExportPlanner.cropForSettings(m.w, m.h, exportSettings)
            else floatArrayOf(0f, 0f, 1f, 1f)
        cropX = crop[0]; cropY = crop[1]; cropW = crop[2]; cropH = crop[3]
        viewScale = 1f
        viewX = cropX
        viewY = cropY
        syncView()
    }

    private fun syncView() {
        hub.viewWidth = cropW / viewScale
        hub.viewHeight = cropH / viewScale
        hub.viewScale = viewScale
        hub.viewX = viewX
        hub.viewY = viewY
    }

    /** zoom = factor, pan y centroide en fracción del tamaño de la vista. */
    fun transformView(zoom: Float, panX: Float, panY: Float, cx: Float, cy: Float) {
        val s0 = viewScale
        val s1 = (s0 * zoom).coerceIn(1f, 10f)
        val ux = viewX + cx * cropW / s0
        val uy = viewY + cy * cropH / s0
        viewX = (ux - (cx + panX) * cropW / s1).coerceIn(cropX, (cropX + cropW - cropW / s1).coerceAtLeast(cropX))
        viewY = (uy - (cy + panY) * cropH / s1).coerceIn(cropY, (cropY + cropH - cropH / s1).coerceAtLeast(cropY))
        viewScale = s1
        syncView()
    }

    fun screenToUv(nx: Float, ny: Float): PointN = PointN(
        (viewX + nx * cropW / viewScale).coerceIn(0f, 1f),
        (viewY + ny * cropH / viewScale).coerceIn(0f, 1f)
    )

    // ============================================================ Edición

    private fun pushUndo(a: UndoAction) {
        undoStack.add(a)
        if (undoStack.size > 200) undoStack.removeAt(0)
        redoStack.clear()
        canRedo = false
        canUndo = true
    }

    fun addArrow(a: Arrow) {
        arrows.add(a)
        pushUndo(UndoAction.AddArrow(a))
        recomputeFlow()
    }

    fun addQuickDirection(direction: Int) {
        val vectors = arrayOf(
            PointN(0f, -0.22f), PointN(0.22f, -0.22f), PointN(0.22f, 0f),
            PointN(0.22f, 0.22f), PointN(0f, 0.22f), PointN(-0.22f, 0.22f),
            PointN(-0.22f, 0f), PointN(-0.22f, -0.22f)
        )
        val v = vectors[direction.coerceIn(0, 7)]
        addArrow(Arrow(0.5f - v.x * 0.5f, 0.5f - v.y * 0.5f, 0.5f + v.x * 0.5f, 0.5f + v.y * 0.5f))
        tool = Tool.ARROW
        message = "Flecha añadida en el centro. Puedes arrastrarla o añadir anclas para delimitar la zona."
    }

    fun addAnchor(p: PointN) {
        anchors.add(p)
        pushUndo(UndoAction.AddAnchor(p))
        recomputeFlow()
    }

    fun removeArrowAt(i: Int) {
        if (i !in arrows.indices) return
        val a = arrows.removeAt(i)
        pushUndo(UndoAction.RemoveArrow(i, a))
        recomputeFlow()
    }

    fun removeAnchorAt(i: Int) {
        if (i !in anchors.indices) return
        val p = anchors.removeAt(i)
        pushUndo(UndoAction.RemoveAnchor(i, p))
        recomputeFlow()
    }

    fun clearGuides() {
        if (arrows.isEmpty() && anchors.isEmpty()) return
        pushUndo(UndoAction.ClearGuides(ArrayList(arrows), ArrayList(anchors)))
        arrows.clear()
        anchors.clear()
        recomputeFlow()
    }

    /** radiusUv: radio del pincel en fracción de la altura de la imagen. */
    fun beginStroke(p: PointN, radiusUv: Float) {
        val mk = masks ?: return
        val layer = if (tool == Tool.MASK) selectedMaskLayer else tool.layer
        if (layer < 0) return
        val s = MaskStroke(layer, radiusUv, feather, eraser)
        s.points.add(p)
        mk.addStroke(s)
        currentStroke = s
        pushUndo(UndoAction.AddStroke(s))
    }

    fun continueStroke(p: PointN) {
        val s = currentStroke ?: return
        val last = s.points.lastOrNull()
        if (last != null && hypot((p.x - last.x).toDouble(), (p.y - last.y).toDouble()) < 0.0015) return
        masks?.extendStroke(s, p)
    }

    fun endStroke() {
        currentStroke = null
    }

    fun cancelStroke() {
        val s = currentStroke ?: return
        currentStroke = null
        masks?.removeStroke(s)
        val last = undoStack.lastOrNull()
        if (last is UndoAction.AddStroke && last.stroke === s) undoStack.removeAt(undoStack.size - 1)
        canUndo = undoStack.isNotEmpty()
    }

    /** Rellena (clear=false) o vacía (clear=true) toda la capa de la herramienta actual. */
    fun fillLayer(clear: Boolean) {
        val mk = masks ?: return
        val layer = if (tool == Tool.MASK) selectedMaskLayer else tool.layer
        if (layer < 0) return
        val s = MaskStroke(layer, 0f, 0f, clear, fill = true)
        mk.addStroke(s)
        pushUndo(UndoAction.AddStroke(s))
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val a = undoStack.removeAt(undoStack.size - 1)
        when (a) {
            is UndoAction.EffectSwitches -> { settings = settings + a.before; pushParams() }
            is UndoAction.AddArrow -> {
                val i = arrows.lastIndexOf(a.arrow)
                if (i >= 0) arrows.removeAt(i)
                recomputeFlow()
            }
            is UndoAction.AddAnchor -> {
                val i = anchors.lastIndexOf(a.point)
                if (i >= 0) anchors.removeAt(i)
                recomputeFlow()
            }
            is UndoAction.AddStroke -> masks?.removeStroke(a.stroke)
            is UndoAction.RemoveArrow -> {
                arrows.add(a.index.coerceIn(0, arrows.size), a.arrow)
                recomputeFlow()
            }
            is UndoAction.RemoveAnchor -> {
                anchors.add(a.index.coerceIn(0, anchors.size), a.point)
                recomputeFlow()
            }
            is UndoAction.ClearGuides -> {
                arrows.addAll(a.arrows)
                anchors.addAll(a.anchors)
                recomputeFlow()
            }
        }
        redoStack.add(a)
        if (redoStack.size > 200) redoStack.removeAt(0)
        canRedo = true
        canUndo = undoStack.isNotEmpty()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val a = redoStack.removeAt(redoStack.size - 1)
        when (a) {
            is UndoAction.EffectSwitches -> { settings = settings + a.after; pushParams() }
            is UndoAction.AddArrow -> {
                arrows.add(a.arrow)
                recomputeFlow()
            }
            is UndoAction.AddAnchor -> {
                anchors.add(a.point)
                recomputeFlow()
            }
            is UndoAction.AddStroke -> masks?.addStroke(a.stroke)
            is UndoAction.RemoveArrow -> {
                val i = arrows.indexOf(a.arrow)
                if (i >= 0) arrows.removeAt(i)
                recomputeFlow()
            }
            is UndoAction.RemoveAnchor -> {
                val i = anchors.indexOf(a.point)
                if (i >= 0) anchors.removeAt(i)
                recomputeFlow()
            }
            is UndoAction.ClearGuides -> {
                arrows.clear()
                anchors.clear()
                recomputeFlow()
            }
        }
        undoStack.add(a)
        if (undoStack.size > 200) undoStack.removeAt(0)
        canUndo = true
        canRedo = redoStack.isNotEmpty()
    }

    // ============================================================ Exportar

    fun startExport() {
        val m = meta ?: return
        val mk = masks ?: return
        if (exportState is ExportState.Running) return
        saveProject()
        cancelFlag.set(false)
        lastProgressPost = -1f
        exportState = ExportState.Running(0f)
        hub.renderEnabled = false

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val req = ExportRequest(
            imageFile = m.imageFile,
            imgW = m.w,
            imgH = m.h,
            name = "ZetaMotion_$stamp",
            settings = exportSettings,
            params = RenderParams.from(settings, aspect),
            flow = hub.flow ?: FlowField.compute(ArrayList(arrows), ArrayList(anchors), aspect, settings["flow.reach"] ?: 0.25f),
            masks = mk
        )
        val exporter = Exporter(getApplication<Application>(), vertSrc, fragSrc)
        viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.Default) {
                    exporter.run(req, cancelFlag) { p -> postProgress(p) }
                }
                exportState = ExportState.Done(result)
            } catch (e: ExportCancelled) {
                exportState = ExportState.Idle
                message = "Exportación cancelada."
            } catch (e: OutOfMemoryError) {
                exportState = ExportState.Failed("No hay memoria suficiente para esa resolución. Prueba con una menor.")
            } catch (e: Throwable) {
                exportState = ExportState.Failed(e.message ?: e.toString())
            } finally {
                hub.renderEnabled = true
            }
        }
    }

    private fun postProgress(p: Float) {
        if (p - lastProgressPost < 0.005f && p < 1f) return
        lastProgressPost = p
        main.post {
            if (exportState is ExportState.Running) exportState = ExportState.Running(p)
        }
    }

    fun cancelExport() {
        cancelFlag.set(true)
    }

    fun dismissExportResult() {
        exportState = ExportState.Idle
    }

    override fun onCleared() {
        cancelFlag.set(true)
        super.onCleared()
    }

    companion object {
        const val PREVIEW_MAX = 2048
    }
}
