package com.zeta.fondo.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.engine.ImportedAudio
import com.zeta.fondo.model.ExportSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/** Picos de la pista PCM, calculados con lecturas limitadas para no bloquear el editor. */
internal fun sampleWaveform(file: File, totalFrames: Long, channels: Int, count: Int = 128): FloatArray {
    val result = FloatArray(count)
    if (!file.isFile || totalFrames <= 0L || channels !in 1..2) return result
    RandomAccessFile(file, "r").use { pcm ->
        val bytesPerFrame = 2L * channels
        val frames = min(totalFrames, pcm.length() / bytesPerFrame)
        if (frames <= 0L) return result
        val chunk = ByteArray(128 * channels * 2)
        for (i in result.indices) {
            val mid = ((i.toDouble() + 0.5) * frames / count).toLong().coerceIn(0L, frames - 1L)
            val start = (mid - 64L).coerceIn(0L, (frames - 128L).coerceAtLeast(0L))
            pcm.seek(start * bytesPerFrame)
            val bytes = pcm.read(chunk, 0, min(chunk.size.toLong(), (frames - start) * bytesPerFrame).toInt())
            var peak = 0
            var k = 0
            while (k + 1 < bytes) {
                val value = (chunk[k].toInt() and 255) or (chunk[k + 1].toInt() shl 8)
                val signed = value.toShort().toInt()
                peak = max(peak, abs(signed))
                k += 2
            }
            result[i] = (peak / 32768f).coerceIn(.025f, 1f)
        }
    }
    return result
}

private fun timeLabel(seconds: Double): String {
    val s = seconds.coerceAtLeast(0.0).toLong()
    return if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, s / 60 % 60, s % 60)
    else String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
}

@Composable
fun AudioTrim(vm: AppViewModel, e: ExportSettings) {
    val meta = vm.meta ?: return
    val total = e.audioFrames
    if (total <= 0L) return
    val rate = e.audioRate.coerceAtLeast(1)
    val length = min(total, e.loopSec.toLong() * rate)
    val maxStart = (total - length).coerceAtLeast(0L)
    val start = e.audioStartFrame.coerceIn(0L, maxStart)
    val end = start + length
    val file = remember(meta.id) { File(meta.dir, ImportedAudio.FILE_NAME) }
    var peaks by remember(file, e.audioFrames, e.audioChannels, e.audioName, file.lastModified()) { mutableStateOf(FloatArray(128) { .12f }) }
    LaunchedEffect(file, e.audioFrames, e.audioChannels, e.audioRate, e.audioName, file.lastModified()) {
        peaks = withContext(Dispatchers.IO) {
            try { sampleWaveform(file, total, e.audioChannels) } catch (_: Exception) { FloatArray(128) { .12f } }
        }
    }
    var widthPx by remember { mutableFloatStateOf(1f) }
    val latestStart by rememberUpdatedState(start)
    val latestSettings by rememberUpdatedState(e)
    var anchorX by remember { mutableFloatStateOf(0f) }
    var anchorFrame by remember { mutableLongStateOf(0L) }
    fun select(frame: Long) {
        val current = latestSettings
        val candidate = frame.coerceIn(0L, maxStart)
        if (candidate != current.audioStartFrame) vm.updateExport(current.copy(audioStartFrame = candidate))
    }
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text("Elegir fragmento · ${timeLabel(total.toDouble() / rate)}", color = StudioMuted, fontSize = 12.sp)
        Canvas(Modifier.fillMaxWidth().height(62.dp)
            .background(StudioTile, RoundedCornerShape(8.dp))
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(total, length) {
                detectTapGestures { point ->
                    select(((point.x / widthPx * total) - length / 2.0).roundToLong())
                }
            }
            .pointerInput(total, length) {
                detectDragGestures(onDragStart = { point ->
                    anchorX = point.x
                    val tapped = (point.x / widthPx * total).toLong()
                    anchorFrame = if (tapped in latestStart..(latestStart + length)) latestStart
                        else (tapped - length / 2).coerceIn(0L, maxStart)
                    if (tapped !in latestStart..(latestStart + length)) select(anchorFrame)
                }, onDrag = { change, _ ->
                    change.consume()
                    select(anchorFrame + ((change.position.x - anchorX) / widthPx * total).roundToLong())
                })
            }) {
            val fromX = size.width * start.toFloat() / total
            val toX = size.width * end.toFloat() / total
            drawRect(StudioPurple.copy(alpha = .22f), Offset(fromX, 0f),
                androidx.compose.ui.geometry.Size((toX - fromX).coerceAtLeast(1f), size.height))
            peaks.forEachIndexed { index, peak ->
                val x = size.width * (index + .5f) / peaks.size
                val h = size.height * peak.coerceIn(.04f, 1f) * .83f
                drawLine(if (x in fromX..toX) StudioPurple else StudioMuted.copy(alpha = .58f),
                    Offset(x, (size.height - h) / 2), Offset(x, (size.height + h) / 2),
                    strokeWidth = (size.width / peaks.size * .65f).coerceAtLeast(1f))
            }
            drawLine(StudioPurple, Offset(fromX, 0f), Offset(fromX, size.height), strokeWidth = 3.dp.toPx())
            drawLine(StudioPurple, Offset(toX, 0f), Offset(toX, size.height), strokeWidth = 3.dp.toPx())
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${timeLabel(start.toDouble() / rate)} → ${timeLabel(end.toDouble() / rate)}",
                color = StudioText, fontSize = 12.sp)
            Text("${timeLabel(length.toDouble() / rate)} seleccionados", color = StudioMuted, fontSize = 12.sp)
        }
        StudioSmallButton(if (vm.playing) "Pausar" else "Escuchar con animación",
            if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, Modifier.fillMaxWidth()) {
            if (!vm.playing) vm.scrubTo(0f)
            vm.togglePlay()
        }
    }
}
