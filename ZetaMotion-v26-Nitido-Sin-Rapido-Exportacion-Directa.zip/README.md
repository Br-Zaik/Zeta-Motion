# Zeta Motion v26

Editor Android para animar fondos e ilustraciones de anime, manga y manhwa.

Esta versión elimina la apertura borrosa, quita el panel Rápido duplicado y muestra toda la configuración de exportación directamente, manteniendo el botón Exportar siempre visible.

Ver `README_V26.md`.
