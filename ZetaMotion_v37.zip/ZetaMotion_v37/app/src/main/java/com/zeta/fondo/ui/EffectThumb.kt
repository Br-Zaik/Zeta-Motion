package com.zeta.fondo.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Miniaturas REALES de los efectos: tiras de 8 cuadros renderizadas con el mismo
 * shader de la app (assets/thumbs/<id>.webp, ~10 KB cada una). Se decodifican solo
 * cuando la tarjeta es visible, en RGB_565 (la mitad de memoria) y con caché LRU.
 */
object ThumbCache {
    private val cache = LruCache<String, ImageBitmap>(24)
    private val missing = HashSet<String>()

    suspend fun load(ctx: Context, id: String): ImageBitmap? = withContext(Dispatchers.IO) {
        cache.get(id)?.let { return@withContext it }
        synchronized(missing) { if (id in missing) return@withContext null }
        try {
            ctx.assets.open("thumbs/$id.webp").use { input ->
                val o = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
                BitmapFactory.decodeStream(input, null, o)?.asImageBitmap()?.also { cache.put(id, it) }
            }
        } catch (_: Exception) {
            synchronized(missing) { missing.add(id) }
            null
        }
    }
}

/** Reloj compartido a ~6 fps para todas las miniaturas visibles (no a 60 fps). */
@Composable
fun rememberThumbTick(): () -> Int {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) { delay(160L); tick++ }
    }
    return { tick }
}

@Composable
fun EffectThumb(id: String, animate: Boolean, tick: () -> Int, glyphTime: () -> Float, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, id) { value = ThumbCache.load(ctx, id) }
    val b = bmp
    if (b == null) {
        Box(modifier) { EffectGlyph(id, glyphTime, animate, modifier) }
        return
    }
    Canvas(modifier.clip(RoundedCornerShape(8.dp))) {
        val frames = (b.width / b.height.coerceAtLeast(1)).coerceAtLeast(1)
        val f = if (animate) tick() % frames else frames / 2
        // Recorte centrado para llenar la tarjeta sin deformar.
        val side = b.height
        val dstW = size.width.toInt().coerceAtLeast(1)
        val dstH = size.height.toInt().coerceAtLeast(1)
        val ratio = dstW.toFloat() / dstH
        val srcW = if (ratio >= 1f) side else (side * ratio).toInt().coerceAtLeast(1)
        val srcH = if (ratio >= 1f) (side / ratio).toInt().coerceAtLeast(1) else side
        drawImage(b, srcOffset = IntOffset(f * side + (side - srcW) / 2, (side - srcH) / 2),
            srcSize = IntSize(srcW, srcH), dstSize = IntSize(dstW, dstH))
    }
}
