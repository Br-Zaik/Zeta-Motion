# Zeta Motion

Código fuente Android de **Zeta Motion v32**, para animar fondos e ilustraciones de anime, manga y manhwa.

Consulta `README_V32.md` para conocer los cambios **implementados**, su alcance real y las pruebas pendientes. Se conserva el historial desde `README_V3.md`.
