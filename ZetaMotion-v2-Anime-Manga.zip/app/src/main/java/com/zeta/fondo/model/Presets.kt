package com.zeta.fondo.model

data class Preset(
    val emoji: String,
    val name: String,
    val hint: String,
    val values: Map<String, Float>,
    val manga: Boolean = false
)

object Presets {
    val all: List<Preset> = listOf(
        Preset(
            "🏞️", "Río que fluye",
            "Pinta el río en Zona 1 y dibuja flechas en la dirección del agua. Congela orillas y personajes.",
            mapOf(
                "flow.on" to 1f, "flow.amount" to 0.3f, "flow.cycles" to 2f,
                "ripple.on" to 1f, "ripple.amp" to 0.0015f, "ripple.freq" to 60f,
                "glint.on" to 1f, "glint.int" to 0.7f
            )
        ),
        Preset(
            "🌊", "Mar tranquilo",
            "Pinta el mar en Zona 1. Congela la orilla, barcos y personajes.",
            mapOf(
                "ripple.on" to 1f, "ripple.amp" to 0.003f, "ripple.freq" to 35f, "ripple.cycles" to 2f,
                "glint.on" to 1f, "glint.int" to 1f, "glint.dens" to 90f,
                "drift.on" to 1f, "drift.dir" to 0f, "drift.speed" to 0.02f
            )
        ),
        Preset(
            "💧", "Cascada",
            "Dibuja flechas hacia abajo sobre la cascada y congela las rocas de los lados.",
            mapOf(
                "flow.on" to 1f, "flow.amount" to 0.5f, "flow.cycles" to 3f,
                "glint.on" to 1f, "glint.int" to 0.6f, "glint.dens" to 110f
            )
        ),
        Preset(
            "☁️", "Nubes en movimiento",
            "Pinta el cielo en Zona 1. Congela montañas, edificios y personajes.",
            mapOf("drift.on" to 1f, "drift.dir" to 0f, "drift.speed" to 0.05f, "flow.cycles" to 1f)
        ),
        Preset(
            "🌅", "Atardecer time-lapse",
            "Pinta el cielo en Zona 1. Las nubes avanzan rápido y entra luz dorada.",
            mapOf(
                "drift.on" to 1f, "drift.speed" to 0.12f, "flow.cycles" to 2f,
                "rays.on" to 1f, "rays.int" to 0.45f, "rays.x" to 0.7f
            )
        ),
        Preset(
            "🌌", "Noche estrellada",
            "Pinta el cielo en Zona 1: las estrellas solo aparecen ahí.",
            mapOf("stars.on" to 1f, "stars.int" to 1.1f, "stars.dens" to 45f, "stars.zone" to 1f)
        ),
        Preset(
            "🌳", "Viento en árboles",
            "Pinta el follaje en Zona 2. Congela troncos, casas y personajes.",
            mapOf("sway.on" to 1f, "sway.amp" to 0.004f, "sway.freq" to 6f, "sway.cycles" to 2f)
        ),
        Preset(
            "🌾", "Hierba ondulando",
            "Pinta la hierba en Zona 2.",
            mapOf("sway.on" to 1f, "sway.amp" to 0.003f, "sway.freq" to 14f, "sway.cycles" to 3f)
        ),
        Preset(
            "🌧️", "Lluvia",
            "Si pintas los charcos o el agua en Zona 1, también se ondulan.",
            mapOf(
                "rain.on" to 1f, "rain.int" to 0.7f, "rain.cycles" to 8f,
                "ripple.on" to 1f, "ripple.amp" to 0.001f, "ripple.freq" to 90f
            )
        ),
        Preset(
            "⛈️", "Tormenta",
            "Lluvia fuerte e inclinada con bruma.",
            mapOf(
                "rain.on" to 1f, "rain.int" to 1f, "rain.angle" to 20f, "rain.cycles" to 12f,
                "fog.on" to 1f, "fog.int" to 0.25f
            )
        ),
        Preset("❄️", "Nieve", "Nieve cayendo sobre toda la imagen.", mapOf("snow.on" to 1f)),
        Preset(
            "🌸", "Sakura",
            "Pétalos cayendo. Si pintas los árboles en Zona 2, también se mecen.",
            mapOf("sakura.on" to 1f, "sway.on" to 1f, "sway.amp" to 0.002f)
        ),
        Preset("💫", "Luciérnagas", "Ideal para noches de verano.", mapOf("flies.on" to 1f)),
        Preset("🌫️", "Niebla matinal", "Bruma que se desplaza despacio.", mapOf("fog.on" to 1f, "fog.int" to 0.4f)),
        Preset("🔥", "Fuego", "Pinta las llamas en Zona 2.", mapOf("heat.on" to 1f)),
        Preset("☀️", "Rayos de luz", "Mueve el origen en Efectos › Rayos de luz.", mapOf("rays.on" to 1f)),
        Preset("🎥", "Zoom lento", "Acercamiento suave que vuelve al inicio.", mapOf("cam.on" to 1f, "cam.zoom" to 0.06f)),

        // Manga blanco y negro
        Preset(
            "🖋️", "Lluvia en tinta",
            "Líneas de lluvia en blanco o negro según el fondo.",
            mapOf("style.mono" to 1f, "rain.on" to 1f, "rain.int" to 0.8f, "rain.cycles" to 10f),
            manga = true
        ),
        Preset(
            "🖋️", "Nieve manga",
            "Copos blancos sobre la página.",
            mapOf("style.mono" to 1f, "snow.on" to 1f),
            manga = true
        ),
        Preset(
            "🖋️", "Destellos",
            "Pinta el cielo o el fondo oscuro en Zona 1.",
            mapOf("style.mono" to 1f, "stars.on" to 1f, "stars.zone" to 1f, "stars.int" to 0.9f),
            manga = true
        ),
        Preset(
            "🖋️", "Tramas intactas",
            "Mueve la imagen píxel por píxel para no deformar las tramas. Anima con flechas cortas.",
            mapOf("style.mono" to 1f, "style.snap" to 1f, "flow.amount" to 0.2f),
            manga = true
        )
    )
}
