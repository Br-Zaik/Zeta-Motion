package com.zeta.fondo.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.ExportState
import com.zeta.fondo.engine.ExportPlanner
import com.zeta.fondo.export.ShareUtil
import com.zeta.fondo.model.Effects
import com.zeta.fondo.model.Kind
import com.zeta.fondo.model.Preset
import com.zeta.fondo.model.Presets
import com.zeta.fondo.model.Tool
import java.util.Locale

@Composable
private fun PanelColumn(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        content()
        Spacer(Modifier.padding(bottom = 12.dp))
    }
}

// ============================================================== Editar

@Composable
fun ToolsPanel(vm: AppViewModel) {
    PanelColumn {
        Text("Animar por zonas", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Hint("Elige una dirección rápida y luego pinta la zona que sí debe moverse.")
        val quick = intArrayOf(7, 0, 1, 6, -1, 2, 5, 4, 3)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("↖", "↑", "↗", "←", "·", "→", "↙", "↓", "↘").forEachIndexed { i, label ->
                Pill(label, false) { if (quick[i] >= 0) vm.addQuickDirection(quick[i]) }
            }
        }
        PillRow(Tool.values().map { it.label }, vm.tool.ordinal) { vm.tool = Tool.values()[it] }
        Hint(vm.tool.hint)
        if (vm.tool.isBrush) {
            LabeledSlider("Tamaño del pincel", vm.brushDp, 6f, 140f, true, suffix = " dp") { vm.brushDp = it }
            LabeledSlider("Borde suave", vm.feather, 0f, 1f, false) { vm.feather = it }
            SwitchRow("🧽 Goma (borrar de esta capa)", vm.eraser) { vm.eraser = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton("Rellenar capa", Modifier.weight(1f), primary = false) { vm.fillLayer(false) }
                ActionButton("Vaciar capa", Modifier.weight(1f), primary = false) { vm.fillLayer(true) }
            }
        }
        if (vm.tool == Tool.ARROW || vm.tool == Tool.ANCHOR || vm.tool == Tool.ERASE_GUIDE) {
            Text(
                "${vm.arrows.size} flechas · ${vm.anchors.size} anclas",
                color = Mist, fontSize = 13.sp
            )
            ActionButton("Borrar todas las flechas y anclas", Modifier.fillMaxWidth(), primary = false) {
                vm.clearGuides()
            }
        }
        SwitchRow("Ver colores de las máscaras", vm.showMasks) { vm.toggleMasks() }
        Hint("Rojo = congelado · Azul = Zona 1 · Verde = Zona 2. Los colores no salen en el vídeo.")
    }
}

// ============================================================== Presets

@Composable
fun PresetsPanel(vm: AppViewModel) {
    PanelColumn {
        Hint("Los presets se suman a lo que ya tienes. Luego ajusta cada efecto en la pestaña Efectos.")
        Text("Anime a color", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        PresetGrid(Presets.all.filter { !it.manga }) { vm.applyPreset(it) }
        Text("Manga blanco y negro", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        PresetGrid(Presets.all.filter { it.manga }) { vm.applyPreset(it) }
        ActionButton("Quitar todos los efectos", Modifier.fillMaxWidth(), primary = false) { vm.clearEffects() }
    }
}

@Composable
private fun PresetGrid(list: List<Preset>, onPick: (Preset) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        list.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { p ->
                    Row(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Dusk1)
                            .clickable { onPick(p) }
                            .padding(horizontal = 12.dp, vertical = 12.dp)
                    ) {
                        Text(p.emoji, fontSize = 18.sp)
                        Text(
                            p.name,
                            color = Ink,
                            fontSize = 13.sp,
                            maxLines = 2,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

// ============================================================== Efectos

@Composable
fun EffectsPanel(vm: AppViewModel) {
    val s = vm.settings
    var category by remember { mutableStateOf("Anime") }
    val categories = listOf("Anime", "Movimiento", "Partículas", "Cámara", "Manga")
    val ids = when (category) {
        "Movimiento" -> setOf("flow", "drift", "ripple", "glint", "sway", "heat")
        "Partículas" -> setOf("rain", "snow", "sakura", "stars", "flies", "fog", "rays", "energy", "speed")
        "Cámara" -> setOf("cam")
        "Manga" -> setOf("style", "speed", "energy")
        else -> setOf("energy", "speed", "ripple", "sway", "heat", "rain", "snow", "sakura")
    }
    PanelColumn {
        Text("Efectos para anime y manga", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            categories.forEach { c -> Pill(c, category == c) { category = c } }
        }
        LabeledSlider("⏱ Duración del loop", vm.exportSettings.loopSec.toFloat(), 2f, 15f, true, suffix = " s") {
            vm.updateExport(vm.exportSettings.copy(loopSec = it.toInt()))
        }
        Hint("Las velocidades se miden en ciclos por loop: así el final empalma perfecto con el inicio.")
        for (def in Effects.all.filter { it.id in ids }) {
            val on = !def.toggleable || (s["${def.id}.on"] ?: 0f) > 0.5f
            SectionCard(
                "${def.emoji}  ${def.title}",
                checked = if (def.toggleable) on else null,
                onCheckedChange = { vm.setSetting("${def.id}.on", if (it) 1f else 0f) }
            ) {
                if (on) {
                    Hint(def.hint)
                    for (p in def.params) {
                        val key = "${def.id}.${p.key}"
                        val value = s[key] ?: p.def
                        if (p.kind == Kind.TOGGLE) {
                            SwitchRow(p.label, value > 0.5f) { vm.setSetting(key, if (it) 1f else 0f) }
                        } else {
                            LabeledSlider(p.label, value, p.min, p.max, p.kind == Kind.INT) { vm.setSetting(key, it) }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================== Exportar

@Composable
fun ExportPanel(vm: AppViewModel) {
    val ctx = LocalContext.current
    val e = vm.exportSettings
    val meta = vm.meta ?: return
    val state = vm.exportState
    val running = state is ExportState.Running

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startExport() else vm.message = "Sin permiso de almacenamiento no se puede guardar en la Galería."
    }

    fun doExport() {
        if (Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            vm.startExport()
        }
    }

    PanelColumn {
        when (state) {
            is ExportState.Running -> {
                SectionCard("Exportando… ${(state.progress * 100).toInt()} %") {
                    VSpace(6)
                    ProgressBar(state.progress)
                    VSpace(10)
                    Hint("Puedes dejar la app abierta. En 4K puede tardar varios minutos.")
                    VSpace(8)
                    ActionButton("Cancelar", Modifier.fillMaxWidth(), primary = false) { vm.cancelExport() }
                }
            }
            is ExportState.Done -> {
                val r = state.result
                SectionCard("✅ Listo: ${r.width}×${r.height} · ${r.fps} fps") {
                    VSpace(4)
                    Hint("Guardado en Galería › ${r.galleryPath}")
                    if (r.reducedFrom != null) {
                        Hint("Tu teléfono no codifica ${r.reducedFrom}, así que se ajustó al máximo que acepta.")
                    }
                    if (r.rotated) {
                        Hint("Se guardó en horizontal con marca de rotación (así lo hace la cámara). Se verá vertical.")
                    }
                    if (r.isPng) {
                        Hint("${r.frames} cuadros PNG sin pérdida. Úsalos en un editor que importe secuencias de imágenes.")
                    }
                    val file = r.file
                    if (!r.isPng && file != null) {
                        VSpace(8)
                        ActionButton("🎬  Enviar a Alight Motion", Modifier.fillMaxWidth()) {
                            if (!ShareUtil.sendToAlight(ctx, file)) {
                                vm.message = "Elige Alight Motion en el menú, o ábrelo e importa el vídeo desde la Galería."
                            }
                        }
                        VSpace(8)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ActionButton("Compartir…", Modifier.weight(1f), primary = false) {
                                ShareUtil.shareChooser(ctx, file)
                            }
                            ActionButton("Abrir Alight", Modifier.weight(1f), primary = false) {
                                if (!ShareUtil.openAlight(ctx)) vm.message = "No encontré Alight Motion instalado."
                            }
                        }
                        VSpace(8)
                        Hint("En Alight Motion: + › Media › Video, elige el archivo y déjalo como la capa de más abajo.")
                    }
                    VSpace(8)
                    ActionButton("Exportar otra versión", Modifier.fillMaxWidth(), primary = false) { vm.dismissExportResult() }
                }
            }
            is ExportState.Failed -> {
                SectionCard("⚠️ No se pudo exportar") {
                    VSpace(4)
                    Text(state.message, color = Danger, fontSize = 13.sp)
                    VSpace(6)
                    Hint("Prueba con menos resolución o 30 fps. Si se repite, envíame este mensaje.")
                }
            }
            ExportState.Idle -> Unit
        }

        if (state !is ExportState.Done) {
            Label("Formato")
            PillRow(listOf("🎬 Vídeo MP4", "🖼 Secuencia PNG"), e.format, enabled = !running) {
                vm.updateExport(e.copy(format = it))
            }
            Label("Resolución")
            PillRow(ExportPlanner.resLabels, e.res, enabled = !running) { vm.updateExport(e.copy(res = it)) }
            Label("Encuadre")
            PillRow(
                listOf("Imagen completa", "9:16 vertical", "16:9 horizontal", "1:1 cuadrado"),
                e.framing, enabled = !running
            ) { vm.updateExport(e.copy(framing = it)) }
            if (e.framing != 0) {
                LabeledSlider("Posición del recorte", e.cropPos, 0f, 1f, false, enabled = !running) {
                    vm.updateExport(e.copy(cropPos = it))
                }
            }
            Label("Cuadros por segundo")
            PillRow(listOf("24", "30", "60"), listOf(24, 30, 60).indexOf(e.fps).coerceAtLeast(0), enabled = !running) {
                vm.updateExport(e.copy(fps = listOf(24, 30, 60)[it]))
            }
            LabeledSlider("Duración del loop", e.loopSec.toFloat(), 2f, 15f, true, enabled = !running, suffix = " s") {
                vm.updateExport(e.copy(loopSec = it.toInt()))
            }
            if (e.format == 0) {
                LabeledSlider("Repetir el loop", e.repeats.toFloat(), 1f, 10f, true, enabled = !running, suffix = " ×") {
                    vm.updateExport(e.copy(repeats = it.toInt()))
                }
                Label("Calidad")
                PillRow(ExportPlanner.qualityLabels, e.quality, enabled = !running) { vm.updateExport(e.copy(quality = it)) }
            }
            SwitchRow("Solo efectos sobre fondo negro", e.overlayOnly, enabled = !running) {
                vm.updateExport(e.copy(overlayOnly = it))
            }
            if (e.overlayOnly) {
                Hint("Exporta solo lluvia, nieve, estrellas, etc. En Alight Motion ponlo encima de tu fondo con fusión Pantalla o Añadir.")
            }

            val (w, h) = ExportPlanner.targetSize(meta.w, meta.h, e)
            val seconds = e.loopSec * (if (e.format == 0) e.repeats else 1)
            val summary = if (e.format == 0) {
                val br = ExportPlanner.bitrate(w, h, e.fps, e.quality)
                val mb = br.toDouble() * seconds / 8.0 / 1_000_000.0
                String.format(
                    Locale.US, "Salida: %d×%d · %d fps · %d s · ~%.0f Mbps · ~%.0f MB",
                    w, h, e.fps, seconds, br / 1_000_000.0, mb
                )
            } else {
                "Salida: ${w}×$h · ${e.loopSec * e.fps} imágenes PNG"
            }
            Text(summary, color = Ink, fontSize = 13.sp)
            val cr = ExportPlanner.crop(meta.w, meta.h, e.framing, e.cropPos)
            if (w > meta.w * cr[2] + 1f || h > meta.h * cr[3] + 1f) {
                Hint("Es más grande que tu imagen, así que se ampliará. Para máxima nitidez usa \"Original\".")
            }
            ActionButton(if (running) "Exportando…" else "📤  Exportar", Modifier.fillMaxWidth(), enabled = !running) {
                doExport()
            }
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(text, color = Mist, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
}
