package com.zeta.fondo.engine

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import com.zeta.fondo.model.MaskStroke
import com.zeta.fondo.model.PointN
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Tres máscaras de 8 bits (ALPHA_8). Se guardan los trazos para poder deshacer
 * y redibujar. Todo acceso a los bitmaps va dentro de synchronized(lock),
 * porque el hilo de OpenGL los lee para subirlos como textura.
 */
class MaskLayers private constructor(val w: Int, val h: Int) {

    val lock = Any()
    val bitmaps: Array<Bitmap> = Array(3) { Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8) }
    private val canvases: Array<Canvas> = Array(3) { Canvas(bitmaps[it]) }
    val strokes: Array<ArrayList<MaskStroke>> = Array(3) { ArrayList<MaskStroke>() }
    val versions = IntArray(3)

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.BLACK
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.BLACK
    }
    private val dstOut = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    private var cachedStroke: MaskStroke? = null
    private var cachedBlur: BlurMaskFilter? = null

    companion object {
        fun create(imgW: Int, imgH: Int, maxSide: Int = 1280): MaskLayers {
            val k = min(1f, maxSide.toFloat() / max(imgW, imgH))
            var w = max(4, (imgW * k).roundToInt())
            val h = max(4, (imgH * k).roundToInt())
            w = (w + 3) / 4 * 4 // ancho múltiplo de 4: filas sin relleno al subir a OpenGL
            return MaskLayers(w, h)
        }
    }

    private fun blurFor(s: MaskStroke): BlurMaskFilter? {
        if (cachedStroke === s) return cachedBlur
        val rPx = s.radius * h
        val blur = rPx * s.feather * 0.9f
        cachedStroke = s
        cachedBlur = if (blur >= 0.5f) BlurMaskFilter(blur, BlurMaskFilter.Blur.NORMAL) else null
        return cachedBlur
    }

    private fun configure(p: Paint, s: MaskStroke) {
        val rPx = s.radius * h
        p.xfermode = if (s.erase) dstOut else null
        p.maskFilter = blurFor(s)
        val blur = rPx * s.feather * 0.9f
        p.strokeWidth = max(1f, rPx * 2f - blur)
    }

    private fun drawDot(s: MaskStroke, pt: PointN) {
        configure(dotPaint, s)
        val r = max(0.5f, dotPaint.strokeWidth / 2f)
        canvases[s.layer].drawCircle(pt.x * w, pt.y * h, r, dotPaint)
    }

    private fun drawFull(s: MaskStroke) {
        val c = canvases[s.layer]
        if (s.fill) {
            dotPaint.maskFilter = null
            dotPaint.xfermode = if (s.erase) dstOut else null
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), dotPaint)
            return
        }
        if (s.points.isEmpty()) return
        if (s.points.size == 1) {
            drawDot(s, s.points[0])
            return
        }
        configure(linePaint, s)
        val path = Path()
        path.moveTo(s.points[0].x * w, s.points[0].y * h)
        for (i in 1 until s.points.size) path.lineTo(s.points[i].x * w, s.points[i].y * h)
        c.drawPath(path, linePaint)
    }

    fun addStroke(s: MaskStroke) {
        synchronized(lock) {
            strokes[s.layer].add(s)
            drawFull(s)
            versions[s.layer]++
        }
    }

    fun extendStroke(s: MaskStroke, pt: PointN) {
        synchronized(lock) {
            val last = s.points.lastOrNull()
            s.points.add(pt)
            if (last == null) {
                drawDot(s, pt)
            } else {
                configure(linePaint, s)
                canvases[s.layer].drawLine(last.x * w, last.y * h, pt.x * w, pt.y * h, linePaint)
            }
            versions[s.layer]++
        }
    }

    fun removeStroke(s: MaskStroke) {
        synchronized(lock) {
            strokes[s.layer].remove(s)
            redraw(s.layer)
        }
    }

    fun setAll(list: List<MaskStroke>) {
        synchronized(lock) {
            for (i in 0..2) strokes[i].clear()
            for (s in list) if (s.layer in 0..2) strokes[s.layer].add(s)
            for (i in 0..2) redraw(i)
        }
    }

    /** Copia de todos los trazos (para guardar el proyecto). */
    fun snapshot(): List<MaskStroke> {
        synchronized(lock) {
            val out = ArrayList<MaskStroke>()
            for (i in 0..2) {
                for (s in strokes[i]) {
                    val c = MaskStroke(s.layer, s.radius, s.feather, s.erase, s.fill)
                    c.points.addAll(s.points)
                    out.add(c)
                }
            }
            return out
        }
    }

    private fun redraw(layer: Int) {
        bitmaps[layer].eraseColor(Color.TRANSPARENT)
        for (s in strokes[layer]) drawFull(s)
        versions[layer]++
    }
}
