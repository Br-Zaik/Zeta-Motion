package com.zeta.fondo.engine

import android.graphics.Bitmap
import com.zeta.fondo.model.Effects

/**
 * Puente entre la interfaz (hilo principal) y el hilo de OpenGL de la vista previa.
 * Todo son referencias @Volatile que se reemplazan enteras: el hilo de OpenGL
 * detecta el cambio comparando identidad y vuelve a subir la textura.
 */
class RenderHub {
    @Volatile var image: Bitmap? = null
    @Volatile var flow: FlowField.Data? = null
    @Volatile var masks: MaskLayers? = null
    @Volatile var params: RenderParams = RenderParams.from(Effects.defaults(), 1f)

    @Volatile var viewScale = 1f
    @Volatile var viewX = 0f
    @Volatile var viewY = 0f
    @Volatile var showMask = true
    @Volatile var renderEnabled = true

    @Volatile var onError: ((String) -> Unit)? = null

    @Volatile private var loopSec = 6f
    @Volatile private var playing = true
    @Volatile private var pausedT = 0f
    @Volatile private var startNs = System.nanoTime()

    fun currentT(): Float {
        if (!playing) return pausedT
        val sec = (System.nanoTime() - startNs) / 1e9
        val t = (sec / loopSec) % 1.0
        return if (t < 0) 0f else t.toFloat()
    }

    fun setLoopSec(sec: Float) {
        val t = currentT()
        loopSec = if (sec > 0.5f) sec else 0.5f
        startNs = System.nanoTime() - (t * loopSec * 1e9).toLong()
    }

    fun setPlaying(p: Boolean) {
        if (p == playing) return
        if (!p) {
            pausedT = currentT()
            playing = false
        } else {
            startNs = System.nanoTime() - (pausedT * loopSec * 1e9).toLong()
            playing = true
        }
    }

    fun setPausedT(t: Float) {
        pausedT = t.coerceIn(0f, 0.9999f)
    }

    fun pausedT(): Float = pausedT
}
