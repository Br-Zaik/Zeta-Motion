package com.zeta.fondo.model

import org.json.JSONObject

/** Punto en coordenadas normalizadas de la imagen (0..1, origen arriba-izquierda). */
data class PointN(val x: Float, val y: Float)

/** Flecha de movimiento en coordenadas normalizadas. */
data class Arrow(val x0: Float, val y0: Float, val x1: Float, val y1: Float)

/** Capas de máscara: 0 = congelar (rojo), 1 = zona 1 (azul), 2 = zona 2 (verde). */
object Layer {
    const val FREEZE = 0
    const val ZONE1 = 1
    const val ZONE2 = 2
}

/**
 * Trazo de pincel sobre una capa de máscara.
 * radius: radio en fracción de la ALTURA de la imagen.
 * feather: suavizado 0..1. fill: rellena/vacía toda la capa.
 */
class MaskStroke(
    val layer: Int,
    val radius: Float,
    val feather: Float,
    val erase: Boolean,
    val fill: Boolean = false
) {
    val points = ArrayList<PointN>()
}

enum class Tool(val label: String, val hint: String) {
    ARROW("➡️ Flechas", "Arrastra para dibujar una flecha: el agua, las nubes o el pelo se moverán hacia donde apunta. Más larga = más rápido. Usa dos dedos para hacer zoom."),
    ANCHOR("📍 Anclas", "Toca para poner un punto fijo que no se mueve. Rodea con anclas la zona que animas para que el movimiento no se escape."),
    FREEZE("🧊 Congelar", "Pinta en rojo lo que NUNCA debe moverse: personajes, casas, rocas y líneas importantes."),
    ZONE1("💧 Zona 1", "Pinta en azul el agua o el cielo. Ahí actúan las ondas, los brillos, la deriva de nubes y los efectos marcados como 'solo en Zona 1'."),
    ZONE2("🌿 Zona 2", "Pinta en verde árboles, hierba o fuego. Ahí actúan el viento y el calor."),
    ERASE_GUIDE("🧽 Quitar guía", "Toca una flecha o un ancla para borrarla."),
    PAN("✋ Mover", "Arrastra con un dedo para moverte y pellizca para acercar o alejar.");

    val isBrush: Boolean get() = this == FREEZE || this == ZONE1 || this == ZONE2
    val layer: Int
        get() = when (this) {
            FREEZE -> Layer.FREEZE
            ZONE1 -> Layer.ZONE1
            ZONE2 -> Layer.ZONE2
            else -> -1
        }
}

enum class EditorTab(val label: String) {
    TOOLS("🖌 Editar"),
    PRESETS("✨ Presets"),
    EFFECTS("🎛 Efectos"),
    EXPORT("📤 Exportar")
}

/** Ajustes de exportación. */
data class ExportSettings(
    val format: Int = 0,        // 0 = MP4, 1 = secuencia PNG
    val res: Int = 3,           // índice en ExportPlanner.resLabels (3 = 1080p)
    val framing: Int = 0,       // 0 completo, 1 = 9:16, 2 = 16:9, 3 = 1:1
    val cropPos: Float = 0.5f,  // posición del recorte 0..1
    val fps: Int = 30,
    val loopSec: Int = 6,
    val repeats: Int = 1,
    val quality: Int = 1,       // 0 alta, 1 máxima, 2 extrema
    val overlayOnly: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject()
        .put("format", format)
        .put("res", res)
        .put("framing", framing)
        .put("cropPos", cropPos.toDouble())
        .put("fps", fps)
        .put("loopSec", loopSec)
        .put("repeats", repeats)
        .put("quality", quality)
        .put("overlayOnly", overlayOnly)

    companion object {
        fun fromJson(j: JSONObject?): ExportSettings {
            if (j == null) return ExportSettings()
            val d = ExportSettings()
            return ExportSettings(
                format = j.optInt("format", d.format).coerceIn(0, 1),
                res = j.optInt("res", d.res).coerceIn(0, 4),
                framing = j.optInt("framing", d.framing).coerceIn(0, 3),
                cropPos = j.optDouble("cropPos", d.cropPos.toDouble()).toFloat().coerceIn(0f, 1f),
                fps = j.optInt("fps", d.fps).let { if (it == 24 || it == 30 || it == 60) it else 30 },
                loopSec = j.optInt("loopSec", d.loopSec).coerceIn(2, 15),
                repeats = j.optInt("repeats", d.repeats).coerceIn(1, 10),
                quality = j.optInt("quality", d.quality).coerceIn(0, 2),
                overlayOnly = j.optBoolean("overlayOnly", d.overlayOnly)
            )
        }
    }
}
