package com.zeta.fondo.ui

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.model.ProjectSummary

@Composable
fun HomeScreen(vm: AppViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importImage(uri)
    }
    var toDelete by remember { mutableStateOf<ProjectSummary?>(null) }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp)
    ) {
        item(span = { GridItemSpan(2) }) {
            Hero(onNew = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            })
        }
        item(span = { GridItemSpan(2) }) {
            Text(
                if (vm.projects.isEmpty()) "Tus fondos aparecerán aquí" else "Tus fondos",
                color = Ink,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        if (vm.projects.isEmpty()) {
            item(span = { GridItemSpan(2) }) {
                Hint(
                    "Toca \"Nuevo fondo animado\" o comparte una imagen desde la Galería, Ibis Paint o Paint Zeta " +
                        "con el botón Compartir y elige Zeta Motion."
                )
            }
        }
        items(vm.projects, key = { it.id }) { p ->
            ProjectCard(p, onOpen = { vm.openProject(p.id) }, onDelete = { toDelete = p })
        }
    }

    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("¿Borrar \"${p.name}\"?") },
            text = { Text("Se borra el proyecto de la app. Los vídeos que ya exportaste siguen en tu Galería.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteProject(p.id)
                    toDelete = null
                }) { Text("Borrar", color = Danger) }
            },
            dismissButton = {
                TextButton(onClick = { toDelete = null }) { Text("Cancelar", color = Ink) }
            },
            containerColor = Dusk1,
            titleContentColor = Ink,
            textContentColor = Mist
        )
    }
}

@Composable
private fun Hero(onNew: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color1, Color2, Color3)
                )
            )
            .padding(20.dp)
    ) {
        Text("Zeta Motion", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            "Anima el agua, el cielo y los árboles de tus fondos de anime y manga sin bajar la resolución.",
            color = Ink.copy(alpha = 0.85f),
            fontSize = 14.sp,
            lineHeight = 20.sp,
            modifier = Modifier.padding(top = 6.dp, bottom = 18.dp)
        )
        ActionButton("＋  Nuevo fondo animado", Modifier.fillMaxWidth(), onClick = onNew)
        Text(
            "Importar → pintar zonas y flechas → elegir efectos → exportar MP4 → Alight Motion",
            color = Ink.copy(alpha = 0.7f),
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 12.dp)
        )
    }
}

private val Color1 = androidx.compose.ui.graphics.Color(0xFF232A5C)
private val Color2 = androidx.compose.ui.graphics.Color(0xFF5B3E7A)
private val Color3 = androidx.compose.ui.graphics.Color(0xFFD9826F)

@Composable
private fun ProjectCard(p: ProjectSummary, onOpen: () -> Unit, onDelete: () -> Unit) {
    val thumb = remember(p.thumb.absolutePath, p.modified) {
        try {
            BitmapFactory.decodeFile(p.thumb.absolutePath)?.asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Dusk1)
            .clickable(onClick = onOpen)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.8f)
                .background(Dusk2)
        ) {
            if (thumb != null) {
                Image(
                    bitmap = thumb,
                    contentDescription = p.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Night.copy(alpha = 0.7f))
                    .clickable(onClick = onDelete),
                contentAlignment = Alignment.Center
            ) {
                Text("🗑", fontSize = 15.sp)
            }
        }
        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Column {
                Text(p.name, color = Ink, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${p.w}×${p.h}", color = Mist, fontSize = 12.sp)
            }
        }
    }
}
