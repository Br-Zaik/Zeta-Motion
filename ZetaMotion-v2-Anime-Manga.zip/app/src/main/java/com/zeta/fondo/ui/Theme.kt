package com.zeta.fondo.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Paleta "hora azul": cielo índigo de anime con acento de atardecer.
val Night = Color(0xFF141830)
val Dusk1 = Color(0xFF1E2446)
val Dusk2 = Color(0xFF2A3160)
val Peach = Color(0xFFFFA385)
val Sky = Color(0xFF8FD3FF)
val Ink = Color(0xFFF0F1FF)
val Mist = Color(0xFFA7ADD4)
val OnPeach = Color(0xFF2B1510)
val Danger = Color(0xFFFF6B7A)

@Composable
fun FondoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Peach,
            onPrimary = OnPeach,
            secondary = Sky,
            onSecondary = Night,
            background = Night,
            onBackground = Ink,
            surface = Dusk1,
            onSurface = Ink,
            surfaceVariant = Dusk2,
            onSurfaceVariant = Mist,
            error = Danger
        ),
        content = content
    )
}
