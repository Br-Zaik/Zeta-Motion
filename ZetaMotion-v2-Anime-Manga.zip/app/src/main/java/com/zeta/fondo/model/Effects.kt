package com.zeta.fondo.model

enum class Kind { FLOAT, INT, TOGGLE }

data class ParamDef(
    val key: String,
    val label: String,
    val min: Float,
    val max: Float,
    val def: Float,
    val kind: Kind = Kind.FLOAT
)

data class EffectDef(
    val id: String,
    val emoji: String,
    val title: String,
    val hint: String,
    val params: List<ParamDef>,
    val toggleable: Boolean = true,
    val defaultOn: Boolean = false
)

object Effects {

    private fun p(key: String, label: String, min: Float, max: Float, def: Float, kind: Kind = Kind.FLOAT) =
        ParamDef(key, label, min, max, def, kind)

    private fun zone(def: Float = 0f) = p("zone", "Solo dentro de la Zona 1 (azul)", 0f, 1f, def, Kind.TOGGLE)

    val all: List<EffectDef> = listOf(
        EffectDef(
            "flow", "➡️", "Flechas de movimiento",
            "Mueve lo que marques con la herramienta Flechas. La velocidad también cambia la deriva de nubes.",
            listOf(
                p("amount", "Distancia del movimiento", 0.05f, 1f, 0.35f),
                p("cycles", "Velocidad (ciclos por loop)", 1f, 8f, 2f, Kind.INT),
                p("reach", "Alcance de cada flecha", 0.05f, 1f, 0.25f)
            ),
            defaultOn = true
        ),
        EffectDef(
            "drift", "☁️", "Deriva de nubes (Zona 1)",
            "Desplaza todo lo pintado en Zona 1 en una dirección. Ideal para cielos y nubes. 0° = derecha, 90° = arriba.",
            listOf(
                p("dir", "Dirección (grados)", 0f, 360f, 0f, Kind.INT),
                p("speed", "Distancia", 0.005f, 0.3f, 0.05f)
            )
        ),
        EffectDef(
            "ripple", "🌊", "Ondas de agua (Zona 1)",
            "Ondulación suave del agua pintada en Zona 1.",
            listOf(
                p("amp", "Fuerza", 0.0005f, 0.012f, 0.003f),
                p("freq", "Tamaño de ondas (más = pequeñas)", 5f, 120f, 40f),
                p("cycles", "Velocidad", 1f, 8f, 2f, Kind.INT)
            )
        ),
        EffectDef(
            "glint", "✨", "Brillos en el agua (Zona 1)",
            "Destellos que aparecen y desaparecen sobre el agua.",
            listOf(
                p("int", "Intensidad", 0f, 2f, 0.8f),
                p("dens", "Densidad", 10f, 200f, 70f),
                p("cycles", "Velocidad", 1f, 8f, 3f, Kind.INT)
            )
        ),
        EffectDef(
            "sway", "🌳", "Viento en árboles (Zona 2)",
            "Balanceo de follaje y hierba pintados en Zona 2. Congela troncos y personajes.",
            listOf(
                p("amp", "Fuerza", 0.0005f, 0.015f, 0.004f),
                p("freq", "Tamaño de ramas (más = pequeñas)", 1f, 30f, 6f),
                p("cycles", "Velocidad", 1f, 6f, 2f, Kind.INT)
            )
        ),
        EffectDef(
            "heat", "🔥", "Fuego y calor (Zona 2)",
            "Distorsión que sube, para llamas, velas y aire caliente.",
            listOf(
                p("amp", "Fuerza", 0.0005f, 0.01f, 0.002f),
                p("freq", "Detalle", 5f, 80f, 30f),
                p("cycles", "Velocidad", 1f, 8f, 3f, Kind.INT)
            )
        ),
        EffectDef(
            "rain", "🌧️", "Lluvia",
            "Tres capas de gotas a distinta velocidad para dar profundidad.",
            listOf(
                p("int", "Intensidad", 0f, 1f, 0.7f),
                p("angle", "Inclinación", -40f, 40f, 10f, Kind.INT),
                p("cycles", "Velocidad", 1f, 16f, 6f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "snow", "❄️", "Nieve",
            "Copos que caen balanceándose.",
            listOf(
                p("int", "Intensidad", 0f, 1f, 0.9f),
                p("size", "Tamaño de copos", 0.3f, 3f, 1f),
                p("cycles", "Velocidad", 1f, 8f, 2f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "sakura", "🌸", "Pétalos de sakura",
            "Pétalos rosados que caen girando.",
            listOf(
                p("int", "Intensidad", 0f, 1f, 0.9f),
                p("size", "Tamaño de pétalos", 0.3f, 3f, 1f),
                p("cycles", "Velocidad", 1f, 6f, 1f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "stars", "⭐", "Estrellas que titilan",
            "Pinta el cielo en Zona 1 para que las estrellas solo salgan ahí.",
            listOf(
                p("int", "Intensidad", 0f, 2f, 1f),
                p("dens", "Cantidad", 10f, 150f, 45f),
                p("cycles", "Velocidad del titileo", 1f, 8f, 3f, Kind.INT),
                zone(1f)
            )
        ),
        EffectDef(
            "flies", "💫", "Luciérnagas",
            "Puntos de luz que flotan y parpadean.",
            listOf(
                p("int", "Intensidad", 0f, 2f, 1f),
                p("dens", "Cantidad (más = más pequeñas)", 2f, 20f, 6f),
                p("cycles", "Velocidad", 1f, 4f, 1f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "fog", "🌫️", "Niebla",
            "Bruma suave que se desplaza.",
            listOf(
                p("int", "Intensidad", 0f, 1f, 0.35f),
                p("scale", "Tamaño (más = más fina)", 0.5f, 10f, 3f),
                p("cycles", "Velocidad", 1f, 4f, 1f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "rays", "☀️", "Rayos de luz",
            "Haces de luz que bajan desde arriba de la imagen.",
            listOf(
                p("int", "Intensidad", 0f, 1.5f, 0.4f),
                p("x", "Origen horizontal", 0f, 1f, 0.3f),
                p("cycles", "Velocidad", 1f, 4f, 1f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "energy", "⚡", "Aura de energía anime",
            "Pulso luminoso radial para poderes, ojos y escenas de combate.",
            listOf(
                p("int", "Intensidad", 0f, 2f, 0.8f),
                p("dens", "Rayos", 4f, 40f, 14f, Kind.INT),
                p("cycles", "Velocidad", 1f, 8f, 2f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "speed", "💨", "Líneas de velocidad manga",
            "Líneas direccionales para carreras, golpes y escenas dinámicas.",
            listOf(
                p("int", "Intensidad", 0f, 1.5f, 0.65f),
                p("angle", "Dirección", -180f, 180f, 0f, Kind.INT),
                p("cycles", "Velocidad", 1f, 10f, 4f, Kind.INT),
                zone()
            )
        ),
        EffectDef(
            "cam", "🎥", "Cámara lenta (zoom y paneo)",
            "Acercamiento o paneo suave que vuelve al inicio al final del loop.",
            listOf(
                p("zoom", "Zoom", 0f, 0.3f, 0.06f),
                p("pan", "Paneo lateral", 0f, 1f, 0f),
                p("cycles", "Velocidad", 1f, 4f, 1f, Kind.INT)
            )
        ),
        EffectDef(
            "style", "🖋️", "Estilo manga",
            "Para páginas en blanco y negro con tramas.",
            listOf(
                p("mono", "Efectos en blanco y negro", 0f, 1f, 0f, Kind.TOGGLE),
                p("snap", "Píxel exacto (protege las tramas)", 0f, 1f, 0f, Kind.TOGGLE)
            ),
            toggleable = false
        )
    )

    private val defaultsMap: Map<String, Float> by lazy {
        val m = LinkedHashMap<String, Float>()
        for (e in all) {
            if (e.toggleable) m["${e.id}.on"] = if (e.defaultOn) 1f else 0f
            for (p in e.params) m["${e.id}.${p.key}"] = p.def
        }
        m
    }

    fun defaults(): Map<String, Float> = defaultsMap

    fun default(key: String): Float = defaultsMap[key] ?: 0f

    /** Apaga todos los efectos menos las flechas. */
    fun allOff(current: Map<String, Float>): Map<String, Float> {
        val m = HashMap(current)
        for (e in all) {
            if (e.toggleable && e.id != "flow") m["${e.id}.on"] = 0f
        }
        m["style.mono"] = 0f
        m["style.snap"] = 0f
        return m
    }
}
