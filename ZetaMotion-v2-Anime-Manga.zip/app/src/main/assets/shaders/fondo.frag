#version 300 es
// Fondo Zeta - shader principal.
// Todo el movimiento depende de uT (0..1 = un loop). Cada efecto usa un número
// ENTERO de ciclos por loop, así el último cuadro empalma con el primero.
precision highp float;
precision highp int;

in vec2 vScreen;
out vec4 fragColor;

uniform sampler2D uImage;
uniform sampler2D uFlow;     // RG: vector de flujo (unidades de imagen por ciclo)
uniform sampler2D uFreeze;   // R: congelar
uniform sampler2D uZone1;    // R: zona 1 (agua / cielo)
uniform sampler2D uZone2;    // R: zona 2 (árboles / fuego)

uniform vec2 uViewOffset;
uniform vec2 uViewScale;
uniform float uFlipY;
uniform float uRotate;
uniform float uT;
uniform float uAspect;       // ancho / alto de la imagen
uniform vec2 uTexSize;
uniform float uShowMask;
uniform float uOverlayOnly;
uniform float uMono;
uniform float uPixelSnap;

uniform vec3 uFlow3;   // encendido, distancia, ciclos
uniform vec2 uDrift;   // deriva en zona 1 (uv por ciclo)
uniform vec3 uRipple;  // fuerza, frecuencia, ciclos
uniform vec3 uGlint;   // intensidad, densidad, ciclos
uniform vec3 uSway;    // fuerza, frecuencia, ciclos
uniform vec3 uHeat;    // fuerza, frecuencia, ciclos
uniform vec4 uRain;    // intensidad, ángulo (rad), ciclos, solo zona 1
uniform vec4 uSnow;    // intensidad, tamaño, ciclos, solo zona 1
uniform vec4 uSakura;  // intensidad, tamaño, ciclos, solo zona 1
uniform vec4 uStars;   // intensidad, densidad, ciclos, solo zona 1
uniform vec4 uFlies;   // intensidad, densidad, ciclos, solo zona 1
uniform vec4 uFog;     // intensidad, escala, ciclos, solo zona 1
uniform vec4 uRays;    // intensidad, origen x, ciclos, solo zona 1
uniform vec4 uEnergy;  // intensidad, rayos, ciclos, solo zona 1
uniform vec4 uSpeed;   // intensidad, ángulo, ciclos, solo zona 1
uniform vec3 uCam;     // zoom, paneo, ciclos

const float TAU = 6.28318530718;

// Hash sin seno (Dave Hoskins, licencia MIT)
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

vec2 hash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy);
}

float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int k = 0; k < 4; k++) {
        v += a * vnoise(p);
        p = p * 2.03 + vec2(17.1, 9.2);
        a *= 0.5;
    }
    return v;
}

float luma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

// 1 cerca de 0, 0 desde e en adelante (suave)
float falloff(float d, float e) {
    return 1.0 - smoothstep(0.0, e, d);
}

vec3 sampleImg(vec2 q) {
    q = clamp(q, vec2(0.0), vec2(1.0));
    if (uPixelSnap > 0.5) {
        q = (floor(q * uTexSize) + 0.5) / uTexSize;
    }
    return texture(uImage, q).rgb;
}

// ---------- Lluvia ----------
float rainLayer(vec2 P, float scale, float cyc, float ang, float seed) {
    float ca = cos(ang);
    float sa = sin(ang);
    vec2 R = vec2(ca * P.x + sa * P.y, -sa * P.x + ca * P.y);
    const float N = 6.0;
    vec2 g = vec2(R.x * scale, R.y * scale * 0.25);
    g.y -= uT * cyc * N;
    vec2 id = floor(g);
    vec2 f = fract(g);
    vec2 idp = vec2(id.x, mod(id.y, N)) + seed;
    vec2 h = hash22(idp);
    float on = step(0.45, hash12(idp + 7.13));
    float x = 0.2 + 0.6 * h.x;
    float len = 0.35 + 0.4 * h.y;
    float y0 = (1.0 - len) * hash12(idp + 3.7);
    float w = falloff(abs(f.x - x), 0.08);
    float v = smoothstep(y0, y0 + 0.08, f.y) * (1.0 - smoothstep(y0 + len - 0.12, y0 + len, f.y));
    return w * v * on;
}

// ---------- Nieve ----------
float snowLayer(vec2 P, float scale, float cyc, float size, float seed) {
    const float N = 5.0;
    vec2 g = P * scale;
    g.y -= uT * cyc * N;
    vec2 id = floor(g);
    vec2 f = fract(g);
    vec2 idp = vec2(id.x, mod(id.y, N)) + seed;
    vec2 h = hash22(idp);
    float on = step(0.5, hash12(idp + 1.7));
    float k = 1.0 + floor(h.y * 2.0);
    vec2 c = vec2(0.5 + 0.28 * sin(TAU * (uT * k + h.x)), 0.25 + 0.5 * h.y);
    float r = clamp(size * (0.06 + 0.08 * h.x), 0.02, 0.2);
    float d = length(f - c);
    return (1.0 - smoothstep(r * 0.35, r, d)) * on;
}

// ---------- Pétalos de sakura ----------
vec4 sakuraLayer(vec2 P, float scale, float cyc, float size, float seed) {
    const float N = 6.0;
    vec2 g = P * scale;
    g.y -= uT * cyc * N;
    g.x += uT * cyc * N;
    vec2 id = floor(g);
    vec2 f = fract(g);
    vec2 idp = mod(id, N) + seed;
    vec2 h = hash22(idp);
    float on = step(0.55, hash12(idp + 4.1));
    vec2 c = vec2(0.5 + 0.2 * sin(TAU * (uT + h.x)), 0.5 + 0.15 * cos(TAU * (uT + h.y)));
    float a = TAU * (uT * (1.0 + floor(h.x * 2.0)) + h.y);
    vec2 d = f - c;
    float ca = cos(a);
    float sa = sin(a);
    d = vec2(ca * d.x - sa * d.y, sa * d.x + ca * d.y);
    float r = clamp(size * (0.08 + 0.06 * h.y), 0.03, 0.25);
    d.x /= r;
    d.y /= r * 0.55;
    float e = length(d);
    float petal = (1.0 - smoothstep(0.7, 1.0, e)) * on;
    vec3 col = mix(vec3(1.0, 0.72, 0.82), vec3(1.0, 0.93, 0.96), clamp(0.5 - d.x * 0.5, 0.0, 1.0));
    return vec4(col, petal);
}

// ---------- Estrellas ----------
vec3 starsLayer(vec2 P, float dens, float cyc) {
    vec2 g = P * dens;
    vec2 id = floor(g);
    vec2 f = fract(g);
    vec2 h = hash22(id + 11.3);
    float present = step(0.62, hash12(id + 5.9));
    vec2 c = 0.2 + 0.6 * h;
    float d = length(f - c);
    float big = step(0.93, hash12(id + 2.2));
    float k = cyc * (1.0 + floor(h.x * 3.0));
    float tw = 0.45 + 0.55 * (0.5 + 0.5 * sin(TAU * (uT * k + h.y)));
    float core = falloff(d, 0.06 + 0.05 * big);
    float glow = falloff(d, 0.3) * 0.25;
    vec2 a = abs(f - c);
    float spikes = big * (falloff(a.x, 0.015) * falloff(a.y, 0.35) + falloff(a.y, 0.015) * falloff(a.x, 0.35));
    float s = (core + glow + spikes * 0.7) * tw * present;
    vec3 col = mix(vec3(0.8, 0.88, 1.0), vec3(1.0, 0.95, 0.8), h.x);
    return col * s;
}

// ---------- Luciérnagas ----------
vec3 fliesLayer(vec2 P, float dens, float cyc) {
    vec2 g = P * dens;
    vec2 id = floor(g);
    vec2 f = fract(g);
    vec2 h = hash22(id + 21.7);
    float present = step(0.55, hash12(id + 8.8));
    float kx = cyc * (1.0 + floor(h.x * 2.0));
    float ky = cyc * (1.0 + floor(h.y * 2.0));
    vec2 c = vec2(0.5 + 0.3 * sin(TAU * (uT * kx + h.y)), 0.5 + 0.3 * sin(TAU * (uT * ky + h.x) + 1.3));
    float d = length(f - c);
    float blink = smoothstep(-0.2, 1.0, sin(TAU * (uT * cyc * 2.0 + h.x)));
    float core = falloff(d, 0.035);
    float glow = falloff(d, 0.18);
    return vec3(0.85, 1.0, 0.45) * (core + glow * glow * 0.6) * blink * present;
}

// ---------- Niebla (fundido de dos fases = loop perfecto) ----------
float fogField(vec2 P, float scale, float cyc) {
    float p1 = fract(uT * cyc);
    float p2 = fract(p1 + 0.5);
    float w1 = 1.0 - abs(2.0 * p1 - 1.0);
    vec2 dir = vec2(0.9, 0.12);
    float a = fbm(P * scale + dir * (p1 - 0.5));
    float b = fbm(P * scale + dir * (p2 - 0.5));
    return mix(b, a, w1);
}

// ---------- Rayos de luz ----------
float raysField(vec2 P, float ox, float cyc) {
    vec2 o = vec2(ox * uAspect, -0.2);
    vec2 v = P - o;
    float ang = atan(v.x, v.y);
    float ph = TAU * uT * cyc;
    float r = sin(ang * 17.0 + ph) + sin(ang * 29.0 - ph * 2.0 + 1.3) + sin(ang * 9.0 + ph + 2.1);
    r = clamp(r / 3.0 * 0.5 + 0.5, 0.0, 1.0);
    r = r * r * r;
    float fall = exp(-length(v) * 1.3);
    return r * fall;
}

float energyField(vec2 P, float rays, float cyc) {
    vec2 q = P - vec2(0.5 * uAspect, 0.5);
    float r = length(q);
    float a = atan(q.y, q.x);
    float pulse = 0.55 + 0.45 * sin(TAU * uT * cyc);
    float spokes = pow(0.5 + 0.5 * sin(a * rays + sin(uT * TAU * cyc) * 2.0), 10.0);
    return spokes * (1.0 - smoothstep(0.08, 0.58, r)) * pulse;
}

float speedField(vec2 P, float angle, float cyc) {
    float a = radians(angle);
    float ca = cos(a);
    float sa = sin(a);
    vec2 q = vec2(ca * P.x + sa * P.y, -sa * P.x + ca * P.y);
    vec2 g = q * vec2(9.0, 34.0);
    g.y -= uT * cyc * 8.0;
    float line = smoothstep(0.47, 0.49, fract(g.y));
    float fade = smoothstep(0.0, 0.18, q.y) * (1.0 - smoothstep(0.55, 1.0, q.y));
    return line * fade * (0.35 + 0.65 * hash12(floor(g)));
}

void main() {
    // Coordenadas de pantalla con origen arriba-izquierda
    vec2 s = vec2(vScreen.x, mix(1.0 - vScreen.y, vScreen.y, uFlipY));
    if (uRotate > 0.5) {
        s = vec2(1.0 - s.y, s.x);
    }

    vec2 uvFrame = uViewOffset + s * uViewScale;

    // Cámara: zoom / paneo suave en loop
    vec2 sc = s;
    if (uCam.x > 0.0 || uCam.y > 0.0) {
        float cph = TAU * uT * uCam.z;
        float zoom = 1.0 + uCam.x * (0.5 - 0.5 * cos(cph)) + 0.12 * uCam.y;
        float margin = 0.5 * (1.0 - 1.0 / zoom);
        sc = (s - 0.5) / zoom + 0.5 + vec2(uCam.y * margin * sin(cph), 0.0);
    }
    vec2 uv = uViewOffset + sc * uViewScale;

    float freeze = texture(uFreeze, uv).r;
    float z1 = texture(uZone1, uv).r;
    float z2 = texture(uZone2, uv).r;
    float move = 1.0 - freeze;
    vec2 asp = vec2(1.0 / uAspect, 1.0);
    vec2 P = vec2(uvFrame.x * uAspect, uvFrame.y);
    vec2 Q = vec2(uv.x * uAspect, uv.y);

    vec3 col = vec3(0.0);

    if (uOverlayOnly < 0.5) {
        // Distorsiones
        vec2 d = vec2(0.0);
        if (uRipple.x > 0.0) {
            vec2 q = Q * uRipple.y;
            float ph = TAU * uT * uRipple.z;
            d += vec2(sin(q.y * 1.7 + ph + sin(q.x * 0.9)), cos(q.x * 1.3 - ph + sin(q.y * 1.1))) * uRipple.x * z1;
        }
        if (uSway.x > 0.0) {
            float n = vnoise(Q * uSway.y);
            float ph = TAU * (uT * uSway.z + n);
            float sw = sin(ph) + 0.35 * sin(2.0 * ph + 1.3);
            d += vec2(sw, 0.3 * cos(ph)) * uSway.x * z2;
        }
        if (uHeat.x > 0.0) {
            vec2 q = Q * uHeat.y;
            float ph = TAU * uT * uHeat.z;
            d += vec2(sin(q.y * 2.0 + ph + vnoise(q) * 3.0), 0.5 * cos(q.x * 1.5 + ph)) * uHeat.x * z2;
        }
        d *= move;

        // Flujo (flechas) + deriva, con fundido de dos fases
        vec2 f = vec2(0.0);
        if (uFlow3.x > 0.5) {
            f += texture(uFlow, uv).rg * uFlow3.y;
        }
        f += uDrift * z1;
        f *= move;

        vec2 base = uv + d * asp;
        if (dot(f, f) > 1e-12) {
            float p1 = fract(uT * uFlow3.z);
            float p2 = fract(p1 + 0.5);
            float w1 = 1.0 - abs(2.0 * p1 - 1.0);
            vec3 c1 = sampleImg(base - f * (p1 - 0.5));
            vec3 c2 = sampleImg(base - f * (p2 - 0.5));
            col = mix(c2, c1, w1);
        } else {
            col = sampleImg(base);
        }

        // Brillos en el agua
        if (uGlint.x > 0.0) {
            vec2 g = Q * uGlint.y;
            vec2 id = floor(g);
            vec2 fq = fract(g);
            vec2 h = hash22(id + 4.4);
            vec2 c = 0.2 + 0.6 * h;
            float dd = length((fq - c) * vec2(0.55, 2.2));
            float tw = 0.5 + 0.5 * sin(TAU * (uT * uGlint.z + h.x));
            float gli = falloff(dd, 0.14) * tw * tw * tw * tw * step(0.5, h.y);
            col += vec3(1.0, 0.98, 0.9) * gli * uGlint.x * z1 * move;
        }
    }

    float bgL = luma(col);

    if (uRays.x > 0.0) {
        float g = mix(1.0, z1, uRays.w);
        vec3 rc = mix(vec3(1.0, 0.92, 0.75), vec3(1.0), uMono);
        col += rc * raysField(P, uRays.y, uRays.z) * uRays.x * g;
    }
    if (uEnergy.x > 0.0) {
        float g = mix(1.0, z1, uEnergy.w);
        vec3 ec = uMono > 0.5 ? vec3(1.0) : vec3(0.28, 0.62, 1.0);
        col += ec * energyField(P, uEnergy.y, uEnergy.z) * uEnergy.x * g;
    }
    if (uSpeed.x > 0.0) {
        float g = mix(1.0, z1, uSpeed.w);
        vec3 sc = uMono > 0.5 ? vec3(1.0) : vec3(0.95, 0.88, 1.0);
        col += sc * speedField(P, uSpeed.y, uSpeed.z) * uSpeed.x * g;
    }
    if (uStars.x > 0.0) {
        float g = mix(1.0, z1, uStars.w);
        vec3 st = starsLayer(P, uStars.y, uStars.z);
        if (uMono > 0.5) {
            st = vec3(luma(st));
        }
        col += st * uStars.x * g;
    }
    if (uFog.x > 0.0) {
        float g = mix(1.0, z1, uFog.w);
        float fv = smoothstep(0.3, 0.85, fogField(P, uFog.y, uFog.z));
        vec3 fc = mix(vec3(0.86, 0.89, 0.95), vec3(1.0), uMono);
        col = mix(col, fc, fv * uFog.x * g);
    }
    if (uRain.x > 0.0) {
        float g = mix(1.0, z1, uRain.w);
        float r = rainLayer(P, 14.0, uRain.z + 2.0, uRain.y, 1.0)
                + 0.7 * rainLayer(P, 24.0, uRain.z + 1.0, uRain.y, 17.0)
                + 0.45 * rainLayer(P, 40.0, uRain.z, uRain.y, 41.0);
        vec3 rc = vec3(0.82, 0.88, 1.0);
        if (uMono > 0.5) {
            rc = bgL > 0.55 ? vec3(0.08) : vec3(0.97);
        }
        col = mix(col, rc, clamp(r, 0.0, 1.0) * uRain.x * g);
    }
    if (uSnow.x > 0.0) {
        float g = mix(1.0, z1, uSnow.w);
        float sn = snowLayer(P, 10.0, uSnow.z + 1.0, uSnow.y * 1.3, 3.0)
                 + 0.8 * snowLayer(P, 18.0, uSnow.z, uSnow.y, 29.0)
                 + 0.6 * snowLayer(P, 30.0, uSnow.z, uSnow.y * 0.8, 53.0);
        col = mix(col, vec3(1.0), clamp(sn, 0.0, 1.0) * uSnow.x * g);
    }
    if (uSakura.x > 0.0) {
        float g = mix(1.0, z1, uSakura.w);
        vec4 pa = sakuraLayer(P, 5.0, uSakura.z + 1.0, uSakura.y * 1.2, 7.0);
        vec4 pb = sakuraLayer(P, 9.0, uSakura.z, uSakura.y, 61.0);
        vec3 ca = pa.rgb;
        vec3 cb = pb.rgb;
        if (uMono > 0.5) {
            ca = vec3(luma(ca));
            cb = vec3(luma(cb));
        }
        col = mix(col, cb, pb.a * uSakura.x * g);
        col = mix(col, ca, pa.a * uSakura.x * g);
    }
    if (uFlies.x > 0.0) {
        float g = mix(1.0, z1, uFlies.w);
        vec3 fl = fliesLayer(P, uFlies.y, uFlies.z);
        if (uMono > 0.5) {
            fl = vec3(luma(fl));
        }
        col += fl * uFlies.x * g;
    }

    if (uShowMask > 0.5) {
        col = mix(col, vec3(1.0, 0.15, 0.25), freeze * 0.45);
        col = mix(col, vec3(0.2, 0.55, 1.0), z1 * 0.4);
        col = mix(col, vec3(0.25, 1.0, 0.45), z2 * 0.4);
    }

    // Dither suave para evitar bandas en cielos y degradados
    col += (hash12(gl_FragCoord.xy) - 0.5) / 255.0;
    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
