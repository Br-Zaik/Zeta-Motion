package com.zeta.fondo.model

/** v39 · Estados del panel inferior. */
enum class PanelState { HIDDEN, COMPACT, EXPANDED;
    /** Deslizar hacia arriba: más panel. */
    fun up(): PanelState = when (this) { HIDDEN -> COMPACT; else -> EXPANDED }
    /** Deslizar hacia abajo: menos panel. */
    fun down(): PanelState = when (this) { EXPANDED -> COMPACT; else -> HIDDEN }
    /** Tocar el asa: abre o cierra las opciones. */
    fun tap(): PanelState = when (this) { HIDDEN -> COMPACT; COMPACT -> EXPANDED; EXPANDED -> COMPACT }
    companion object { fun of(name: String?): PanelState = values().firstOrNull { it.name == name } ?: COMPACT }
}

/**
 * v39 · Medidas del editor (en dp), sin dependencias de Android para poder probarlas.
 *
 * - El panel inferior tiene 3 estados: CONTRAÍDO (solo el asa), COMPACTO (línea de tiempo
 *   fina + herramientas + categorías; predeterminado) y EXPANDIDO (además, las opciones).
 * - El lienzo toma la altura que la imagen necesita a lo ancho (una imagen horizontal no
 *   deja una franja negra enorme): el espacio sobrante se da al panel de opciones.
 * - Cambiar de categoría o herramienta NO cambia nada de esto; el zoom del usuario nunca
 *   se toca. Pantalla completa solo con su botón.
 */
data class EditorLayout(
    val landscape: Boolean,
    val topBar: Float,
    val canvasH: Float,
    val handle: Float,
    val strip: Float,
    val content: Float,
    val toolRow: Float,
    val tabBar: Float,
    val sideW: Float,
    val state: PanelState
) {
    /** Hay sitio para mostrar opciones (panel de la herramienta) sin tapar el lienzo. */
    val showsContent: Boolean get() = content >= MIN_CONTENT_VISIBLE

    companion object {
        const val TOP = 48f
        const val HANDLE = 22f
        const val STRIP = 30f
        const val TOOLS = 56f
        const val TABS = 54f
        const val MIN_CANVAS = 180f
        const val EXPANDED_CONTENT = 220f
        const val MIN_CONTENT_VISIBLE = 96f
        const val SIDE_MARGIN = 20f

        fun compute(widthDp: Float, heightDp: Float, imageAspect: Float, state: PanelState, fullscreen: Boolean): EditorLayout {
            val w = widthDp.coerceAtLeast(1f)
            val h = heightDp.coerceAtLeast(1f)
            if (fullscreen) return EditorLayout(false, 0f, h, 0f, 0f, 0f, 0f, 0f, 0f, state)
            if (w > h * 1.15f) {
                // Horizontal / tableta: lienzo a la izquierda y herramientas en una columna
                // (contraído = la columna se oculta y queda un botón para recuperarla).
                val side = if (state == PanelState.HIDDEN) 0f else (w * 0.38f).coerceIn(280f, 400f).coerceAtMost(w * 0.5f)
                val content = if (state == PanelState.HIDDEN) 0f else (h - STRIP - TOOLS - TABS).coerceAtLeast(0f)
                return EditorLayout(true, TOP, (h - TOP).coerceAtLeast(0f), 0f, STRIP, content, TOOLS, TABS, side, state)
            }
            val avail = (h - TOP - HANDLE).coerceAtLeast(0f)
            val fixed = if (state == PanelState.HIDDEN) 0f else STRIP + TOOLS + TABS
            val reserve = if (state == PanelState.EXPANDED) EXPANDED_CONTENT else 0f
            val maxCanvas = (avail - fixed - reserve).coerceAtLeast(MIN_CANVAS.coerceAtMost(avail - fixed))
            // Altura que necesita la imagen a todo el ancho (+ un pequeño margen).
            val a = if (imageAspect > 0.05f) imageAspect else 1f
            val natural = (w - SIDE_MARGIN) / a + 8f
            val canvas = natural.coerceIn(MIN_CANVAS.coerceAtMost(maxCanvas), maxCanvas.coerceAtLeast(0f))
            val content = (avail - fixed - canvas).coerceAtLeast(0f)
            return if (state == PanelState.HIDDEN)
                EditorLayout(false, TOP, canvas, HANDLE, 0f, 0f, 0f, 0f, 0f, state)
            else EditorLayout(false, TOP, canvas, HANDLE, STRIP, content, TOOLS, TABS, 0f, state)
        }
    }
}

/** Rectángulo (en píxeles) donde se ve la imagen dentro del lienzo, igual que en OpenGL. */
data class ImageRect(val left: Float, val top: Float, val width: Float, val height: Float) {
    fun normX(x: Float): Float = (x - left) / width.coerceAtLeast(1f)
    fun normY(y: Float): Float = (y - top) / height.coerceAtLeast(1f)
    fun contains(x: Float, y: Float): Boolean = x >= left && y >= top && x <= left + width && y <= top + height

    companion object {
        /** Encaja [aspect] (ancho/alto) centrado en un lienzo de [boxW]×[boxH]. */
        fun fit(boxW: Float, boxH: Float, aspect: Float): ImageRect {
            val bw = boxW.coerceAtLeast(1f)
            val bh = boxH.coerceAtLeast(1f)
            val a = if (aspect > 0.01f) aspect else bw / bh
            return if (bw / bh > a) {
                val w = bh * a
                ImageRect((bw - w) / 2f, 0f, w, bh)
            } else {
                val hh = bw / a
                ImageRect(0f, (bh - hh) / 2f, bw, hh)
            }
        }
    }
}

/**
 * Decide qué hace un toque sobre el lienzo. Dos dedos SIEMPRE son zoom/desplazamiento,
 * aunque esté activo el pincel o cualquier herramienta; un dedo solo pinta o dibuja
 * después de moverse más que [slop] (un toque sin mover = punto).
 */
object GestureRules {
    enum class Mode { WAITING, DRAW, TRANSFORM }

    fun next(mode: Mode, pointers: Int, movedPx: Float, slop: Float, toolDraws: Boolean): Mode = when {
        pointers >= 2 -> Mode.TRANSFORM
        mode == Mode.TRANSFORM -> Mode.TRANSFORM          // al soltar un dedo no empieza a pintar
        !toolDraws -> Mode.TRANSFORM                      // herramienta Mover: un dedo desplaza
        // toolDraws = la herramienta usa un dedo (pincel, flecha, ancla, origen…)
        mode == Mode.WAITING && movedPx > slop -> Mode.DRAW
        else -> mode
    }
}
