package com.zeta.fondo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.engine.ModelStore

private fun mb(b: Long) = "${(b + 512 * 1024) / (1024 * 1024)} MB"

/**
 * v48 · Un modelo de IA descargable: tamaño, para qué sirve, Descargar / progreso y Cancelar /
 * Reintentar / Borrar. Se baja una sola vez desde GitHub y se comprueba con SHA-256.
 */
@Composable
fun ModelDownloadCard(vm: AppViewModel, spec: ModelStore.Spec, compact: Boolean = false) {
    val installed = vm.modelInstalled(spec)
    val progress = vm.downloadProgress[spec.id]
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(StudioTile)
        .padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(spec.label, color = StudioText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        if (!compact) Text("${spec.use} · ${mb(spec.bytes)} · ${spec.license}", color = StudioMuted, fontSize = 11.sp)
        when {
            progress != null -> {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = StudioPink)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Descargando ${(progress * 100).toInt()} % de ${mb(spec.bytes)}", color = StudioMuted, fontSize = 11.sp,
                        modifier = Modifier.weight(1f))
                    SmallChoice("Cancelar", false) { vm.cancelDownload(spec) }
                }
            }
            installed -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Descargado y verificado ✓", color = StudioMuted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                if (!compact) SmallChoice("Borrar (${mb(spec.bytes)})", false) { vm.removeModel(spec) }
            }
            else -> {
                vm.downloadError[spec.id]?.let { AiWarn(it) }
                val part = vm.modelPartial(spec)
                if (vm.onMeteredNetwork()) Text("Estás con datos móviles: mejor descárgalo con Wi-Fi.", color = StudioOrange, fontSize = 11.sp)
                SmallChoice(if (part > 0) "Continuar descarga (${mb(spec.bytes - part)} restantes)" else "Descargar IA (${mb(spec.bytes)})", false) {
                    vm.downloadModel(spec)
                }
            }
        }
    }
}

/** v48 · Ajustes › IA: qué modelos hay, cuánto ocupan, descargar o borrar. */
@Composable
fun ModelsPanel(vm: AppViewModel) {
    Column(Modifier.fillMaxSize()) {
        CapHeader("IA") { vm.applyAndClose() }
        PanelScroll {
            Text("La app se instala ligera. Cada IA se descarga solo si la usas, una vez, desde su publicación oficial en " +
                "GitHub, y se comprueba que el archivo es el original (SHA-256). Después funciona sin internet.",
                color = StudioMuted, fontSize = 12.sp, lineHeight = 15.sp)
            ModelDownloadCard(vm, ModelStore.DEPTH)
            ModelDownloadCard(vm, ModelStore.MIDAS)
            vm.modelsRevision
            Text("Ocupan ahora: ${mb(ModelStore.installedBytes())}. La detección de caras, cielo/agua y «Mejorar imagen» " +
                "ya vienen en la app y no necesitan descarga.", color = StudioMuted, fontSize = 11.sp, lineHeight = 14.sp,
                modifier = Modifier.padding(top = 4.dp))
        }
    }
}
