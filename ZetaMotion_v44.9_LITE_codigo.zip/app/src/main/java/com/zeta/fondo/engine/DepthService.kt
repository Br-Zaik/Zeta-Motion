package com.zeta.fondo.engine

import android.app.ActivityManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import com.zeta.fondo.diag.ZetaLog
import java.io.File

/**
 * v49 · La IA de profundidad corre en un PROCESO APARTE (":ia", ver AndroidManifest).
 *
 * Si el teléfono se queda sin memoria, Android cierra solo ese proceso: el editor sigue
 * abierto, la app lo detecta (sin resultado y sin proceso) y vuelve a intentarlo con menos
 * memoria o propone el «2.5D rápido» sin IA. Antes, el cierre se llevaba toda la app.
 *
 * Comunicación por archivos en la carpeta del proyecto (simple y a prueba de cierres):
 * depth_job.txt = "running" | "ok" | "error:<motivo>"; el mapa queda en depth.png/depth.txt.
 */
class DepthService : Service() {

    override fun onBind(intent: Intent): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val dir = intent?.getStringExtra(EXTRA_DIR)?.let { File(it) }
        val image = intent?.getStringExtra(EXTRA_IMAGE)?.let { File(it) }
        val level = intent?.getIntExtra(EXTRA_LEVEL, 0) ?: 0
        if (dir == null || image == null) { stopSelf(startId); return START_NOT_STICKY }
        ModelStore.dir = File(filesDir, "models_dl")
        try { ZetaLog.init(filesDir) } catch (_: Throwable) {}
        val status = File(dir, JOB)
        status.writeText("running")
        Thread({
            val result = try {
                val est = DepthEstimator(this).apply { this.level = level }
                kotlinx.coroutines.runBlocking { est.estimate(dir, image) }
                "ok"
            } catch (e: Throwable) {
                ZetaLog.warn("depth", "proceso IA: ${e.javaClass.simpleName} ${e.message}")
                "error:" + (e.message ?: e.javaClass.simpleName).take(200).replace('\n', ' ')
            }
            status.writeText(result)
            stopSelf(startId)
            // Libera TODA la memoria nativa de ONNX Runtime: el proceso :ia termina aquí.
            android.os.Process.killProcess(android.os.Process.myPid())
        }, "zeta-ia").apply { priority = Thread.NORM_PRIORITY - 1 }.start()
        return START_NOT_STICKY
    }

    companion object {
        const val EXTRA_DIR = "dir"
        const val EXTRA_IMAGE = "image"
        const val EXTRA_LEVEL = "level"
        const val JOB = "depth_job.txt"
        private const val PROCESS_SUFFIX = ":ia"

        fun start(ctx: Context, projectDir: File, image: File, level: Int) {
            File(projectDir, JOB).delete()
            ctx.startService(Intent(ctx, DepthService::class.java)
                .putExtra(EXTRA_DIR, projectDir.path).putExtra(EXTRA_IMAGE, image.path).putExtra(EXTRA_LEVEL, level))
        }

        /** Estado escrito por el proceso :ia (null = aún no empezó). */
        fun status(projectDir: File): String? = File(projectDir, JOB).takeIf { it.isFile }?.readText()?.trim()

        private fun iaProcess(ctx: Context): ActivityManager.RunningAppProcessInfo? =
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).runningAppProcesses
                ?.firstOrNull { it.processName == ctx.packageName + PROCESS_SUFFIX }

        fun running(ctx: Context): Boolean = iaProcess(ctx) != null

        /** Cancelar: se cierra el proceso :ia (es de la propia app, mismo usuario). */
        fun cancel(ctx: Context, projectDir: File) {
            iaProcess(ctx)?.let { android.os.Process.killProcess(it.pid) }
            File(projectDir, JOB).delete()
        }

        /** Nivel de memoria inicial según la RAM del teléfono. */
        fun initialLevel(ctx: Context): Int {
            val mi = ActivityManager.MemoryInfo()
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            val gb = mi.totalMem / (1024.0 * 1024 * 1024)
            return when { gb >= 7.0 -> 0; gb >= 4.5 -> 1; else -> 2 }
        }
    }
}
