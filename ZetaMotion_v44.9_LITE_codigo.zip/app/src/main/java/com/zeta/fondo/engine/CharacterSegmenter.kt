package com.zeta.fondo.engine

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import com.zeta.fondo.diag.ZetaLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.coroutines.coroutineContext

/**
 * v46 · IA de recorte y relleno, en el teléfono y sin internet.
 *
 * - (v49: el recorte con isnetis se quitó de Zeta Motion; está en el módulo para Zeta Paint.)
 *   Antes: máscara del personaje con isnetis (SkyTNT anime-segmentation, Apache-2.0;
 *   ONNX publicado por rembg). Entrada fija 1x3x1024x1024. Va a la capa Proteger.
 * - [fillBackground]: rellena lo que hay detrás del personaje. Con MI-GAN importado por el
 *   usuario (no viene en el APK: sus pesos solo se publican en Hugging Face / Google Drive)
 *   se usa la IA; si no, el relleno pull-push de [CutoutMath.fill].
 * Un modelo a la vez; cada sesión se cierra al terminar.
 */
class CharacterSegmenter(private val ctx: Context) {

    val miganAvailable: Boolean get() = File(OnnxAssets.userDir(ctx), MIGAN_ASSET).isFile

    /**
     * Fondo sin el personaje (placa) para el 2.5D. [hole] = máscara del personaje del mismo
     * tamaño que [src] (0..255). Devuelve ARGB y si se usó MI-GAN.
     */
    suspend fun fillBackground(src: Bitmap, hole: ByteArray): Pair<IntArray, Boolean> = withContext(Dispatchers.Default) {
        val w = src.width; val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        // Un poco más ancho que el personaje: el contorno (líneas, halo) no se copia al fondo.
        val grown = CutoutMath.dilate(hole, w, h, (maxOf(w, h) / 160).coerceIn(2, 12))
        coroutineContext.ensureActive()
        if (miganAvailable) {
            try {
                return@withContext migan(px, w, h, grown) to true
            } catch (e: kotlinx.coroutines.CancellationException) { throw e
            } catch (e: Throwable) {
                ZetaLog.warn("cutout", "MI-GAN falló, se usa el relleno básico: ${e.javaClass.simpleName} ${e.message}")
            }
        }
        CutoutMath.fill(px, w, h, grown) to false
    }

    /** MI-GAN «pipeline» (create_onnx_pipeline.py): image uint8 1x3xHxW, mask uint8 1x1xHxW (255 = conocido) → result uint8. */
    private fun migan(px: IntArray, w: Int, h: Int, hole: ByteArray): IntArray {
        val model = File(OnnxAssets.userDir(ctx), MIGAN_ASSET)
        val n = w * h
        val img = ByteBuffer.allocateDirect(3 * n).order(ByteOrder.nativeOrder())
        for (c in 0..2) for (i in 0 until n) img.put(((px[i] shr (16 - 8 * c)) and 0xFF).toByte())
        img.rewind()
        val mask = ByteBuffer.allocateDirect(n).order(ByteOrder.nativeOrder())
        for (i in 0 until n) mask.put(if ((hole[i].toInt() and 0xFF) >= 128) 0 else 255.toByte())
        mask.rewind()
        val env = OrtEnvironment.getEnvironment()
        val out = IntArray(n)
        OrtSession.SessionOptions().use { opt ->
            opt.setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(1, 4))
            env.createSession(model.path, opt).use { session ->
                OnnxTensor.createTensor(env, img, longArrayOf(1, 3, h.toLong(), w.toLong()), OnnxJavaType.UINT8).use { ti ->
                    OnnxTensor.createTensor(env, mask, longArrayOf(1, 1, h.toLong(), w.toLong()), OnnxJavaType.UINT8).use { tm ->
                        session.run(mapOf("image" to ti, "mask" to tm)).use { res ->
                            val bb = (res[0] as OnnxTensor).byteBuffer
                            if (bb.remaining() != 3 * n) throw IllegalStateException("MI-GAN devolvió ${bb.remaining()} bytes")
                            for (i in 0 until n) {
                                val r = bb.get(i).toInt() and 0xFF; val g = bb.get(n + i).toInt() and 0xFF; val b = bb.get(2 * n + i).toInt() and 0xFF
                                out[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                            }
                        }
                    }
                }
            }
        }
        // Fuera del hueco, siempre la imagen original.
        for (i in 0 until n) if ((hole[i].toInt() and 0xFF) < 128) out[i] = px[i] or (0xFF shl 24)
        return out
    }

    /** Copia un MI-GAN elegido por el usuario y comprueba que ONNX Runtime lo abre con las entradas esperadas. */
    fun importMigan(input: java.io.InputStream): String {
        val dir = OnnxAssets.userDir(ctx)
        val tmp = File(dir, "$MIGAN_ASSET.part")
        input.use { i -> tmp.outputStream().use { i.copyTo(it, 1 shl 16) } }
        try {
            val env = OrtEnvironment.getEnvironment()
            OrtSession.SessionOptions().use { opt ->
                env.createSession(tmp.path, opt).use { s ->
                    if (!s.inputNames.containsAll(listOf("image", "mask")))
                        throw IllegalArgumentException("No es el «pipeline» ONNX de MI-GAN (entradas: ${s.inputNames})")
                }
            }
        } catch (e: Throwable) { tmp.delete(); throw e }
        val sha = sha256(tmp)
        val f = File(dir, MIGAN_ASSET)
        f.delete()
        if (!tmp.renameTo(f)) throw IllegalStateException("No se pudo guardar el modelo")
        File(dir, "$MIGAN_ASSET.sha256").writeText(sha)
        return sha
    }

    fun removeMigan() { File(OnnxAssets.userDir(ctx), MIGAN_ASSET).delete(); File(OnnxAssets.userDir(ctx), "$MIGAN_ASSET.sha256").delete() }
    fun miganSha(): String? = File(OnnxAssets.userDir(ctx), "$MIGAN_ASSET.sha256").takeIf { it.isFile }?.readText()

    private fun sha256(f: File): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        f.inputStream().use { i -> val b = ByteArray(1 shl 16); while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    companion object {
        const val MIGAN_ASSET = "migan_pipeline.onnx"
    }
}
