"""v40 · Comprobaciones automáticas de los efectos mejorados con el shader REAL (Mesa EGL):
1) el shader compila y enlaza; 2) cada efecto cambia la imagen; 3) bucle perfecto:
el cuadro t=1 es idéntico al t=0 (la explosión, que es un evento, debe terminar vacía).
Uso: python3 tools/check_v40_fx.py
"""
import os, sys
from pathlib import Path
os.environ.setdefault('FX_W', '160'); os.environ.setdefault('FX_H', '160')
sys.argv = [sys.argv[0], '']
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np
import fx_render as fx

def frame(preset, t, off=False):
    p = dict(fx.PRESETS[preset])
    if off:
        p = {k: v for k, v in p.items() if k.startswith('_')}
    fx.apply(p)
    return fx.render(t)[..., :3].astype(int)

fails = 0
for name in fx.PRESETS:
    base = frame(name, .37, off=True)
    times = (.31, .33) if name == 'bolt' else (.05, .2, .37, .6)
    changed = max(np.abs(frame(name, t) - base).max() for t in times)
    if name.startswith('blast'):
        end = np.abs(frame(name, .999) - frame(name, .999, off=True)).max()
        loop_ok = end <= 2
        detail = f'final vacío (dif {end})'
    elif name == 'bolt':
        loop_ok = np.abs(frame(name, 0.0) - frame(name, 1.0)).max() <= 2
        detail = 'bucle'
    else:
        d = np.abs(frame(name, 0.0) - frame(name, 1.0)).max()
        loop_ok = d <= 2
        detail = f'bucle t0=t1 (dif {d})'
    ok = changed > 10 and loop_ok
    fails += not ok
    print(('OK   ' if ok else 'FALLO'), f'{name:14s} efecto visible (dif {changed}) · {detail}')
print('fallos:', fails)
sys.exit(1 if fails else 0)
