"""v40 · Regenera las miniaturas animadas (tiras de 8 cuadros de 128x128, WebP) de los
efectos mejorados, renderizadas con el MISMO shader de la app (fondo.frag) y los
valores por defecto de cada efecto. Uso: python3 tools/make_thumbs.py [salida]
Requiere Mesa (EGL sin pantalla). Las escenas de fondo son simples y sin personajes.
"""
import os, sys
from pathlib import Path
os.environ['FX_W'] = os.environ['FX_H'] = '256'      # se reduce a 128: bordes suaves
sys.argv = [sys.argv[0], ''] + sys.argv[1:]
sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np
from PIL import Image
import fx_render as fx

OUT = Path(sys.argv[2] if len(sys.argv) > 2 else Path(__file__).resolve().parents[1] / 'app/src/main/assets/thumbs')
# (efecto de la app, preset de escena, inicio y fin del bucle a mostrar)
JOBS = [
    ('blast', 'blast', 0.0, 0.8),
    ('smoke', 'smoke', 0.0, 1.0),
    ('flame', 'flame_thumb', 0.0, 1.0),
    ('energy', 'energy_rays', 0.0, 1.0),
    ('electric', 'electric', 0.0, 1.0),
    ('bolt', 'bolt', 0.296, 0.37),
    ('waterfall', 'waterfall', 0.0, 1.0),
    ('shore', 'shore_thumb', 0.0, 1.0),
    ('water', 'water', 0.0, 1.0),
    ('rays', 'rays', 0.0, 1.0),
    # sin siluetas de personaje repetidas: cada uno sobre un motivo propio
    ('blackaura', 'blackaura_thumb', 0.0, 1.0),
    ('dispersion', 'dispersion_thumb', 0.0, 1.0),
    ('reveal', 'reveal_thumb', 0.0, 1.0),
]
for app_id, preset, t0, t1 in JOBS:
    fx.apply(fx.PRESETS[preset])
    frames = []
    for i in range(8):
        a = fx.render(t0 + (t1 - t0) * (i + .5) / 8)[..., :3]
        frames.append(np.asarray(Image.fromarray(a).resize((128, 128), Image.LANCZOS)))
    strip = Image.fromarray(np.concatenate(frames, axis=1))
    strip.save(OUT / f'{app_id}.webp', 'WEBP', quality=80, method=6)
    print(app_id, (OUT / f'{app_id}.webp').stat().st_size, 'bytes')
