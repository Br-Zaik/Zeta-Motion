"""v40 · Render de efectos con el shader REAL (fondo.frag) en OpenGL ES 3 por EGL sin
pantalla (Mesa). Llena el bloque std140 ZetaParams consultando los offsets como la app.
Uso: python3 tools/fx_render.py <imagen> <carpeta_salida> [efectos...]
"""
import ctypes as C, os, re, sys, json
from pathlib import Path
import numpy as np
from PIL import Image
os.environ.setdefault('EGL_PLATFORM', 'surfaceless')
E = C.CDLL('libEGL.so.1'); I = C.c_int; U = C.c_uint; P = C.c_void_p; F = C.c_float
E.eglGetProcAddress.restype = P; E.eglGetProcAddress.argtypes = [C.c_char_p]
def egl(name, rest, args):
    f = getattr(E, name); f.restype = rest; f.argtypes = args; return f
W = int(os.environ.get('FX_W', 384)); H = int(os.environ.get('FX_H', 384))
d = egl('eglGetDisplay', P, [P])(None); ma = I(); mi = I()
assert egl('eglInitialize', U, [P, C.POINTER(I), C.POINTER(I)])(d, C.byref(ma), C.byref(mi))
assert egl('eglBindAPI', U, [U])(0x30A0)
attrs = (I * 13)(0x3024, 8, 0x3023, 8, 0x3022, 8, 0x3033, 1, 0x3040, 0x40, 0x3021, 8, 0x3038)
config = P(); n = I()
assert egl('eglChooseConfig', U, [P, C.POINTER(I), C.POINTER(P), I, C.POINTER(I)])(d, attrs, C.byref(config), 1, C.byref(n)) and n.value
surf = egl('eglCreatePbufferSurface', P, [P, P, C.POINTER(I)])(d, config, (I * 5)(0x3057, W, 0x3056, H, 0x3038))
ctx = egl('eglCreateContext', P, [P, P, P, C.POINTER(I)])(d, config, None, (I * 3)(0x3098, 3, 0x3038))
assert ctx and egl('eglMakeCurrent', U, [P, P, P, P])(d, surf, surf, ctx)
def gl(name, rest, args): return C.CFUNCTYPE(rest, *args)(E.eglGetProcAddress(name.encode()))
G = {}
for name, ret, args in [
    ('glCreateShader', U, [U]), ('glShaderSource', None, [U, I, C.POINTER(C.c_char_p), P]), ('glCompileShader', None, [U]),
    ('glGetShaderiv', None, [U, U, C.POINTER(I)]), ('glGetShaderInfoLog', None, [U, I, P, P]), ('glCreateProgram', U, []),
    ('glAttachShader', None, [U, U]), ('glLinkProgram', None, [U]), ('glGetProgramiv', None, [U, U, C.POINTER(I)]),
    ('glGetProgramInfoLog', None, [U, I, P, P]), ('glUseProgram', None, [U]), ('glGetUniformLocation', I, [U, C.c_char_p]),
    ('glUniform1f', None, [I, F]), ('glUniform1i', None, [I, I]), ('glUniform2f', None, [I, F, F]),
    ('glGenTextures', None, [I, C.POINTER(U)]), ('glBindTexture', None, [U, U]), ('glActiveTexture', None, [U]),
    ('glTexParameteri', None, [U, U, I]), ('glTexImage2D', None, [U, I, I, I, I, I, U, U, P]),
    ('glTexImage3D', None, [U, I, I, I, I, I, I, U, U, P]), ('glGenVertexArrays', None, [I, C.POINTER(U)]),
    ('glBindVertexArray', None, [U]), ('glGenBuffers', None, [I, C.POINTER(U)]), ('glBindBuffer', None, [U, U]),
    ('glBufferData', None, [U, C.c_ssize_t, P, U]), ('glEnableVertexAttribArray', None, [U]),
    ('glVertexAttribPointer', None, [U, I, U, U, I, P]), ('glViewport', None, [I, I, I, I]), ('glDrawArrays', None, [U, I, I]),
    ('glReadPixels', None, [I, I, I, I, U, U, P]), ('glGetError', U, []),
    ('glGetUniformBlockIndex', U, [U, C.c_char_p]), ('glUniformBlockBinding', None, [U, U, U]),
    ('glGetActiveUniformBlockiv', None, [U, U, U, C.POINTER(I)]), ('glBindBufferBase', None, [U, U, U]),
    ('glGetUniformIndices', None, [U, I, C.POINTER(C.c_char_p), C.POINTER(U)]),
    ('glGetActiveUniformsiv', None, [U, I, C.POINTER(U), U, C.POINTER(I)]),
]:
    G[name] = gl(name, ret, args)
g = type('g', (), {k: staticmethod(v) for k, v in G.items()})
root = Path(os.environ.get('FX_DIR') or Path(__file__).resolve().parents[1] / 'app/src/main/assets/shaders')
prog = g.glCreateProgram()
for kind, file in [(0x8B31, 'fondo.vert'), (0x8B30, 'fondo.frag')]:
    sh = g.glCreateShader(kind); src = C.c_char_p((root / file).read_bytes())
    g.glShaderSource(sh, 1, C.byref(src), None); g.glCompileShader(sh); ok = I(); g.glGetShaderiv(sh, 0x8B81, C.byref(ok))
    log = C.create_string_buffer(30000); g.glGetShaderInfoLog(sh, 30000, None, log)
    if not ok.value: print(file, log.value.decode()); sys.exit(1)
    g.glAttachShader(prog, sh)
g.glLinkProgram(prog); ok = I(); g.glGetProgramiv(prog, 0x8B82, C.byref(ok))
if not ok.value:
    log = C.create_string_buffer(30000); g.glGetProgramInfoLog(prog, 30000, None, log); print(log.value.decode()); sys.exit(1)
g.glUseProgram(prog)
blk = g.glGetUniformBlockIndex(prog, b'ZetaParams'); g.glUniformBlockBinding(prog, blk, 1)
size = I(); g.glGetActiveUniformBlockiv(prog, blk, 0x8A40, C.byref(size))
ubo = U(); g.glGenBuffers(1, C.byref(ubo)); g.glBindBuffer(0x8A11, ubo); g.glBindBufferBase(0x8A11, 1, ubo)
frag = (root / 'fondo.frag').read_text()
body = frag[frag.index('uniform ZetaParams'):]
body = body[:body.index('};')]
fields = []
for typ, names in re.findall(r'^\s*(vec4|vec3|vec2|int|float)\s+([^;]+);', body, re.M):
    for nm_ in names.split(','):
        m_ = re.match(r'\s*(\w+)(\[\d+\])?', nm_); fields.append((typ, m_.group(1), m_.group(2) or ''))
offs = {}
for typ, name, arr in fields:
    nm = name + ('[0]' if arr else '')
    s = C.c_char_p(nm.encode()); idx = U(); g.glGetUniformIndices(prog, 1, C.byref(s), C.byref(idx))
    o = I(); g.glGetActiveUniformsiv(prog, 1, C.byref(idx), 0x8A3B, C.byref(o))
    st = I(); g.glGetActiveUniformsiv(prog, 1, C.byref(idx), 0x8A3C, C.byref(st))
    offs[name] = (typ, o.value, st.value, int(arr[1:-1]) if arr else 0)
buf = np.zeros(size.value, dtype=np.uint8)
def put(name, *vals, index=0):
    typ, o, stride, cnt = offs[name]
    o += index * max(stride, 16)
    if typ == 'int': buf[o:o + 4] = np.frombuffer(np.int32(int(vals[0])).tobytes(), np.uint8)
    else:
        a = np.array(vals, dtype=np.float32); buf[o:o + 4 * len(a)] = np.frombuffer(a.tobytes(), np.uint8)
def reset():
    buf[:] = 0
    for name, (typ, o, st, cnt) in offs.items():
        if typ == 'int' and name.startswith('uMask'): put(name, -2)
    put('uLoopInfo', 6, -1, -1, 0); put('uAspect', W / H); put('uCharAspect', 1)
    for k in ('uEventPhase', 'uEventPhase2'): put(k, -1, -1, -1, -1)
    for i in range(4): put('uElementPose', .5, .5, .3, 0, index=i)
def loc(n): return g.glGetUniformLocation(prog, n.encode())
def setf(n, *v):
    l = loc(n)
    if len(v) == 1: g.glUniform1f(l, *v)
    else: g.glUniform2f(l, *v)
ids = (U * 4)(); g.glGenTextures(4, ids)
def tex2d(unit, data, ww, hh, internal, fmt):
    g.glActiveTexture(0x84C0 + unit); g.glBindTexture(0x0DE1, ids[unit])
    for p_, v_ in ((0x2801, 0x2601), (0x2800, 0x2601), (0x2802, 0x812F), (0x2803, 0x812F)): g.glTexParameteri(0x0DE1, p_, v_)
    g.glTexImage2D(0x0DE1, 0, internal, ww, hh, 0, fmt, 0x1401, data.ctypes.data)
src = sys.argv[1] if len(sys.argv) > 1 else None
if src:
    im = Image.open(src).convert('RGBA'); s = min(im.width, im.height)
    im = im.crop(((im.width - s) // 2, (im.height - s) // 4, (im.width - s) // 2 + s, (im.height - s) // 4 + s)).resize((W, H), Image.LANCZOS)
    img = np.ascontiguousarray(np.asarray(im, dtype=np.uint8))
else:
    y, x = np.mgrid[0:H, 0:W]; img = np.zeros((H, W, 4), np.uint8); img[..., 0] = 40; img[..., 1] = (60 + y / H * 80).astype('uint8'); img[..., 2] = 110; img[..., 3] = 255
tex2d(0, img, W, H, 0x8058, 0x1908)
zero = np.zeros((H, W), np.uint8); tex2d(1, zero, W, H, 0x8229, 0x1903)
g.glActiveTexture(0x84C0 + 2); g.glBindTexture(0x8C1A, ids[2])
for p_, v_ in ((0x2801, 0x2601), (0x2800, 0x2601), (0x2802, 0x812F), (0x2803, 0x812F)): g.glTexParameteri(0x8C1A, p_, v_)
atlas = np.zeros((12, H, W), np.uint8); g.glTexImage3D(0x8C1A, 0, 0x8229, W, H, 12, 0, 0x1903, 0x1401, atlas.ctypes.data)
tex2d(3, np.zeros((4, 4, 4), np.uint8), 4, 4, 0x8058, 0x1908)
for i, nm in enumerate(['uImage', 'uFlow', 'uMasks', 'uCharacter']): g.glUniform1i(loc(nm), i)
vao = U(); vbo = U(); g.glGenVertexArrays(1, C.byref(vao)); g.glBindVertexArray(vao); g.glGenBuffers(1, C.byref(vbo)); g.glBindBuffer(0x8892, vbo)
quad = np.array([-1, -1, 1, -1, -1, 1, 1, 1], dtype='float32'); g.glBufferData(0x8892, quad.nbytes, quad.ctypes.data, 0x88E4)
g.glEnableVertexAttribArray(0); g.glVertexAttribPointer(0, 2, 0x1406, 0, 8, None); g.glViewport(0, 0, W, H)
setf('uViewScale', 1, 1); setf('uTexSize', W, H); setf('uFlipY', 0)   # como en pantalla: origen arriba-izquierda, y hacia abajo
if loc('uAspect') >= 0: setf('uAspect', 1)
reset()
def render(t):
    g.glBindBuffer(0x8A11, ubo); g.glBufferData(0x8A11, buf.nbytes, buf.ctypes.data, 0x88E8)
    setf('uT', t); g.glDrawArrays(5, 0, 4)
    a = np.zeros((H, W, 4), np.uint8); g.glReadPixels(0, 0, W, H, 0x1908, 0x1401, a.ctypes.data)
    assert g.glGetError() == 0
    return a[::-1]

# ---------------------------------------------------------------- escenas de prueba
PRESETS = {
    'blast': {'uFxBlast': (.9, .65, 1, 0), 'uBlastShape': (0, .8, .7, 0), 'uBlastMore': (0, .65, .5, 0), 'uMotionBlast': (1, 0, .5, .5)},
    'blast_mush': {'uFxBlast': (.9, .65, 1, 0), 'uBlastShape': (1, .8, .7, 0), 'uBlastMore': (0, .65, .5, 0), 'uMotionBlast': (1, 0, .5, .6)},
    'blast_manga': {'uFxBlast': (.9, .65, 1, 0), 'uBlastShape': (2, .8, .7, 0), 'uBlastMore': (0, .65, .5, 0), 'uMotionBlast': (1, 0, .5, .5)},
    'smoke': {'_scene': 'dusk', 'uFxSmoke': (.6, 3, 1, 0), 'uSmokeShape': (0, .5, .35, 0), 'uSmokeControl': (0, .95, .55, 1), 'uMotionSmoke': (0, -1, .5, .82)},
    'smoke_threads': {'_scene': 'dusk', 'uFxSmoke': (.6, 3, 1, 0), 'uSmokeShape': (1, .5, .35, 0), 'uSmokeControl': (0, .95, .55, 1), 'uMotionSmoke': (0, -1, .5, .82)},
    'smoke_fill': {'_scene': 'dusk', 'uFxSmoke': (.6, 3, 1, 0), 'uSmokeShape': (0, .5, .35, 1), 'uSmokeControl': (0, .95, .55, 1), 'uMotionSmoke': (1, 0, .5, .5)},
    'smoke_ink': {'_scene': 'dusk', 'uFxSmoke': (.7, 3, 1, 0), 'uSmokeShape': (2, .5, .35, 0), 'uSmokeControl': (2, .95, .55, 1), 'uMotionSmoke': (0, -1, .5, .82)},
    'smoke_crawl': {'_scene': 'dusk', 'uFxSmoke': (.6, 3, 1, 0), 'uSmokeShape': (3, .5, .35, 0), 'uSmokeControl': (0, .95, .55, 1), 'uMotionSmoke': (1, 0, .2, .8)},
    'smoke_black': {'_scene': 'dusk', 'uFxSmoke': (.6, 3, 1, 0), 'uSmokeShape': (0, .5, .35, 0), 'uSmokeControl': (1, .95, .55, 1), 'uMotionSmoke': (0, -1, .5, .82)},
    'flame': {'_scene': 'night', '_masks': {4: 'firebase'}, 'uMaskFlame': (4,), 'uFxFlame': (.7, 1, 2, 0), 'uFlameShape': (0, .5, .25, .5), 'uFlameExtra': (.5, 0, 0, 0), 'uFlameBox': (.33, .72, .67, .82)},
    'flame_torch': {'_scene': 'night', '_masks': {4: 'torchbase'}, 'uMaskFlame': (4,), 'uFxFlame': (.7, 1, 2, 0), 'uFlameShape': (2, .5, .25, .5), 'uFlameExtra': (.5, .5, 0, 0), 'uFlameBox': (.45, .70, .55, .78)},
    'energy_rays': {'_scene': 'night', 'uEnergy': (.8, 14, 2, 0), 'uEnergyShape': (0, .5, .6, 0), 'uMotionEnergy': (1, 0, .5, .5)},
    'energy_aura': {'_scene': 'night', '_masks': {0: 'person'}, 'uEnergy': (.8, 14, 2, 0), 'uEnergyShape': (1, .5, .6, 0), 'uMotionEnergy': (1, 0, .5, .5)},
    'energy_rings': {'_scene': 'night', 'uEnergy': (.8, 14, 2, 0), 'uEnergyShape': (2, .5, .6, 0), 'uMotionEnergy': (1, 0, .5, .5)},
    'energy_battle': {'_scene': 'night', '_masks': {0: 'person'}, 'uEnergy': (.8, 14, 2, 0), 'uEnergyShape': (3, .5, .6, 0), 'uMotionEnergy': (1, 0, .5, .5)},
    'electric': {'_scene': 'night', 'uFxElectric': (.8, 16, 4, 0), 'uMotionElectric': (1, 0, .5, .5)},
    'bolt': {'_scene': 'night', 'uBolt': (.9, .55, 1, .5)},
    'waterfall': {'_scene': 'cliff', '_masks': {3: 'fall'}, 'uFxWaterfall': (.75, 8, 4, 0), 'uMaskWaterfall': (3,)},
    'shore': {'_scene': 'sea', '_masks': {3: 'sea'}, 'uShore': (.65, 3, 1, 0), 'uShoreMore': (.55, 1, 0, 0), 'uMotionShore': (0, 1, .5, .5), 'uMaskShore': (3,)},
    'water': {'_scene': 'sea', '_masks': {3: 'sea'}, 'uStudioWater': (.4, 1, 0, 0), 'uMaskWater': (3,)},
    'rays': {'_scene': 'day', 'uRays': (.4, .3, 1, 0), 'uMotionRays': (1, 0, .3, 0)},
    'flame_thumb': {'_scene': 'night', '_masks': {4: 'bigfire'}, 'uMaskFlame': (4,), 'uFxFlame': (.7, 1, 2, 0), 'uFlameShape': (0, .5, .25, .5), 'uFlameExtra': (.5, 0, 0, 0), 'uFlameBox': (.3, .70, .7, .80)},
    'shore_thumb': {'_scene': 'beach', '_masks': {3: 'beachwater'}, 'uShore': (.65, 3, 1, 0), 'uShoreMore': (.55, 1, 0, 0), 'uMotionShore': (0, 1, .5, .5), 'uMaskShore': (3,)},
    'blackaura_thumb': {'_scene': 'tower', '_masks': {3: 'towerarea'}, 'uFxBlackaura': (.55, 2.5, 2, 0), 'uMaskBlackaura': (3,)},
    'dispersion_thumb': {'_scene': 'moon', '_masks': {3: 'moondisc'}, 'uStudioDispersion': (.7, 1, 0, 0), 'uDispersionMore': (28, .7, 0, 0), 'uMaskDispersion': (3,)},
    'reveal_thumb': {'_scene': 'day', 'uFxReveal': (.75, .8, 1, 0), 'uRevealShape': (0, .6, 0, 0), 'uRevealStyle': (0, 0, 0, 0)},
    'blast_energy': {'uFxBlast': (.9, .65, 1, 0), 'uBlastShape': (3, .8, .7, 0), 'uBlastMore': (0, .65, .5, 0), 'uMotionBlast': (1, 0, .5, .5)},
}

def _noise1(x, seed):
    rng = np.random.default_rng(seed); pts = rng.random(64)
    xi = x * 12.0; i = np.floor(xi).astype(int) % 63; f = xi - np.floor(xi); f = f * f * (3 - 2 * f)
    return pts[i] * (1 - f) + pts[i + 1] * f

def vnoise2(x, y, seed, cells=8):
    rng = np.random.default_rng(seed); g = rng.random((cells + 2, cells + 2))
    xs = x * cells; ys = y * cells; xi = np.floor(xs).astype(int) % cells; yi = np.floor(ys).astype(int) % cells
    fx = xs - np.floor(xs); fy = ys - np.floor(ys); fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy)
    a = g[yi, xi]; b = g[yi, xi + 1]; c = g[yi + 1, xi]; d = g[yi + 1, xi + 1]
    return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy

def scene(kind):
    """Fondos de prueba sencillos de estilo anime (sin personajes ni fotos)."""
    y, x = np.mgrid[0:H, 0:W] / np.array([H, W]).reshape(2, 1, 1); y = y[..., 0] if y.ndim == 3 else y
    yy, xx = np.mgrid[0:H, 0:W]; yy = yy / H; xx = xx / W
    img = np.zeros((H, W, 3))
    def grad(c0, c1, t): return np.array(c0)[None, None] * (1 - t[..., None]) + np.array(c1)[None, None] * t[..., None]
    if kind in ('tower', 'moon'):
        img = grad((.10, .09, .22), (.55, .33, .45), np.clip(yy / .8, 0, 1))
        if kind == 'tower':
            img = grad((.42, .40, .62), (.98, .72, .52), np.clip(yy / .75, 0, 1))
        ridge = .7 + .05 * _noise1(xx, 31)
        img = np.where((yy > ridge)[..., None], np.array((.12, .10, .18))[None, None], img)
        if kind == 'tower':
            body = (np.abs(xx - .5) < .07 + .03 * np.clip((yy - .3) / .5, 0, 1)) & (yy > .3) & (yy < .75)
            roof = (yy > .2) & (yy <= .3) & (np.abs(xx - .5) < (yy - .2) * 1.0)
            win = (np.abs(xx - .5) < .012) & (yy > .42) & (yy < .47)
            img = np.where((body | roof)[..., None], np.array((.16, .13, .2))[None, None], img)
            img = np.where(win[..., None], np.array((1.0, .8, .4))[None, None], img)
        else:
            r = np.sqrt((xx - .5) ** 2 + ((yy - .38) * H / W) ** 2)
            moon = r < .2
            shade = .82 + .18 * vnoise2(xx * 2, yy * 2, 41, 10)
            img = np.where(moon[..., None], np.stack([.98 * shade, .94 * shade, .82 * shade], -1), img)
        return np.clip(img * 255, 0, 255).astype(np.uint8)
    if kind == 'beach':
        img = grad((.36, .58, .9), (.85, .92, .98), np.clip(yy / .4, 0, 1))
        img = np.where((yy > .4)[..., None], grad((.15, .45, .65), (.25, .62, .72), np.clip((yy - .4) / .35, 0, 1)), img)
        shore_y = .74 + .03 * _noise1(xx, 21)
        img = np.where((yy > shore_y)[..., None], grad((.93, .84, .64), (.86, .74, .52), np.clip((yy - .74) / .26, 0, 1)), img)
        return np.clip(img * 255, 0, 255).astype(np.uint8)
    if kind in ('night', 'dusk', 'day', 'sea', 'cliff'):
        top, bot = {'night': ((.05, .07, .16), (.20, .17, .32)), 'dusk': ((.17, .14, .34), (.93, .55, .42)),
                    'day': ((.33, .55, .88), (.78, .88, .97)), 'sea': ((.20, .30, .62), (.95, .70, .60)),
                    'cliff': ((.35, .58, .85), (.80, .90, .96))}[kind]
        img = grad(top, bot, np.clip(yy / .62, 0, 1))
        ridge = .58 + .07 * _noise1(xx, 3) + .03 * _noise1(xx * 3, 4)
        far = (yy > ridge)[..., None]
        mc = {'night': (.10, .10, .2), 'dusk': (.36, .25, .40), 'day': (.42, .55, .70), 'sea': (.45, .38, .55), 'cliff': (.40, .55, .65)}[kind]
        img = np.where(far, np.array(mc)[None, None], img)
        if kind == 'sea':
            sun = ((xx - .62) ** 2 + ((yy - .5) * H / W) ** 2) < .045 ** 2
            img = np.where(sun[..., None], np.array((1.0, .92, .72))[None, None], img)
            img = np.where((yy > .6)[..., None], grad((.16, .34, .56), (.06, .18, .36), np.clip((yy - .6) / .4, 0, 1)), img)
            refl = ((yy > .6) * np.clip(1 - np.abs(xx - .62) / (.05 + .12 * (yy - .6)), 0, 1) * (.35 + .65 * vnoise2(xx * 2, yy * 6, 5, 16)))[..., None]
            img = img * (1 - .7 * refl) + np.array((1.0, .85, .65))[None, None] * .7 * refl
        else:
            g0 = {'night': (.09, .12, .15), 'dusk': (.25, .17, .22), 'day': (.30, .52, .28), 'cliff': (.30, .50, .28)}[kind]
            ground = .78 + .03 * _noise1(xx * 2, 7)
            img = np.where((yy > ground)[..., None], grad(g0, tuple(c * .6 for c in g0), np.clip((yy - .78) / .22, 0, 1)), img)
        if kind == 'cliff':
            rock = (np.abs(xx - .5) > .12 + .02 * _noise1(yy * 3, 9)) & (yy > .12)
            nn = vnoise2(xx, yy, 11, 6) * .6 + vnoise2(xx, yy, 12, 18) * .4
            shade = np.where(nn > .55, 1.0, np.where(nn > .4, .82, .66)) * (1 - .25 * np.abs(xx - .5))
            img = np.where(rock[..., None], np.stack([.42 * shade, .40 * shade, .40 * shade], -1), img)
            fall = (~rock) & (yy > .12) & (yy < .86)
            img = np.where(fall[..., None], grad((.35, .55, .70), (.30, .50, .68), yy), img)
    return np.clip(img * 255, 0, 255).astype(np.uint8)

def mask_shape(kind):
    yy, xx = np.mgrid[0:H, 0:W]; yy = yy / H; xx = (xx / W - .5) * (W / H) + .5
    if kind == 'person':      # silueta neutra (cabeza + torso), solo para el aura
        head = ((xx - .5) ** 2 + ((yy - .36) / 1.1) ** 2) < .085 ** 2
        body = (np.abs(xx - .5) < .1 + .12 * np.clip((yy - .47) / .3, 0, 1)) & (yy > .46)
        neck = (np.abs(xx - .5) < .04) & (yy > .40) & (yy < .5)
        m = head | body | neck
    elif kind == 'fall':
        m = (np.abs(xx - .5) < .12) & (yy > .12) & (yy < .86)
    elif kind == 'firebase':
        m = (np.abs(xx - .5) < .17) & (yy > .72) & (yy < .82)
    elif kind == 'torchbase':
        m = (np.abs(xx - .5) < .05) & (yy > .70) & (yy < .78)
    elif kind == 'sea':
        m = yy > .6
    elif kind == 'beachwater':
        m = (yy > .42) & (yy < .86)
    elif kind == 'towerarea':
        m = ((xx - .5) ** 2 / .22 ** 2 + (yy - .48) ** 2 / .34 ** 2) < 1
    elif kind == 'moondisc':
        m = np.sqrt((xx - .5) ** 2 + ((yy - .38)) ** 2) < .2
    elif kind == 'bigfire':
        m = (np.abs(xx - .5) < .2) & (yy > .70) & (yy < .80)
    else:
        m = np.ones((H, W), bool)
    m = m.astype(np.float32)
    if kind == 'towerarea':                         # borde suave, como un pincel real
        for _ in range(6):
            m = (m + np.roll(m, 3, 0) + np.roll(m, -3, 0) + np.roll(m, 3, 1) + np.roll(m, -3, 1)) / 5
    return (m * 255).astype(np.uint8)

def apply(preset):
    reset()
    img = scene(preset.get('_scene', 'night'))
    rgba = np.concatenate([img, np.full((H, W, 1), 255, np.uint8)], -1)
    tex2d(0, np.ascontiguousarray(rgba), W, H, 0x8058, 0x1908)
    atl = np.zeros((12, H, W), np.uint8)
    for layer, kind in preset.get('_masks', {}).items(): atl[layer] = mask_shape(kind)
    g.glActiveTexture(0x84C0 + 2); g.glBindTexture(0x8C1A, ids[2])
    g.glTexImage3D(0x8C1A, 0, 0x8229, W, H, 12, 0, 0x1903, 0x1401, np.ascontiguousarray(atl).ctypes.data)
    for k, v in preset.items():
        if k.startswith('_'): continue
        put(k, *v)

if __name__ == '__main__':
    out = Path(sys.argv[2] if len(sys.argv) > 2 else '/tmp/fx'); out.mkdir(parents=True, exist_ok=True)
    names = sys.argv[3:] or list(PRESETS)
    N = int(os.environ.get('FX_N', 8))
    T0 = float(os.environ.get('FX_T0', 0)); T1 = float(os.environ.get('FX_T1', 1))
    for nm in names:
        apply(PRESETS[nm])
        frames = [render(T0 + (T1 - T0) * (i + .5) / N) for i in range(N)]
        strip = np.concatenate(frames, axis=1)
        Image.fromarray(strip[..., :3]).save(out / f'{nm}.png')
        print('ok', nm)
