package com.zeta.fondo.engine

import android.graphics.Bitmap
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import com.zeta.fondo.model.Effects
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class PreviewRenderer(
    private val hub: RenderHub,
    private val vertSrc: String,
    private val fragSrc: String,
    private val liteSrc: String? = null,
    private val shaderCacheDir: java.io.File? = null
) : GLSurfaceView.Renderer {

    private var gl: FondoGl? = null
    private var vw = 1
    private var vh = 1
    private var lastImage: Bitmap? = null
    private var lastFlow: FlowField.Data? = null
    private var lastChar: Bitmap? = null
    private var charUploaded = false
    private var lastMasks: MaskLayers? = null
    private val maskVer = IntArray(MaskLayers.MAX_MASKS) { -1 }
    private val view = FloatArray(4)
    private var failed = false
    private var firstFrameSent = false
    private var maxTextureSize = 2048
    private var fullAnnounced = false
    private var compileScheduled = false
    // Parámetros neutros: comparación Original/Animado sin tocar el proyecto ni las máscaras.
    private val originalParams = RenderParams.from(
        Effects.defaults().mapValues { (key, value) ->
            if (key.endsWith(".on")) 0f else value
        }, 1f)

    override fun onSurfaceCreated(unused: GL10?, config: EGLConfig?) {
        // Contexto nuevo: hay que volver a subir todo
        lastImage = null
        lastFlow = null
        lastChar = null
        charUploaded = false
        lastMasks = null
        maskVer.fill(-1)
        failed = false
        firstFrameSent = false
        fullAnnounced = false
        compileScheduled = false
        val maxTex = IntArray(1)
        GLES30.glGetIntegerv(GLES30.GL_MAX_TEXTURE_SIZE, maxTex, 0)
        maxTextureSize = maxTex[0].coerceAtLeast(2048)
        hub.onFramePending?.invoke()
        gl = try {
            // v38: solo el programa ligero al crear la superficie. El primer cuadro sale
            // al instante y el zoom responde desde el primer toque; el shader completo
            // se compila después, en cuanto no haya gestos (ver onDrawFrame).
            FondoGl(vertSrc, fragSrc, liteSrc, shaderCacheDir).also { it.init(deferFull = liteSrc != null) }
        } catch (t: Throwable) {
            failed = true
            hub.onError?.invoke(t.message ?: t.toString())
            null
        }
    }

    override fun onSurfaceChanged(unused: GL10?, width: Int, height: Int) {
        vw = width
        vh = height
    }

    override fun onDrawFrame(unused: GL10?) {
        compileScheduled = false
        val g = gl
        if (g == null || failed || !hub.renderEnabled) {
            GLES30.glClearColor(0.08f, 0.09f, 0.19f, 1f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
            return
        }
        try {
            val img = hub.image
            if (img != null && img !== lastImage && !img.isRecycled) {
                if (img.width <= maxTextureSize && img.height <= maxTextureSize) {
                    g.uploadImage(img)
                } else {
                    // Seguridad para GPUs antiguas: la app sigue funcionando aunque el
                    // dispositivo tenga un GL_MAX_TEXTURE_SIZE menor que la preview adaptativa.
                    val longSide = maxOf(img.width, img.height).toFloat()
                    val k = maxTextureSize / longSide
                    val w = maxOf(1, (img.width * k).toInt())
                    val h = maxOf(1, (img.height * k).toInt())
                    val safe = Bitmap.createScaledBitmap(img, w, h, true)
                    try { g.uploadImage(safe) } finally { if (safe !== img) safe.recycle() }
                }
                lastImage = img
            }
            val f = hub.flow
            if (f != null && f !== lastFlow) {
                g.uploadFlow(f)
                lastFlow = f
            }
            val ch = hub.character
            if (!charUploaded || ch !== lastChar) {
                g.uploadCharacter(ch)
                lastChar = ch
                charUploaded = true
            }
            val m = hub.masks
            if (m != null) {
                if (m !== lastMasks) {
                    lastMasks = m
                    maskVer.fill(-1)
                }
                synchronized(m.lock) {
                    if (m.count > 0 && g.prepareMasks(m.w, m.h)) maskVer.fill(-1)
                    for (i in m.bitmaps.indices) {
                        if (m.versions[i] != maskVer[i]) {
                            // Solo las filas tocadas por el pincel; una capa nueva o un
                            // contexto recreado se sube completo.
                            val rows = m.takeDirtyRows(i)
                            if (maskVer[i] == -1) g.uploadMask(i, m.bitmaps[i])
                            else if (rows[1] > rows[0]) g.uploadMask(i, m.bitmaps[i], rows[0], rows[1])
                            maskVer[i] = m.versions[i]
                        }
                    }
                }
            }
            if (lastImage == null) {
                GLES30.glClearColor(0.08f, 0.09f, 0.19f, 1f)
                GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
                return
            }
            view[0] = hub.viewX
            view[1] = hub.viewY
            view[2] = hub.viewWidth
            view[3] = hub.viewHeight
            // Encuadre centrado dentro de la superficie: cambiar de formato no recrea la vista.
            val a = hub.displayAspect.takeIf { it > 0.01f } ?: (vw.toFloat() / vh.coerceAtLeast(1))
            var dw = vw
            var dh = vh
            if (vw.toFloat() / vh.coerceAtLeast(1) > a) dw = (vh * a).toInt().coerceIn(1, vw)
            else dh = (vw / a).toInt().coerceIn(1, vh)
            // Área libre: el panel inferior ocupa la parte baja de la superficie; la imagen
            // se ajusta al hueco visible en lugar de quedar tapada (sin redimensionar la
            // superficie, que provocaría saltos).
            val inset = (vh * hub.bottomInset.coerceIn(0f, 0.7f)).toInt()
            val availH = (vh - inset).coerceAtLeast(1)
            dw = vw; dh = availH
            if (vw.toFloat() / availH > a) dw = (availH * a).toInt().coerceIn(1, vw)
            else dh = (vw / a).toInt().coerceIn(1, availH)
            // ¿Shader ligero o completo?
            //  - ligero: mientras el completo no está listo, durante el zoom/arrastre de
            //    dos dedos, al pintar una máscara y en la comparación con el original;
            //  - completo: el resto (efectos visibles).
            val painting = hub.showMask && hub.activeMask >= 0 && !hub.showOriginal
            if (!g.fullReady && g.hasLite) maybeBuildFull(g)
            val lite = g.hasLite && (!g.fullReady || hub.gestureActive || hub.resizing || painting || hub.showOriginal)
            if (lite) {
                g.drawLite(dw, dh, view, painting, hub.activeMask, (vw - dw) / 2, inset + (availH - dh) / 2, hub.maskAlpha)
            } else {
                g.draw(if (hub.showOriginal) originalParams else hub.params,
                    if (hub.showOriginal) 0f else hub.currentT(), dw, dh, view,
                    false, false, painting, false, hub.activeMask, (vw - dw) / 2, inset + (availH - dh) / 2)
            }
            if (!firstFrameSent) {
                firstFrameSent = true
                hub.onFrameReady?.invoke()
            }
        } catch (t: Throwable) {
            failed = true
            hub.onError?.invoke(t.message ?: t.toString())
        }
    }

    /**
     * Compila el shader completo cuando hay calma (≥ 300 ms sin tocar la pantalla), para
     * que la pausa de compilación nunca coincida con el primer zoom. Si todavía hay
     * gestos, vuelve a intentarlo un poco después.
     */
    private fun maybeBuildFull(g: FondoGl) {
        val idle = hub.idleMs()
        if (idle >= IDLE_BEFORE_COMPILE_MS || !firstFrameSent) {
            if (!firstFrameSent) { scheduleRetry(IDLE_BEFORE_COMPILE_MS); return }
            g.buildFull()
            if (!fullAnnounced) { fullAnnounced = true; hub.onFullReady?.invoke() }
        } else scheduleRetry(IDLE_BEFORE_COMPILE_MS - idle + 20)
    }

    private fun scheduleRetry(ms: Long) {
        if (compileScheduled) return
        compileScheduled = true
        hub.onRenderLater?.invoke(ms.coerceIn(30L, 1000L))
        // Se libera en el siguiente cuadro (lo pida quien lo pida).
    }

    private companion object { const val IDLE_BEFORE_COMPILE_MS = 300L }
}
