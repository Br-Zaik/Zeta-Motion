package com.zeta.fondo.model

/**
 * Estados del panel inferior. v40: COMPACTO y EXPANDIDO tienen el mismo lienzo; solo cambia
 * cuánto alto pueden usar las opciones (propio del tipo / todo el espacio libre).
 * CONTRAÍDO oculta todo salvo el asa.
 */
enum class PanelState { HIDDEN, COMPACT, EXPANDED;
    /** Deslizar hacia arriba: más panel. */
    fun up(): PanelState = when (this) { HIDDEN -> COMPACT; else -> EXPANDED }
    /** Deslizar hacia abajo: menos panel. */
    fun down(): PanelState = when (this) { EXPANDED -> COMPACT; else -> HIDDEN }
    /** Tocar el asa: abre o cierra las opciones. */
    fun tap(): PanelState = when (this) { HIDDEN -> COMPACT; COMPACT -> EXPANDED; EXPANDED -> COMPACT }
    companion object { fun of(name: String?): PanelState = values().firstOrNull { it.name == name } ?: COMPACT }
}

/**
 * v40 · Qué opciones tiene la herramienta elegida. NONE = no hay nada que ajustar: NO se
 * dibuja ningún panel (antes quedaba un bloque alto con «Elige una herramienta»).
 * Cada tipo tiene una altura propia, proporcionada a lo que muestra.
 */
enum class PanelKind(val preferred: Float) {
    NONE(0f),
    SHORTCUTS(54f),      // Animar: accesos a las animaciones activas (una fila)
    GUIDE_CLEAR(54f),    // Ancla con puntos: un solo botón
    GUIDE_SLIDERS(150f), // Ruta con rutas dibujadas: 2 deslizadores + borrar
    BRUSH(200f),         // Proteger / zona: capas + 3 deslizadores
    CATALOG(236f),       // Efectos: catálogo
    EFFECT_EDIT(250f),   // Edición de un efecto
    SETTINGS(214f),      // Ajustes: duración, formato, color, audio
    LOOP(214f)           // Bucle
}

/**
 * v40 · Medidas del editor (en dp), sin dependencias de Android para poder probarlas.
 *
 * Regla principal: el LIENZO NO CAMBIA de tamaño ni de sitio al elegir Animar, Proteger,
 * Efectos o Ajustes, ni al abrir o cerrar las opciones. Su altura solo depende de la
 * pantalla y de la proporción de la imagen. Solo «Ocultar» (el asa hacia abajo, una
 * acción explícita) le da más altura.
 *
 * Retrato (de arriba abajo):
 *   barra superior · LIENZO fijo · línea de tiempo fina · [bloques] · fila de HERRAMIENTAS
 *   · OPCIONES (solo si existen, con su altura) · … · asa · categorías.
 * La fila de herramientas queda justo bajo el lienzo (se ve al entrar en Animar, sin un
 * bloque vacío delante). Las opciones ocupan el espacio que el lienzo deja reservado
 * debajo de la fila: no empujan ni tapan nada, y las categorías siguen fijas abajo.
 */
data class EditorLayout(
    val landscape: Boolean,
    val topBar: Float,
    val canvasH: Float,
    val handle: Float,
    val strip: Float,
    /** Altura máxima disponible para las opciones (el espacio libre bajo la línea de tiempo). */
    val content: Float,
    val toolRow: Float,
    val tabBar: Float,
    val sideW: Float,
    val state: PanelState
) {
    /** Hay sitio para mostrar opciones sin tocar el lienzo. */
    val showsContent: Boolean get() = state != PanelState.HIDDEN && content >= MIN_CONTENT_VISIBLE

    /**
     * Altura del panel de opciones para [kind]. NONE = 0 (sin panel vacío). COMPACTO usa la
     * altura propia del tipo; EXPANDIDO usa todo el espacio libre. [timeline] = altura de los
     * bloques de la línea de tiempo si están desplegados (se descuentan).
     */
    fun panelHeight(kind: PanelKind, timeline: Float = 0f): Float {
        if (kind == PanelKind.NONE || state == PanelState.HIDDEN) return 0f
        val free = (content - timeline).coerceAtLeast(0f)
        if (landscape) return free
        return if (state == PanelState.EXPANDED) free else kind.preferred.coerceAtMost(free)
    }

    companion object {
        const val TOP = 48f
        const val HANDLE = 22f
        const val STRIP = 30f
        const val TOOLS = 56f
        const val TABS = 54f
        const val MIN_CANVAS = 180f
        /** Espacio que el lienzo deja SIEMPRE libre para las opciones (retrato). */
        const val PANEL_RESERVE = 160f
        const val EXPANDED_CONTENT = PANEL_RESERVE
        const val MIN_CONTENT_VISIBLE = 50f
        const val SIDE_MARGIN = 20f
        const val TIMELINE_MAX = 88f

        fun compute(widthDp: Float, heightDp: Float, imageAspect: Float, state: PanelState, fullscreen: Boolean): EditorLayout {
            val w = widthDp.coerceAtLeast(1f)
            val h = heightDp.coerceAtLeast(1f)
            if (fullscreen) return EditorLayout(false, 0f, h, 0f, 0f, 0f, 0f, 0f, 0f, state)
            if (w > h * 1.15f) {
                // Horizontal / tableta: lienzo a la izquierda y herramientas en una columna
                // (contraído = la columna se oculta y queda un botón para recuperarla).
                val side = if (state == PanelState.HIDDEN) 0f else (w * 0.38f).coerceIn(280f, 400f).coerceAtMost(w * 0.5f)
                val content = if (state == PanelState.HIDDEN) 0f else (h - 28f - STRIP - TOOLS - TABS).coerceAtLeast(0f)
                return EditorLayout(true, TOP, (h - TOP).coerceAtLeast(0f), 0f, STRIP, content, TOOLS, TABS, side, state)
            }
            val avail = (h - TOP - HANDLE).coerceAtLeast(0f)
            val a = if (imageAspect > 0.05f) imageAspect else 1f
            // Altura que necesita la imagen a todo el ancho (+ un pequeño margen).
            val natural = (w - SIDE_MARGIN) / a + 8f
            if (state == PanelState.HIDDEN) {
                val canvas = natural.coerceIn(MIN_CANVAS.coerceAtMost(avail), avail)
                return EditorLayout(false, TOP, canvas, HANDLE, 0f, 0f, 0f, 0f, 0f, state)
            }
            val fixed = STRIP + TOOLS + TABS
            // Compacto y expandido: EXACTAMENTE la misma altura de lienzo.
            val maxCanvas = (avail - fixed - PANEL_RESERVE).coerceAtLeast(MIN_CANVAS.coerceAtMost(avail - fixed))
            val canvas = natural.coerceIn(MIN_CANVAS.coerceAtMost(maxCanvas), maxCanvas.coerceAtLeast(0f))
            val content = (avail - fixed - canvas).coerceAtLeast(0f)
            return EditorLayout(false, TOP, canvas, HANDLE, STRIP, content, TOOLS, TABS, 0f, state)
        }
    }
}

/** Rectángulo (en píxeles) donde se ve la imagen dentro del lienzo, igual que en OpenGL. */
data class ImageRect(val left: Float, val top: Float, val width: Float, val height: Float) {
    fun normX(x: Float): Float = (x - left) / width.coerceAtLeast(1f)
    fun normY(y: Float): Float = (y - top) / height.coerceAtLeast(1f)
    fun contains(x: Float, y: Float): Boolean = x >= left && y >= top && x <= left + width && y <= top + height

    companion object {
        /** Encaja [aspect] (ancho/alto) centrado en un lienzo de [boxW]×[boxH]. */
        fun fit(boxW: Float, boxH: Float, aspect: Float): ImageRect {
            val bw = boxW.coerceAtLeast(1f)
            val bh = boxH.coerceAtLeast(1f)
            val a = if (aspect > 0.01f) aspect else bw / bh
            return if (bw / bh > a) {
                val w = bh * a
                ImageRect((bw - w) / 2f, 0f, w, bh)
            } else {
                val hh = bw / a
                ImageRect(0f, (bh - hh) / 2f, bw, hh)
            }
        }
    }
}

/**
 * Decide qué hace un toque sobre el lienzo. Dos dedos SIEMPRE son zoom/desplazamiento,
 * aunque esté activo el pincel o cualquier herramienta; un dedo solo pinta o dibuja
 * después de moverse más que [slop] (un toque sin mover = punto).
 */
object GestureRules {
    enum class Mode { WAITING, DRAW, TRANSFORM }

    fun next(mode: Mode, pointers: Int, movedPx: Float, slop: Float, toolDraws: Boolean): Mode = when {
        pointers >= 2 -> Mode.TRANSFORM
        mode == Mode.TRANSFORM -> Mode.TRANSFORM          // al soltar un dedo no empieza a pintar
        !toolDraws -> Mode.TRANSFORM                      // herramienta Mover: un dedo desplaza
        // toolDraws = la herramienta usa un dedo (pincel, flecha, ancla, origen…)
        mode == Mode.WAITING && movedPx > slop -> Mode.DRAW
        else -> mode
    }
}
