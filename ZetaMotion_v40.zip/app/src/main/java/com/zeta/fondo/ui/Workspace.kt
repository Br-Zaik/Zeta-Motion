package com.zeta.fondo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.model.EditorTab
import com.zeta.fondo.model.PreviewSize
import com.zeta.fondo.model.Tool

/*
 * v40 · Zona de trabajo bajo los controles del lienzo. Muestra UNA cosa según el contexto:
 *  - la línea de tiempo con sus pistas (por defecto);
 *  - o las opciones de la herramienta: hoja COMPACTA (solo la altura que necesita, la
 *    línea de tiempo sigue visible encima) o COMPLETA (catálogo, editor de un efecto,
 *    Ajustes) con su propio scroll.
 * Nunca hay un rectángulo vacío reservado de antemano ni párrafos fijos, y el lienzo no
 * cambia de tamaño al abrir o cerrar nada.
 */

internal enum class SheetKind { NONE, COMPACT, FULL }

internal fun sheetKind(vm: AppViewModel): SheetKind = when {
    vm.paintingZone && vm.editingEffect != null -> SheetKind.COMPACT
    vm.editingEffect != null -> SheetKind.FULL
    vm.replacingClip != null -> SheetKind.FULL
    vm.tab == EditorTab.TOOLS -> when {
        vm.animPanel == "loop" -> SheetKind.FULL
        vm.paintingZone -> SheetKind.COMPACT
        vm.tool == Tool.ARROW && vm.arrows.isNotEmpty() -> SheetKind.COMPACT
        (vm.tool == Tool.ANCHOR || vm.tool == Tool.ERASE_GUIDE) && (vm.arrows.isNotEmpty() || vm.anchors.isNotEmpty()) -> SheetKind.COMPACT
        else -> SheetKind.NONE
    }
    !vm.optionsOpen -> SheetKind.NONE
    vm.tab == EditorTab.MASKS -> if (vm.paintingZone) SheetKind.COMPACT else SheetKind.NONE
    else -> SheetKind.FULL
}

@Composable
fun EditorWorkspace(vm: AppViewModel, modifier: Modifier) {
    val kind = sheetKind(vm)
    BoxWithConstraints(modifier.background(Night)) {
        val h = maxHeight
        Column(Modifier.fillMaxSize()) {
            when (kind) {
                SheetKind.NONE -> TimelineLanes(vm, Modifier.fillMaxWidth().weight(1f))
                SheetKind.COMPACT -> {
                    TimelineLanes(vm, Modifier.fillMaxWidth().weight(1f), showRuler = h > 220.dp)
                    Box(Modifier.fillMaxWidth().heightIn(max = (h * .72f).coerceAtLeast(96.dp))
                        .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)).background(StudioPanel)) {
                        EditorPanel(vm)
                    }
                }
                SheetKind.FULL -> {
                    TimeStrip(vm, Modifier.fillMaxWidth().height(32.dp), showLanesToggle = vm.effectClips.isNotEmpty())
                    if (vm.lanesWithOptions && vm.effectClips.isNotEmpty())
                        TimelineLanes(vm, Modifier.fillMaxWidth().height((h * .38f).coerceIn(70.dp, 150.dp)), showRuler = false)
                    Box(Modifier.fillMaxWidth().weight(1f)
                        .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)).background(StudioPanel)) {
                        EditorPanel(vm)
                    }
                }
            }
        }
    }
}

/** Cabecera fina de una hoja: título y botón para volver a la línea de tiempo. */
@Composable
fun SheetHeader(title: String, onClose: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(34.dp).padding(start = 14.dp, end = 2.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = StudioText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(17.dp)).clickable(onClick = onClose),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.ExpandMore, "Cerrar opciones", tint = StudioMuted, modifier = Modifier.size(22.dp))
        }
    }
}

/**
 * Acciones del bloque seleccionado (como al tocar un efecto en la línea de tiempo de un
 * editor de vídeo). « vuelve a las herramientas de la categoría.
 */
@Composable
fun ClipActionRow(vm: AppViewModel, modifier: Modifier) {
    val clip = vm.selectedClip() ?: return
    val id = clip.effectId
    Row(modifier.background(Night), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(44.dp).fillMaxHeight().clickable { vm.selectTimelineClip(null) },
            contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.ChevronLeft, "Volver a las herramientas", tint = StudioText, modifier = Modifier.size(22.dp))
        }
        Row(Modifier.weight(1f).fillMaxHeight().horizontalScroll(rememberScrollState()).padding(vertical = 5.dp, horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            ToolChip("Ajustar", Icons.Filled.Tune, false) { vm.editEffect(id) }
            // Mover en el TIEMPO = arrastrar el bloque; este botón lo mueve/agranda EN LA IMAGEN.
            ToolChip("Mover", Icons.Filled.OpenWith, vm.placingClip,
                help = if (vm.canPlace(id)) "Arrastra el punto en la imagen · aro = tamaño · flecha = dirección"
                       else "Este efecto se coloca con su zona (Ajustar › Zona); en el tiempo, arrastra el bloque",
                onHelp = { vm.showHint(it) }) { vm.togglePlacing() }
            ToolChip("Dividir", Icons.Filled.ContentCut, false) { vm.splitEffectClip(clip.uid) }
            ToolChip("Duplicar", Icons.Filled.ContentCopy, false) { vm.duplicateEffectClip(clip.uid) }
            ToolChip("Sustituir", Icons.Filled.SwapHoriz, vm.replacingClip == clip.uid) { vm.startReplace() }
            if (id in behindCapable) ToolChip(if (vm.isBehind(id)) "Detrás" else "Delante", Icons.Filled.Layers,
                vm.isBehind(id)) { vm.setBehind(id, !vm.isBehind(id)) }
            ToolChip("Eliminar", Icons.Filled.DeleteOutline, false) { vm.removeEffectClip(clip.uid) }
        }
    }
}

/** Ajustes › Vista: el usuario decide el tamaño del lienzo (nunca cambia solo). */
@Composable
fun PreviewSizePanel(vm: AppViewModel) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SheetHeader("Tamaño de la vista previa") { vm.closeOptions() }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PreviewSize.values().forEach { size ->
                Box(Modifier.weight(1f)) { SmallChoice(size.label, vm.previewSize == size) { vm.changePreviewSize(size) } }
            }
        }
    }
}
