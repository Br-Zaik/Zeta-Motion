package com.zeta.fondo.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ViewStream
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.model.ClipEdits
import com.zeta.fondo.model.EffectClip
import com.zeta.fondo.model.Effects
import kotlin.math.abs
import kotlin.math.roundToInt

/*
 * v40 · Línea de tiempo con edición REAL de bloques, como en un editor de vídeo:
 *  - tocar un bloque lo selecciona (y abajo aparecen sus acciones);
 *  - un bloque seleccionado se arrastra directamente para moverlo (otra pista: hacia
 *    arriba o abajo); uno sin seleccionar necesita mantener pulsado (así nunca se mueve
 *    por accidente al desplazar la línea de tiempo);
 *  - los tiradores blancos de los extremos recortan o alargan desde cada lado;
 *  - mientras se arrastra se ve el inicio y la duración y la vista previa se actualiza;
 *  - tocar o arrastrar la regla o una zona libre mueve el cabezal.
 */

private fun secText(sec: Float): String = String.format(java.util.Locale.US, "%.1f", sec.coerceAtLeast(0f))

/** Nombres cortos: la timeline muestra el EFECTO, nunca su configuración. */
internal fun timelineTitle(id: String): String = when (id) {
    "gust" -> "Viento"
    "appear" -> "Personaje"
    "impact" -> "Impacto"
    "bolt" -> "Rayo"
    "parallax" -> "Profundidad"
    "natural" -> "Natural"
    "mesh" -> "Deformar"
    "cam" -> "Cámara"
    "shore" -> "Olas"
    "leaves" -> "Hojas"
    "clouds3" -> "Nubes"
    "blast" -> "Explosión"
    "slash" -> "Corte"
    "blood" -> "Tinta"
    "reveal" -> "Revelación"
    "sunpath" -> "Reflejo"
    "zonemotion" -> "Zona"
    "smoke" -> "Humo"
    "flame" -> "Fuego"
    else -> Effects.all.firstOrNull { it.id == id }?.title
        ?.replace(" (Zona 1)", "")
        ?.replace(" (Zona 2)", "")
        ?.replace(" 2.5D", "")
        ?.substringBefore(" (")
        ?.substringBefore(" /")
        ?: id
}

/** Color de cada familia en la línea de tiempo (identifica el bloque de un vistazo). */
private fun clipColor(id: String): Color = when (id) {
    "flame", "blast", "embers", "heat" -> Color(0xFFE0633A)
    "smoke", "fog", "ash", "clouds3", "dust" -> Color(0xFF6E7590)
    "water", "shore", "waterfall", "reflect", "rain", "snow", "bubbles" -> Color(0xFF3C8FD6)
    "energy", "electric", "shock", "bolt", "slash", "blackaura", "runes" -> Color(0xFF8A5CF6)
    "natural", "parallax", "mesh", "cam", "zonemotion", "flow" -> Color(0xFF2FA67A)
    else -> StudioPurple
}

internal data class TimelineSnap(val startSec: Float, val guideSec: Float?)

/**
 * Magnetismo de edición: pega el inicio o final del bloque al inicio/final de otro clip
 * (o al cabezal) cuando están a pocos píxeles. Devuelve además la guía vertical a dibujar.
 */
internal fun snapTimelineStart(
    movingUid: Long, wantedStart: Float, duration: Float, total: Float,
    widthPx: Float, clips: List<EffectClip>, playheadSec: Float? = null
): TimelineSnap {
    val maxStart = (total - duration).coerceAtLeast(0f)
    val clamped = wantedStart.coerceIn(0f, maxStart)
    val thresholdSec = (10f / widthPx.coerceAtLeast(1f) * total).coerceIn(.025f, .18f)
    var bestStart = clamped
    var bestGuide: Float? = null
    var bestDelta = thresholdSec + .001f
    val movingEnd = clamped + duration
    val anchors = ArrayList<Float>()
    clips.filter { it.uid != movingUid }.forEach { anchors += it.startSec; anchors += it.startSec + it.durationSec }
    playheadSec?.let { anchors += it }
    for (anchor in anchors) {
        val deltaStart = anchor - clamped
        if (abs(deltaStart) < bestDelta) {
            val candidate = (clamped + deltaStart).coerceIn(0f, maxStart)
            if (abs(candidate - clamped) <= thresholdSec + .001f) {
                bestDelta = abs(deltaStart); bestStart = candidate; bestGuide = anchor
            }
        }
        val deltaEnd = anchor - movingEnd
        if (abs(deltaEnd) < bestDelta) {
            val candidate = (clamped + deltaEnd).coerceIn(0f, maxStart)
            if (abs(candidate - clamped) <= thresholdSec + .001f) {
                bestDelta = abs(deltaEnd); bestStart = candidate; bestGuide = anchor
            }
        }
    }
    return TimelineSnap(bestStart, bestGuide)
}

/** Asigna pistas solo cuando los bloques se solapan; clips consecutivos comparten la misma fila. */
internal fun timelineLaneLayout(clips: List<EffectClip>): Pair<Map<Long, Int>, Int> {
    if (clips.isEmpty()) return emptyMap<Long, Int>() to 1
    val result = LinkedHashMap<Long, Int>()
    val placed = mutableListOf<Triple<Int, Float, Float>>() // pista, inicio, fin
    fun overlaps(start: Float, end: Float, otherStart: Float, otherEnd: Float): Boolean =
        start < otherEnd - .015f && otherStart < end - .015f
    clips.sortedWith(compareBy<EffectClip> { it.startSec }.thenBy { it.uid }).forEach { clip ->
        val startSec = clip.startSec
        val endSec = clip.startSec + clip.durationSec
        fun free(track: Int): Boolean = placed.none { (t, s, e) ->
            t == track && overlaps(startSec, endSec, s, e)
        }
        var lane = clip.track
        if (lane < 0 || !free(lane)) {
            lane = 0
            while (!free(lane)) lane++
        }
        result[clip.uid] = lane
        placed += Triple(lane, startSec, endSec)
    }
    val count = (result.values.maxOrNull() ?: 0) + 1
    return result to count.coerceAtLeast(1)
}

@Composable
private fun rememberPlayhead(vm: AppViewModel): State<Float> {
    val position = remember { mutableFloatStateOf(vm.scrubT) }
    LaunchedEffect(vm.playing, vm.scrubT) {
        if (!vm.playing) position.floatValue = vm.scrubT
        else while (true) { withFrameNanos { position.floatValue = vm.hub.currentT() } }
    }
    return position
}

/**
 * Tira compacta (cuando hay opciones abiertas): cabezal, marcas de los bloques y botón
 * para mostrar u ocultar las pistas. La vista previa nunca cambia de tamaño por esto.
 */
@Composable
fun TimeStrip(vm: AppViewModel, modifier: Modifier, showLanesToggle: Boolean) {
    val position by rememberPlayhead(vm)
    val total = vm.exportSettings.loopSec.toFloat().coerceAtLeast(.5f)
    val clips = vm.effectClips
    Row(modifier.background(Night).padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxHeight()) {
            val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
            Canvas(Modifier.fillMaxSize()
                .pointerInput(widthPx) {
                    detectTapGestures { tap ->
                        if (vm.playing) vm.togglePlay()
                        vm.scrubTo((tap.x / widthPx).coerceIn(0f, .999f))
                    }
                }
                .pointerInput(widthPx) {
                    detectHorizontalDragGestures(onDragStart = { if (vm.playing) vm.togglePlay() }) { change, _ ->
                        change.consume()
                        vm.scrubTo((change.position.x / widthPx).coerceIn(0f, .999f))
                    }
                }) {
                val mid = size.height / 2f
                drawLine(StudioTile, Offset(0f, mid), Offset(size.width, mid), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                clips.forEachIndexed { i, clip ->
                    val x0 = (clip.startSec / total).coerceIn(0f, 1f) * size.width
                    val x1 = ((clip.startSec + clip.durationSec) / total).coerceIn(0f, 1f) * size.width
                    val y = mid - 8.dp.toPx() + (i % 3) * 3.dp.toPx()
                    drawLine(if (clip.uid == vm.selectedTimelineClip) StudioPink else clipColor(clip.effectId),
                        Offset(x0, y), Offset(x1.coerceAtLeast(x0 + 2f), y), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                }
                val px = position.coerceIn(0f, 1f) * size.width
                drawLine(StudioPink, Offset(0f, mid), Offset(px, mid), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                drawCircle(Color.White, 6.dp.toPx(), Offset(px, mid))
            }
        }
        if (showLanesToggle) Box(Modifier.size(36.dp).clickable { vm.toggleLanesWithOptions() }, contentAlignment = Alignment.Center) {
            Icon(if (vm.lanesWithOptions) Icons.Filled.ExpandLess else Icons.Filled.ViewStream,
                if (vm.lanesWithOptions) "Ocultar pistas" else "Ver pistas de efectos",
                tint = if (vm.lanesWithOptions) StudioPink else StudioText, modifier = Modifier.size(19.dp))
        }
    }
}

/**
 * Línea de tiempo completa: regla, pista de la imagen y una pista por capa de efectos.
 * Se desplaza por dentro (vertical); nunca empuja ni tapa el lienzo.
 */
@Composable
fun TimelineLanes(vm: AppViewModel, modifier: Modifier, showRuler: Boolean = true) {
    val clips = vm.effectClips.sortedWith(compareBy<EffectClip> { it.startSec }.thenBy { it.uid })
    val position by rememberPlayhead(vm)
    val total = vm.exportSettings.loopSec.toFloat().coerceAtLeast(.5f)
    val (laneByUid, usedLaneCount) = remember(clips) { timelineLaneLayout(clips) }
    // Una pista vacía al final hace que mover hacia abajo sea natural, como en un editor de vídeo.
    val laneCount = if (clips.isEmpty()) 0 else usedLaneCount + 1
    val scrollY = rememberScrollState()
    var movingClip by remember { mutableStateOf(false) }
    var snapGuideSec by remember { mutableStateOf<Float?>(null) }
    var live by remember { mutableStateOf<Pair<Float, String>?>(null) }   // x (0..1) y texto
    val rulerH = if (showRuler) 22.dp else 0.dp
    val imageH = 30.dp
    val laneStep = 32.dp
    val blockH = 26.dp
    val lanesTop = rulerH + imageH + 6.dp
    val hintH = if (clips.isEmpty()) 30.dp else 0.dp
    val contentHeight = lanesTop + laneStep * laneCount.toFloat() + hintH + 8.dp

    BoxWithConstraints(modifier.background(Night)) {
        val viewportH = maxHeight
        Box(Modifier.fillMaxWidth().verticalScroll(scrollY, enabled = !movingClip)) {
            BoxWithConstraints(Modifier.fillMaxWidth().height(maxOf(contentHeight, viewportH))
                .padding(horizontal = 12.dp)) {
                val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
                val density = LocalDensity.current
                val laneStepPx = with(density) { laneStep.toPx() }

                // Fondo: tocar o arrastrar una zona libre mueve el cabezal y suelta la selección.
                Canvas(Modifier.fillMaxSize()
                    .pointerInput(total, widthPx) {
                        detectTapGestures { tap ->
                            if (vm.playing) vm.togglePlay()
                            vm.selectTimelineClip(null)
                            vm.scrubTo((tap.x / widthPx).coerceIn(0f, .999f))
                        }
                    }
                    .pointerInput(total, widthPx) {
                        detectHorizontalDragGestures(onDragStart = { if (vm.playing) vm.togglePlay() }) { change, _ ->
                            change.consume()
                            vm.scrubTo((change.position.x / widthPx).coerceIn(0f, .999f))
                        }
                    }) {
                    // Regla con segundos.
                    if (showRuler) {
                        val step = when { total <= 8f -> 1; total <= 20f -> 2; total <= 40f -> 5; else -> 10 }
                        var sec = 0
                        while (sec <= total.toInt()) {
                            val x = (sec / total) * size.width
                            drawLine(StudioMuted.copy(alpha = .45f), Offset(x, rulerH.toPx() - 6.dp.toPx()),
                                Offset(x, rulerH.toPx()), 1.dp.toPx())
                            sec += step
                        }
                    }
                    // Pistas de efectos.
                    for (lane in 0 until laneCount) {
                        val y = lanesTop.toPx() + lane * laneStep.toPx() + blockH.toPx() / 2f
                        drawLine(StudioTile, Offset(0f, y), Offset(size.width, y), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                    }
                    snapGuideSec?.let { guideSec ->
                        val gx = (guideSec.coerceIn(0f, total) / total) * size.width
                        drawLine(StudioPink.copy(alpha = .95f), Offset(gx, 0f), Offset(gx, size.height),
                            strokeWidth = 1.4.dp.toPx())
                    }
                }
                if (showRuler) RulerLabels(total, Modifier.fillMaxWidth().height(rulerH))
                ImageTrack(vm, Modifier.offset(y = rulerH).fillMaxWidth().height(imageH))
                if (clips.isEmpty()) {
                    Text("Sin efectos · añádelos desde Efectos", color = StudioMuted, fontSize = 11.sp, maxLines = 1,
                        modifier = Modifier.offset(y = lanesTop + 4.dp))
                }

                clips.forEach { clip ->
                    key(clip.uid) {
                        val lane = laneByUid[clip.uid] ?: vm.timelineTrackOf(clip.uid)
                        TimelineBlock(vm, clip, lane, clips, total, widthPx, laneStepPx, laneCount,
                            top = lanesTop, laneStep = laneStep, blockH = blockH,
                            onMoving = { movingClip = it },
                            onGuide = { snapGuideSec = it },
                            onLive = { live = it })
                    }
                }
                // Cabezal blanco sobre todo (sin captar toques).
                Canvas(Modifier.fillMaxSize()) {
                    val px = position.coerceIn(0f, 1f) * size.width
                    drawLine(Color.White.copy(alpha = .95f), Offset(px, 0f), Offset(px, size.height), strokeWidth = 1.6.dp.toPx())
                    drawCircle(Color.White, 4.dp.toPx(), Offset(px, 3.dp.toPx()))
                }
                live?.let { (x, text) ->
                    val pxDp = with(density) { (x * widthPx).toDp() }
                    Text(text, color = Color.White, fontSize = 10.sp, maxLines = 1, textAlign = TextAlign.Center,
                        modifier = Modifier.offset(x = (pxDp - 60.dp).coerceAtLeast(0.dp), y = rulerH + 2.dp)
                            .width(120.dp).clip(RoundedCornerShape(8.dp)).background(StudioPink.copy(alpha = .92f))
                            .padding(vertical = 3.dp))
                }
            }
        }
    }
}

@Composable
private fun RulerLabels(total: Float, modifier: Modifier) {
    BoxWithConstraints(modifier) {
        val w = maxWidth
        val step = when { total <= 8f -> 1; total <= 20f -> 2; total <= 40f -> 5; else -> 10 }
        var sec = 0
        while (sec <= total.toInt()) {
            val x = w * (sec / total)
            Text("${sec}s", color = StudioMuted, fontSize = 9.sp, maxLines = 1,
                modifier = Modifier.offset(x = (x - 8.dp).coerceIn(0.dp, (w - 22.dp).coerceAtLeast(0.dp))))
            sec += step
        }
    }
}

/** Pista base con miniaturas de la imagen (como la pista de vídeo de un editor). */
@Composable
private fun ImageTrack(vm: AppViewModel, modifier: Modifier) {
    val bmp = vm.previewFallback
    val image = remember(bmp) { bmp?.takeIf { !it.isRecycled }?.asImageBitmap() }
    Canvas(modifier.clip(RoundedCornerShape(6.dp)).background(StudioTile)) {
        val img = image ?: return@Canvas
        val tileH = size.height
        val tileW = (tileH * img.width / img.height.coerceAtLeast(1)).coerceAtLeast(8f)
        val count = (size.width / tileW).toInt() + 1
        for (i in 0 until count) {
            drawImage(img, srcOffset = IntOffset.Zero, srcSize = IntSize(img.width, img.height),
                dstOffset = IntOffset((i * tileW).roundToInt(), 0), dstSize = IntSize(tileW.roundToInt(), tileH.roundToInt()),
                alpha = .85f)
        }
    }
}

/** Un bloque de efecto: seleccionar, mover, recortar desde los dos extremos. */
@Composable
private fun TimelineBlock(
    vm: AppViewModel, clip: EffectClip, lane: Int, clips: List<EffectClip>, total: Float, widthPx: Float,
    laneStepPx: Float, laneCount: Int, top: androidx.compose.ui.unit.Dp, laneStep: androidx.compose.ui.unit.Dp,
    blockH: androidx.compose.ui.unit.Dp, onMoving: (Boolean) -> Unit, onGuide: (Float?) -> Unit,
    onLive: (Pair<Float, String>?) -> Unit
) {
    val density = LocalDensity.current
    var editing by remember(clip.uid) { mutableStateOf(false) }
    var visualStart by remember(clip.uid) { mutableFloatStateOf(clip.startSec) }
    var visualDuration by remember(clip.uid) { mutableFloatStateOf(clip.durationSec) }
    var visualTrack by remember(clip.uid) { mutableIntStateOf(lane) }
    LaunchedEffect(clip.startSec, clip.durationSec, clip.track, lane, editing) {
        if (!editing) {
            visualStart = clip.startSec
            visualDuration = clip.durationSec
            visualTrack = lane
        }
    }
    val selected = vm.selectedTimelineClip == clip.uid
    val clipsNow by rememberUpdatedState(clips)
    // Posición "cruda" del dedo: el imán puede pegar el bloque, pero el dedo siempre
    // puede volver a despegarlo (si no, los pasos pequeños quedarían atrapados).
    var rawStart by remember(clip.uid) { mutableFloatStateOf(clip.startSec) }
    val safeDuration = visualDuration.coerceIn(ClipEdits.MIN_DURATION, total)
    val rawWidth = with(density) { ((safeDuration / total) * widthPx).toDp() }
    val blockWidth = rawWidth.coerceAtLeast(if (selected) 56.dp else 30.dp)
    val maxStart = (total - safeDuration).coerceAtLeast(0f)
    fun liveText(): String = "${secText(visualStart)} s → ${secText(visualStart + visualDuration)} s · ${secText(visualDuration)} s"
    fun publish() = onLive(((visualStart + visualDuration / 2f) / total) to liveText())
    var lastPreviewNs = 0L
    fun preview() {
        val now = System.nanoTime()
        if (lastPreviewNs == 0L || now - lastPreviewNs >= 16_000_000L) {
            lastPreviewNs = now
            vm.previewEffectClipTiming(clip.uid, visualStart, visualDuration)
        }
    }
    fun begin() {
        if (vm.playing) vm.togglePlay()
        val current = vm.effectClips.firstOrNull { it.uid == clip.uid } ?: clip
        visualStart = current.startSec
        visualDuration = current.durationSec
        visualTrack = vm.timelineTrackOf(clip.uid)
        editing = true
        lastPreviewNs = 0L
        onGuide(null)
        vm.selectTimelineClip(clip.uid)
        publish()
    }
    fun finish() {
        vm.setEffectClipPlacement(clip.uid, visualStart, visualDuration, visualTrack)
        editing = false
        onMoving(false)
        onGuide(null)
        onLive(null)
        vm.saveProject()
    }
    val color = clipColor(clip.effectId)
    Box(
        Modifier
            .graphicsLayer { translationX = (visualStart.coerceIn(0f, maxStart) / total) * widthPx }
            .offset(y = top + laneStep * visualTrack.toFloat())
            .width(blockWidth)
            .height(blockH)
            .clip(RoundedCornerShape(6.dp))
            .background(if (selected) color else color.copy(alpha = .78f))
            .then(if (selected) Modifier.border(2.dp, Color.White, RoundedCornerShape(6.dp)) else Modifier)
    ) {
        // Centro: tocar selecciona; mover = arrastrar (seleccionado) o mantener pulsado (sin seleccionar).
        var baseTrack = 0
        var dragY = 0f
        val moveGesture: suspend androidx.compose.ui.input.pointer.PointerInputScope.() -> Unit = {
            val onStart: (Offset) -> Unit = {
                begin(); baseTrack = visualTrack; dragY = 0f; rawStart = visualStart; onMoving(true)
            }
            val onDrag: (androidx.compose.ui.input.pointer.PointerInputChange, Offset) -> Unit = { change, dragAmount ->
                change.consume()
                rawStart = ClipEdits.move(rawStart, visualDuration, dragAmount.x / widthPx * total, total)
                val snapped = snapTimelineStart(clip.uid, rawStart, visualDuration, total, widthPx, clipsNow,
                    playheadSec = vm.scrubT * total)
                visualStart = snapped.startSec
                onGuide(snapped.guideSec)
                dragY += dragAmount.y
                val requested = (baseTrack + (dragY / laneStepPx).roundToInt()).coerceIn(0, (laneCount - 1).coerceAtLeast(0))
                // Solo cambia de pista cuando el hueco está realmente libre en ese instante.
                if (vm.isTimelineTrackFree(clip.uid, visualStart, visualDuration, requested)) visualTrack = requested
                else if (!vm.isTimelineTrackFree(clip.uid, visualStart, visualDuration, visualTrack))
                    visualTrack = vm.suggestTimelineTrack(clip.uid, visualStart, visualDuration, requested)
                publish()
                preview()
            }
            if (selected) detectDragGestures(onDragStart = onStart, onDragEnd = { finish() },
                onDragCancel = { finish() }, onDrag = onDrag)
            else detectDragGesturesAfterLongPress(onDragStart = onStart, onDragEnd = { finish() },
                onDragCancel = { finish() }, onDrag = onDrag)
        }
        Box(
            Modifier.fillMaxSize()
                // Zona táctil exclusiva a cada extremo: mover nunca roba el recorte.
                .padding(horizontal = if (selected) 18.dp else 0.dp)
                .clickable { vm.selectTimelineClip(clip.uid) }
                .pointerInput(clip.uid, selected, total, widthPx, laneCount) { moveGesture() },
            contentAlignment = Alignment.Center
        ) {
            // Seleccionado: también su duración (como en un editor de vídeo).
            Text(timelineTitle(clip.effectId) + (if (clip.overrides.isNotEmpty()) " •" else "") +
                (if (selected && !editing) " · ${secText(clip.durationSec)} s" else ""),
                color = StudioText, fontSize = 10.sp,
                fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 3.dp))
        }

        if (selected) {
            // Tirador izquierdo: el final queda fijo y cambia el inicio (y la duración).
            TrimHandle(Modifier.align(Alignment.CenterStart), clip.uid, "left", total, widthPx) { phase, dx ->
                when (phase) {
                    0 -> begin()
                    1 -> {
                        val anchorEnd = (vm.effectClips.firstOrNull { it.uid == clip.uid } ?: clip).endSec
                        val (s, d) = ClipEdits.trimStart(visualStart, anchorEnd, dx / widthPx * total)
                        visualStart = s; visualDuration = d
                        publish(); preview()
                    }
                    else -> finish()
                }
            }
            // Tirador derecho: el inicio queda fijo y cambia la duración.
            TrimHandle(Modifier.align(Alignment.CenterEnd), clip.uid, "right", total, widthPx) { phase, dx ->
                when (phase) {
                    0 -> begin()
                    1 -> {
                        val (s, d) = ClipEdits.trimEnd(visualStart, visualStart + visualDuration, dx / widthPx * total, total)
                        visualStart = s; visualDuration = d
                        publish(); preview()
                    }
                    else -> finish()
                }
            }
        }
    }
}

/** Tirador de recorte (18 dp de zona táctil, barra blanca visible). phase: 0 inicio, 1 arrastre, 2 fin. */
@Composable
private fun TrimHandle(modifier: Modifier, uid: Long, side: String, total: Float, widthPx: Float,
                       onEvent: (phase: Int, dx: Float) -> Unit) {
    Box(
        modifier.fillMaxHeight().width(18.dp)
            .background(Color.White.copy(alpha = .22f))
            .pointerInput(uid, side, total, widthPx) {
                detectDragGestures(
                    onDragStart = { onEvent(0, 0f) },
                    onDragEnd = { onEvent(2, 0f) },
                    onDragCancel = { onEvent(2, 0f) }
                ) { change, dragAmount ->
                    change.consume()
                    onEvent(1, dragAmount.x)
                }
            },
        contentAlignment = Alignment.Center
    ) { Box(Modifier.width(3.dp).height(14.dp).clip(RoundedCornerShape(2.dp)).background(Color.White)) }
}
