package com.zeta.fondo.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** v39: panel inferior de 3 estados, lienzo según la proporción y tamaño único de vista previa. */
class V39Test {
    private val W = 392f
    private val H = 820f

    @Test fun panelStatesMoveWithSwipesAndTaps() {
        assertEquals(PanelState.EXPANDED, PanelState.COMPACT.up())
        assertEquals(PanelState.COMPACT, PanelState.HIDDEN.up())
        assertEquals(PanelState.COMPACT, PanelState.EXPANDED.down())
        assertEquals(PanelState.HIDDEN, PanelState.COMPACT.down())
        assertEquals(PanelState.HIDDEN, PanelState.HIDDEN.down())
        assertEquals(PanelState.COMPACT, PanelState.HIDDEN.tap())
        assertEquals(PanelState.EXPANDED, PanelState.COMPACT.tap())
        assertEquals(PanelState.COMPACT, PanelState.EXPANDED.tap())
        assertEquals(PanelState.COMPACT, PanelState.of(null))
        assertEquals(PanelState.HIDDEN, PanelState.of("HIDDEN"))
    }

    @Test fun partsAlwaysFitTheScreen() {
        for (a in listOf(9f / 16f, 3f / 4f, 1f, 4f / 3f, 16f / 9f, 21f / 9f)) for (st in PanelState.values()) {
            val l = EditorLayout.compute(W, H, a, st, false)
            val used = l.topBar + l.canvasH + l.handle + l.strip + l.content + l.toolRow + l.tabBar
            assertTrue("$a $st: $used", used <= H + .01f)
            assertTrue(l.canvasH >= EditorLayout.MIN_CANVAS - .01f)
        }
    }

    @Test fun horizontalImageLeavesLittleBlackAndGivesSpaceToOptions() {
        val l = EditorLayout.compute(W, H, 16f / 9f, PanelState.COMPACT, false)
        val imageH = (W - EditorLayout.SIDE_MARGIN) / (16f / 9f)
        assertTrue("franja negra pequeña", l.canvasH - imageH <= 12f)
        assertTrue("el espacio sobrante muestra opciones", l.showsContent)
    }

    @Test fun verticalImageCompactKeepsFixedBars() {
        val l = EditorLayout.compute(W, H, 9f / 16f, PanelState.COMPACT, false)
        // v40: el lienzo siempre deja libre el espacio de opciones (no cambia al abrirlas).
        assertTrue(l.showsContent)
        assertEquals(EditorLayout.TOOLS + EditorLayout.TABS + EditorLayout.STRIP, l.toolRow + l.tabBar + l.strip, .01f)
    }

    @Test fun expandedAlwaysHasRoomForOptions() {
        for (a in listOf(9f / 16f, 1f, 16f / 9f)) {
            val l = EditorLayout.compute(W, H, a, PanelState.EXPANDED, false)
            assertTrue(l.content >= EditorLayout.EXPANDED_CONTENT - .01f)
        }
    }

    @Test fun hidingThePanelNeverGoesFullscreenAndKeepsBars() {
        val hidden = EditorLayout.compute(W, H, 9f / 16f, PanelState.HIDDEN, false)
        assertEquals(EditorLayout.TOP, hidden.topBar, 0f)
        assertTrue(hidden.canvasH < H - EditorLayout.TOP)
        assertEquals(0f, hidden.toolRow + hidden.tabBar, 0f)
        // Una imagen horizontal no crece al ocultar el panel (ya ocupa todo el ancho).
        val c = EditorLayout.compute(W, H, 16f / 9f, PanelState.COMPACT, false)
        val h = EditorLayout.compute(W, H, 16f / 9f, PanelState.HIDDEN, false)
        assertEquals(c.canvasH, h.canvasH, .01f)
        // Solo el botón de pantalla completa la hace completa.
        assertEquals(H, EditorLayout.compute(W, H, 1f, PanelState.COMPACT, true).canvasH, 0f)
    }

    @Test fun landscapeHiddenRemovesSideColumn() {
        val l = EditorLayout.compute(H, W, 16f / 9f, PanelState.HIDDEN, false)
        assertTrue(l.landscape)
        assertEquals(0f, l.sideW, 0f)
        assertTrue(EditorLayout.compute(H, W, 16f / 9f, PanelState.COMPACT, false).sideW >= 280f)
    }

    @Test fun onePreviewSizeForImportCacheAndOpen() {
        assertEquals(1600, PreviewSizing.target(true, 512))
        assertEquals(2048, PreviewSizing.target(false, 192))
        assertEquals(2560, PreviewSizing.target(false, 512))
        // La caché de 1920 de proyectos v38 sirve para un objetivo de 2048 o 2560: no se re-decodifica.
        assertTrue(PreviewSizing.cacheIsEnough(1920, 2048, 4000))
        assertTrue(PreviewSizing.cacheIsEnough(1920, 2560, 4000))
        // Una caché diminuta (miniatura) no sirve.
        assertFalse(PreviewSizing.cacheIsEnough(480, 2048, 4000))
        // Imagen original pequeña: la caché del mismo tamaño sirve.
        assertTrue(PreviewSizing.cacheIsEnough(1000, 2560, 1000))
    }
}
