package com.zeta.fondo.engine

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v40: contratos de la mejora visual de efectos (el render real se comprueba con tools/check_v40_fx.py). */
class V40ShaderTest {
    private fun read(name: String): String = listOf(File("src/main/assets/$name"), File("app/src/main/assets/$name"))
        .first { it.isFile }.readText()

    private fun body(src: String, signature: String): String {
        val start = src.indexOf(signature)
        assertTrue("falta $signature", start >= 0)
        var depth = 0
        var i = src.indexOf('{', start)
        val from = i
        while (i < src.length) {
            if (src[i] == '{') depth++
            if (src[i] == '}') { depth--; if (depth == 0) break }
            i++
        }
        return src.substring(from, i + 1)
    }

    @Test fun explosionIsBuiltFromBillowsFragmentsAndResidualSmoke() {
        val blast = body(read("shaders/fondo.frag"), "vec3 zetaBlast(vec3 col, vec2 P, vec2 uv, float zone)")
        assertTrue(blast.contains("blastBillow("))          // cúmulos irregulares, no un disco
        assertTrue(blast.contains("Fragmentos"))            // trozos con gravedad
        assertTrue(blast.contains("Humo residual"))
        assertTrue(blast.contains("heat"))                  // se enfría de blanco a humo
        // Todo depende de la fase del evento (bucle/Una vez) y nada de la hora absoluta.
        assertFalse(blast.contains("uT *") && !blast.contains("fract(uT * cycles)"))
    }

    @Test fun smokeUsesPuffsAndKeepsThreadsShape() {
        val src = read("shaders/fondo.frag")
        val smoke = body(src, "vec3 zetaSmoke(vec3 col, vec2 P, vec2 uv, float zone)")
        assertTrue(smoke.contains("zetaSmokeThreads("))
        assertTrue(smoke.contains("const int N = 12;"))
        assertTrue(src.contains("vec3 zetaSmokeThreads(vec3 col, vec2 P, vec2 uv, float zone)"))
    }

    @Test fun steppedElectricArcsLoopExactly() {
        val src = read("shaders/fondo.frag")
        assertTrue(src.contains("float k = mod(floor(uT * steps), steps);"))
    }

    @Test fun improvedEffectsShipRealThumbnails() {
        for (id in listOf("blast", "smoke", "flame", "energy", "electric", "bolt", "waterfall", "shore", "water", "rays",
            "blackaura", "dispersion", "reveal")) {
            val f = listOf(File("src/main/assets/thumbs/$id.webp"), File("app/src/main/assets/thumbs/$id.webp")).first { it.isFile }
            assertTrue("$id.webp vacía", f.length() in 1500..40000)
        }
    }
}
