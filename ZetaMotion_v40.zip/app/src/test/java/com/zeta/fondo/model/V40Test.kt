package com.zeta.fondo.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v40: el lienzo queda fijo arriba (no cambia de tamaño ni de sitio al cambiar de
 * categoría ni al abrir/cerrar opciones), y sin herramienta elegida NO hay panel vacío.
 */
class V40Test {
    private val sizes = listOf(360f to 640f, 392f to 820f, 412f to 915f, 480f to 1000f)
    private val aspects = listOf(9f / 16f, 3f / 4f, 1f, 4f / 3f, 16f / 9f, 21f / 9f)

    @Test fun canvasIsIdenticalInCompactAndExpanded() {
        for ((w, h) in sizes) for (a in aspects) {
            val c = EditorLayout.compute(w, h, a, PanelState.COMPACT, false)
            val e = EditorLayout.compute(w, h, a, PanelState.EXPANDED, false)
            assertEquals("$w x $h, $a", c.canvasH, e.canvasH, 0f)
            assertEquals(c.topBar, e.topBar, 0f)
        }
    }

    @Test fun noOptionsMeansNoPanel() {
        for (st in PanelState.values()) for (a in aspects) {
            assertEquals(0f, EditorLayout.compute(392f, 820f, a, st, false).panelHeight(PanelKind.NONE), 0f)
        }
    }

    @Test fun compactPanelHasItsOwnProportionedHeight() {
        // Imagen horizontal (mucho espacio libre): el panel NO ocupa todo, solo lo suyo.
        val l = EditorLayout.compute(392f, 820f, 16f / 9f, PanelState.COMPACT, false)
        assertTrue(l.content > 300f)
        assertEquals(PanelKind.SHORTCUTS.preferred, l.panelHeight(PanelKind.SHORTCUTS), 0f)
        assertEquals(PanelKind.CATALOG.preferred, l.panelHeight(PanelKind.CATALOG), 0f)
        // Expandido: usa todo el espacio libre (sin tocar el lienzo).
        val e = EditorLayout.compute(392f, 820f, 16f / 9f, PanelState.EXPANDED, false)
        assertEquals(e.content, e.panelHeight(PanelKind.CATALOG), 0f)
        assertEquals(l.canvasH, e.canvasH, 0f)
    }

    @Test fun nothingOverlapsWithTimelineAndPanel() {
        for ((w, h) in sizes) for (a in aspects) for (st in listOf(PanelState.COMPACT, PanelState.EXPANDED))
            for (k in PanelKind.values()) for (tl in listOf(0f, EditorLayout.TIMELINE_MAX)) {
                val l = EditorLayout.compute(w, h, a, st, false)
                val used = l.topBar + l.canvasH + l.strip + tl + l.handle + l.panelHeight(k, tl) + l.toolRow + l.tabBar
                assertTrue("$w x $h $a $st $k tl=$tl: $used", used <= h + .01f)
            }
    }

    @Test fun canvasKeepsAMinimumAndOptionsKeepTheirReserve() {
        for ((w, h) in sizes) for (a in aspects) {
            val l = EditorLayout.compute(w, h, a, PanelState.COMPACT, false)
            assertTrue(l.canvasH >= EditorLayout.MIN_CANVAS - .01f)
            assertTrue("$w x $h $a", l.content >= EditorLayout.PANEL_RESERVE - .01f)
        }
    }
}
