> **Versión actual: v39 — lee LEEME_V39.md** (cambios, compilación y pruebas).

# Zeta Motion v35.1 — APK firmado

Antes de instalar lee [LEEME_INSTALACION_ESTABLE.md](LEEME_INSTALACION_ESTABLE.md).

El código conserva los efectos y herramientas de v35.
