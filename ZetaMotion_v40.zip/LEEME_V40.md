# Zeta Motion v40 (versionCode 41 · 40.0.0)

Esta versión corrige solo los puntos de «ZETA_MOTION_V39_SOLO_ERRORES_SOLICITADOS». Se parte del ZIP V39 y el resto se conserva tal cual: no se tocaron el zoom, los tiempos de carga, la importación ni GitHub, y no hay funciones nuevas.

## 1. Lienzo fijo arriba

- El lienzo tiene **la misma altura y la misma posición** en Animar, Proteger, Efectos y Ajustes. Tampoco cambia al abrir o cerrar opciones ni al desplegar la línea de tiempo.
  - En la v39, al abrir opciones el panel pasaba a «expandido» y el lienzo se encogía 220 dp.
  - Ahora compacto y expandido tienen el mismo lienzo (`EditorLayout.compute`). Solo cambia cuánto alto pueden usar las opciones.
- Su altura depende únicamente de la pantalla y de la proporción de la imagen.
  - Solo crece al ocultar el panel con el asa, que es una acción tuya.
  - Se eliminó el desplazamiento vertical que lo centraba al ocultar el panel: ahora queda siempre arriba.
- Deshacer, Rehacer y Play/Pausa siguen sobre el lienzo, sin cambios.
- Pantalla completa: solo con su botón, como antes.

## 2. Sin el gran espacio vacío de «Animar»

- **La fila de herramientas va justo debajo del lienzo y de la línea de tiempo.** Ruta, Ancla, Eliminar, Congelar, Natural, 2.5D… se ven en cuanto entras en Animar.
- Si no hay herramienta elegida, **no se dibuja ningún panel**. Se quitaron los textos de relleno: «Elige una herramienta», «Dibuja una ruta…», «Toca la imagen…» y los de Proteger.
  - La indicación corta y temporal que sale sobre el lienzo al elegir una herramienta sigue igual.
  - La ayuda larga, solo con el botón **?** o manteniendo pulsada la herramienta (como en la v39).
- Al elegir una herramienta con ajustes, sus opciones aparecen **debajo de la fila**, con una altura propia según lo que muestran (`PanelKind`):
  - accesos a animaciones activas: una fila (54 dp);
  - Ruta con rutas dibujadas: 2 deslizadores y un botón (150 dp);
  - pincel de Proteger o de zona: 200 dp;
  - catálogo de Efectos: 236 dp;
  - edición de un efecto: 250 dp;
  - Ajustes y Bucle: 214 dp.
- Si la opción no cabe entera, tiene su propio scroll. Lo de arriba no se mueve.

## 3. Parte inferior organizada (lógica tipo CapCut)

- **Orden fijo, de arriba abajo:**
  1. barra superior;
  2. lienzo;
  3. línea de tiempo fina;
  4. bloques de la línea de tiempo, solo si los despliegas;
  5. fila de herramientas;
  6. opciones, solo si existen;
  7. asa;
  8. barra de categorías (Animar · Proteger · Efectos · Ajustes).
- **Tocar una categoría cambia solo su fila y sus opciones.** El lienzo, la línea de tiempo y la barra de categorías no se mueven.
- **Subvistas:**
  - el catálogo de Efectos y Ajustes tienen un ✕ pequeño en la esquina para cerrarlos; se vuelven a abrir al elegir otra herramienta o categoría;
  - la edición de un efecto mantiene sus ✓ y ✕.
- **Asa (sin cambios de uso):**
  - tocar o deslizar cambia entre compacto, ampliado y oculto;
  - ampliado da a las opciones todo el espacio libre, sin tocar el lienzo;
  - oculto deja solo el asa.
- **Línea de tiempo:** desplegar sus bloques ya no abre ni amplía ningún panel. Los bloques se colocan bajo la línea fina (como mucho 3 carriles) y las opciones se reducen para dejarles sitio.
- **En horizontal / tableta:** columna lateral con el mismo orden (línea de tiempo, herramientas, opciones, categorías).
- **Imágenes horizontales:**
  - el lienzo sigue tomando solo la altura que la imagen necesita (no vuelve el negro alrededor que se corrigió en la v39);
  - el espacio que sobra queda libre bajo la fila de herramientas y lo usan las opciones al elegir una herramienta;
  - no se reserva nada encima de las herramientas.

Esquemas calculados con las medidas reales de `EditorLayout`, para un teléfono de 392 × 820 dp. **Son dibujos generados a partir de las fórmulas, no capturas del teléfono:**
- `docs/v40_esquema_vertical_9x16.png`
- `docs/v40_esquema_horizontal_16x9.png`

## 4. Calidad visual de los efectos (estilo anime, sin fotorrealismo)

Todo está en `assets/shaders/fondo.frag`. Se conservan todos los parámetros, colores personalizados, formas, zonas, máscaras y la línea de tiempo (modos Una vez / Repetir / Continuo). Comparación V39 frente a V40 con el mismo shader y los valores por defecto: `docs/v40_efectos_antes_despues.png`.

- **Explosión (reescrita):**
  - destello breve que ilumina la escena;
  - bola de fuego hecha de cúmulos irregulares (7 lóbulos unidos con borde de «coliflor» que hierve), no una mancha ni un círculo;
  - bandas de color planas que se **enfrían** de blanco → amarillo → naranja → brasa → humo, en vez de desvanecerse como un velo;
  - humo residual que sube, se ensancha y se deshace en jirones, con luz arriba y sombra abajo;
  - fragmentos que salen girando, caen por gravedad, pasan de incandescentes a oscuros y dejan estela;
  - chispas finas estiradas por la velocidad;
  - onda de aire rota.
  - Las 4 formas siguen distintas:
    - Clásica;
    - Hongo: la bola sube, con tallo de humo y falda de polvo en el suelo;
    - Estallido manga: tinta negra, trama de puntos, contorno y líneas de impacto, animada «en dos»;
    - Energía: sin humo, con anillos dobles luminosos.
- **Humo (formas Ondulante, Tinta manga y Rastrero):**
  - columna de **bocanadas** que nacen, viajan con el viento, crecen, se curvan y se disuelven;
  - las nuevas se dibujan delante de las viejas, lo que da profundidad;
  - cada bocanada tiene luz, tono medio y sombra, y se compone como una sola capa (no se ven discos transparentes superpuestos);
  - en Tinta manga, el contorno va solo en la silueta.
  - «Llenar toda la zona»: dos capas (lejos y cerca) con bordes vaporosos; se quitaron las rayas y las manchas tipo camuflaje.
  - La forma «Hilos» queda como estaba.
- **Fuego:**
  - lenguas que se afinan en los bordes de la zona pintada, en lugar del corte vertical recto;
  - la hoguera se estrecha hacia arriba;
  - llamas algo más altas en zonas anchas;
  - colores planos sólidos de anime, sin velos;
  - luz cálida que parpadea sobre la escena alrededor del fuego.
- **Energía:**
  - Rayos: púas afiladas de largo irregular que laten cada una a su ritmo, con núcleo y resplandor (antes era una estrella geométrica perfecta).
  - Anillos: borde de luz nítido con estela hacia dentro, grosor y radio que ondulan, tramos rotos.
  - Aura y Aura de batalla:
    - lenguas más vivas que suben desde la silueta;
    - resplandor exterior;
    - **luz de contorno sobre el personaje**, que lo integra con el aura;
    - el aura ya no tapa al personaje;
    - el contorno de tinta queda solo por fuera.
- **Rayos y relámpago:**
  - Electricidad: arcos con resplandor más amplio y horquillas que nacen del arco.
  - Relámpago:
    - canal que se adelgaza hacia la punta;
    - 3 ramas que nacen del canal (antes una rama empezaba con un salto);
    - punta suave con resplandor de impacto;
    - segunda descarga breve, como un rayo real;
    - destello que ilumina más el cielo que el suelo.
- **Agua:**
  - Cascada (reescrita): cortinas de agua que caen con vetas claras y oscuras, labio de espuma arriba, espuma que hierve abajo y bruma bajo la cascada. Se detecta con tu propia zona pintada.
  - Olas con espuma:
    - el frente de espuma va delante y su estela detrás (antes el orden quedaba invertido respecto al movimiento);
    - encaje de espuma redondeado en vez de bloques verticales;
    - cara y seno de la ola con volumen suave.
  - Agua (pintar agua): líneas de luz finas en las crestas que miran a la luz.
- **Rayos de luz:** haces de ancho y brillo irregulares que respiran lentamente, y motas de polvo que solo brillan dentro de la luz.
- **Rendimiento:**
  - no se añadieron capas de partículas a pantalla completa;
  - las partes caras de la explosión solo se calculan dentro de su zona;
  - las bocanadas de humo y las horquillas eléctricas se saltan los píxeles que no tocan;
  - la cascada no calcula nada fuera de su zona;
  - el shader compilado se guarda por contenido, así que la caché antigua se ignora sola y se vuelve a compilar una vez.
- **Bucle perfecto:**
  - todo depende de fases enteras del bucle;
  - se corrigió de paso un salto en el último cuadro de la Electricidad (afectaba al cuadro que no se exporta).
- **Miniaturas:** 13 tiras regeneradas con **el mismo shader y los valores por defecto**: explosión, humo, fuego, energía, electricidad, relámpago, cascada, olas, agua, rayos de luz, aura oscura, dispersión y revelación.
  - Las tres últimas ya no usan una silueta de personaje repetida: aura oscura sobre una torre, dispersión sobre una luna, revelación sobre un paisaje.
  - Generador: `tools/make_thumbs.py`.

## Pruebas realmente hechas en este entorno

- **Shader real (`fondo.frag`) compilado, enlazado y dibujado** con OpenGL ES 3.0 por EGL sin pantalla (Mesa, por software).
  - Se rellena el bloque de parámetros con los mismos desplazamientos que consulta la app.
  - Herramienta: `tools/fx_render.py`.
  - Revisé visualmente cuadro a cuadro la explosión (4 formas), el humo (5 variantes), el fuego, la energía (4 formas), la electricidad, el relámpago, la cascada, las olas, el agua y los rayos de luz.
- **`tools/check_v40_fx.py`:** 27 casos y **0 fallos**. Comprueba que cada efecto cambia la imagen, que el cuadro final de bucle es idéntico al primero y que la explosión termina sin restos.
- **Disposición del editor:** repliqué las fórmulas de `EditorLayout` en Python y comprobé 864 casos: 4 tamaños de teléfono × 6 proporciones × 2 estados × 9 tipos de opciones, con y sin bloques de línea de tiempo. Resultado: 0 problemas. Nada se solapa con el asa ni con las categorías, el lienzo es idéntico en compacto y ampliado, y quedan siempre al menos 180 dp de lienzo y 160 dp para opciones.
- **Pruebas unitarias nuevas, escritas pero no ejecutadas:** `V40Test` (disposición) y `V40ShaderTest` (contratos del shader y miniaturas). Se adaptó una prueba de `V39Test` a la nueva regla.
  - Repliqué las comprobaciones de texto de `V40ShaderTest` y `V38ShaderTest`, y pasan.
  - El bloque de parámetros del shader es idéntico al de la V39 (no se añadió ni quitó ningún parámetro), así que el contrato Kotlin ↔ shader de `V36Test` no cambia.
- **No compilado:** el código Kotlin no se pudo compilar aquí. Gradle, Maven y el compilador de Kotlin no se pueden descargar en este entorno, así que no ejecuté `./gradlew assembleDebug` ni `./gradlew test`.
  - Revisé a mano los cambios de Compose: importaciones, ámbitos y `coerceIn` sin rangos invertidos.
  - Aun así, la primera compilación en Android Studio o GitHub Actions es la comprobación real.
- **No probado en dispositivo.** No hay capturas ni vídeo del teléfono: las imágenes de `docs/` son renders del shader y esquemas calculados.
- `tools/check_render.py` (antiguo) ya fallaba en la V39 con el mismo error. Escribe los parámetros de una forma anterior al bloque de parámetros. No se tocó.
- **GitHub:** ninguna operación (sin push, commits, ramas ni workflows).

## Archivos cambiados

- `model/EditorLayout.kt`: lienzo fijo, `PanelKind` y `panelHeight`.
- `ui/EditorScreen.kt`: nuevo orden de la parte inferior; el lienzo siempre arriba.
- `ui/EditorTools.kt`: `panelKind()`, ✕ en catálogo y ajustes, y fuera los textos de relleno.
- `AppViewModel.kt`: `optionsClosed`.
- `assets/shaders/fondo.frag`: efectos.
- `assets/thumbs/*.webp`: 13 miniaturas.
- `app/build.gradle.kts`: versión 41 / 40.0.0.
- Pruebas: `V39Test.kt`, `V40Test.kt` (nuevo) y `engine/V40ShaderTest.kt` (nuevo).
- Herramientas nuevas: `tools/fx_render.py`, `tools/check_v40_fx.py` y `tools/make_thumbs.py`.
- `docs/`: comparación de efectos y esquemas.

## Qué comprobar en tu teléfono

1. Entrar en Animar sin herramienta: la fila de herramientas aparece justo bajo la imagen y no hay bloque con texto.
2. Cambiar entre Animar, Proteger, Efectos y Ajustes: la imagen no se mueve ni cambia de tamaño.
3. Elegir Ruta, dibujar una ruta: aparecen solo sus 2 deslizadores. Abrir el catálogo y cerrarlo con ✕.
4. Desplegar los bloques de la línea de tiempo: no se solapan con herramientas ni categorías.
5. Asa: compacto, ampliado y oculto. El lienzo solo crece al ocultar.
6. Imagen vertical, cuadrada y horizontal.
7. Explosión con sus 4 formas, humo, fuego, energía, relámpago, cascada y olas, en vista previa y en el vídeo exportado.
8. Fluidez de la vista previa con la explosión y el humo activos en un teléfono modesto.
