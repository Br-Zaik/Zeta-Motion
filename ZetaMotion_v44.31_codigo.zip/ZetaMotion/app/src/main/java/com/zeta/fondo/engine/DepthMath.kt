package com.zeta.fondo.engine

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Matemática de máscaras sin Android (se prueba en la JVM): reescalado, desenfoque de caja y la
 * silueta automática del personaje (fondo liso de los bordes + caras) de «Buscar personaje solo».
 */
object DepthMath {

    /** Percentiles [lo] y [hi] (0..1) de los valores finitos, con una muestra de hasta 65 536. */
    fun percentiles(raw: FloatArray, lo: Float, hi: Float): FloatArray {
        val step = max(1, raw.size / 65_536)
        val sample = ArrayList<Float>(raw.size / step + 1)
        var i = 0
        while (i < raw.size) { val v = raw[i]; if (v.isFinite()) sample.add(v); i += step }
        if (sample.isEmpty()) return floatArrayOf(0f, 1f)
        sample.sort()
        fun at(p: Float) = sample[((sample.size - 1) * p.coerceIn(0f, 1f)).roundToInt()]
        return floatArrayOf(at(lo), at(hi))
    }

    /** Reescalado bilineal de un mapa de un canal (fila 0 = arriba). */
    fun resize(src: ByteArray, sw: Int, sh: Int, dw: Int, dh: Int): ByteArray {
        if (sw == dw && sh == dh) return src.copyOf()
        val out = ByteArray(dw * dh)
        for (y in 0 until dh) {
            val fy = ((y + .5f) * sh / dh - .5f).coerceIn(0f, (sh - 1).toFloat())
            val y0 = fy.toInt(); val y1 = minOf(y0 + 1, sh - 1); val ty = fy - y0
            for (x in 0 until dw) {
                val fx = ((x + .5f) * sw / dw - .5f).coerceIn(0f, (sw - 1).toFloat())
                val x0 = fx.toInt(); val x1 = minOf(x0 + 1, sw - 1); val tx = fx - x0
                fun p(xx: Int, yy: Int) = (src[yy * sw + xx].toInt() and 0xFF).toFloat()
                val top = p(x0, y0) + (p(x1, y0) - p(x0, y0)) * tx
                val bot = p(x0, y1) + (p(x1, y1) - p(x0, y1)) * tx
                out[y * dw + x] = (top + (bot - top) * ty + .5f).toInt().coerceIn(0, 255).toByte()
            }
        }
        return out
    }

    /**
     * v44.10 · Silueta aproximada del personaje (0..1) a partir de caras normalizadas
     * [x, y, ancho, alto] (0..1): cabeza con pelo (elipse) + cuello y torso que se ensanchan
     * hacia abajo hasta el borde inferior. Bordes suaves. Sirve para «Buscar personaje solo».
     */
    fun subjectPrior(w: Int, h: Int, faces: List<FloatArray>): FloatArray {
        val out = FloatArray(w * h)
        for (f in faces) {
            if (f.size < 4) continue
            val fx = f[0] * w; val fy = f[1] * h; val fw = f[2] * w; val fh = f[3] * h
            if (fw < 2f || fh < 2f) continue
            val cx = fx + fw / 2f
            val hcY = fy + fh * .42f
            val hrx = fw * .95f; val hry = fh * 1.0f        // cabeza + pelo
            val neckY = fy + fh * .85f
            for (y in 0 until h) {
                val py = y + .5f
                val t = (py - neckY) / (fh * 1.3f)            // 0 en el cuello, 1 ≈ hombros
                val half = if (t < 0f) 0f else fw * (.42f + .9f * min(t, 1f) + .35f * max(0f, t - 1f))
                for (x in 0 until w) {
                    val px = x + .5f
                    val ex = (px - cx) / hrx; val ey = (py - hcY) / hry
                    val head = smooth(1.08f, .8f, kotlin.math.sqrt(ex * ex + ey * ey))
                    val body = if (half <= 0f) 0f else smooth(half * 1.15f, half * .85f, kotlin.math.abs(px - cx)) *
                        smooth(neckY - fh * .1f, neckY + fh * .1f, py)
                    val v = max(head, body)
                    val i = y * w + x
                    if (v > out[i]) out[i] = v
                }
            }
        }
        return boxBlur(out, w, h, max(1, max(w, h) / 64))
    }

    /**
     * v44.10 · Silueta del personaje SIN IA: el fondo de las ilustraciones anime suele ser liso
     * y estar en las esquinas de arriba. Se «inunda» desde esas esquinas (y la parte alta de los
     * lados) por píxeles de color parecido y sin línea de tinta en medio; lo que no se inunda es
     * el personaje. Devuelve 0..1 (1 = personaje) o null si la imagen no parece un retrato con
     * fondo separable (paisajes, fondos muy cargados): entonces no se propone personaje.
     */
    fun subjectFromBackground(argb: IntArray, w: Int, h: Int): FloatArray? {
        val n = w * h
        if (w < 16 || h < 16 || argb.size < n) return null
        val r = FloatArray(n); val g = FloatArray(n); val b = FloatArray(n)
        for (i in 0 until n) { val c = argb[i]; r[i] = ((c shr 16) and 0xFF) / 255f; g[i] = ((c shr 8) and 0xFF) / 255f; b[i] = (c and 0xFF) / 255f }
        val cw = max(3, (w * .10f).toInt()); val ch = max(3, (h * .08f).toInt())
        val seeds = ArrayList<Int>()
        for (y in 0 until ch) { for (x in 0 until cw) seeds.add(y * w + x); for (x in w - cw until w) seeds.add(y * w + x) }
        for (y in 0 until (h * .4f).toInt()) for (x in intArrayOf(0, 1, w - 2, w - 1)) seeds.add(y * w + x)
        // Paleta del fondo: hasta 64 colores de las semillas.
        val step = max(1, seeds.size / 64)
        val pal = seeds.filterIndexed { k, _ -> k % step == 0 }.map { floatArrayOf(r[it], g[it], b[it]) }
        fun score(i: Int): Float {
            var best = Float.MAX_VALUE
            for (p in pal) {
                val dr = r[i] - p[0]; val dg = g[i] - p[1]; val db = b[i] - p[2]
                val d = dr * dr + dg * dg + db * db
                if (d < best) best = d
            }
            return sqrt(best)
        }
        val thr = .10f; val near = .03f * .03f
        val bg = BooleanArray(n)
        val queue = IntArray(n); var head = 0; var tail = 0
        for (i in seeds) if (!bg[i] && score(i) < thr) { bg[i] = true; queue[tail++] = i }
        val sc = FloatArray(n) { -1f }
        while (head < tail) {
            val i = queue[head++]; val x = i % w; val y = i / w
            for (k in 0..3) {
                val nx = x + intArrayOf(1, -1, 0, 0)[k]; val ny = y + intArrayOf(0, 0, 1, -1)[k]
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                val j = ny * w + nx
                if (bg[j]) continue
                val dr = r[j] - r[i]; val dg = g[j] - g[i]; val db = b[j] - b[i]
                if (dr * dr + dg * dg + db * db >= near) continue
                if (sc[j] < 0f) sc[j] = score(j)
                if (sc[j] >= thr) continue
                bg[j] = true; queue[tail++] = j
            }
        }
        val frac = tail.toFloat() / n
        if (frac < .04f || frac > .85f) return null
        return boxBlur(FloatArray(n) { if (bg[it]) 0f else 1f }, w, h, max(1, max(w, h) / 96))
    }

    /**
     * v44.24 · Silueta del personaje (0..1) sin IA, la mejor disponible:
     *  1. fondo liso inundado desde las esquinas, SOLO si es creíble (antes una imagen con fondo
     *     con detalle podía dar el 80 % de la imagen como «personaje» y la silueta no servía);
     *  2. si no, la silueta por color y nitidez ([SubjectSegment]), que funciona sin caras;
     *  3. las caras detectadas se suman a cualquiera de las dos (o van solas).
     * null = no se distingue un personaje (paisajes).
     */
    fun subjectAuto(argb: IntArray, w: Int, h: Int, faces: List<FloatArray> = emptyList()): FloatArray? {
        val fromBg = subjectFromBackground(argb, w, h)?.takeIf { SubjectSegment.plausible(it, argb, w, h) }
        val shape = fromBg ?: SubjectSegment.detect(argb, w, h)
        val fromFaces = if (faces.isNotEmpty()) subjectPrior(w, h, faces) else null
        return when {
            shape != null && fromFaces != null -> FloatArray(w * h) { max(shape[it], fromFaces[it]) }
            else -> shape ?: fromFaces
        }
    }

    /**
     * v44.16 · «Proteger automático»: silueta del personaje (0..255) para los efectos que la
     * necesitan (luz de contorno, aura, efectos detrás del personaje) cuando el usuario aún no ha
     * pintado Proteger. Une el fondo liso inundado y las caras detectadas. null = no se distingue.
     */
    fun autoProtect(argb: IntArray, w: Int, h: Int, faces: List<FloatArray> = emptyList()): ByteArray? {
        val s = subjectAuto(argb, w, h, faces) ?: return null
        // Cierre morfológico (dilatar y luego erosionar): tapa los huecos finos que deja la tinta
        // dentro del pelo o la ropa, para que el aura y la luz no aparezcan DENTRO del personaje.
        val r = max(2, max(w, h) / 48)
        val dil = boxBlur(FloatArray(w * h) { if (s[it] > .5f) 1f else 0f }, w, h, r)
        val closed = boxBlur(FloatArray(w * h) { if (dil[it] > .2f) 1f else 0f }, w, h, r)
        val soft = boxBlur(FloatArray(w * h) { if (closed[it] > .8f) 1f else 0f }, w, h, max(1, r / 3))
        var cover = 0f
        for (v in soft) cover += v
        cover /= soft.size
        if (cover < .04f || cover > .92f) return null
        return ByteArray(w * h) { (soft[it] * 255f).roundToInt().coerceIn(0, 255).toByte() }
    }

    /** 1 cuando v ≤ b, 0 cuando v ≥ a (a > b), suave entre medias; o al revés si a < b. */
    private fun smooth(a: Float, b: Float, v: Float): Float {
        val t = ((v - a) / (b - a)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** Desenfoque de caja separable (radio [r]) con sumas acumuladas: O(n) sea cual sea el radio. */
    fun boxBlur(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(w * h); val out = FloatArray(w * h)
        val acc = FloatArray(max(w, h) + 1)
        for (y in 0 until h) {
            acc[0] = 0f
            for (x in 0 until w) acc[x + 1] = acc[x] + src[y * w + x]
            for (x in 0 until w) { val a = max(0, x - r); val b = minOf(w, x + r + 1); tmp[y * w + x] = (acc[b] - acc[a]) / (b - a) }
        }
        for (x in 0 until w) {
            acc[0] = 0f
            for (y in 0 until h) acc[y + 1] = acc[y] + tmp[y * w + x]
            for (y in 0 until h) { val a = max(0, y - r); val b = minOf(h, y + r + 1); out[y * w + x] = (acc[b] - acc[a]) / (b - a) }
        }
        return out
    }

}
