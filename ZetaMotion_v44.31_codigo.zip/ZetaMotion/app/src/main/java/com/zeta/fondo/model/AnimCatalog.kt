package com.zeta.fondo.model

/**
 * v44 · Catálogo de Animar, con el mismo flujo que Efectos: categorías, miniaturas que
 * enseñan lo que hace cada animación, tocar = probar sobre tu imagen (sin confirmar),
 * tocar otra vez = Ajustar, ✓ confirma y ✕ descarta. Código puro (pruebas JVM).
 *
 * v44.30 · Nada repetido: aquí solo están las animaciones que viven en Animar (cámara, viento,
 * tela y zonas). Las herramientas de dedo (Ruta, Ancla y Borrar) están únicamente en la
 * barra de Animar; Agua, Cielo y Ojos brillantes, únicamente en Efectos; el 2.5D se retiró.
 */
object AnimCatalog {
    /**
     * [effectId] = animación del motor (cam, natural, mesh, zonemotion).
     * [variant] = estilo dentro del efecto (modo de cámara, preset…).
     * [thumb] = miniatura (assets/thumbs/<thumb>.webp, renderizada con el shader de la app).
     */
    data class Entry(val key: String, val title: String, val effectId: String,
                     val variant: Int = 0, val thumb: String = effectId, val needsZone: Boolean = false)

    val categories = listOf("Cámara", "Viento y tela", "Zona y personaje")

    private fun cam(mode: Int, title: String) = Entry("cam$mode", title, "cam", mode, thumb = "anim_cam$mode")

    val entries: Map<String, List<Entry>> = mapOf(
        "Cámara" to listOf(
            cam(0, "Acercar"), cam(1, "Alejar"), cam(2, "Desplazar"), cam(3, "Girar"),
            cam(4, "Temblar"), cam(5, "Órbita 3D"), cam(6, "Latido"), cam(7, "Flotar"), cam(8, "Balanceo"),
            Entry("cam9", "Cámara libre (◆)", "cam", 9, thumb = "anim_cam0")),
        "Viento y tela" to listOf(
            Entry("natural4", "Cabello", "natural", 4, needsZone = true),
            Entry("natural5", "Ropa", "natural", 5, needsZone = true),
            Entry("natural1", "Bandera", "natural", 1, needsZone = true),
            Entry("natural3", "Cortina", "natural", 3, needsZone = true),
            Entry("natural0", "Árbol", "natural", 0, needsZone = true),
            Entry("natural2", "Pasto", "natural", 2, needsZone = true),
            Entry("mesh2", "Tela ondulante", "mesh", 2, needsZone = true),
            Entry("mesh0", "Ondulación", "mesh", 0, needsZone = true)),
        "Zona y personaje" to listOf(
            Entry("zonemotion0", "Balanceo de zona", "zonemotion", 0, needsZone = true),
            Entry("zonemotion1", "Ondulación de zona", "zonemotion", 1, needsZone = true),
            Entry("zonemotion2", "Respiración", "zonemotion", 2, needsZone = true),
            Entry("mesh1", "Respirar (tela)", "mesh", 1, needsZone = true))
    )

    fun all(): List<Entry> = categories.flatMap { entries[it].orEmpty() }
    fun find(key: String): Entry? = all().firstOrNull { it.key == key }

    /** ¿Esta entrada es la que está activa con los ajustes actuales? */
    fun isActive(e: Entry, s: Map<String, Float>): Boolean {
        if ((s["${e.effectId}.on"] ?: 0f) < .5f) return false
        val v = when (e.effectId) {
            "cam" -> s["cam.mode"]
            else -> s["${e.effectId}.variant"]
        }?.toInt() ?: 0
        return v == e.variant
    }
}
