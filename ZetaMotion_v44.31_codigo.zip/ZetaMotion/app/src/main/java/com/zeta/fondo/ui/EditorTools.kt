package com.zeta.fondo.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.model.EditorTab
import com.zeta.fondo.model.Tool

/*
 * v38 · Herramientas del editor (fila compacta sobre las categorías) y el panel de cada
 * herramienta. Una sola regla para toda la app:
 *   categoría (abajo) → herramientas (fila) → opciones (panel sobre la fila).
 */

// ------------------------------------------------------------------ Barra inferior (v41)
// Una sola barra, como en un editor de vídeo:
//   principal: Animar · Proteger · Efectos · Imagen · Texto · Audio · Ajustes
//   categoría o selección: «<» + sus herramientas (tocar «<» vuelve a la principal).

private data class MainItem(val label: String, val icon: ImageVector, val action: (AppViewModel) -> Unit)

private val mainItems = listOf(
    MainItem("Animar", Icons.Filled.PlayCircleOutline) { it.openCategory(EditorTab.TOOLS) },
    MainItem("Proteger", Icons.Filled.Shield) { it.openCategory(EditorTab.MASKS) },
    MainItem("Efectos", Icons.Filled.AutoAwesome) { it.openCategory(EditorTab.EFFECTS) },
    MainItem("Audio", Icons.Filled.MusicNote) { it.openAudio() },
    MainItem("Ajustes", Icons.Filled.Settings) { it.openCategory(EditorTab.CANVAS) }
)

/** Barra principal: iconos con su nombre, sin fondos, repartidos a lo ancho. */
@Composable
fun MainBar(vm: AppViewModel, modifier: Modifier) {
    // v44.23: «Imagen» agrega otra imagen encima (capa), como en Alight Motion o ibisPaint.
    // v44.25: se pueden elegir VARIAS a la vez (hasta el máximo del teléfono; ver addLayers).
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.PickMultipleVisualMedia(
            com.zeta.fondo.model.ImageLayers.maxLayers(false))) { uris -> if (uris.isNotEmpty()) vm.addLayers(uris) }
    val items = mainItems.take(3) + MainItem("Imagen", Icons.Filled.AddPhotoAlternate) { model ->
        val limit = com.zeta.fondo.model.ImageLayers.maxLayers(model.lowResourceDevice)
        if (model.layers.size >= limit) {
            model.message = "Máximo $limit imágenes por proyecto en este teléfono."
            return@MainItem
        }
        val ok = try {
            picker.launch(androidx.activity.result.PickVisualMediaRequest(
                androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly))
            true
        } catch (_: Throwable) { false }
        if (!ok) model.message = "No se pudo abrir la galería"
    } + MainItem("Texto", Icons.Filled.TextFields) { it.openNewText() } + mainItems.drop(3)
    // v44.24: en tabletas los botones no se separan de más (como máximo 560 dp, centrados).
    // v44.31: con 7 botones, en teléfonos angostos (360 dp) la letra baja a 10 sp para que
    // «Proteger» no salga cortado; nunca se montan.
    BoxWithConstraints(modifier.background(Night), contentAlignment = Alignment.Center) {
        val perItem = minOf(maxWidth, 560.dp) / items.size
        val labelSize = if (perItem < 56.dp) 10.sp else 11.sp
        Row(Modifier.fillMaxHeight().fillMaxWidth().widthIn(max = 560.dp), verticalAlignment = Alignment.CenterVertically) {
            items.forEach { item ->
                Column(Modifier.weight(1f).fillMaxHeight().clickable { item.action(vm) },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(item.icon, null, tint = StudioText, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.height(4.dp))
                    Text(item.label, color = StudioText, fontSize = labelSize, maxLines = 1, softWrap = false,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 1.dp))
                }
            }
        }
    }
}

/** «<» a la izquierda y las herramientas al lado, con desplazamiento lateral. */
@Composable
fun BarWithBack(modifier: Modifier, onBack: () -> Unit, content: @Composable RowScope.() -> Unit) {
    Row(modifier.background(Night), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.padding(start = 8.dp, end = 4.dp).size(width = 40.dp, height = 52.dp)
            .clip(RoundedCornerShape(10.dp)).background(StudioTile).clickable(onClick = onBack),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.ChevronLeft, "Volver", tint = StudioText, modifier = Modifier.size(24.dp))
        }
        Row(Modifier.weight(1f).fillMaxHeight().horizontalScroll(rememberScrollState()).padding(end = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically,
            content = content)
    }
}

/**
 * Botón de herramienta plano: icono y nombre, sin recuadro. Activo = rosa. Mantener
 * pulsado muestra una ayuda corta.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ToolChip(label: String, icon: ImageVector, selected: Boolean, modifier: Modifier = Modifier,
             enabled: Boolean = true, badge: String? = null, help: String? = null,
             onHelp: ((String) -> Unit)? = null, onClick: () -> Unit) {
    val tint = when {
        !enabled -> StudioMuted.copy(alpha = .45f)
        selected -> StudioPink
        else -> StudioText
    }
    // v44.31: el ancho crece con el nombre (mínimo 64 dp). Antes era fijo y nombres como
    // «Diagnóstico» o «Quitar clave» salían cortados («Diagnós…»). Las barras se desplazan de lado.
    Box(modifier.widthIn(min = 64.dp).fillMaxHeight().clip(RoundedCornerShape(10.dp))
        .combinedClickable(enabled = enabled, onClickLabel = label,
            onLongClick = if (help != null && onHelp != null) ({ onHelp(help) }) else null,
            onClick = onClick), contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxHeight().padding(horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
            Spacer(Modifier.height(4.dp))
            Text(label, color = tint, fontSize = 11.sp, lineHeight = 12.sp, maxLines = 1, softWrap = false,
                textAlign = TextAlign.Center,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
        }
        if (badge != null) Text(badge, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 6.dp, end = 8.dp).clip(RoundedCornerShape(6.dp))
                .background(StudioPink).padding(horizontal = 4.dp))
    }
}

/** Botón «?» al final de cada fila: abre la ayuda de la categoría. */
@Composable
private fun HelpChip(vm: AppViewModel, tab: EditorTab) {
    Box(Modifier.width(48.dp).fillMaxHeight().clip(RoundedCornerShape(12.dp)).clickable { vm.helpTab = tab },
        contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.HelpOutline, "Ayuda", tint = StudioMuted, modifier = Modifier.size(20.dp))
    }
}

/** Contenido de una barra con «<» (las filas de cada categoría se dibujan aquí dentro). */
@Composable
private fun ToolRowContainer(modifier: Modifier, content: @Composable RowScope.() -> Unit) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically,
        content = content)
}

/** Ayudas cortas (pulsación larga en cada herramienta y diálogo «?»). */
internal val toolHelp = mapOf(
    "Catálogo" to "Todas las animaciones, con su miniatura",
    "Ruta" to "Dibuja la dirección del movimiento",
    "Ancla" to "Toca para fijar un punto que no se mueve",
    "Borrar" to "Toca una ruta o un ancla para quitarla",
    "Pincel" to "Un dedo pinta · dos dedos hacen zoom",
    "Borrador" to "Borra lo pintado",
    "Rellenar" to "Pinta toda la capa",
    "Vaciar" to "Borra toda la capa",
    "Mostrar" to "Muestra u oculta la máscara",
    "Opciones" to "Tamaño, borde, capa y transparencia"
)

/** Barra inferior según el contexto (una sola barra, nunca dos filas). */
@Composable
fun EditorToolRow(vm: AppViewModel, modifier: Modifier) {
    val editing = vm.editingEffect
    when {
        // v44.27: recortando una capa → ✕ · proporciones · Girar · Original · ✓.
        vm.layerCrop != null -> LayerCropBar(vm, modifier)
        vm.paintingZone && editing != null -> BarWithBack(modifier, onBack = { vm.finishPainting() }) {
            BrushToolRow(vm, Modifier, onDone = { vm.finishPainting() })
        }
        // v44.23: capa de imagen seleccionada → sus acciones (Mezcla, Clave, Movimiento…).
        vm.selectedLayerObj() != null && !vm.paintingZone -> LayerActionRow(vm, modifier)
        // v40: bloque seleccionado en la línea de tiempo → sus acciones (edición por contexto).
        vm.selectedClip() != null && !vm.paintingZone -> ClipActionRow(vm, modifier)
        // v44.30: la pista de la imagen muestra los mismos Ajustes del proyecto (una sola lista).
        vm.imageSelected -> BarWithBack(modifier, onBack = { vm.selectImageTrack(false) }) { SettingsToolRow(vm, Modifier) }
        !vm.categoryOpen -> MainBar(vm, modifier)
        vm.tab == EditorTab.TOOLS -> BarWithBack(modifier, onBack = { vm.backToMain() }) { AnimateToolRow(vm, Modifier) }
        vm.tab == EditorTab.MASKS -> BarWithBack(modifier, onBack = { vm.backToMain() }) { ProtectToolRow(vm, Modifier) }
        else -> BarWithBack(modifier, onBack = { vm.backToMain() }) { SettingsToolRow(vm, Modifier) }
    }
}

/** Separador fino entre grupos (herramientas de un dedo · animaciones · global). */
@Composable
private fun GroupDivider() {
    Box(Modifier.width(1.dp).height(28.dp).background(StudioMuted.copy(alpha = .25f)))
}

/**
 * v44.30 · Animar sin nada repetido: las animaciones están SOLO en su catálogo (miniaturas, como
 * Efectos) y aquí quedan las herramientas de dedo de las rutas. «Bucle» está en Ajustes y lo que
 * no se mueve se pinta en Proteger.
 */
@Composable
private fun AnimateToolRow(vm: AppViewModel, modifier: Modifier) {
    val guide = vm.editingEffect == null && !vm.paintingZone
    val help: (String) -> Unit = { vm.showHint(it) }
    fun guideTool(t: Tool, name: String) {
        val wasSelected = vm.tool == t && guide
        vm.selectGuideTool(t)
        if (!wasSelected) vm.showHint(toolHelp.getValue(name))
    }
    ToolRowContainer(modifier) {
        ToolChip("Catálogo", Icons.Filled.GridView, vm.animCatalogOpen, help = toolHelp["Catálogo"], onHelp = help) { vm.openAnimCatalog() }
        GroupDivider()
        // Herramientas de un dedo sobre la imagen
        ToolChip("Ruta", Icons.Filled.Timeline, guide && vm.tool == Tool.ARROW,
            badge = vm.arrows.size.takeIf { it > 0 }?.toString(), help = toolHelp["Ruta"], onHelp = help) { guideTool(Tool.ARROW, "Ruta") }
        ToolChip("Ancla", Icons.Filled.PushPin, guide && vm.tool == Tool.ANCHOR,
            badge = vm.anchors.size.takeIf { it > 0 }?.toString(), help = toolHelp["Ancla"], onHelp = help) { guideTool(Tool.ANCHOR, "Ancla") }
        ToolChip("Borrar", Icons.Filled.RemoveCircleOutline, guide && vm.tool == Tool.ERASE_GUIDE,
            enabled = vm.arrows.isNotEmpty() || vm.anchors.isNotEmpty(), help = toolHelp["Borrar"], onHelp = help) { guideTool(Tool.ERASE_GUIDE, "Borrar") }
        HelpChip(vm, EditorTab.TOOLS)
    }
}

@Composable
private fun ProtectToolRow(vm: AppViewModel, modifier: Modifier) {
    val painting = vm.paintingZone
    val help: (String) -> Unit = { vm.showHint(it) }
    ToolRowContainer(modifier) {
        ToolChip("Pincel", Icons.Filled.Brush, painting && !vm.eraser, help = toolHelp["Pincel"], onHelp = help) {
            if (!painting) vm.protect()
            vm.eraser = false
        }
        ToolChip("Borrador", ZetaEraserIcon, painting && vm.eraser, help = toolHelp["Borrador"], onHelp = help) {
            if (!painting) vm.protect()
            vm.eraser = true
        }
        ToolChip("Rellenar", Icons.Filled.FormatColorFill, false, help = toolHelp["Rellenar"], onHelp = help) {
            if (!painting) vm.protect()
            vm.fillLayer(false)
        }
        ToolChip("Vaciar", Icons.Filled.LayersClear, false, help = toolHelp["Vaciar"], onHelp = help) {
            if (!painting) vm.protect()
            vm.fillLayer(true)
        }
        ToolChip(if (vm.showMasks) "Ocultar" else "Mostrar", if (vm.showMasks) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
            false, help = toolHelp["Mostrar"], onHelp = help) { vm.toggleMasks() }
        ToolChip("Opciones", Icons.Filled.LineWeight, false, help = toolHelp["Opciones"], onHelp = help) {
            if (!painting) vm.protect()
            vm.requestOptions()
        }
        HelpChip(vm, EditorTab.MASKS)
    }
}

/** Pincel de la zona de un efecto: mismas herramientas + Listo. */
@Composable
private fun BrushToolRow(vm: AppViewModel, modifier: Modifier, onDone: () -> Unit) {
    val help: (String) -> Unit = { vm.showHint(it) }
    ToolRowContainer(modifier) {
        ToolChip("Pincel", Icons.Filled.Brush, !vm.eraser, help = toolHelp["Pincel"], onHelp = help) { vm.eraser = false }
        ToolChip("Borrador", ZetaEraserIcon, vm.eraser, help = toolHelp["Borrador"], onHelp = help) { vm.eraser = true }
        ToolChip("Rellenar", Icons.Filled.FormatColorFill, false, help = toolHelp["Rellenar"], onHelp = help) { vm.fillLayer(false) }
        ToolChip("Vaciar", Icons.Filled.LayersClear, false, help = toolHelp["Vaciar"], onHelp = help) { vm.fillLayer(true) }
        GroupDivider()
        ToolChip("Listo", Icons.Filled.Check, true, onClick = onDone)
    }
}

/**
 * v44.30 · Ajustes del proyecto, cada cosa una sola vez: el audio tiene su botón en la barra
 * principal y aquí no se repite. El número es la sección de [SettingsPanel].
 */
private val settingsTools = listOf(
    Triple(0, "Duración", Icons.Filled.Timer),
    Triple(1, "Formato", Icons.Filled.CropPortrait),
    Triple(2, "Color", Icons.Filled.Palette),
    Triple(4, "Bucle", Icons.Filled.AllInclusive),
    Triple(5, "Vista", Icons.Filled.AspectRatio),
    Triple(7, "Viento", Icons.Filled.Air),
    Triple(9, "Mejorar", Icons.Filled.HighQuality),
    Triple(6, "Diagnóstico", Icons.Filled.Speed),
    Triple(8, "Licencias", Icons.Filled.Info)
)

@Composable
private fun SettingsToolRow(vm: AppViewModel, modifier: Modifier) {
    ToolRowContainer(modifier) {
        settingsTools.forEach { (i, label, icon) ->
            val open = vm.tab == EditorTab.CANVAS && vm.settingsSection == i && vm.optionsOpen
            ToolChip(label, icon, open) {
                if (i != 1) vm.finishCropEdit()
                when {
                    open -> vm.closeOptions()
                    // Desde la pista de la imagen: misma hoja, sin perder la selección de la pista.
                    vm.imageSelected -> vm.openImageSetting(i)
                    else -> { vm.settingsSection = i; vm.requestOptions() }
                }
            }
        }
        GroupDivider()
        ToolChip(if (vm.advancedMode) "Avanzado" else "Fácil", if (vm.advancedMode) Icons.Filled.Science else Icons.Filled.AutoFixHigh,
            vm.advancedMode) { vm.toggleAdvancedMode() }
    }
}

// ------------------------------------------------------------------ Panel

/**
 * v41 · Hoja COMPLETA: cubre la línea de tiempo y la barra (catálogo de efectos, ajustes de
 * un efecto, ajustes del proyecto, audio…), como en un editor de vídeo. ✓ la cierra.
 */
@Composable
fun FullSheet(vm: AppViewModel, modifier: Modifier) {
    val editing = vm.editingEffect
    Box(modifier.background(StudioPanel)) {
        when {
            vm.blendPanelOpen && vm.selectedLayer != null -> BlendSheet(vm)
            vm.layerFxOpen && vm.selectedLayer != null -> LayerFxSheet(vm)
            vm.soundEditing != null -> SoundClipPanel(vm, vm.soundEditing!!)
            vm.replacingClip != null && vm.replaceInAnim -> AnimCatalogPanel(vm)
            vm.replacingClip != null -> EffectCatalogPanel(vm)
            vm.animCatalogOpen && !vm.adjustOpen -> AnimCatalogPanel(vm)
            editing != null && vm.editFromCatalog && !vm.adjustOpen -> EffectCatalogPanel(vm)
            editing != null -> EffectEditorPanel(vm, editing)
            vm.tab == EditorTab.EFFECTS -> EffectCatalogPanel(vm)
            else -> SettingsPanel(vm)
        }
    }
}

/** v41 · Hoja COMPACTA sobre la barra: solo lo que necesita la herramienta (pincel, rutas). */
@Composable
fun CompactSheet(vm: AppViewModel, modifier: Modifier) {
    Box(modifier.background(StudioPanel)) {
        when {
            vm.paintingZone && vm.editingEffect != null -> SimpleBrushPanel(vm)
            vm.tab == EditorTab.MASKS -> ProtectPanel(vm)
            else -> AnimatePanel(vm)
        }
    }
}

/** Cabecera de una hoja: título y ✓ (listo). */
@Composable
fun CapHeader(title: String, onDone: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(48.dp).padding(start = 16.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = StudioText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(22.dp)).clickable(onClick = onDone),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Check, "Listo", tint = StudioText, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
internal fun PanelScroll(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
}

/** Animar: solo controles útiles de la herramienta elegida; nada de textos fijos. */
@Composable
private fun AnimatePanel(vm: AppViewModel) {
    if (vm.paintingZone) { SimpleBrushPanel(vm); return }
    PanelScroll {
        if (vm.tool == Tool.ARROW && vm.arrows.isNotEmpty()) {
            LabeledSlider("Movimiento", vm.settings["flow.amount"] ?: .35f, .05f, 1f, false) { vm.setSetting("flow.amount", it) }
            LabeledSlider("Velocidad", vm.settings["flow.cycles"] ?: 2f, 1f, 8f, true) { vm.setSetting("flow.cycles", it) }
        }
        if (vm.arrows.isNotEmpty() || vm.anchors.isNotEmpty()) SmallChoice("Borrar rutas y anclas", false) { vm.clearGuides() }
        else EmptyHint(if (vm.tool == Tool.ANCHOR) "Toca la imagen para fijar puntos" else "Dibuja una ruta sobre la imagen")
    }
}

/** Una sola línea discreta cuando no hay nada que ajustar. */
@Composable
fun EmptyHint(text: String) {
    Text(text, color = StudioMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        modifier = Modifier.padding(vertical = 4.dp))
}

/**
 * Proteger: se pinta directamente (un dedo) lo que NO se mueve; dos dedos hacen zoom.
 * Capa, tamaño, borde suave y transparencia de la máscara, sin párrafos.
 */
@Composable
private fun ProtectPanel(vm: AppViewModel) {
    PanelScroll {
        if (vm.paintingZone) {
            val layer = vm.selectedMaskLayer
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                vm.maskNames.forEachIndexed { i, name ->
                    val label = when (i) { 0 -> "Proteger"; 1 -> "Zona azul"; 2 -> "Zona verde"; else -> name }
                    SmallChoice(label, layer == i, dot = when (i) { 0 -> StudioPink; 1 -> Sky; 2 -> Color(0xFF6BD68A); else -> StudioPurple }) {
                        vm.selectMask(i)
                    }
                }
                SmallChoice("+ Nueva", false) { vm.addMask() }
            }
            LabeledSlider("Tamaño", vm.brushDp, 6f, 140f, true) { vm.brushDp = it }
            LabeledSlider("Borde suave", vm.feather, 0f, 1f, false) { vm.feather = it }
            LabeledSlider("Transparencia", vm.maskOpacity, .1f, .9f, false) { vm.changeMaskOpacity(it, persist = false) }
            // Se guarda al soltar: un solo acceso a disco por gesto.
            DisposableEffect(Unit) { onDispose { vm.changeMaskOpacity(vm.maskOpacity, persist = true) } }
        } else {
            EmptyHint("Elige Pincel para pintar lo que no se mueve")
        }
    }
}

@Composable
fun SmallChoice(label: String, selected: Boolean, dot: Color? = null, onClick: () -> Unit) {
    Row(Modifier.height(34.dp).clip(RoundedCornerShape(10.dp))
        .background(if (selected) StudioPink.copy(alpha = .9f) else StudioTile)
        .clickable(onClick = onClick).padding(horizontal = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        if (dot != null) {
            Box(Modifier.size(8.dp).clip(RoundedCornerShape(4.dp)).background(dot))
            Spacer(Modifier.width(6.dp))
        }
        Text(label, color = StudioText, fontSize = 12.sp, maxLines = 1,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
    }
}

@Composable
private fun SettingsPanel(vm: AppViewModel) {
    if (vm.settingsSection == 5) { PreviewSizePanel(vm); return }
    if (vm.settingsSection == 6) { DiagnosticsPanel(vm); return }
    if (vm.settingsSection == 7) { WindPanel(vm); return }
    if (vm.settingsSection == 8) { LicensesPanel(vm); return }
    if (vm.settingsSection == 9) { SuperResPanel(vm); return }
    Column(Modifier.fillMaxSize()) {
        if (vm.settingsSection in 0..3 && vm.settingsSection != 2)
            CapHeader(when (vm.settingsSection) { 3 -> "Audio"
                else -> settingsTools.firstOrNull { it.first == vm.settingsSection }?.second ?: "Ajustes" }) { vm.applyAndClose() }
        Box(Modifier.fillMaxWidth().weight(1f)) {
            when (vm.settingsSection) {
                0 -> DurationPanel(vm)
                1 -> CanvasPanel(vm)
                2 -> ColorPanel(vm)
                3 -> AudioPanel(vm)
                else -> LoopPanel(vm) { vm.applyAndClose() }
            }
        }
    }
}

@Composable
private fun DurationPanel(vm: AppViewModel) {
    val e = vm.exportSettings
    PanelScroll {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(4, 6, 8, 10, 15, 30).forEach { sec ->
                SmallChoice("${sec}s", e.loopSec == sec) { vm.updateExport(e.copy(loopSec = sec)); vm.saveProject() }
            }
        }
        LabeledSlider("Segundos", e.loopSec.toFloat(), 2f, 60f, true, suffix = " s") {
            vm.updateExport(vm.exportSettings.copy(loopSec = it.toInt()))
        }
        Text("Fotogramas por segundo", color = StudioMuted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(24, 30, 60).forEach { fps ->
                SmallChoice("$fps fps", e.fps == fps) { vm.updateExport(vm.exportSettings.copy(fps = fps)) }
            }
        }
        // v39: tiempos reales medidos en ESTE teléfono al abrir la imagen.
        fun sec(ms: Long) = if (ms < 0) "—" else String.format(java.util.Locale.US, "%.1f s", ms / 1000f)
        Text("Última apertura · imagen ${sec(vm.perfImageMs)} · efectos ${sec(vm.perfEffectsMs)} · 1.er zoom ${sec(vm.perfZoomMs)}",
            color = StudioMuted, fontSize = 10.sp, maxLines = 2)
    }
}

/** Ayuda de la categoría (botón «?»): todas las herramientas en una lista corta. */
@Composable
fun EditorHelpDialog(tab: EditorTab, onDismiss: () -> Unit) {
    val items = when (tab) {
        EditorTab.TOOLS -> listOf("Catálogo", "Ruta", "Ancla", "Borrar")
        EditorTab.MASKS -> listOf("Pincel", "Borrador", "Rellenar", "Vaciar", "Mostrar", "Opciones")
        else -> emptyList()
    }
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(StudioPanel).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Ayuda", color = StudioText, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            items.forEach { name ->
                Row {
                    Text(name, color = StudioText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(92.dp))
                    Text(toolHelp[name] ?: "", color = StudioMuted, fontSize = 13.sp)
                }
            }
            Text("Dos dedos: zoom y mover, con cualquier herramienta. Mantén pulsada una herramienta para ver su ayuda. " +
                "Toca un efecto en la línea de tiempo para moverlo, recortarlo, duplicarlo o colocarlo en la imagen.",
                color = StudioMuted, fontSize = 12.sp)
            Box(Modifier.fillMaxWidth().height(42.dp).clip(RoundedCornerShape(11.dp)).background(StudioTile)
                .clickable(onClick = onDismiss), contentAlignment = Alignment.Center) {
                Text("Entendido", color = StudioText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
