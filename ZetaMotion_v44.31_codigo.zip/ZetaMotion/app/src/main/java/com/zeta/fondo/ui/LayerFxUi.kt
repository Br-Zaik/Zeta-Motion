package com.zeta.fondo.ui

import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.model.ImageLayer
import com.zeta.fondo.model.ImageLayers
import com.zeta.fondo.model.LayerFx
import kotlinx.coroutines.delay
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/*
 * v44.30 · Efectos de una capa (imagen o texto), con la misma forma de usar que los Efectos del
 * fondo: pestañas (Efecto · Movimiento · Entrada), miniaturas que enseñan lo que hace cada uno,
 * tocar = ponerlo, tocar otra vez = Ajustar.
 *
 * Optimización: las miniaturas son dibujos de pocas líneas (no vídeos ni imágenes guardadas), se
 * redibujan a ~20 cuadros por segundo con UN solo reloj y solo mientras la hoja está abierta.
 * No tocan la vista previa ni el vídeo.
 */

private val FxThumbBg = Color(0xFF15151B)
private val layerFxTabs = listOf("Efecto", "Movimiento", "Entrada")
private const val TAU = 6.2831855f

/** Segundos desde que se abrió la hoja, a ~20 cuadros por segundo. */
@Composable
private fun rememberFxClock(): () -> Float {
    val sec = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) {
            delay(45L)
            val now = withFrameNanos { it }
            sec.floatValue = (((now - start) / 1_000_000L) % 3_600_000L) / 1000f
        }
    }
    return { sec.floatValue }
}

/** Dibuja la miniatura animada de un efecto, un movimiento o una entrada. Sin crear objetos por cuadro. */
private class FxThumbPainter {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val spark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val path = Path()
    private val matrix = Matrix()
    private val hsv = floatArrayOf(0f, .75f, 1f)
    private var shine: LinearGradient? = null
    private var shineSize = 0f
    private var isText = true
    private var cx = 0f
    private var cy = 0f
    private var base = 0f

    private val sparkX = floatArrayOf(-.26f, .24f, -.05f, .3f, -.3f)
    private val sparkY = floatArrayOf(-.2f, -.24f, .02f, .16f, .2f)
    private val sparkPh = floatArrayOf(0f, .37f, .61f, .18f, .83f)

    fun draw(c: android.graphics.Canvas, w: Float, h: Float, tab: Int, index: Int, text: Boolean, t: Float) {
        val s = min(w, h)
        if (s < 4f) return
        isText = text
        cx = w / 2f; cy = h / 2f
        paint.shader = null
        paint.clearShadowLayer()
        paint.color = WHITE
        paint.textSize = s * .5f
        base = cy - (paint.ascent() + paint.descent()) / 2f
        if (!isText) buildPicture(s)
        when (tab) {
            0 -> effect(c, s, h, index, t)
            1 -> motion(c, s, index, t)
            else -> entrance(c, s, h, index, t)
        }
    }

    private fun subject(c: android.graphics.Canvas) {
        if (isText) c.drawText("Aa", cx, base, paint) else c.drawPath(path, paint)
    }

    /** Para las imágenes: una fotito (marco, sol y montañas). */
    private fun buildPicture(s: Float) {
        val hw = s * .3f; val hh = s * .23f; val r = s * .06f; val b = s * .035f
        path.reset()
        path.fillType = Path.FillType.EVEN_ODD
        path.addRoundRect(cx - hw, cy - hh, cx + hw, cy + hh, r, r, Path.Direction.CW)
        path.addRoundRect(cx - hw + b, cy - hh + b, cx + hw - b, cy + hh - b, r * .5f, r * .5f, Path.Direction.CW)
        path.addCircle(cx - hw * .45f, cy - hh * .35f, s * .05f, Path.Direction.CW)
        path.moveTo(cx - hw * .7f, cy + hh * .62f)
        path.lineTo(cx - hw * .05f, cy - hh * .1f)
        path.lineTo(cx + hw * .3f, cy + hh * .3f)
        path.lineTo(cx + hw * .5f, cy + hh * .05f)
        path.lineTo(cx + hw * .78f, cy + hh * .62f)
        path.close()
    }

    private fun effect(c: android.graphics.Canvas, s: Float, h: Float, index: Int, t: Float) {
        when (index) {
            LayerFx.SHIMMER -> {
                paint.color = 0xFFB4BACD.toInt()
                subject(c)
                val g = shine.takeIf { shineSize == s } ?: LinearGradient(0f, 0f, s * .34f, s * .15f,
                    intArrayOf(0x00FFE27A, 0xFFFFF3C4.toInt(), 0x00FFE27A), null, Shader.TileMode.CLAMP)
                    .also { shine = it; shineSize = s }
                matrix.setTranslate(cx - s * .8f + (t / 1.8f % 1f) * s * 1.5f, cy - s * .08f)
                g.setLocalMatrix(matrix)
                paint.color = WHITE
                paint.shader = g
                subject(c)
                paint.shader = null
            }
            LayerFx.NEON -> {
                val pulse = .5f + .5f * sin(TAU * t / 1.6f)
                paint.setShadowLayer(s * (.06f + .07f * pulse), 0f, 0f, 0xFFFF2D92.toInt())
                subject(c); subject(c)
                paint.clearShadowLayer()
            }
            LayerFx.WAVE -> {
                val n = 9
                val x0 = cx - s * .42f
                val sw = s * .84f / n
                for (i in 0 until n) {
                    c.save()
                    c.clipRect(x0 + i * sw, 0f, x0 + (i + 1) * sw + .5f, h)
                    c.translate(0f, sin(TAU * t / 1.6f + i * .75f) * s * .055f)
                    subject(c)
                    c.restore()
                }
            }
            LayerFx.SPARKLE -> {
                subject(c)
                spark.strokeWidth = s * .022f
                for (i in 0 until 5) {
                    val tw = max(0f, sin(TAU * (t / 1.5f + sparkPh[i])))
                    val k = tw * tw
                    if (k < .02f) continue
                    val x = cx + sparkX[i] * s; val y = cy + sparkY[i] * s; val r = s * .085f * k
                    spark.color = 0xFFFFD84A.toInt()
                    spark.alpha = (255f * k).toInt().coerceIn(0, 255)
                    c.drawLine(x - r, y, x + r, y, spark)
                    c.drawLine(x, y - r, x, y + r, spark)
                }
            }
            LayerFx.HUE -> {
                hsv[0] = (t / 3f % 1f) * 360f
                paint.color = android.graphics.Color.HSVToColor(hsv)
                subject(c)
            }
            else -> subject(c)
        }
    }

    private fun motion(c: android.graphics.Canvas, s: Float, index: Int, t: Float) {
        val ph = TAU * t / 2f
        c.save()
        when (index) {
            ImageLayers.MOTION_FLOAT -> { c.translate(0f, sin(ph) * s * .09f) }
            ImageLayers.MOTION_PULSE -> { val k = 1f + .22f * (.5f - .5f * cos(ph * 1.6f)); c.scale(k, k, cx, cy) }
            ImageLayers.MOTION_SWAY -> { c.rotate(sin(ph) * 16f, cx, cy) }
            ImageLayers.MOTION_SPIN -> { c.rotate(360f * (t / 3f % 1f), cx, cy) }
            ImageLayers.MOTION_FLICKER -> { paint.alpha = (255f * (1f - .7f * (.5f + .5f * sin(ph * 5.3f) * sin(ph * 2.1f + 1f)))).toInt().coerceIn(0, 255) }
            ImageLayers.MOTION_BREATHE -> { paint.alpha = (255f * (1f - .65f * (.5f - .5f * cos(ph)))).toInt().coerceIn(0, 255) }
            ImageLayers.MOTION_DRIFT -> { c.translate(sin(ph) * s * .08f, cos(ph) * s * .08f) }
            else -> {}
        }
        subject(c)
        c.restore()
    }

    private fun entrance(c: android.graphics.Canvas, s: Float, h: Float, index: Int, t: Float) {
        // Entra en ~1 s y se queda un momento a la vista antes de repetir.
        val p = ((t % 2.2f) / 1.1f).coerceIn(0f, 1f)
        val e = LayerFx.entranceAt(index, p)
        c.save()
        c.translate(0f, e.dy / .08f * s * .28f)
        c.scale(e.scale, e.scale, cx, cy)
        if (e.reveal < 1f) {
            // En los textos, letra por letra (aquí son dos); en las imágenes, un barrido.
            val r = if (isText) ceil(e.reveal * 2f - 1e-4f) / 2f else e.reveal
            c.clipRect(cx - s * .42f, 0f, cx - s * .42f + s * .84f * r, h)
        }
        paint.alpha = (255f * e.alpha).toInt().coerceIn(0, 255)
        subject(c)
        c.restore()
    }

    private companion object {
        const val WHITE = -1
    }
}

@Composable
private fun LayerFxThumb(tab: Int, index: Int, isText: Boolean, clock: () -> Float, modifier: Modifier) {
    val painter = remember { FxThumbPainter() }
    Canvas(modifier.background(FxThumbBg)) {
        // «Ninguno» no se mueve: no lee el reloj y no se redibuja.
        val t = if (index == 0) 0f else clock()
        drawIntoCanvas { painter.draw(it.nativeCanvas, size.width, size.height, tab, index, isText, t) }
    }
}

/** Hoja «Efectos» de la capa elegida: Efecto, Movimiento y Entrada con miniaturas animadas. */
@Composable
fun LayerFxSheet(vm: AppViewModel) {
    val l = vm.selectedLayerObj() ?: run { LaunchedEffect(Unit) { vm.layerFxOpen = false }; return }
    var tab by remember(l.id) { mutableIntStateOf(0) }
    var adjusting by remember(l.id) { mutableStateOf(false) }
    val clock = rememberFxClock()
    val names = when (tab) {
        0 -> LayerFx.names
        1 -> ImageLayers.motionNames
        else -> LayerFx.inNames
    }
    val chosen = (when (tab) {
        0 -> l.fx
        1 -> l.motion
        else -> l.inType
    }).coerceIn(0, names.size - 1)
    val indices = remember(names.size) { List(names.size) { it } }
    val isText = l.text != null
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
            // «‹» solo aparece dentro de Ajustar (vuelve a las miniaturas).
            if (adjusting) Box(Modifier.size(48.dp).clickable { adjusting = false }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.ChevronLeft, "Volver a las miniaturas", tint = StudioText, modifier = Modifier.size(26.dp))
            } else Spacer(Modifier.size(48.dp))
            TextTabs(layerFxTabs, tab, Modifier.weight(1f).fillMaxHeight()) { tab = it; adjusting = false }
            Box(Modifier.size(48.dp).clickable { vm.layerFxOpen = false }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Check, "Listo", tint = StudioText, modifier = Modifier.size(26.dp))
            }
        }
        if (adjusting && chosen != 0) {
            LayerFxAdjust(vm, l, tab, names[chosen], Modifier.fillMaxWidth().weight(1f))
        } else {
            LazyVerticalGrid(GridCells.Adaptive(78.dp), Modifier.fillMaxWidth().weight(1f),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(indices, key = { it }) { i ->
                    val selected = i == chosen
                    CatalogCard(names[i], selected, false, Modifier.clickable {
                        when {
                            selected && i != 0 -> { adjusting = true }
                            tab == 0 -> vm.chooseLayerFx(l.id, i)
                            tab == 1 -> vm.setLayerMotion(l.id, i)
                            else -> vm.chooseLayerEntrance(l.id, i)
                        }
                    }) {
                        LayerFxThumb(tab, i, isText, clock, Modifier.fillMaxSize())
                        if (selected && i != 0) Column(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .45f)),
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Icon(Icons.Filled.Tune, null, tint = Color.White, modifier = Modifier.size(22.dp))
                            Text("Ajustar", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FxLabel(text: String) {
    Text(text, color = StudioText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun CycleRow(choices: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (n in choices) SmallChoice("$n", selected == n) { onPick(n) }
    }
}

/** Ajustar lo elegido en la pestaña [tab]: solo los controles que ese efecto usa. */
@Composable
private fun LayerFxAdjust(vm: AppViewModel, l: ImageLayer, tab: Int, title: String, modifier: Modifier) {
    Column(modifier.verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = StudioPink, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        when (tab) {
            0 -> {
                var amt by remember(l.id, l.fx) { mutableFloatStateOf(l.fxAmt) }
                FxLabel("Fuerza")
                Slider(value = amt, onValueChange = { amt = it; vm.changeLayerFxAmt(l.id, it, live = true) },
                    onValueChangeFinished = { vm.changeLayerFxAmt(l.id, amt, live = false) }, colors = capSliderColors())
                FxLabel("Vueltas por vídeo")
                CycleRow(LayerFx.cycleChoices, l.fxCycles) { vm.changeLayerFxCycles(l.id, it) }
                if (LayerFx.usesColor(l.fx)) SwatchRow("Color", l.fxColor) { vm.changeLayerFxColor(l.id, it) }
            }
            1 -> {
                var amt by remember(l.id, l.motion) { mutableFloatStateOf(l.motionAmt) }
                FxLabel("Fuerza")
                Slider(value = amt, onValueChange = { amt = it; vm.setLayerMotionAmt(l.id, it, live = true) },
                    onValueChangeFinished = { vm.setLayerMotionAmt(l.id, amt, live = false) }, colors = capSliderColors())
                if (l.motion == ImageLayers.MOTION_SPIN)
                    Text("Menos de la mitad = gira al revés.", color = StudioMuted, fontSize = 11.sp)
                FxLabel("Vueltas por vídeo")
                CycleRow(LayerFx.cycleChoices, l.motionCycles) { vm.setLayerMotionCycles(l.id, it) }
            }
            else -> {
                var inSec by remember(l.id, l.inType) { mutableFloatStateOf(l.inSec) }
                FxLabel("Duración: ${String.format(java.util.Locale.US, "%.1f", inSec)} s")
                Slider(value = inSec, valueRange = LayerFx.IN_MIN..LayerFx.IN_MAX,
                    onValueChange = { inSec = it; vm.changeLayerEntranceSec(l.id, it, live = true) },
                    onValueChangeFinished = { vm.changeLayerEntranceSec(l.id, inSec, live = false) }, colors = capSliderColors())
                Text("Pasa al empezar el tramo de la capa (Tiempo).", color = StudioMuted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}
