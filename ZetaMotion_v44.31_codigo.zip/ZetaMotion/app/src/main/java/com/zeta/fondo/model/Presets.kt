package com.zeta.fondo.model

data class Preset(
    val emoji: String,
    val name: String,
    val hint: String,
    val values: Map<String, Float>,
    val manga: Boolean = false,
    /** v44: sonidos de la escena (id, volumen): se añaden como bloques que cubren el vídeo. */
    val sounds: List<Pair<String, Float>> = emptyList()
)

object Presets {
    /**
     * v36 · Escenas rápidas: un toque las activa con valores ya ajustados y abre el
     * efecto principal para personalizarlo. Usan las formas nuevas (no solo colores).
     */
    val scenes: List<Preset> = listOf(
        // v44.14 · edits de manga / manhwa (tono, luz de color, bruma, grano)
        Preset("🩶", "Edit manga (gris azulado)", "Página de manga en gris azulado con grano, luces que flotan y resplandor suave.",
            mapOf("gradmap.on" to 1f, "gradmap.variant" to 0f, "gradmap.int" to .85f, "gradmap.contrast" to .2f,
                "flies.on" to 1f, "flies.int" to .55f,
                "finish.on" to 1f, "finish.variant" to 0f, "finish.int" to .3f, "finish.bloom" to .35f,
                "finish.vignette" to .4f, "finish.grain" to .55f, "finish.aberration" to .2f)),
        Preset("🌸", "Edit manhwa (rosa y azul)", "Tono rosa y azul, luz cálida desde arriba, destellos y resplandor pastel.",
            mapOf("gradmap.on" to 1f, "gradmap.variant" to 2f, "gradmap.int" to .55f,
                "lightdir.on" to 1f, "lightdir.variant" to 1f, "lightdir.int" to .7f, "lightdir.direction" to 60f, "lightdir.edge" to .3f,
                "sparkle.on" to 1f, "sparkle.int" to .4f,
                "finish.on" to 1f, "finish.variant" to 3f, "finish.int" to .5f, "finish.bloom" to .6f,
                "finish.vignette" to .25f, "finish.grain" to .2f)),
        Preset("🔴", "Luz roja desde abajo", "Noche azul con una luz roja que sube desde abajo y borde brillante, como en los edits de acción.",
            mapOf("gradmap.on" to 1f, "gradmap.variant" to 1f, "gradmap.int" to .55f,
                "lightdir.on" to 1f, "lightdir.variant" to 0f, "lightdir.int" to 1f, "lightdir.direction" to 270f,
                "lightdir.edge" to .8f, "lightdir.spread" to .45f, "lightdir.shadow" to .2f,
                "finish.on" to 1f, "finish.variant" to 4f, "finish.int" to .5f, "finish.bloom" to .45f,
                "finish.vignette" to .5f, "finish.grain" to .35f, "finish.aberration" to .2f)),
        Preset("✨", "Bruma mágica", "Bruma del color de tu imagen, motas de luz y resplandor suave.",
            mapOf("atmos.on" to 1f, "atmos.int" to .55f, "atmos.variant" to 0f,
                "dust.on" to 1f, "dust.int" to .4f,
                "finish.on" to 1f, "finish.variant" to 3f, "finish.int" to .45f, "finish.bloom" to .6f,
                "finish.vignette" to .3f, "finish.grain" to .15f)),
        // v44.13 · paisajes pintados listos en un toque (horizonte y sol se colocan solos)
        Preset("🌅", "Atardecer en el mar", "Las nubes de tu imagen se mueven, el mar ondula con destellos y el sol respira. Ajusta el Horizonte si hace falta.",
            mapOf("skydrift.on" to 1f, "skydrift.amount" to 1f, "skydrift.life" to .5f,
                "seawaves.on" to 1f, "seawaves.int" to 1f, "seawaves.glitter" to .7f,
                "sunlight.on" to 1f, "sunlight.variant" to 0f, "sunlight.int" to .7f, "sunlight.rays" to .5f, "sunlight.warm" to .5f,
                "finish.on" to 1f, "finish.variant" to 1f, "finish.int" to .6f, "finish.bloom" to .5f,
                "finish.vignette" to .35f, "finish.grain" to .15f, "finish.aberration" to .12f),
            sounds = listOf("waves" to .6f, "seagulls" to .2f)),
        Preset("🌇", "Cielo de anime", "Nubes en movimiento, luz suave y destellos, con acabado pastel luminoso.",
            mapOf("skydrift.on" to 1f, "skydrift.amount" to 1.2f, "skydrift.life" to .6f,
                "sunlight.on" to 1f, "sunlight.variant" to 0f, "sunlight.int" to .55f, "sunlight.rays" to .45f,
                "sparkle.on" to 1f, "sparkle.int" to .45f,
                "finish.on" to 1f, "finish.variant" to 3f, "finish.int" to .6f, "finish.bloom" to .55f,
                "finish.vignette" to .25f, "finish.grain" to .12f, "finish.aberration" to .1f),
            sounds = listOf("wind" to .35f)),
        Preset("🌕", "Noche de luna llena", "Luz fría de luna con halo, estrellas que titilan y nubes lentas.",
            mapOf("skydrift.on" to 1f, "skydrift.amount" to .6f, "skydrift.life" to .4f,
                "sunlight.on" to 1f, "sunlight.variant" to 2f, "sunlight.int" to .75f, "sunlight.rays" to .25f, "sunlight.warm" to .4f,
                "stars.on" to 1f, "stars.int" to .8f,
                "finish.on" to 1f, "finish.variant" to 2f, "finish.int" to .55f, "finish.bloom" to .45f,
                "finish.vignette" to .45f, "finish.grain" to .2f),
            sounds = listOf("crickets" to .45f, "wind" to .25f)),
        Preset("🌧", "Lluvia de noche", "Lluvia realista con charcos, luz que parpadea y look azul de cine.",
            mapOf("rain.on" to 1f, "rain.int" to .7f, "rain.variant" to 1f, "rain.puddles" to .5f, "rain.haze" to .4f,
                "flicker.on" to 1f, "flicker.variant" to 2f, "flicker.int" to .35f,
                "finish.on" to 1f, "finish.variant" to 2f, "finish.int" to .6f, "finish.bloom" to .4f,
                "finish.vignette" to .45f, "finish.grain" to .25f),
            sounds = listOf("rain_soft" to .75f, "city" to .2f)),
        Preset("🌳", "Mañana en el bosque", "Manchas de sol entre las hojas, motas de polvo en la luz y color natural.",
            mapOf("dapple.on" to 1f, "dapple.int" to .8f,
                "dust.on" to 1f, "dust.int" to .35f,
                "sunlight.on" to 1f, "sunlight.variant" to 1f, "sunlight.int" to .45f, "sunlight.rays" to .55f,
                "finish.on" to 1f, "finish.variant" to 0f, "finish.int" to .5f, "finish.bloom" to .4f, "finish.vignette" to .3f),
            sounds = listOf("birds" to .5f, "leaves" to .3f)),
        Preset("◑", "Aparición entre humo", "Pinta al personaje en Proteger: emerge del humo y el humo pasa por detrás.",
            mapOf("reveal.on" to 1f, "reveal.int" to .85f, "reveal.variant" to 0f, "reveal.shape" to 1f,
                "reveal.edge" to .8f, "reveal.mask" to 0f, "reveal.cycles" to 1f,
                "smoke.on" to 1f, "smoke.int" to .38f, "smoke.variant" to 1f, "smoke.shape" to 3f,
                "smoke.behind" to 1f, "smoke.mask" to -2f)),
        Preset("💥", "Explosión anime", "Coloca el centro: destello, bola de fuego, onda, chispas y humo por fases.",
            mapOf("blast.on" to 1f, "blast.int" to 1f, "blast.shape" to 0f, "blast.variant" to 0f,
                "blast.flash" to .85f, "blast.ring" to .75f, "blast.smoke" to .7f, "blast.sparks" to .65f,
                "blast.mask" to -2f, "impact.on" to 1f, "impact.int" to .08f, "impact.shake" to .5f)),
        Preset("☁", "Cielo animado", "Pinta el cielo en Zona azul: nubes en capas y luz suave.",
            mapOf("clouds3.on" to 1f, "clouds3.int" to .62f, "clouds3.cycles" to 1f, "clouds3.mask" to 1f,
                "rays.on" to 1f, "rays.int" to .18f, "rays.mask" to 1f)),
        Preset("◉", "Aura oscura", "Pinta al personaje en Proteger: llamas de aura y sombra detrás de él.",
            mapOf("energy.on" to 1f, "energy.shape" to 1f, "energy.variant" to 1f, "energy.int" to 1.05f,
                "energy.size" to .55f, "energy.mask" to -2f,
                "blackaura.on" to 1f, "blackaura.int" to .5f, "blackaura.behind" to 1f, "blackaura.mask" to -2f)),
        Preset("👁️", "Ojo brillante", "Pinta solo los ojos: brillo con halo y destello.",
            mapOf("eyes.on" to 1f, "eyes.int" to 1.1f, "eyes.shape" to 2f, "eyes.halo" to .65f,
                "embers.on" to 1f, "embers.int" to .25f)),
        Preset("✹", "Impacto manga", "Líneas de enfoque, golpe con temblor y destello.",
            mapOf("focus.on" to 1f, "focus.int" to .85f, "focus.mask" to -2f,
                "impact.on" to 1f, "impact.int" to .14f, "impact.shake" to .75f, "impact.flash" to .45f,
                "blood.on" to 1f, "blood.shape" to 2f, "blood.variant" to 1f, "blood.int" to .8f, "blood.mask" to -2f)),
        Preset("🍃", "Viento en cabello", "Pinta solo el cabello: raíz fija arriba y puntas con rebote.",
            mapOf("natural.on" to 1f, "natural.variant" to 4f, "natural.anchor" to 4f, "natural.int" to .0055f,
                "natural.cycles" to 2f, "natural.flex" to .8f, "natural.variation" to .6f, "natural.gust" to .45f,
                "natural.weight" to .4f, "natural.spring" to .7f, "natural.direction" to 0f,
                "gust.on" to 1f, "gust.int" to .3f, "gust.debris" to .2f, "gust.cycles" to 2f)),
        Preset("🔥", "Fuego y humo", "Pinta la base del fuego: llamas que suben, humo y brasas.",
            mapOf("flame.on" to 1f, "flame.int" to .95f, "flame.shape" to 0f, "flame.height" to .55f,
                "smoke.on" to 1f, "smoke.int" to .35f, "smoke.variant" to 0f, "smoke.shape" to 0f,
                "smoke.rise" to .9f, "smoke.direction" to 270f, "smoke.mask" to -2f,
                "embers.on" to 1f, "embers.int" to .55f)),
        Preset("☁", "Nubes detrás del personaje", "Pinta al personaje en Proteger: las nubes pasan por detrás.",
            mapOf("clouds3.on" to 1f, "clouds3.int" to .7f, "clouds3.scale" to 1.6f, "clouds3.mask" to -2f,
                "clouds3.behind" to 1f, "fog.on" to 1f, "fog.shape" to 1f, "fog.int" to .3f,
                "fog.behind" to 1f, "fog.mask" to -2f)),
        // v44 · escenas con los efectos nuevos
        Preset("≈", "Tormenta de arena", "Velo de arena con viento fuerte y polvo; el cielo se tiñe.",
            mapOf("sand.on" to 1f, "sand.int" to 1f, "sand.variant" to 0f, "sand.force" to 1.4f, "sand.mask" to -2f,
                "dust.on" to 1f, "dust.int" to .35f, "gust.on" to 1f, "gust.int" to .45f, "gust.debris" to .3f)),
        Preset("≋", "Noche con aurora", "Aurora detrás del personaje y estrellas con fugaces. Mejor en imágenes oscuras.",
            mapOf("aurora.on" to 1f, "aurora.int" to .95f, "aurora.behind" to 1f, "aurora.mask" to -2f,
                "stars.on" to 1f, "stars.shooting" to 1f, "stars.behind" to 1f, "stars.mask" to -2f)),
        Preset("▦", "Ciudad de noche", "Las luces de tu imagen titilan, con tráfico y lluvia fina.",
            mapOf("citylights.on" to 1f, "citylights.int" to 1f, "citylights.mask" to -2f,
                "rain.on" to 1f, "rain.int" to .35f, "rain.puddles" to .6f, "rain.mask" to -2f)),
        Preset("◌", "Lluvia en la ventana", "Gotas en el cristal, vaho y lluvia detrás.",
            mapOf("glassrain.on" to 1f, "glassrain.int" to .9f, "glassrain.fog" to .55f, "glassrain.mask" to -2f,
                "rain.on" to 1f, "rain.int" to .5f, "rain.haze" to .5f, "rain.mask" to -2f)),
        // v44 · 11 familias de escenas de un toque: efectos + sonidos compatibles (cada capa se ajusta después).
        Preset("⛈", "Tormenta", "Lluvia fuerte con charcos, relámpagos sincronizados con el trueno y viento.",
            mapOf("rain.on" to 1f, "rain.variant" to 3f, "rain.int" to 1.1f, "rain.puddles" to .6f, "rain.haze" to .4f, "rain.mask" to -2f,
                "bolt.on" to 1f, "bolt.cycles" to 2f, "fog.on" to 1f, "fog.int" to .2f, "fog.behind" to 1f, "fog.mask" to -2f),
            sounds = listOf("rain_heavy" to .8f, "thunder" to .9f, "gale" to .35f)),
        Preset("☔", "Noche lluviosa", "Lluvia suave, charcos que brillan y luces de ciudad.",
            mapOf("rain.on" to 1f, "rain.variant" to 1f, "rain.int" to .6f, "rain.puddles" to .8f, "rain.mask" to -2f,
                "citylights.on" to 1f, "citylights.int" to .9f, "citylights.mask" to -2f),
            sounds = listOf("rain_soft" to .7f, "drip" to .4f, "city" to .25f)),
        Preset("≈", "Desierto ventoso", "Arena que avanza con el viento global y polvo.",
            mapOf("sand.on" to 1f, "sand.int" to .9f, "sand.variant" to 2f, "sand.mask" to -2f, "sand.followWind" to 1f,
                "wind.on" to 1f, "wind.direction" to 0f, "wind.force" to 1.5f, "wind.gust" to .5f, "wind.turb" to .3f,
                "dust.on" to 1f, "dust.int" to .4f, "dust.followWind" to 1f),
            sounds = listOf("sand" to .6f, "gale" to .6f)),
        Preset("🏙", "Ciudad", "Luces que titilan, tráfico y algo de niebla urbana.",
            mapOf("citylights.on" to 1f, "citylights.variant" to 2f, "citylights.mask" to -2f, "fog.on" to 1f, "fog.shape" to 2f,
                "fog.int" to .15f, "fog.mask" to -2f),
            sounds = listOf("city" to .7f, "horn" to .4f, "footsteps" to .3f)),
        Preset("🌲", "Bosque", "Hojas al viento, luz entre los árboles y Natural en las ramas (pinta la zona).",
            mapOf("leaves.on" to 1f, "leaves.int" to .7f, "leaves.mask" to -2f, "rays.on" to 1f, "rays.int" to .35f, "rays.mask" to -2f,
                "dust.on" to 1f, "dust.int" to .3f),
            sounds = listOf("birds" to .6f, "leaves" to .5f, "wind" to .35f)),
        Preset("🌊", "Mar", "Olas con espuma, reflejo del sol y gaviotas (pinta el agua).",
            mapOf("shore.on" to 1f, "shore.int" to .7f, "sunpath.on" to 1f, "sunpath.int" to .8f, "birds.on" to 1f, "birds.variant" to 1f,
                "birds.count" to 5f, "birds.mask" to -2f),
            sounds = listOf("waves" to .8f, "seagulls" to .4f, "wind" to .3f)),
        Preset("⚔", "Batalla anime", "Energía, brasas, líneas de enfoque y golpes de impacto.",
            mapOf("energy.on" to 1f, "energy.shape" to 3f, "energy.int" to .9f, "energy.mask" to -2f, "embers.on" to 1f, "embers.int" to .6f,
                "focus.on" to 1f, "focus.int" to .5f, "focus.mask" to -2f, "shock.on" to 1f, "shock.int" to .6f),
            sounds = listOf("fire" to .4f, "gale" to .3f)),
        Preset("🌅", "Mañana tranquila", "Luz cálida, motas de polvo y pájaros.",
            mapOf("lightleak.on" to 1f, "lightleak.int" to .35f, "lightleak.mask" to -2f, "dust.on" to 1f, "dust.int" to .35f,
                "rays.on" to 1f, "rays.int" to .3f, "rays.mask" to -2f),
            sounds = listOf("birds" to .7f, "river" to .3f)),
        Preset("🕯", "Terror", "Sombra dramática, niebla baja y tinta que gotea.",
            mapOf("dramatic.on" to 1f, "dramatic.int" to .7f, "dramatic.mask" to -2f, "fog.on" to 1f, "fog.shape" to 1f, "fog.int" to .35f,
                "fog.mask" to -2f, "inkdrip.on" to 1f, "inkdrip.int" to .4f),
            sounds = listOf("creak" to .6f, "heartbeat" to .5f, "wind" to .4f, "drip" to .3f)),
        Preset("❄", "Nieve intensa", "Ventisca con remolinos, bruma y viento.",
            mapOf("snow.on" to 1f, "snow.variant" to 3f, "snow.int" to 1.15f, "snow.swirl" to .6f, "snow.haze" to .5f, "snow.mask" to -2f,
                "snow.followWind" to 1f, "wind.on" to 1f, "wind.direction" to 20f, "wind.force" to 1.6f, "wind.gust" to .6f),
            sounds = listOf("gale" to .7f, "wind" to .4f)),
        Preset("🌇", "Atardecer", "Luz cálida, sombras de nubes y destello de lente (colócalo en el sol).",
            mapOf("lightleak.on" to 1f, "lightleak.variant" to 0f, "lightleak.int" to .45f, "lightleak.mask" to -2f,
                "cloudshadow.on" to 1f, "cloudshadow.int" to .35f, "lensflare.on" to 1f, "lensflare.int" to .7f),
            sounds = listOf("wind" to .3f, "birds" to .25f)),
        Preset("ᨐ", "Pájaros al atardecer", "Bandada que cruza el cielo, sombras de nubes y luz cálida.",
            mapOf("birds.on" to 1f, "birds.int" to .95f, "birds.behind" to 1f, "birds.mask" to -2f,
                "cloudshadow.on" to 1f, "cloudshadow.int" to .4f, "cloudshadow.mask" to -2f,
                "lightleak.on" to 1f, "lightleak.int" to .35f, "lightleak.mask" to -2f))
    )

    /** Efecto que se abre para ajustar después de aplicar la escena. */
    fun sceneMainEffect(p: Preset): String = when (p.name) {
        "Aparición entre humo" -> "reveal"
        "Explosión anime" -> "blast"
        "Cielo animado", "Nubes detrás del personaje" -> "clouds3"
        "Aura oscura" -> "energy"
        "Ojo brillante" -> "eyes"
        "Impacto manga" -> "focus"
        "Viento en cabello" -> "natural"
        "Fuego y humo" -> "flame"
        "Tormenta de arena" -> "sand"
        "Noche con aurora" -> "aurora"
        "Ciudad de noche" -> "citylights"
        "Lluvia en la ventana" -> "glassrain"
        "Pájaros al atardecer" -> "birds"
        "Atardecer en el mar", "Cielo de anime", "Noche de luna llena" -> "skydrift"
        "Lluvia de noche" -> "rain"
        "Edit manga (gris azulado)", "Edit manhwa (rosa y azul)", "Luz roja desde abajo" -> "gradmap"
        "Bruma mágica" -> "atmos"
        "Mañana en el bosque" -> "dapple"
        else -> p.values.keys.firstOrNull { it.endsWith(".on") }?.substringBefore('.') ?: "smoke"
    }
}
