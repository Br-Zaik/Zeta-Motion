package com.zeta.fondo.engine

import kotlin.math.min

/** Operaciones sobre máscaras de un canal, sin Android (se prueba en la JVM). */
object CutoutMath {

    /** Dilata un hueco (>=128) [r] píxeles: así el relleno no arrastra el contorno del personaje. */
    fun dilate(mask: ByteArray, w: Int, h: Int, r: Int): ByteArray {
        if (r <= 0) return mask.copyOf()
        val tmp = ByteArray(w * h)
        val out = ByteArray(w * h)
        for (y in 0 until h) {
            var run = -1
            // distancia al último píxel de hueco por la izquierda y por la derecha
            val row = y * w
            val left = IntArray(w); val right = IntArray(w)
            for (x in 0 until w) { if ((mask[row + x].toInt() and 0xFF) >= 128) run = x; left[x] = if (run < 0) Int.MAX_VALUE else x - run }
            run = -1
            for (x in w - 1 downTo 0) { if ((mask[row + x].toInt() and 0xFF) >= 128) run = x; right[x] = if (run < 0) Int.MAX_VALUE else run - x }
            for (x in 0 until w) if (min(left[x], right[x]) <= r) tmp[row + x] = 255.toByte()
        }
        for (x in 0 until w) {
            var run = -1
            val up = IntArray(h); val down = IntArray(h)
            for (y in 0 until h) { if (tmp[y * w + x].toInt() != 0) run = y; up[y] = if (run < 0) Int.MAX_VALUE else y - run }
            run = -1
            for (y in h - 1 downTo 0) { if (tmp[y * w + x].toInt() != 0) run = y; down[y] = if (run < 0) Int.MAX_VALUE else run - y }
            for (y in 0 until h) if (min(up[y], down[y]) <= r) out[y * w + x] = 255.toByte()
        }
        return out
    }
}
