package com.zeta.fondo.model

import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * v44.29 · Efectos y entradas de CAPA (imágenes y textos).
 *
 * Optimización: todo se calcula en el mismo paso que ya dibuja cada capa (LayerCompositor), solo
 * dentro de su recuadro. No se vuelve a procesar el fondo ni se multiplica el trabajo por capa;
 * una capa sin efecto cuesta igual que antes. Los efectos cierran el bucle exacto (vueltas enteras
 * por vídeo) y se ven igual en la vista previa y en la exportación.
 *
 * - Efecto ([ImageLayer.fx]): Brillo que pasa, Neón (halo con las mipmaps de la textura: casi
 *   gratis), Ondear, Destellos, Color que cambia.
 * - Entrada ([ImageLayer.inType]) al empezar el tramo de la capa: Aparecer, Deslizar, Zoom,
 *   Letra por letra (en los textos va por letras del renglón más largo).
 */
object LayerFx {
    const val NONE = 0
    const val SHIMMER = 1
    const val NEON = 2
    const val WAVE = 3
    const val SPARKLE = 4
    const val HUE = 5

    val names = listOf("Ninguno", "Brillo que pasa", "Neón", "Ondear", "Destellos", "Color que cambia")

    /** Efectos que usan [ImageLayer.fxColor]. */
    fun usesColor(fx: Int) = fx == SHIMMER || fx == NEON || fx == SPARKLE

    /** Color con el que empieza cada efecto. */
    fun defaultColor(fx: Int): Int = when (fx) {
        NEON -> 0xFFFF2D92.toInt()
        SHIMMER, SPARKLE -> 0xFFFFE27A.toInt()
        else -> TextLayers.WHITE
    }

    /** v44.30 · Fuerza con la que empieza un efecto recién elegido (se nota sin tocar nada). */
    const val DEFAULT_AMT = .85f

    /** Segundos que dura una vuelta para que el efecto se vea vivo (brillo que pasa, latido…). */
    fun period(fx: Int): Float = when (fx) {
        SHIMMER -> 2.4f
        NEON -> 1.8f
        WAVE -> 2.4f
        SPARKLE -> 2f
        HUE -> 4f
        else -> 2f
    }

    /**
     * v44.30 · Vueltas con las que empieza un efecto según lo que dura el vídeo. Antes era siempre 1:
     * en un vídeo de 8 s el brillo pasaba una sola vez y parecía que el efecto no hacía nada.
     * Siempre vueltas enteras (el final empalma con el inicio).
     */
    fun defaultCycles(fx: Int, loopSec: Float): Int =
        if (fx == NONE) 1 else (loopSec.coerceIn(.5f, 600f) / period(fx)).roundToInt().coerceIn(1, MAX_CYCLES)

    const val MAX_CYCLES = 8
    /** Opciones de «Vueltas» del panel. */
    val cycleChoices = listOf(1, 2, 3, 4, 6, 8)

    const val IN_NONE = 0
    const val IN_FADE = 1
    const val IN_SLIDE = 2
    const val IN_ZOOM = 3
    const val IN_TYPE = 4

    val inNames = listOf("Ninguna", "Aparecer", "Deslizar", "Zoom", "Letra por letra")

    const val IN_MIN = .2f
    const val IN_MAX = 3f

    /** Cómo está la entrada en el segundo [sec]: desplazamiento (0..1 del fondo), escala, alfa y revelado. */
    data class Entrance(val dy: Float = 0f, val scale: Float = 1f, val alpha: Float = 1f, val reveal: Float = 1f)

    private fun easeOut(p: Float) = 1f - (1f - p).pow(3)

    /** Con un poco de rebote al final (Zoom). */
    private fun easeOutBack(p: Float): Float {
        val c1 = 1.4f; val c3 = c1 + 1f
        val q = p - 1f
        return 1f + c3 * q * q * q + c1 * q * q
    }

    fun entrance(layer: ImageLayer, sec: Float, loopSec: Float): Entrance {
        if (layer.inType == IN_NONE) return Entrance()
        val total = loopSec.coerceAtLeast(.1f)
        val start = if (layer.durSec > 0f) layer.startSec.coerceIn(0f, total) else 0f
        val dur = layer.inSec.coerceIn(IN_MIN, IN_MAX)
        return entranceAt(layer.inType, ((sec - start) / dur).coerceIn(0f, 1f))
    }

    /** La entrada [type] cuando va por la fracción [p] (0 = empieza, 1 = ya entró). La usan también las miniaturas. */
    fun entranceAt(type: Int, p: Float): Entrance {
        return when (type) {
            IN_FADE -> Entrance(alpha = easeOut(p))
            IN_SLIDE -> Entrance(dy = (1f - easeOut(p)) * .08f, alpha = (p * 2.5f).coerceAtMost(1f))
            IN_ZOOM -> Entrance(scale = max(.05f, .55f + .45f * easeOutBack(p)), alpha = (p * 3f).coerceAtMost(1f))
            IN_TYPE -> Entrance(reveal = p)
            else -> Entrance()
        }
    }

    /** Pasos de «Letra por letra»: letras del renglón más largo del texto (0 = barrido suave en imágenes). */
    fun revealSteps(layer: ImageLayer): Int =
        layer.text?.text?.lines()?.maxOfOrNull { it.trimEnd().length }?.coerceIn(0, 200) ?: 0
}
