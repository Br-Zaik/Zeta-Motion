package com.zeta.fondo.ui

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * v43: bloques más largos que la pantalla.
 * Valores tomados de la captura del usuario: 214 px por segundo (con zoom), pantalla de
 * 576 px, línea blanca en el centro (288 px) a los 2,3 s.
 */
class V43TimelineSnapTest {
    private val pps = 214f

    @Test fun longBlockKeepsItsRealEndWhenZoomed() {
        // Nieve de 0 a 3,8 s con la línea a 2,3 s: empieza fuera de la pantalla (−204 px)
        // y termina a 609 px, también fuera. Se dibuja de 0 a 576 (la v42 lo acababa a 372).
        val x0 = 288f + (0f - 2.3f) * pps
        val x1 = x0 + 3.8f * pps
        assertEquals(0 to 576, visibleSpan(x0, x1, 576))
        // Recortado hasta la línea blanca: su final queda exactamente en el centro.
        val (left, w) = visibleSpan(x0, x0 + 2.3f * pps, 576)
        assertEquals(288, left + w)
        // Entero fuera de la pantalla: no ocupa nada.
        assertEquals(0, visibleSpan(-500f, -10f, 576).second)
    }
}
