package com.zeta.fondo.engine

import com.zeta.fondo.model.Effects
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v45 · Reescalado bilineal de máscaras. */
class V45DepthTest {

    private fun file(rel: String) = listOf(File(rel), File("app/$rel")).first { it.exists() }

    @Test fun bilinearResizeKeepsCornersAndRange() {
        val src = byteArrayOf(0, 255.toByte(), 255.toByte(), 0)
        val r = DepthMath.resize(src, 2, 2, 8, 8)
        assertEquals(64, r.size)
        assertEquals(0, r[0].toInt() and 0xFF)
        assertEquals(255, r[7].toInt() and 0xFF)
        assertArrayEquals(src, DepthMath.resize(src, 2, 2, 2, 2))
    }
}
