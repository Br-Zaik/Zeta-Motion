package com.zeta.fondo.engine

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v44.31 · Revisión: nombres que no se cortan, nada encima de otra cosa y sin código muerto. */
class V4431Test {
    private fun file(rel: String) = listOf(File(rel), File("app/$rel")).first { it.exists() }
    private fun ui(name: String) = file("src/main/java/com/zeta/fondo/ui/$name").readText()

    @Test fun labelsAreNeverCut() {
        // Botones de las barras: el ancho crece con el nombre (las barras se desplazan de lado).
        val tools = ui("EditorTools.kt")
        val chip = tools.substringAfter("fun ToolChip(").substringBefore("/** Botón «?»")
        assertTrue(chip.contains("widthIn(min = 64.dp)") && chip.contains("softWrap = false"))
        assertFalse(chip.contains("width(64.dp)") || chip.contains("TextOverflow.Ellipsis"))
        // Barra principal: con 7 botones en 360 dp la letra baja a 10 sp.
        assertTrue(tools.contains("val labelSize = if (perItem < 56.dp) 10.sp else 11.sp"))
        // Miniaturas: dos renglones (alto fijo de 2 para que la cuadrícula no salte).
        assertTrue(ui("SimpleEditorPanels.kt").contains("minLines = 2, maxLines = 2"))
        // Cajita junto a la capa: botones que crecen con el nombre y su tamaño real medido.
        val quick = ui("LayerCropUi.kt")
        assertTrue(quick.contains("Column(Modifier.widthIn(min = 58.dp)"))
        assertTrue(quick.contains(".onSizeChanged { if (it != measured) measured = it }"))
    }

    @Test fun quickBarDoesNotCoverTheCanvasControls() {
        val quick = ui("LayerCropUi.kt").substringAfter("fun LayerQuickBar(")
        assertTrue(quick.contains("var y = max(maxY + gap, topSafe)"))
        assertTrue(quick.contains("if (y < topSafe) y = (areaH - pillH - margin).coerceAtLeast(margin)"))
    }

    @Test fun deadCodeStaysGone() {
        val main = file("src/main/java/com/zeta/fondo")
        val all = main.walkTopDown().filter { it.extension == "kt" }.joinToString("\n") { it.readText() }
        for (gone in listOf("fun MasksPanel(", "fun CameraPanel(", "fun PresetsPanel(", "fun EffectsPanel(",
            "fun PillRow(", "fun RoundButton(", "fun ActionButton(", "fun SectionCard(", "fun SheetHeader(",
            "fun activateOrSelectEffect(", "fun importAudio(", "fun snapEdge(", "val missingRecordings",
            "fun put4(", "fun openAlight(", "val all: List<Preset>"))
            assertFalse(gone, all.contains(gone))
    }
}
