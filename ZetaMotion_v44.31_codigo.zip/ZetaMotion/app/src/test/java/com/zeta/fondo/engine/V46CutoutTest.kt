package com.zeta.fondo.engine

import com.zeta.fondo.model.Effects
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v46 · Dilatación de máscaras. */
class V46CutoutTest {

    private fun file(rel: String) = listOf(File(rel), File("app/$rel")).first { it.exists() }

    @Test fun dilateGrowsTheHoleByRadius() {
        val w = 9; val h = 9
        val m = ByteArray(w * h); m[4 * w + 4] = 255.toByte()
        val d = CutoutMath.dilate(m, w, h, 2)
        assertEquals(255, d[4 * w + 6].toInt() and 0xFF)
        assertEquals(0, d[4 * w + 7].toInt() and 0xFF)
        assertEquals(255, d[2 * w + 2].toInt() and 0xFF) // cuadrado (Chebyshev)
        assertEquals(0, d[1 * w + 4].toInt() and 0xFF)
    }
}
