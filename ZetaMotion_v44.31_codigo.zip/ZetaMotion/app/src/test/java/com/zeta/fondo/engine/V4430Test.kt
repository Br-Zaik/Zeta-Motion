package com.zeta.fondo.engine

import com.zeta.fondo.model.AnimCatalog
import com.zeta.fondo.model.EffectCatalog
import com.zeta.fondo.model.Effects
import com.zeta.fondo.model.ImageLayer
import com.zeta.fondo.model.ImageLayers
import com.zeta.fondo.model.LayerFx
import com.zeta.fondo.model.Presets
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * v44.30 · Sin 2.5D, nada repetido en las barras (un icono por función), Mezcla sin textos fijos
 * y efectos de capa con miniaturas animadas y valores iniciales que se notan.
 */
class V4430Test {
    private fun file(rel: String) = listOf(File(rel), File("app/$rel")).first { it.exists() }
    private fun main(rel: String) = file("src/main/java/com/zeta/fondo/$rel")
    private fun exists(rel: String) = File("src/main/$rel").exists() || File("app/src/main/$rel").exists()

    // ---------------------------------------------------------------- 2.5D retirado

    @Test fun depthEffectIsGoneEverywhere() {
        assertTrue(Effects.all.none { it.id == "parallax" })
        assertTrue(AnimCatalog.all().none { it.effectId == "parallax" })
        assertTrue(Presets.scenes.none { p -> p.values.keys.any { it.startsWith("parallax.") } })
        for (gone in listOf("java/com/zeta/fondo/engine/DepthEstimator.kt", "java/com/zeta/fondo/engine/BackgroundFill.kt",
            "java/com/zeta/fondo/model/LayerParallax.kt", "java/com/zeta/fondo/ui/DepthPanel.kt", "assets/thumbs/parallax.webp"))
            assertFalse(gone, exists(gone))
        // El shader ya no lee el mapa ni la placa (una rama menos en cada lectura de la imagen).
        val frag = file("src/main/assets/shaders/fondo.frag").readText()
        for (word in listOf("uDepth", "uPlate", "gPlate", "FX_PARALLAX", "uParallax"))
            assertFalse(word, frag.contains(word))
        val gl = main("engine/FondoGl.kt").readText()
        assertFalse(gl.contains("uploadDepth") || gl.contains("uploadPlate") || gl.contains("keepProtect"))
        // Los parámetros del cuadro no llevan nada del 2.5D.
        val p = RenderParams.from(Effects.defaults() + mapOf("parallax.on" to 1f, "parallax.amount" to .03f), 1f, 6f)
        assertFalse(p.studio.containsKey("uParallax") || p.studio.containsKey("uDepthInfo"))
    }

    @Test fun oldProjectsOpenWithoutTheRemovedEffect() {
        assertTrue(Effects.isRemovedKey("parallax.on") && Effects.isRemovedKey("parallax.copy.on"))
        assertFalse(Effects.isRemovedKey("cam.on") || Effects.isRemovedKey("parallaxx.on"))
        val store = main("model/ProjectStore.kt").readText()
        assertTrue(store.contains("if (Effects.isRemovedKey(k)) continue"))
        assertTrue(store.contains("if (id.isBlank() || id in Effects.removed) continue"))
        // Sus archivos de trabajo se borran al abrir (espacio que vuelve al teléfono).
        val vm = main("AppViewModel.kt").readText()
        assertTrue(vm.contains("for (name in RETIRED_FILES)"))
        assertTrue(vm.contains("listOf(\"depth.png\", \"depth.txt\", \"plate.png\", \"plate.txt\")"))
    }

    // ---------------------------------------------------------------- nada repetido

    @Test fun animateCatalogOnlyHasItsOwnAnimations() {
        val all = AnimCatalog.all()
        assertEquals(all.size, all.map { it.key }.toSet().size)
        assertEquals(all.size, all.map { it.title }.toSet().size)
        // Nada de Animar aparece también en el catálogo de Efectos (ni al revés).
        for (e in all) assertTrue(e.key, e.effectId in EffectCatalog.animateIds)
        val inEffects = EffectCatalog.groupIds.values.flatten().toSet()
        assertTrue(all.none { it.effectId in inEffects })
        assertEquals(listOf("Cámara", "Viento y tela", "Zona y personaje"), AnimCatalog.categories)
        assertEquals(AnimCatalog.categories.toSet(), AnimCatalog.entries.keys)
    }

    /** (nombre, icono) de cada botón con nombre de las barras del editor. */
    private fun buttons(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val icon = "(Icons\\.Filled\\.\\w+|ZetaEraserIcon)"
        val plain = Regex("(?:ToolChip|MainItem|QuickButton)\\(\"([^\"]+)\",\\s*$icon")
        val both = Regex("(?:ToolChip|QuickButton)\\(if \\([^\"]*?\\) \"([^\"]+)\" else \"([^\"]+)\",\\s*if \\([^\"]*?\\) $icon else $icon")
        val oneIcon = Regex("(?:ToolChip|QuickButton)\\(if \\([^\"]*?\\) \"([^\"]+)\" else \"([^\"]+)\",\\s*$icon")
        val triple = Regex("Triple\\(\\d+, \"([^\"]+)\", $icon\\)")
        for (name in listOf("EditorTools.kt", "Workspace.kt", "LayerPanels.kt", "LayerCropUi.kt")) {
            val s = main("ui/$name").readText()
            for (m in plain.findAll(s)) out.add(m.groupValues[1] to m.groupValues[2])
            for (m in both.findAll(s)) { out.add(m.groupValues[1] to m.groupValues[3]); out.add(m.groupValues[2] to m.groupValues[4]) }
            for (m in oneIcon.findAll(s)) { out.add(m.groupValues[1] to m.groupValues[3]); out.add(m.groupValues[2] to m.groupValues[3]) }
            for (m in triple.findAll(s)) out.add(m.groupValues[1] to m.groupValues[2])
        }
        return out
    }

    @Test fun everyButtonHasItsOwnIcon() {
        val all = buttons()
        assertTrue("se leyeron ${all.size} botones", all.size >= 60)
        // Un mismo nombre siempre lleva el mismo icono…
        for ((label, icons) in all.groupBy({ it.first }, { it.second }))
            assertEquals("«$label» con iconos distintos: ${icons.toSet()}", 1, icons.toSet().size)
        // …y un icono no se usa para dos cosas (salvo los dos estados de un mismo interruptor).
        val toggles = setOf(setOf("Detrás", "Delante"), setOf("Clave", "Quitar clave"))
        for ((ic, labels) in all.groupBy({ it.second }, { it.first })) {
            val set = labels.toSet()
            assertTrue("$ic se usa para $set", set.size == 1 || set in toggles)
        }
    }

    @Test fun barsDoNotRepeatEachOther() {
        val tools = main("ui/EditorTools.kt").readText()
        val animate = tools.substringAfter("private fun AnimateToolRow(").substringBefore("private fun ProtectToolRow(")
        val chip = Regex("ToolChip\\(\"([^\"]+)\"")
        // Animar: el catálogo y las herramientas de dedo; ni animaciones sueltas, ni Bucle, ni Congelar.
        assertEquals(listOf("Catálogo", "Ruta", "Ancla", "Borrar"), chip.findAll(animate).map { it.groupValues[1] }.toList())
        // Proteger ya no repite las anclas de Animar.
        val protect = tools.substringAfter("private fun ProtectToolRow(").substringBefore("private val settingsTools")
        assertFalse(protect.contains("PushPin") || protect.contains("Tool.ANCHOR"))
        // Ajustes: sin Audio (tiene su botón en la barra principal).
        val settings = Regex("Triple\\(\\d+, \"([^\"]+)\"").findAll(tools).map { it.groupValues[1] }.toList()
        assertEquals(listOf("Duración", "Formato", "Color", "Bucle", "Vista", "Viento", "Mejorar", "Diagnóstico", "Licencias"), settings)
        val mainBar = Regex("MainItem\\(\"([^\"]+)\"").findAll(tools).map { it.groupValues[1] }.toList()
        assertEquals(mainBar.size, mainBar.toSet().size)
        assertTrue(settings.none { it in mainBar })
        // La pista de la imagen abre los mismos Ajustes (no otra barra con lo mismo).
        assertTrue(tools.contains("vm.imageSelected -> BarWithBack(modifier, onBack = { vm.selectImageTrack(false) }) { SettingsToolRow(vm, Modifier) }"))
        assertFalse(main("ui/Workspace.kt").readText().contains("fun ImageActionRow"))
        // Capa: lo que está en la cajita junto a la imagen no se repite abajo.
        val row = main("ui/LayerPanels.kt").readText().substringAfter("fun LayerActionRow(").substringBefore("@Composable")
        val quick = main("ui/LayerCropUi.kt").readText().substringAfter("fun LayerQuickBar(")
        for (label in listOf("Recortar", "Editar", "Efectos", "Girar")) {
            assertTrue(label, quick.contains("QuickButton(\"$label\""))
            assertFalse(label, row.contains("ToolChip(\"$label\""))
        }
        // Voltear y Detrás: uno arriba y el otro abajo, según sea imagen o texto.
        assertTrue(row.contains("if (l.text == null) ToolChip(if (l.behind) \"Detrás\" else \"Delante\""))
        assertTrue(row.contains("else ToolChip(\"Voltear\""))
    }

    @Test fun blendPanelHasNoFixedTexts() {
        val ui = main("ui/LayerPanels.kt").readText()
        val sheet = ui.substringAfter("fun BlendSheet(").substringBefore("private fun BlendThumb(")
        assertFalse(sheet.contains("current.help") || sheet.contains("Consejo:") || sheet.contains("groupHelp"))
        // La explicación sigue a un toque largo.
        assertTrue(ui.contains("onLongClick = { vm.showHint(\"\${mode.name}: \${mode.help}\", 5000L) }"))
    }

    // ---------------------------------------------------------------- efectos de capa

    @Test fun layerEffectsStartVisible() {
        // Antes siempre 1 vuelta: en un vídeo de 8 s el brillo pasaba una sola vez.
        assertEquals(3, LayerFx.defaultCycles(LayerFx.SHIMMER, 8f))
        assertEquals(3, LayerFx.defaultCycles(LayerFx.NEON, 6f))
        assertEquals(1, LayerFx.defaultCycles(LayerFx.HUE, 2f))
        assertEquals(1, LayerFx.defaultCycles(LayerFx.NONE, 60f))
        for (fx in 1 until LayerFx.names.size) for (sec in listOf(.1f, 2f, 6f, 15f, 60f, 1e6f, Float.NaN)) {
            val n = LayerFx.defaultCycles(fx, if (sec.isNaN()) 6f else sec)
            assertTrue("$fx · $sec s → $n", n in 1..LayerFx.MAX_CYCLES)
        }
        assertTrue(LayerFx.DEFAULT_AMT > .6f && LayerFx.DEFAULT_AMT <= 1f)
        assertTrue(LayerFx.cycleChoices.all { it in 1..LayerFx.MAX_CYCLES })
        // Movimientos de capa: igual.
        assertEquals(5, ImageLayers.defaultMotionCycles(ImageLayers.MOTION_PULSE, 6f))
        assertEquals(2, ImageLayers.defaultMotionCycles(ImageLayers.MOTION_FLOAT, 6f))
        assertEquals(1, ImageLayers.defaultMotionCycles(ImageLayers.MOTION_NONE, 6f))
        for (m in 1 until ImageLayers.motionNames.size) assertTrue(ImageLayers.defaultMotionCycles(m, 600f) in 1..8)
        val vm = main("AppViewModel.kt").readText()
        assertTrue(vm.contains("fxCycles = com.zeta.fondo.model.LayerFx.defaultCycles(fx, exportSettings.loopSec.toFloat())"))
        assertTrue(vm.contains("if (fx != com.zeta.fondo.model.LayerFx.NONE && !playing) togglePlay()"))
    }

    @Test fun thumbnailsUseTheRealEntranceCurve() {
        val l = ImageLayer(id = 1, name = "a", file = "layers/a.png", aspect = 2f, inSec = 1f)
        for (type in 0 until LayerFx.inNames.size) for (p in listOf(0f, .25f, .5f, 1f)) {
            assertEquals(LayerFx.entrance(l.copy(inType = type), p, 6f), LayerFx.entranceAt(type, p))
        }
        for (type in 1 until LayerFx.inNames.size) assertEquals(LayerFx.Entrance(), LayerFx.entranceAt(type, 1f).let {
            it.copy(dy = if (kotlin.math.abs(it.dy) < 1e-6f) 0f else it.dy, scale = if (kotlin.math.abs(it.scale - 1f) < 1e-5f) 1f else it.scale)
        })
    }

    @Test fun layerEffectsSheetLooksLikeTheMainCatalog() {
        val ui = main("ui/LayerFxUi.kt").readText()
        assertTrue(ui.contains("listOf(\"Efecto\", \"Movimiento\", \"Entrada\")"))
        assertTrue(ui.contains("LazyVerticalGrid(GridCells.Adaptive(78.dp)") && ui.contains("CatalogCard(names[i], selected, false"))
        assertTrue(ui.contains("selected && i != 0 -> { adjusting = true }"))
        // Un solo reloj, a ~20 cuadros por segundo; «Ninguno» no se redibuja.
        assertEquals(1, Regex("rememberFxClock\\(\\)").findAll(ui.substringAfter("fun LayerFxSheet(")).count())
        assertTrue(ui.contains("delay(45L)") && ui.contains("val t = if (index == 0) 0f else clock()"))
        // Movimiento vive solo aquí (ya no hay otra hoja ni otro botón).
        val panels = main("ui/LayerPanels.kt").readText()
        assertFalse(panels.contains("LayerMotionSheet") || panels.contains("ToolChip(\"Movimiento\""))
        assertFalse(main("AppViewModel.kt").readText().contains("layerMotionOpen"))
        // El shader: ondear con el lado corto de la capa y el brillo enciende el contorno.
        val c = main("engine/LayerCompositor.kt").readText()
        assertTrue(c.contains("min(uHalf.x, uHalf.y) / max(uHalf, vec2(1e-3))"))
        assertTrue(c.contains("float gs = smoothstep(0.04, 0.45, haloS) * band"))
    }
}
