> **Versión actual: v44.31 — lee LEEME_V44.md** (cambios, compilación y pruebas).

> **Edición Lite:** solo el código y lo que la app necesita para compilar y funcionar (sin docs/, tools/ ni checks/).

# Zeta Motion v35.1 — APK firmado

Antes de instalar lee [LEEME_INSTALACION_ESTABLE.md](LEEME_INSTALACION_ESTABLE.md).

El código conserva los efectos y herramientas de v35.
