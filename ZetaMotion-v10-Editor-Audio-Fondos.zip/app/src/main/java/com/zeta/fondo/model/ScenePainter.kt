package com.zeta.fondo.model

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import java.util.Random

/** Ocho fondos vectoriales propios, pintados una vez al crear el proyecto. */
object ScenePainter {
    val names = listOf("Atardecer", "Noche", "Sakura", "Tormenta", "Ciudad neón",
        "Lago", "Bosque", "Nieve")
    private val tops = intArrayOf(0xFF253E98.toInt(), 0xFF08112B.toInt(), 0xFF4D569B.toInt(),
        0xFF172639.toInt(), 0xFF120E30.toInt(), 0xFF3675AE.toInt(), 0xFF174F70.toInt(), 0xFF405C86.toInt())
    private val horizons = intArrayOf(0xFFFF8790.toInt(), 0xFF6261AA.toInt(), 0xFFFFAFC6.toInt(),
        0xFF758291.toInt(), 0xFF8C4CC6.toInt(), 0xFFFFC9A8.toInt(), 0xFFB5B491.toInt(), 0xFFE5E6F1.toInt())

    fun create(index: Int, width: Int = 720, height: Int = 1280): Bitmap {
        val k = index.coerceIn(names.indices)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap)
        c.scale(width / 720f, height / 1280f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        fun color(v: Int) { p.shader = null; p.color = v; p.style = Paint.Style.FILL }
        p.shader = LinearGradient(0f, 0f, 0f, 1000f, tops[k], horizons[k], Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, 720f, 1280f, p)
        p.shader = null
        val night = k == 1 || k == 4
        val rnd = Random(2048L + k)
        if (night) {
            color(Color.WHITE)
            repeat(110) {
                val x = rnd.nextInt(720).toFloat()
                val y = rnd.nextInt(750).toFloat()
                p.alpha = 80 + rnd.nextInt(150)
                c.drawCircle(x, y, 0.7f + rnd.nextFloat() * 1.7f, p)
            }
            p.alpha = 255
        }
        color(if (k == 0) 0xFFFFDA9C.toInt() else if (night) 0xFFD9EAFF.toInt()
            else 0xFFFCF2D6.toInt())
        c.drawCircle(if (k == 0) 510f else 526f, if (k == 0) 624f else 348f,
            if (k == 0) 112f else 50f, p)

        fun peaks(base: Float, magnitude: Float, fill: Int, seed: Int) {
            color(fill)
            val r = Random(seed.toLong() + k)
            val path = Path().apply { moveTo(0f, 1280f); lineTo(0f, base) }
            for (j in 1..10) path.lineTo(j * 80f, base - magnitude * (0.2f + r.nextFloat()))
            path.lineTo(720f, 1280f)
            path.close()
            c.drawPath(path, p)
        }
        peaks(840f, 250f, if (night) 0xFF3C4B78.toInt() else 0xFF8C8DC0.toInt(), 85)
        peaks(980f, 240f, if (k == 7) 0xFFD3DCF0.toInt() else if (k == 5) 0xFF5980A7.toInt()
            else 0xFF514F83.toInt(), 39)

        if (k == 4) {
            for (j in 0..13) {
                val x = j * 56f
                val height = 140f + rnd.nextInt(310)
                color(if (j % 2 == 0) 0xFF151630.toInt() else 0xFF22244C.toInt())
                c.drawRect(x, 900f - height, x + 50f, 1280f, p)
                color(if (j % 3 == 0) 0xFFFF78D3.toInt() else 0xFF65D9F1.toInt())
                for (yy in (920 - height.toInt())..1120 step 29) for (xx in 0..2) {
                    if (rnd.nextBoolean()) c.drawRect(x + 8f + xx * 14f, yy.toFloat(),
                        x + 12f + xx * 14f, yy + 9f, p)
                }
            }
        } else if (k == 5) {
            color(0xFF5E82AD.toInt())
            c.drawRect(0f, 980f, 720f, 1280f, p)
            color(0xFFB5C3D8.toInt())
            for (j in 0..17) {
                val y = 995f + j * 16f
                c.drawRoundRect(220f - j * 10f, y, 530f + j * 10f, y + 2f, 2f, 2f, p)
            }
        } else {
            peaks(1160f, 160f, if (k == 7) 0xFFB9C9E0.toInt() else 0xFF292F60.toInt(), 4)
        }

        if (k == 2 || k == 6 || k == 7) {
            color(if (k == 2) 0xFF472B58.toInt() else 0xFF1B333E.toInt())
            for (side in 0..1) {
                val x = if (side == 0) 52f else 645f
                c.drawRect(x, 680f, x + 17f, 1280f, p)
                for (j in 0..8) {
                    val yy = 770f + j * 55f
                    c.drawCircle(x + (if (side == 0) 18f else -12f), yy, 53f, p)
                }
                if (k == 2) {
                    color(0xFFF5B4CB.toInt())
                    repeat(65) { c.drawCircle(x + rnd.nextInt(160) - 80f,
                        730f + rnd.nextInt(450), 2f + rnd.nextFloat() * 6f, p) }
                    color(0xFF472B58.toInt())
                }
            }
        }
        if (k == 0 || k == 1 || k == 3) {
            val x = 210f
            color(0xFF21203E.toInt())
            c.drawRect(x, 860f, x + 270f, 1140f, p)
            for (floor in 0..2) {
                val y = 855f - floor * 62f
                val roof = Path().apply {
                    moveTo(x - 49f + floor * 25f, y)
                    lineTo(x + 135f, y - 70f)
                    lineTo(x + 318f - floor * 25f, y)
                    lineTo(x + 273f - floor * 22f, y + 12f)
                    lineTo(x + floor * 22f, y + 12f)
                    close()
                }
                color(if (k == 0) 0xFF792E65.toInt() else 0xFF292746.toInt())
                c.drawPath(roof, p)
                color(0xFFF0A6A4.toInt())
                c.drawRect(x + 31f, y + 24f, x + 229f, y + 30f, p)
            }
        }
        return bitmap
    }
}
