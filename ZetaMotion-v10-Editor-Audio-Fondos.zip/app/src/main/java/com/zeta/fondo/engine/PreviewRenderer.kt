package com.zeta.fondo.engine

import android.graphics.Bitmap
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class PreviewRenderer(
    private val hub: RenderHub,
    private val vertSrc: String,
    private val fragSrc: String
) : GLSurfaceView.Renderer {

    private var gl: FondoGl? = null
    private var vw = 1
    private var vh = 1
    private var lastImage: Bitmap? = null
    private var lastFlow: FlowField.Data? = null
    private var lastMasks: MaskLayers? = null
    private val maskVer = IntArray(MaskLayers.MAX_MASKS) { -1 }
    private val view = FloatArray(4)
    private var failed = false

    override fun onSurfaceCreated(unused: GL10?, config: EGLConfig?) {
        // Contexto nuevo: hay que volver a subir todo
        lastImage = null
        lastFlow = null
        lastMasks = null
        maskVer.fill(-1)
        failed = false
        gl = try {
            FondoGl(vertSrc, fragSrc).also { it.init() }
        } catch (t: Throwable) {
            failed = true
            hub.onError?.invoke(t.message ?: t.toString())
            null
        }
    }

    override fun onSurfaceChanged(unused: GL10?, width: Int, height: Int) {
        vw = width
        vh = height
    }

    override fun onDrawFrame(unused: GL10?) {
        val g = gl
        if (g == null || failed || !hub.renderEnabled) {
            GLES30.glClearColor(0.08f, 0.09f, 0.19f, 1f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
            return
        }
        try {
            val img = hub.image
            if (img != null && img !== lastImage && !img.isRecycled) {
                g.uploadImage(img)
                lastImage = img
            }
            val f = hub.flow
            if (f != null && f !== lastFlow) {
                g.uploadFlow(f)
                lastFlow = f
            }
            val m = hub.masks
            if (m != null) {
                if (m !== lastMasks) {
                    lastMasks = m
                    maskVer.fill(-1)
                }
                synchronized(m.lock) {
                    if (m.count > 0 && g.prepareMasks(m.w, m.h)) maskVer.fill(-1)
                    for (i in m.bitmaps.indices) {
                        if (m.versions[i] != maskVer[i]) {
                            g.uploadMask(i, m.bitmaps[i])
                            maskVer[i] = m.versions[i]
                        }
                    }
                }
            }
            if (lastImage == null) {
                GLES30.glClearColor(0.08f, 0.09f, 0.19f, 1f)
                GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
                return
            }
            val s = hub.viewScale
            view[0] = hub.viewX
            view[1] = hub.viewY
            view[2] = 1f / s
            view[3] = 1f / s
            g.draw(hub.params, hub.currentT(), vw, vh, view, false, false, hub.showMask, false, hub.activeMask)
        } catch (t: Throwable) {
            failed = true
            hub.onError?.invoke(t.message ?: t.toString())
        }
    }
}
