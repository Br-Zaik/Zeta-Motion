package com.zeta.fondo.engine

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.os.Process
import com.zeta.fondo.model.ExportSettings
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.sin

/** Ambientes sintetizados dentro de la app: sin archivos ajenos, red ni derechos de terceros. */
object AudioBed {
    const val RATE = 22050
    val labels = listOf("Sin sonido", "Lluvia", "Truenos", "Viento", "Fuego", "Magia", "Río")

    private fun noise(i: Int): Float {
        var x = i xor 0x51ed270b
        x = (x xor (x ushr 16)) * 0x7feb352d
        x = (x xor (x ushr 15)) * 0x846ca68b.toInt()
        return ((x xor (x ushr 16)).ushr(8) / 8388607.5f) - 1f
    }

    fun sample(sound: Int, seconds: Double, volume: Float): Short {
        if (sound == 0 || volume <= 0f) return 0
        val t = seconds % 6.0
        val n = noise((seconds * RATE).toInt())
        val slow = noise((seconds * 320).toInt())
        val wave = sin(seconds * 2.0 * PI)
        val signal = when (sound) {
            1 -> 0.46 * n + 0.22 * slow + 0.03 * wave
            2 -> {
                val strike = if (t in 0.9..2.4) (1.0 - (t - 0.9) / 1.5) else if (t in 4.1..5.1) 0.5 * (5.1 - t) else 0.0
                0.15 * n + strike * (0.68 * slow + 0.26 * n)
            }
            3 -> (0.19 + 0.15 * sin(seconds * 1.7)) * slow + 0.08 * n
            4 -> 0.27 * slow + 0.16 * n * if (noise((seconds * 37).toInt()) > 0.68f) 1.0 else 0.20
            5 -> 0.15 * sin(seconds * 11.0) + 0.12 * sin(seconds * 18.2) + 0.1 * slow
            6 -> 0.23 * slow + 0.20 * n + 0.04 * sin(seconds * 7.0)
            else -> 0.0
        }
        return (signal * volume.coerceIn(0f, 1f) * 20500.0).toInt().coerceIn(-32768, 32767).toShort()
    }

    data class Packet(val bytes: ByteArray, val info: MediaCodec.BufferInfo)
    data class Encoded(val format: MediaFormat, val packets: List<Packet>)

    fun encode(s: ExportSettings, cancel: AtomicBoolean): Encoded {
        val duration = s.loopSec.toLong() * s.repeats
        val totalSamples = duration * RATE
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, RATE, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 96000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 4096)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        val packets = ArrayList<Packet>()
        var outputFormat: MediaFormat? = null
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            val info = MediaCodec.BufferInfo()
            var written = 0L
            var done = false
            var tries = 0
            while (!done) {
                if (cancel.get()) throw ExportCancelled()
                if (written <= totalSamples) {
                    val index = codec.dequeueInputBuffer(10_000)
                    if (index >= 0) {
                        val count = minOf(1024L, totalSamples - written).toInt()
                        val buffer = codec.getInputBuffer(index) ?: error("Codificador AAC sin búfer de entrada")
                        buffer.clear()
                        buffer.order(ByteOrder.LITTLE_ENDIAN)
                        for (j in 0 until count) {
                            val sec = (written + j).toDouble() / RATE
                            buffer.putShort(sample(s.sound, sec, s.soundVolume))
                        }
                        codec.queueInputBuffer(index, 0, count * 2, written * 1_000_000L / RATE,
                            if (count == 0) MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0)
                        written += if (count == 0) 1 else count
                    }
                }
                while (true) {
                    val index = codec.dequeueOutputBuffer(info, 10_000)
                    if (index == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (++tries > 500) error("AAC no terminó la codificación")
                        break
                    }
                    tries = 0
                    if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) outputFormat = codec.outputFormat
                    else if (index >= 0) {
                        if (info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            val src = codec.getOutputBuffer(index) ?: error("AAC sin búfer de salida")
                            src.position(info.offset)
                            src.limit(info.offset + info.size)
                            val bytes = ByteArray(info.size)
                            src.get(bytes)
                            val copy = MediaCodec.BufferInfo().apply {
                                set(0, bytes.size, info.presentationTimeUs,
                                    info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM.inv())
                            }
                            packets.add(Packet(bytes, copy))
                        }
                        done = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        codec.releaseOutputBuffer(index, false)
                        if (done) break
                    }
                }
            }
            return Encoded(outputFormat ?: error("AAC no entregó formato de salida"), packets)
        } finally {
            try { codec.stop() } catch (_: Exception) { }
            codec.release()
        }
    }
}

/** Audio de prueba en un hilo aparte; lee el mismo reloj que el vídeo. */
class PreviewAudio(private val settings: () -> ExportSettings, private val playing: () -> Boolean,
                   private val time: () -> Float) {
    private val running = AtomicBoolean(true)
    @Volatile private var foreground = true
    private val thread = Thread {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        var track: AudioTrack? = null
        val block = ShortArray(1024)
        var active = false
        try {
            while (running.get()) {
                val s = settings()
                if (!foreground || !playing() || s.sound == 0 || s.soundVolume == 0f) {
                    if (active) { track?.pause(); track?.flush(); active = false }
                    Thread.sleep(35)
                    continue
                }
                val audio = track ?: run {
                    val min = AudioTrack.getMinBufferSize(AudioBed.RATE, AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(4096)
                    AudioTrack.Builder()
                        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                        .setAudioFormat(AudioFormat.Builder().setSampleRate(AudioBed.RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                        .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(min)
                        .build().also { track = it }
                }
                if (!active) { audio.play(); active = true }
                val begin = time().toDouble() * s.loopSec
                for (i in block.indices) block[i] = AudioBed.sample(s.sound,
                    begin + i.toDouble() / AudioBed.RATE, s.soundVolume)
                audio.write(block, 0, block.size, AudioTrack.WRITE_BLOCKING)
            }
        } catch (_: InterruptedException) {
        } catch (_: Exception) {
        } finally {
            try { track?.pause(); track?.flush(); track?.release() } catch (_: Exception) { }
        }
    }.apply { name = "ZetaPreviewAudio"; isDaemon = true }

    fun start() = thread.start()
    fun setForeground(value: Boolean) { foreground = value }
    fun stop() { running.set(false); thread.interrupt() }
}
