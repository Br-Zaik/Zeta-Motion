package com.zeta.fondo.ui

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.model.EditorTab
import com.zeta.fondo.model.ProjectSummary
import com.zeta.fondo.model.ScenePainter

/** Inicio limpio: una sola acción para importar y la lista real de proyectos. */
@Composable
fun HomeScreen(vm: AppViewModel) {
    var newTab by remember { mutableStateOf(EditorTab.TOOLS) }
    var newCategory by remember { mutableStateOf("Anime") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importImage(uri, newTab, newCategory)
    }
    fun newProject(tab: EditorTab = EditorTab.TOOLS, category: String = "Anime") {
        newTab = tab
        newCategory = category
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }
    var toDelete by remember { mutableStateOf<ProjectSummary?>(null) }
    val grid = rememberLazyGridState()
    Column(Modifier.fillMaxSize().background(Night)) {
        Row(Modifier.fillMaxWidth().height(62.dp).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Zeta", color = StudioText, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(" Motion", color = StudioPurple, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f))
            Row(Modifier.height(40.dp).clip(RoundedCornerShape(12.dp)).background(StudioTile)
                .clickable { newProject() }.padding(horizontal = 11.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AddPhotoAlternate, "Importar", tint = StudioText, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(7.dp))
                Text("Importar", color = StudioText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Text("Fondos ilustrados", color = StudioText, fontSize = 15.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 5.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 13.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ScenePainter.names.forEachIndexed { index, name ->
                val art = remember(index) { ScenePainter.create(index, 112, 196).asImageBitmap() }
                Column(Modifier.width(78.dp).clip(RoundedCornerShape(9.dp)).background(StudioPanel)
                    .clickable { vm.createScene(index) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(art, name, Modifier.fillMaxWidth().height(92.dp), contentScale = ContentScale.Crop)
                    Text(name, color = StudioText, fontSize = 10.sp, maxLines = 1,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp))
                }
            }
        }
        Text("Proyectos", color = StudioText, fontSize = 19.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 10.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), state = grid, modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(11.dp), verticalArrangement = Arrangement.spacedBy(11.dp),
            contentPadding = PaddingValues(start = 15.dp, end = 15.dp, bottom = 20.dp)) {
            if (vm.projects.isEmpty()) item {
                Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(14.dp))
                    .background(StudioPanel).clickable { newProject() }, contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.AddPhotoAlternate, null, tint = StudioPurple, modifier = Modifier.size(29.dp))
                        Text("Importar imagen", color = StudioMuted, fontSize = 13.sp)
                    }
                }
            }
            items(vm.projects, key = { it.id }) { p ->
                HomeProject(p, onOpen = { vm.openProject(p.id) }, onDelete = { toDelete = p })
            }
        }
    }
    toDelete?.let { p ->
        AlertDialog(onDismissRequest = { toDelete = null },
            title = { Text("¿Borrar proyecto?") },
            text = { Text(p.name) },
            confirmButton = { TextButton(onClick = { vm.deleteProject(p.id); toDelete = null }) {
                Text("Borrar", color = Danger) } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } },
            containerColor = StudioPanel)
    }
}

@Composable
private fun HomeProject(p: ProjectSummary, onOpen: () -> Unit, onDelete: () -> Unit) {
    val bitmap = remember(p.thumb.absolutePath, p.modified) {
        runCatching { BitmapFactory.decodeFile(p.thumb.absolutePath)?.asImageBitmap() }.getOrNull()
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp))
        .background(StudioPanel).clickable(onClick = onOpen)) {
        Box(Modifier.fillMaxWidth().aspectRatio(1.23f).background(StudioTile)) {
            if (bitmap != null) Image(bitmap, p.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Icon(Icons.Filled.MoreVert, "Borrar proyecto", tint = StudioText,
                modifier = Modifier.align(Alignment.TopEnd).padding(5.dp).size(43.dp)
                    .clip(RoundedCornerShape(15.dp)).background(Night.copy(alpha = .75f))
                    .clickable(onClick = onDelete).padding(9.dp))
        }
        Text(p.name, color = StudioText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 10.dp, end = 8.dp, top = 9.dp))
        Text("${p.w}×${p.h}", color = StudioMuted, fontSize = 12.sp,
            modifier = Modifier.padding(start = 10.dp, bottom = 10.dp, top = 2.dp))
    }
}
