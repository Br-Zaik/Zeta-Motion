package com.zeta.fondo.model

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import com.zeta.fondo.engine.BitmapUtil
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class ProjectSummary(
    val id: String,
    val name: String,
    val thumb: File,
    val modified: Long,
    val w: Int,
    val h: Int
)

data class ProjectMeta(
    val id: String,
    val name: String,
    val dir: File,
    val imageFile: File,
    val w: Int,
    val h: Int
)

class LoadedProject(
    val meta: ProjectMeta,
    val arrows: List<Arrow>,
    val anchors: List<PointN>,
    val strokes: List<MaskStroke>,
    val settings: Map<String, Float>,
    val export: ExportSettings,
    val maskNames: List<String>
)

/**
 * Cada proyecto es una carpeta: source.img (copia EXACTA de tu imagen, sin
 * recomprimir), thumb.jpg y project.json con flechas, máscaras y ajustes.
 */
class ProjectStore(private val ctx: Context) {

    private val root = File(ctx.filesDir, "projects")

    fun createScene(index: Int): String {
        root.mkdirs()
        val id = System.currentTimeMillis().toString()
        val dir = File(root, id)
        dir.mkdirs()
        try {
            val image = ScenePainter.create(index)
            File(dir, IMAGE).outputStream().use { image.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val thumb = Bitmap.createScaledBitmap(image, 270, 480, true)
            File(dir, THUMB).outputStream().use { thumb.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            thumb.recycle()
            image.recycle()
            File(dir, JSON).writeText(JSONObject().put("name", ScenePainter.names[index])
                .put("w", 720).put("h", 1280).toString())
            return id
        } catch (e: Throwable) {
            dir.deleteRecursively()
            throw e
        }
    }

    fun list(): List<ProjectSummary> {
        root.mkdirs()
        val dirs = root.listFiles() ?: return emptyList()
        return dirs.filter { it.isDirectory && File(it, JSON).exists() }.mapNotNull { dir ->
            try {
                val jf = File(dir, JSON)
                val j = JSONObject(jf.readText())
                ProjectSummary(
                    dir.name, j.optString("name", dir.name), File(dir, THUMB),
                    jf.lastModified(), j.getInt("w"), j.getInt("h")
                )
            } catch (e: Exception) {
                null
            }
        }.sortedByDescending { it.modified }
    }

    fun create(uri: Uri): String {
        root.mkdirs()
        val id = System.currentTimeMillis().toString()
        val dir = File(root, id)
        dir.mkdirs()
        try {
            val cr = ctx.contentResolver
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            val opened = cr.openInputStream(uri) ?: throw IOException("No se pudo abrir la imagen")
            opened.use { BitmapFactory.decodeStream(it, null, o) }
            if (o.outWidth <= 0 || o.outHeight <= 0) throw IOException("Ese archivo no es una imagen compatible")

            val img = File(dir, IMAGE)
            var w = o.outWidth
            var h = o.outHeight
            val rotation = readRotation(uri)
            if (rotation == 0) {
                // Copia byte a byte: conserva la calidad y resolución originales
                val input = cr.openInputStream(uri) ?: throw IOException("No se pudo leer la imagen")
                input.use { i -> img.outputStream().use { i.copyTo(it) } }
            } else {
                val input = cr.openInputStream(uri) ?: throw IOException("No se pudo leer la imagen")
                val full = input.use { BitmapFactory.decodeStream(it) } ?: throw IOException("No se pudo decodificar la imagen")
                val m = Matrix().apply { postRotate(rotation.toFloat()) }
                val rot = Bitmap.createBitmap(full, 0, 0, full.width, full.height, m, true)
                img.outputStream().use { rot.compress(Bitmap.CompressFormat.PNG, 100, it) }
                w = rot.width
                h = rot.height
                if (rot !== full) rot.recycle()
                full.recycle()
            }

            val th = BitmapUtil.decodeAtMost(img, 480)
            File(dir, THUMB).outputStream().use { th.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            th.recycle()

            val name = "Fondo " + SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())
            val j = JSONObject().put("name", name).put("w", w).put("h", h)
            File(dir, JSON).writeText(j.toString())
            return id
        } catch (e: Throwable) {
            dir.deleteRecursively()
            throw e
        }
    }

    private fun readRotation(uri: Uri): Int = try {
        val input = ctx.contentResolver.openInputStream(uri)
        if (input == null) 0 else input.use { s ->
            when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        }
    } catch (e: Exception) {
        0
    }

    fun load(id: String): LoadedProject {
        val dir = File(root, id)
        val j = JSONObject(File(dir, JSON).readText())
        val w = j.getInt("w")
        val h = j.getInt("h")
        val meta = ProjectMeta(id, j.optString("name", "Fondo"), dir, File(dir, IMAGE), w, h)

        val arrows = ArrayList<Arrow>()
        j.optJSONArray("arrows")?.let { a ->
            for (i in 0 until a.length()) {
                val e = a.getJSONArray(i)
                arrows.add(Arrow(e.f(0), e.f(1), e.f(2), e.f(3)))
            }
        }
        val anchors = ArrayList<PointN>()
        j.optJSONArray("anchors")?.let { a ->
            for (i in 0 until a.length()) {
                val e = a.getJSONArray(i)
                anchors.add(PointN(e.f(0), e.f(1)))
            }
        }
        val strokes = ArrayList<MaskStroke>()
        j.optJSONArray("strokes")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val s = MaskStroke(
                    o.getInt("l"),
                    o.getDouble("r").toFloat(),
                    o.optDouble("f", 0.3).toFloat(),
                    o.optBoolean("e", false),
                    o.optBoolean("fill", false)
                )
                o.optJSONArray("p")?.let { p ->
                    var k = 0
                    while (k + 1 < p.length()) {
                        s.points.add(PointN(p.f(k), p.f(k + 1)))
                        k += 2
                    }
                }
                strokes.add(s)
            }
        }
        val settings = HashMap(Effects.defaults())
        j.optJSONObject("settings")?.let { o ->
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                settings[k] = o.optDouble(k, 0.0).toFloat()
            }
        }
        val export = ExportSettings.fromJson(j.optJSONObject("export"))
        val maskNames = ArrayList<String>()
        j.optJSONArray("maskNames")?.let { arr ->
            for (i in 0 until arr.length()) maskNames.add(arr.optString(i, "Máscara $i"))
        }
        return LoadedProject(meta, arrows, anchors, strokes, settings, export, maskNames)
    }

    fun save(
        meta: ProjectMeta,
        arrows: List<Arrow>,
        anchors: List<PointN>,
        strokes: List<MaskStroke>,
        settings: Map<String, Float>,
        export: ExportSettings,
        maskNames: List<String>
    ) {
        val j = JSONObject()
            .put("name", meta.name)
            .put("w", meta.w)
            .put("h", meta.h)
        val a = JSONArray()
        for (ar in arrows) a.put(JSONArray().put(r4(ar.x0)).put(r4(ar.y0)).put(r4(ar.x1)).put(r4(ar.y1)))
        j.put("arrows", a)
        val an = JSONArray()
        for (p in anchors) an.put(JSONArray().put(r4(p.x)).put(r4(p.y)))
        j.put("anchors", an)
        val st = JSONArray()
        for (s in strokes) {
            val pts = JSONArray()
            for (p in s.points) {
                pts.put(r4(p.x))
                pts.put(r4(p.y))
            }
            st.put(
                JSONObject()
                    .put("l", s.layer)
                    .put("r", s.radius.toDouble())
                    .put("f", s.feather.toDouble())
                    .put("e", s.erase)
                    .put("fill", s.fill)
                    .put("p", pts)
            )
        }
        j.put("strokes", st)
        j.put("maskNames", JSONArray(maskNames))
        val so = JSONObject()
        for ((k, v) in settings) so.put(k, v.toDouble())
        j.put("settings", so)
        j.put("export", export.toJson())

        val tmp = File(meta.dir, "$JSON.tmp")
        tmp.writeText(j.toString())
        val dest = File(meta.dir, JSON)
        if (!tmp.renameTo(dest)) {
            dest.writeText(j.toString())
            tmp.delete()
        }
    }

    fun delete(id: String) {
        File(root, id).deleteRecursively()
    }

    private fun r4(v: Float): Double = (v * 10000f).roundToInt() / 10000.0

    private fun JSONArray.f(i: Int): Float = getDouble(i).toFloat()

    companion object {
        const val JSON = "project.json"
        const val THUMB = "thumb.jpg"
        const val IMAGE = "source.img"
    }
}
