# Zeta Motion

App Android para animar SOLO el fondo de imágenes de anime y manga (agua, cielo, árboles, lluvia, nieve, estrellas…) y exportarlo en MP4 H.264 a la resolución de tu imagen, en loop, listo para Alight Motion.

## Compilar con GitHub Actions (sin PC)

1. Descomprime el ZIP.
2. Sube todo su contenido a la raíz de tu repositorio. En la raíz deben quedar: `.github`, `app`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties` y este README (no dentro de otra carpeta).
3. Al subirlo, Actions compila solo (o entra a Actions › "Compilar APK Zeta Motion" › Run workflow).
4. Si en Actions no aparece nada, falta `.github/workflows/build.yml` (las carpetas que empiezan con punto a veces no se suben desde el celular). Créalo con "Add file › Create new file", escribe `.github/workflows/build.yml` como nombre y pega el contenido de abajo.
5. Cuando termine (5–8 min la primera vez), abre la ejecución, baja a "Artifacts" y descarga `ZetaMotion-APK`. Dentro está el APK.
6. Si falla, copia el texto del error de Actions y pásamelo.

No hace falta `gradlew`: el workflow instala Gradle 8.9 por su cuenta.

La app se firma con `app/fondozeta.jks`, así cada APK nuevo se instala encima del anterior sin borrar tus proyectos. Esa firma es solo para uso personal; no la uses para publicar en Play Store.

### Contenido de `.github/workflows/build.yml`

```yaml
name: Compilar APK Zeta Motion

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Descargar código
        uses: actions/checkout@v4

      - name: Instalar Java 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Instalar Gradle 8.9
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'

      - name: Compilar APK
        run: gradle assembleRelease --stacktrace

      - name: Subir APK
        uses: actions/upload-artifact@v4
        with:
          name: ZetaMotion-APK
          path: app/build/outputs/apk/release/*.apk
```

## Cómo se usa

1. Importa una imagen con "Nuevo fondo animado", o compártela desde la Galería, Ibis Paint o Paint Zeta y elige Zeta Motion. La imagen se guarda tal cual, sin recomprimir.
2. Pestaña Editar:
   - Flechas: arrastra en la dirección en que debe moverse el agua, las nubes o el pelo. Más larga = más rápido.
   - Anclas: toca para fijar puntos que no se mueven.
   - Congelar (rojo): personajes, casas y líneas que nunca deben moverse.
   - Zona 1 (azul): agua o cielo (ondas, brillos, deriva de nubes, estrellas).
   - Zona 2 (verde): árboles, hierba o fuego (viento y calor).
   - Dos dedos: zoom y mover. ↶ deshace. ❚❚ pausa y deja revisar cuadro por cuadro.
3. Presets: un toque activa efectos típicos (río, mar, nubes, noche estrellada, lluvia, sakura, manga B/N…).
4. Efectos: ajusta cada efecto. Las velocidades son "ciclos por loop", por eso el final empalma perfecto con el inicio.
5. Exportar: MP4 o secuencia PNG. El vídeo va a Galería › Movies/FondoZeta y puedes enviarlo directo a Alight Motion.

## Ajustes recomendados para Alight Motion

- Vídeo MP4, 30 fps, calidad Máxima.
- Proyecto vertical 1080×1920 en Alight: resolución 1080p y encuadre 9:16.
- Loop de 4 a 8 segundos. En Alight puedes duplicar el clip, o usar "Repetir el loop" aquí.
- Lluvia, nieve o estrellas encima de otro clip: activa "Solo efectos sobre fondo negro" y en Alight usa fusión Pantalla o Añadir.
- Si tu teléfono no puede codificar el tamaño pedido (por ejemplo 4K vertical), la app lo ajusta sola y te avisa. Para más de 4K usa la secuencia PNG.

## Estructura del código

- `app/src/main/assets/shaders/fondo.frag`: todos los efectos en un solo shader (la vista previa y la exportación usan el mismo).
- `engine/`: OpenGL, campo de flujo de las flechas, máscaras y exportación con MediaCodec.
- `model/`: efectos, presets y guardado de proyectos.
- `ui/`: pantallas en Jetpack Compose.
