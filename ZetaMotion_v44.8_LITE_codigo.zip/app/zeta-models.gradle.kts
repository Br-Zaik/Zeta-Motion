// v45 · Modelos de profundidad IA para el 2.5D (funcionan SIN internet en el teléfono).
//
// Los pesos NO van dentro del ZIP del proyecto (pesan ~160 MB). Al compilar (GitHub Actions)
// se descargan de las publicaciones OFICIALES en GitHub, se comprueba su SHA-256 y se copian
// como assets del APK. Si la descarga falla, la compilación sigue: la app funciona igual con
// el 2.5D manual (Zona verde / Zona azul) y lo indica en Ajustes del efecto.
//
//  · Depth Anything V2 Small (Apache-2.0) — exportación ONNX de fabio-sim/Depth-Anything-ONNX
//    (repositorio Apache-2.0). Modelo principal.
//  · MiDaS v2.1 small 256 (MIT) — isl-org/MiDaS. Alternativa ligera si el principal falla.
//  · isnetis (SkyTNT anime-segmentation, Apache-2.0), exportado a ONNX por rembg — v46,
//    recorte del personaje en un toque.
//
// Variables opcionales: ZETA_SKIP_MODELS=1 (no descargar), ZETA_MODELS_DIR=<carpeta con los
// .onnx ya descargados> (por ejemplo para compilar sin red).

import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.security.MessageDigest

data class ZetaModel(val file: String, val url: String, val sha256: String, val bytes: Long)

val zetaModelList = listOf(
    ZetaModel(
        "depth_anything_v2_vits.onnx",
        "https://github.com/fabio-sim/Depth-Anything-ONNX/releases/download/v2.0.0/depth_anything_v2_vits_dynamic.onnx",
        "46c4e8eeda3a27f34701831b6a2ec7753d7b38779b215acb5633424703deed8f",
        99_092_268L
    ),
    ZetaModel(
        "midas_v21_small_256.onnx",
        "https://github.com/isl-org/MiDaS/releases/download/v2_1/model-small.onnx",
        "2d8c6cb8f415229daf1eb041024208e2608c9f98e17c81cc7c6ecb449c56fd58",
        66_764_249L
    ),
    // v46 · recorte de personaje anime (SkyTNT anime-segmentation, Apache-2.0); ONNX de rembg (MIT),
    // cuyo código lo verifica con md5 6f184e756bb3bd901c8849220a83e38e.
    ZetaModel(
        "isnetis_anime.onnx",
        "https://github.com/danielgatis/rembg/releases/download/v0.0.0/isnet-anime.onnx",
        "f15622d853e8260172812b657053460e20806f04b9e05147d49af7bed31a6e99",
        176_069_933L
    )
)

fun zetaSha256(f: File): String {
    val md = MessageDigest.getInstance("SHA-256")
    f.inputStream().use { input ->
        val buf = ByteArray(1 shl 16)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            md.update(buf, 0, n)
        }
    }
    return md.digest().joinToString("") { "%02x".format(it) }
}

fun zetaDownload(url: String, dest: File) {
    var current = url
    for (hop in 0 until 6) {
        val c = URI(current).toURL().openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.connectTimeout = 30_000
        c.readTimeout = 120_000
        c.setRequestProperty("User-Agent", "ZetaMotion-build")
        val code = c.responseCode
        if (code in 300..399) {
            current = c.getHeaderField("Location") ?: throw GradleException("Redirección sin destino: $current")
            c.disconnect()
            continue
        }
        if (code != 200) throw GradleException("HTTP $code al descargar $current")
        c.inputStream.use { input -> dest.outputStream().use { input.copyTo(it, 1 shl 16) } }
        return
    }
    throw GradleException("Demasiadas redirecciones: $url")
}

val zetaModelsOut = layout.buildDirectory.dir("generated/zetaModels/assets/models")

tasks.register("downloadZetaModels") {
    group = "zeta"
    description = "Descarga y verifica (SHA-256) los modelos de profundidad IA del 2.5D."
    doLast {
        val dir = zetaModelsOut.get().asFile
        dir.mkdirs()
        // v48: por defecto los modelos NO van en el APK (se descargan dentro de la app).
        // ZETA_BUNDLE_MODELS=1 los incluye (APK de ~430 MB que funciona sin internet).
        if (System.getenv("ZETA_BUNDLE_MODELS").isNullOrBlank()) {
            dir.listFiles()?.filter { it.name.endsWith(".onnx") || it.name.endsWith(".part") }?.forEach { it.delete() }
            logger.lifecycle("Modelos de IA: se descargan dentro de la app (APK ligero). ZETA_BUNDLE_MODELS=1 para incluirlos.")
            return@doLast
        }
        val local = System.getenv("ZETA_MODELS_DIR")?.takeIf { it.isNotBlank() }?.let { File(it) }
        for (m in zetaModelList) {
            val target = File(dir, m.file)
            if (target.isFile && target.length() == m.bytes && zetaSha256(target) == m.sha256) {
                logger.lifecycle("Modelo verificado (caché): ${m.file}")
                continue
            }
            target.delete()
            val fromLocal = local?.listFiles()?.firstOrNull { it.isFile && it.length() == m.bytes && zetaSha256(it) == m.sha256 }
            if (fromLocal != null) {
                fromLocal.copyTo(target, overwrite = true)
                logger.lifecycle("Modelo copiado de ZETA_MODELS_DIR: ${m.file}")
                continue
            }
            if (!System.getenv("ZETA_SKIP_MODELS").isNullOrBlank()) {
                logger.warn("ZETA_SKIP_MODELS: ${m.file} no se incluye (la app usará el 2.5D manual).")
                continue
            }
            val tmp = File(dir, m.file + ".part")
            try {
                zetaDownload(m.url, tmp)
                val got = zetaSha256(tmp)
                if (got != m.sha256) throw GradleException("SHA-256 distinto para ${m.file}: $got")
                if (!tmp.renameTo(target)) { tmp.copyTo(target, overwrite = true); tmp.delete() }
                logger.lifecycle("Modelo descargado y verificado: ${m.file} (${target.length()} bytes)")
            } catch (e: Exception) {
                tmp.delete()
                logger.warn("AVISO: no se pudo incluir ${m.file} (${e.message}). El APK funcionará con el 2.5D manual.")
            }
        }
    }
}
