package com.zeta.fondo.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeta.fondo.AppViewModel
import com.zeta.fondo.engine.DepthEstimator
import com.zeta.fondo.engine.DepthMath
import com.zeta.fondo.model.EffectDef

private val Leaf = Color(0xFF6BD68A)

/** Claves del 2.5D que se muestran en este bloque y no en la lista general de ajustes. */
val depthParamKeys = setOf("ai", "layers", "fix", "plate")

/**
 * v45 · Ajustes del 2.5D: profundidad IA (calcular una vez, cancelar, ver mapa, capas) y
 * pinceles de corrección Acercar (Zona verde) / Alejar (Zona azul). Sin modelo o si la IA
 * falla, queda el 2.5D manual con los mismos pinceles.
 */
@Composable
fun DepthControls(vm: AppViewModel, def: EffectDef) {
    LaunchedEffect(Unit) { vm.ensureDepth() }
    val aiOn = (vm.settings["parallax.ai"] ?: 1f) > .5f
    val state = vm.depthState
    Text("Profundidad IA", color = StudioText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    if (!vm.depthAvailable) {
        // v48: la IA de profundidad se descarga aquí mismo (una vez). Mientras, 2.5D manual.
        ModelDownloadCard(vm, com.zeta.fondo.engine.ModelStore.DEPTH)
        Note("Sin descargarla, el 2.5D funciona en modo manual: pinta el fondo (azul) y el primer plano (verde).")
    } else {
        SwitchRow("Usar profundidad IA", aiOn) { vm.setSetting("parallax.ai", if (it) 1f else 0f) }
        if (aiOn) when (state) {
            is AppViewModel.DepthState.Idle -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                SmallChoice("Calcular profundidad", false) { vm.computeDepth() }
            }
            is AppViewModel.DepthState.Running -> Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = StudioPink)
                Text(state.stage, color = StudioMuted, fontSize = 11.sp)
                SmallChoice("Cancelar", false) { vm.cancelDepth() }
            }
            is AppViewModel.DepthState.Ready -> {
                val secs = String.format(java.util.Locale.US, "%.1f", state.ms / 1000f)
                Text("Listo · ${DepthEstimator.labelOf(state.model)}" +
                        if (state.fromCache) " · guardado con el proyecto" else " · $secs s",
                    color = StudioMuted, fontSize = 11.sp)
                if (state.contrast < DepthMath.LOW_CONTRAST) {
                    Warn("El mapa casi no tiene profundidad (habitual en manga B/N, tramas o viñetas planas). " +
                        "Revisa «Ver mapa» y corrige con Acercar y Alejar antes de exportar.")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    SmallChoice("Ver mapa", vm.depthView) { vm.toggleDepthView() }
                    SmallChoice("Recalcular", false) { vm.computeDepth() }
                    SmallChoice("Borrar", false) { vm.discardDepth() }
                }
            }
            is AppViewModel.DepthState.Failed -> {
                Warn(state.reason)
                SmallChoice("Reintentar", false) { vm.computeDepth() }
            }
        }
    }
    val ai = vm.depthUsable
    Text(if (ai) "Corrección con pinceles" else "Zonas de profundidad", color = StudioMuted, fontSize = 11.sp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        SmallChoice(if (ai) "Alejar" else "Pintar fondo", vm.maskHasPaint(1), dot = Sky) { vm.paintBuiltinMask(1) }
        SmallChoice(if (ai) "Acercar" else "Pintar primer plano", vm.maskHasPaint(2), dot = Leaf) { vm.paintBuiltinMask(2) }
    }
    if (ai) {
        def.params.filter { it.key == "layers" || it.key == "fix" }.forEach { EffectParameter(vm, def, it) }
        Note("Capas: 1 = profundidad continua; 2-4 = planos separados. Proteger fija el plano de foco (el personaje no se deforma).")
        if (!vm.depthView && state is AppViewModel.DepthState.Ready)
            Note("Manga B/N: la IA puede leer tramas como relieve o dejar la cara «lejos». No es un 2.5D listo hasta revisarlo con «Ver mapa».")
    }
    CharacterAndBackground(vm)
}

/**
 * v46 · Personaje y fondo: recorte por IA (→ Proteger) y relleno de lo que hay detrás,
 * para que al moverse el fondo no arrastre el contorno del personaje.
 */
@Composable
private fun CharacterAndBackground(vm: AppViewModel) {
    LaunchedEffect(Unit) { vm.refreshMigan(); vm.ensurePlate() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importMigan(uri)
    }
    Text("Personaje y fondo", color = StudioText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 6.dp))
    val cut = vm.cutState
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        if (vm.segAvailable) {
            if (cut is AppViewModel.AiJob.Running) SmallChoice("Cancelar recorte", false) { vm.cancelCutout() }
            else SmallChoice("Recortar personaje (IA)", vm.maskHasPaint(0)) { vm.cutoutCharacter() }
        }
        SmallChoice("Pincel Proteger", false, dot = Color(0xFFFF6B6B)) { vm.protect() }
    }
    when (cut) {
        is AppViewModel.AiJob.Running -> { LinearProgressIndicator(Modifier.fillMaxWidth(), color = StudioPink); Note(cut.stage) }
        is AppViewModel.AiJob.Done -> { Note(cut.text); cut.warning?.let { Warn(it) } }
        is AppViewModel.AiJob.Failed -> Warn(cut.reason)
        else -> if (!vm.segAvailable) {
            ModelDownloadCard(vm, com.zeta.fondo.engine.ModelStore.CUTOUT, compact = true)
            Note("O pinta al personaje en Proteger con el pincel (no necesita descarga).")
        }
    }
    val plateOn = (vm.settings["parallax.plate"] ?: 1f) > .5f
    SwitchRow("Rellenar detrás del personaje", plateOn) { vm.setSetting("parallax.plate", if (it) 1f else 0f); if (it) vm.ensurePlate() }
    if (plateOn) {
        when (val pl = vm.plateState) {
            is AppViewModel.AiJob.Running -> { LinearProgressIndicator(Modifier.fillMaxWidth(), color = StudioPink); Note(pl.stage) }
            is AppViewModel.AiJob.Done -> {
                Note(pl.text)
                if (vm.plateStale) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Warn("Proteger cambió desde el último relleno.")
                }
                SmallChoice(if (vm.plateStale) "Actualizar relleno" else "Rehacer relleno", vm.plateStale) { vm.computePlate() }
            }
            is AppViewModel.AiJob.Failed -> { Warn(pl.reason); SmallChoice("Reintentar", false) { vm.computePlate() } }
            else -> if (vm.maskHasPaint(0)) SmallChoice("Rellenar fondo", false) { vm.computePlate() }
                else Note("Recorta o pinta al personaje en Proteger para rellenar lo que hay detrás.")
        }
        Text("Relleno con IA (MI-GAN, opcional)", color = StudioMuted, fontSize = 11.sp)
        if (vm.miganInstalled) {
            Note("MI-GAN instalado · SHA-256 ${vm.miganSha?.take(16) ?: "?"}…")
            SmallChoice("Quitar MI-GAN", false) { vm.removeMigan() }
        } else {
            Note("No viene en el APK: sus pesos solo se publican en Hugging Face y Google Drive. Si descargas tú «migan_pipeline_v2.onnx» " +
                "(github.com/Picsart-AI-Research/MI-GAN, licencia MIT), impórtalo aquí. Sin él se usa el relleno básico.")
            SmallChoice("Importar MI-GAN (.onnx)", false) { picker.launch(arrayOf("*/*")) }
        }
    }
}

@Composable
private fun Note(text: String) {
    Text(text, color = StudioMuted, fontSize = 11.sp, lineHeight = 14.sp)
}

@Composable
private fun Warn(text: String) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(StudioOrange.copy(alpha = .16f))
        .padding(horizontal = 10.dp, vertical = 8.dp)) {
        Text(text, color = StudioText, fontSize = 12.sp, lineHeight = 15.sp)
    }
}
