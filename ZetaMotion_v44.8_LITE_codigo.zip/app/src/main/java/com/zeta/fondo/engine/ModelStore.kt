package com.zeta.fondo.engine

import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URI
import java.security.MessageDigest

/**
 * v48 · Modelos de IA que se DESCARGAN dentro de la app (como Zeta Paint): el APK queda
 * ligero y cada modelo se baja solo cuando el usuario lo pide, desde la publicación OFICIAL
 * en GitHub, y se verifica con SHA-256 antes de usarlo. Sin Android: se prueba en la JVM.
 *
 * - Reanuda descargas cortadas (cabecera Range sobre el archivo .part).
 * - Si el hash no coincide, el archivo se borra y no se usa nunca.
 * - No envía ningún dato del usuario: solo pide el archivo público.
 */
object ModelStore {

    data class Spec(val id: String, val file: String, val label: String, val use: String,
                    val url: String, val sha256: String, val bytes: Long, val license: String)

    val DEPTH = Spec("depth_anything_v2_small", "depth_anything_v2_vits.onnx", "Profundidad 2.5D (Depth Anything V2 Small)",
        "Profundidad automática del 2.5D",
        "https://github.com/fabio-sim/Depth-Anything-ONNX/releases/download/v2.0.0/depth_anything_v2_vits_dynamic.onnx",
        "46c4e8eeda3a27f34701831b6a2ec7753d7b38779b215acb5633424703deed8f", 99_092_268L, "Apache-2.0")
    val MIDAS = Spec("midas_v21_small", "midas_v21_small_256.onnx", "Profundidad ligera (MiDaS v2.1 small)",
        "Alternativa más ligera y rápida para el 2.5D",
        "https://github.com/isl-org/MiDaS/releases/download/v2_1/model-small.onnx",
        "2d8c6cb8f415229daf1eb041024208e2608c9f98e17c81cc7c6ecb449c56fd58", 66_764_249L, "MIT")
    val CUTOUT = Spec("isnetis_anime", "isnetis_anime.onnx", "Recorte de personaje (isnetis)",
        "Proteger al personaje en un toque",
        "https://github.com/danielgatis/rembg/releases/download/v0.0.0/isnet-anime.onnx",
        "f15622d853e8260172812b657053460e20806f04b9e05147d49af7bed31a6e99", 176_069_933L, "Apache-2.0")

    val ALL = listOf(DEPTH, MIDAS, CUTOUT)

    fun byFile(file: String): Spec? = ALL.firstOrNull { it.file == file }

    /** Carpeta de modelos descargados (la fija la app: filesDir/models_dl). */
    @Volatile var dir: File? = null

    fun target(spec: Spec): File? = dir?.let { File(it, spec.file) }

    /** ¿Está descargado y completo? (tamaño exacto; el hash se comprobó al terminar la descarga). */
    fun installed(spec: Spec): Boolean = target(spec)?.let { it.isFile && it.length() == spec.bytes } == true

    fun partialBytes(spec: Spec): Long = dir?.let { File(it, spec.file + ".part").takeIf { f -> f.isFile }?.length() } ?: 0L

    fun remove(spec: Spec) {
        target(spec)?.delete()
        dir?.let { File(it, spec.file + ".part").delete() }
    }

    fun installedBytes(): Long = ALL.filter { installed(it) }.sumOf { it.bytes }

    fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { i -> val b = ByteArray(1 shl 16); while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    class Cancelled : Exception("Descarga cancelada")

    /**
     * Descarga [spec] a [dir]. [progress] recibe (bytes, total). [cancelled] se consulta a menudo:
     * si devuelve true, se para y el .part queda para reanudar después. Lanza excepción si falla.
     */
    fun download(spec: Spec, progress: (Long, Long) -> Unit = { _, _ -> }, cancelled: () -> Boolean = { false }) {
        val d = dir ?: throw IllegalStateException("Carpeta de modelos sin configurar")
        d.mkdirs()
        val part = File(d, spec.file + ".part")
        if (part.length() > spec.bytes) part.delete()
        var url = spec.url
        var conn: HttpURLConnection? = null
        for (hop in 0 until 8) {
            val c = URI(url).toURL().openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20_000
            c.readTimeout = 60_000
            c.setRequestProperty("User-Agent", "ZetaMotion")
            val have = part.length()
            if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
            val code = c.responseCode
            if (code in 300..399) {
                url = c.getHeaderField("Location") ?: throw IllegalStateException("Redirección sin destino")
                if (!url.startsWith("https://")) throw IllegalStateException("Redirección no segura")
                c.disconnect(); continue
            }
            if (code == 416) { c.disconnect(); break } // ya estaba completo
            if (code != 200 && code != 206) throw IllegalStateException("El servidor respondió $code")
            if (code == 200 && have > 0) part.delete() // no admite reanudar: empezar de cero
            conn = c
            break
        }
        conn?.let { c ->
            RandomAccessFile(part, "rw").use { raf ->
                raf.seek(part.length())
                var done = part.length()
                c.inputStream.use { input ->
                    val buf = ByteArray(1 shl 16)
                    var last = 0L
                    while (true) {
                        if (cancelled()) { c.disconnect(); throw Cancelled() }
                        val n = input.read(buf)
                        if (n < 0) break
                        raf.write(buf, 0, n)
                        done += n
                        if (done - last > 256 * 1024) { progress(done, spec.bytes); last = done }
                        if (done > spec.bytes) throw IllegalStateException("El archivo es más grande de lo esperado")
                    }
                }
                progress(done, spec.bytes)
            }
            c.disconnect()
        }
        if (part.length() != spec.bytes) throw IllegalStateException("Descarga incompleta (${part.length()} de ${spec.bytes} bytes). Vuelve a intentarlo: continuará donde se quedó.")
        val got = sha256(part)
        if (got != spec.sha256) { part.delete(); throw IllegalStateException("El archivo descargado no es el oficial (SHA-256 distinto). Se borró.") }
        val f = File(d, spec.file)
        f.delete()
        if (!part.renameTo(f)) throw IllegalStateException("No se pudo guardar el modelo")
    }
}
