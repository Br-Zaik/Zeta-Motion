package com.zeta.fondo.engine

import android.content.Context
import java.io.File

/**
 * v46 · Archivos de modelos ONNX: los que trae el APK (assets/models, descargados y
 * verificados al compilar) y los que el usuario importa a mano (p. ej. MI-GAN).
 * ONNX Runtime necesita una ruta de archivo, así que cada asset se copia UNA vez al
 * almacenamiento interno (no se respalda en la nube). [clearCopies] libera ese espacio.
 */
object OnnxAssets {

    fun bundled(ctx: Context): Set<String> =
        try { ctx.assets.list("models")?.toSet() ?: emptySet() } catch (_: Exception) { emptySet() }

    private fun copiesDir(ctx: Context) = File(ctx.noBackupFilesDir, "models")
    fun userDir(ctx: Context) = File(ctx.filesDir, "models_user").apply { mkdirs() }

    /** v48: ¿existe el modelo? (descargado dentro de la app, importado o incluido en el APK). */
    fun has(ctx: Context, asset: String): Boolean =
        ModelStore.byFile(asset)?.let { ModelStore.installed(it) } == true ||
            File(userDir(ctx), asset).isFile || asset in bundled(ctx)

    /** Ruta del modelo listo para ONNX Runtime (descargado, importado o copiado del APK). */
    fun file(ctx: Context, asset: String): File {
        ModelStore.byFile(asset)?.let { s -> if (ModelStore.installed(s)) return ModelStore.target(s)!! }
        val user = File(userDir(ctx), asset)
        if (user.isFile) return user
        val dir = copiesDir(ctx).apply { mkdirs() }
        val f = File(dir, asset)
        val expected = try { ctx.assets.openFd("models/$asset").use { it.length } } catch (_: Exception) { -1L }
        if (f.isFile && (expected < 0 || f.length() == expected)) return f
        val tmp = File(dir, "$asset.part")
        ctx.assets.open("models/$asset").use { input -> tmp.outputStream().use { input.copyTo(it, 1 shl 16) } }
        if (!tmp.renameTo(f)) throw IllegalStateException("No se pudo preparar $asset")
        return f
    }

    /** Bytes que ocupan las copias internas de los modelos del APK. */
    fun copiesBytes(ctx: Context): Long = copiesDir(ctx).listFiles()?.sumOf { it.length() } ?: 0L

    /** Borra las copias (se vuelven a crear la próxima vez que se use la IA). */
    fun clearCopies(ctx: Context) { copiesDir(ctx).listFiles()?.forEach { it.delete() } }
}
