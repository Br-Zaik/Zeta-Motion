package com.zeta.fondo

import android.app.Application
import android.app.ActivityManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zeta.fondo.engine.BitmapUtil
import com.zeta.fondo.engine.ExportCancelled
import com.zeta.fondo.engine.ExportRequest
import com.zeta.fondo.engine.ExportPlanner
import com.zeta.fondo.engine.ExportResult
import com.zeta.fondo.engine.Exporter
import com.zeta.fondo.engine.FlowField
import com.zeta.fondo.engine.MaskLayers
import com.zeta.fondo.engine.RenderHub
import com.zeta.fondo.engine.RenderParams
import com.zeta.fondo.export.ExportRunner
import com.zeta.fondo.export.ExportService
import com.zeta.fondo.model.Arrow
import com.zeta.fondo.model.EditorTab
import com.zeta.fondo.model.PreviewSize
import com.zeta.fondo.model.ClipEdits
import com.zeta.fondo.model.EffectClip
import com.zeta.fondo.model.EventMode
import com.zeta.fondo.model.EffectTimeline
import com.zeta.fondo.model.Effects
import com.zeta.fondo.model.ExportSettings
import com.zeta.fondo.model.MaskStroke
import com.zeta.fondo.model.PointN
import com.zeta.fondo.model.Preset
import com.zeta.fondo.model.ProjectMeta
import com.zeta.fondo.model.ProjectStore
import com.zeta.fondo.model.ProjectSummary
import com.zeta.fondo.model.Tool
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.hypot

enum class Screen { HOME, EDITOR }

sealed class ExportState {
    object Idle : ExportState()
    data class Running(val progress: Float) : ExportState()
    data class Done(val result: ExportResult) : ExportState()
    data class Failed(val message: String) : ExportState()
}

private sealed class UndoAction {
    class EffectSwitches(
        val before: Map<String, Float>,
        val after: Map<String, Float>,
        val beforeClips: List<EffectClip>? = null,
        val afterClips: List<EffectClip>? = null,
        /** v40.1: claves que NO existían antes / después (deshacer las quita, no las pone a 0). */
        val absentBefore: Set<String> = emptySet(),
        val absentAfter: Set<String> = emptySet()
    ) : UndoAction()
    class AddArrow(val arrow: Arrow) : UndoAction()
    class AddAnchor(val point: PointN) : UndoAction()
    class AddStroke(val stroke: MaskStroke) : UndoAction()
    class RemoveArrow(val index: Int, val arrow: Arrow) : UndoAction()
    class RemoveAnchor(val index: Int, val point: PointN) : UndoAction()
    class ClearGuides(val arrows: List<Arrow>, val anchors: List<PointN>) : UndoAction()
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val main = Handler(Looper.getMainLooper())
    private val prefs = app.getSharedPreferences("zeta_prefs", Context.MODE_PRIVATE)
    private val store = ProjectStore(app)
    private val saveMutex = Mutex()
    private var autoSaveJob: Job? = null

    /** Guarda después de una pausa de edición; no escribe JSON por cada píxel del pincel. */
    private fun scheduleAutosave() {
        if (meta == null) return
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(900L)
            saveProject(forceCurrent = true)
        }
    }
    val hub = RenderHub()
    val vertSrc: String = app.assets.open("shaders/fondo.vert").bufferedReader().use { it.readText() }
    val fragSrc: String = app.assets.open("shaders/fondo.frag").bufferedReader().use { it.readText() }
    /** v38: shader ligero (imagen + máscara) para el primer cuadro, el zoom y el pincel. */
    val liteSrc: String? = try { app.assets.open("shaders/lite.frag").bufferedReader().use { it.readText() } } catch (_: Exception) { null }
    /** v39: el shader completo compilado se guarda aquí (se borra solo al actualizar la app). */
    val shaderCacheDir: java.io.File = java.io.File(app.codeCacheDir, "shaders")
    /** false mientras el shader completo de efectos se compila tras abrir el editor. */
    var effectsReady by mutableStateOf(false)
        private set

    // ---------------- Navegación y avisos
    var screen by mutableStateOf(Screen.HOME)
    var projects by mutableStateOf<List<ProjectSummary>>(emptyList())
    var busy by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)
    var glError by mutableStateOf<String?>(null)
    /** Thumbnail visible de inmediato mientras OpenGL compila/sube texturas. */
    var previewFallback by mutableStateOf<Bitmap?>(null)
        private set
    var previewReady by mutableStateOf(false)
        private set
    /** Comparación temporal de la imagen de entrada, sin cambiar ningún efecto del proyecto. */
    var showOriginal by mutableStateOf(false)
        private set
    fun updateOriginalPreview(show: Boolean) {
        showOriginal = show
        hub.showOriginal = show
    }

    // ---------------- Proyecto abierto
    var meta by mutableStateOf<ProjectMeta?>(null)
        private set
    val arrows = mutableStateListOf<Arrow>()
    val anchors = mutableStateListOf<PointN>()
    var masks: MaskLayers? = null
        private set
    var maskNames by mutableStateOf<List<String>>(listOf("Congelar", "Zona azul", "Zona verde"))
        private set
    var selectedMaskLayer by mutableStateOf(0)
        private set
    var settings by mutableStateOf(Effects.defaults())
        private set
    var exportSettings by mutableStateOf(ExportSettings())
        private set
    var effectClips by mutableStateOf<List<EffectClip>>(emptyList())
        private set
    var selectedTimelineClip by mutableStateOf<Long?>(null)
        private set

    // ---------------- Herramientas
    var tool by mutableStateOf(Tool.PAN)
    var eraser by mutableStateOf(false)
    var brushDp by mutableFloatStateOf(36f)
    var feather by mutableFloatStateOf(0.35f)
    var showGuides by mutableStateOf(false)
    var showMasks by mutableStateOf(true)
        private set
    var playing by mutableStateOf(false)
        private set
    var scrubT by mutableFloatStateOf(0f)
        private set
    var tab by mutableStateOf(EditorTab.TOOLS)
        private set
    var settingsSection by mutableStateOf(0)
    var fullscreen by mutableStateOf(false)
    var activeMotionEffect by mutableStateOf<String?>(null)
    var effectsCategory by mutableStateOf("Populares")
    /** v38: sección del editor de un efecto (Ajustes, Estilo, Color, Tiempo, Zona). */
    var effectSection by mutableStateOf("Ajustes")
    /** v38: panel auxiliar de Animar ("loop" = Bucle). */
    var animPanel by mutableStateOf("")

    var editingEffect by mutableStateOf<String?>(null)
        private set
    var paintingZone by mutableStateOf(false)
        private set
    var selectedElement by mutableStateOf(-1)
        private set
    var brushCursor by mutableStateOf<PointN?>(null)
    private data class EditSnapshot(val settings: Map<String, Float>, val strokes: List<MaskStroke>,
        val names: List<String>, val arrows: List<Arrow>, val anchors: List<PointN>, val undo: List<UndoAction>,
        val redo: List<UndoAction>, val effectClips: List<EffectClip>)
    private var editSnapshot: EditSnapshot? = null
    private fun beginEdit() {
        if (editSnapshot != null) return
        endStroke()
        val mk = masks ?: return
        editSnapshot = EditSnapshot(settings.toMap(), synchronized(mk.lock) { mk.strokes.flatten().toList() },
            mk.names.toList(), arrows.toList(), anchors.toList(), undoStack.toList(), redoStack.toList(), effectClips.toList())
    }
    /** Herramientas de movimiento conservan su propio panel; nunca saltan a Efectos. */
    fun editEffect(id: String, autoPaint: Boolean = true) {
        finishEdit(true); beginEdit(); editingEffect = id
        effectSection = "Ajustes"; animPanel = ""
        requestOptions()
        tab = if (id in setOf("natural", "parallax", "mesh", "cam", "zonemotion"))
            EditorTab.TOOLS else EditorTab.EFFECTS
        val currentMask = settings["$id.mask"]?.toInt()
        val firstLocalEffect = id in zoneEffects && !settings.containsKey("$id.ownedMask") &&
            (!settings.containsKey("$id.mask") || (id == "shore" && currentMask == -2))
        if (id != "elements") {
            if (id != "style") ensureTimelineActivation(id)
            if (!settings.containsKey("$id.mask")) {
                val legacy = when {
                    id in setOf("sway", "heat", "flame", "cloth") -> 2
                    id in setOf("drift", "ripple", "glint", "eyes", "blink") -> 1
                    (settings["$id.zone"] ?: 0f) > .5f -> 1
                    else -> -2
                }
                val used = masks?.strokes?.getOrNull(legacy)?.isNotEmpty() == true
                settings = settings + ("$id.mask" to (if (used) legacy.toFloat() else -2f))
                pushParams()
            }
        }
        // v44: desde el catálogo de Animar se prueba primero (zona = toda la imagen); la zona se
        // pinta luego en Ajustar › Zona. Ya no se abre el pincel antes de ver qué hace.
        if (firstLocalEffect && autoPaint) paintEffectZone()
    }
    /**
     * v42 · Animación de cámara de un toque: Acercar, Alejar, Latido, Flotar, Balanceo,
     * Temblar… Abre la vista previa con ✓ / ✕ y valores pensados para cada movimiento;
     * en Ajustar se cambia la fuerza, la velocidad y el resto de estilos.
     */
    fun applyCameraPreset(mode: Int) {
        if (editingEffect != "cam") editEffect("cam")
        val (zoom, pan) = when (mode) {
            0, 1 -> .08f to 0f
            4 -> .05f to .6f
            6 -> .07f to 0f
            7 -> .05f to .6f
            8 -> .08f to 0f
            else -> .06f to .5f
        }
        setSetting("cam.mode", mode.toFloat())
        setSetting("cam.zoom", zoom)
        setSetting("cam.pan", pan)
        effectSection = "Ajustes"
        if (mode == 9) showHint("Cámara libre: pon el cabezal, ajusta zoom/posición/giro y toca ◆. Repite en otro momento.", 4200L)
    }

    fun finishEdit(commit: Boolean) {
        endStroke()
        val saved = editSnapshot
        if (!commit && saved != null) {
            settings = saved.settings
            arrows.clear(); arrows.addAll(saved.arrows)
            anchors.clear(); anchors.addAll(saved.anchors); recomputeFlow()
            masks?.setAll(saved.strokes, saved.names)
            maskNames = masks?.names?.toList() ?: saved.names
            undoStack.clear(); undoStack.addAll(saved.undo)
            redoStack.clear(); redoStack.addAll(saved.redo)
            effectClips = saved.effectClips
            selectedTimelineClip = null
            canUndo = undoStack.isNotEmpty(); canRedo = redoStack.isNotEmpty(); pushParams()
            refreshEffectBoxes()
        }
        if (commit && saved != null && (saved.settings !== settings || saved.effectClips != effectClips)) {
            // v40.1: ✓ Aplicar se puede deshacer de una vez (todos los ajustes de la edición).
            // Los cambios de ajustes intermedios se sustituyen por esta única entrada; los
            // trazos del pincel y las guías conservan sus propias entradas.
            if (undoStack.size >= saved.undo.size) {
                val added = ArrayList(undoStack.subList(saved.undo.size, undoStack.size))
                while (undoStack.size > saved.undo.size) undoStack.removeAt(undoStack.size - 1)
                undoStack.addAll(added.filter { it !is UndoAction.EffectSwitches })
            }
            val entry = settingsUndo(saved.settings, saved.effectClips)
            if (entry.before.isNotEmpty() || entry.after.isNotEmpty() || saved.effectClips != effectClips) pushUndo(entry)
            else { canUndo = undoStack.isNotEmpty() }
        }
        // v40: al aplicar (✓) un efecto se vuelve a la línea de tiempo con su bloque
        // seleccionado; al descartar (✕) se sigue en el catálogo.
        if (commit && editingEffect != null && editingEffect != "elements") optionsOpen = false
        editSnapshot = null; editingEffect = null; paintingZone = false; selectedElement = -1; brushCursor = null
        adjustOpen = false; editFromCatalog = false
        tool = Tool.PAN; showGuides = false; hub.showMask = false
        if (saved != null) {
            // Al cancelar, la restauración también debe persistirse por si ya
            // hubo un autoguardado mientras se editaba.
            autoSaveJob?.cancel()
            saveProject(forceCurrent = true)
        }
    }
    fun paintEffectZone() {
        val id = editingEffect ?: return
        val mk = masks ?: return
        var layer = (settings["$id.ownedMask"] ?: -1f).toInt()
        if (layer !in 3 until mk.count) {
            layer = mk.addLayer(Effects.all.firstOrNull { it.id == id }?.title ?: id)
            if (layer < 0) { message = "Límite de nueve zonas independientes por proyecto."; return }
            setSetting("$id.ownedMask", layer.toFloat())
            // Migrate an existing zone without altering the zones used by other effects.
            val previous = (settings["$id.mask"] ?: -1f).toInt()
            if (previous in 0 until layer) {
                val copy = mk.snapshot().filter { it.layer == previous }.map { old ->
                    MaskStroke(layer, old.radius, old.feather, old.erase, old.fill, old.image).also { it.points.addAll(old.points) }
                }
                copy.forEach { mk.addStroke(it) }
            }
        }
        maskNames = mk.names.toList(); setEffectMask(id, layer)
        requestOptions()
        if (playing) togglePlay()
        selectMask(layer); eraser = false; paintingZone = true; showGuides = true
    }
    fun wholeEffectZone() { editingEffect?.let { setEffectMask(it, -2) } }
    fun finishPainting() { endStroke(); paintingZone = false; brushCursor = null; tool = Tool.PAN; showGuides = false; hub.showMask = false }
    /** Animar › Congelar: pinta lo que no se mueve sin salir de Animar. */
    fun freezeZone() {
        finishEdit(true); beginEdit(); animPanel = ""
        if (playing) togglePlay()
        selectMask(0); eraser = false; showGuides = true; paintingZone = true
    }

    /** Animar: elige Ruta / Ancla / Borrar. Tocar otra vez la misma herramienta la suelta. */
    fun selectGuideTool(t: Tool) {
        val same = tool == t && editingEffect == null && !paintingZone
        finishEdit(true); animPanel = ""
        if (playing) togglePlay()
        tool = if (same) Tool.PAN else t
        showGuides = true
        hub.showMask = false
    }

    // v40: el lienzo tiene un tamaño FIJO. Solo cambia si el usuario elige otro tamaño
    // de vista previa (Ajustes › Vista) o con el botón de pantalla completa.
    var previewSize by mutableStateOf(PreviewSize.of(prefs.getString("previewSize", null)))
        private set
    fun changePreviewSize(size: PreviewSize) {
        if (size == previewSize) return
        previewSize = size
        prefs.edit().putString("previewSize", size.name).apply()
    }
    /**
     * v40: hoja de opciones de la herramienta (en la zona de trabajo inferior, nunca
     * encima del lienzo). Cerrada = se ve la línea de tiempo.
     */
    var optionsOpen by mutableStateOf(false)
        private set
    fun requestOptions() { optionsOpen = true }
    fun closeOptions() {
        optionsOpen = false
        if (animPanel.isNotEmpty()) animPanel = ""
        replacingClip = null
    }

    // ============================================================ v41: navegación como un editor de vídeo
    /** false = barra principal (Animar, Proteger, Efectos, Audio, Ajustes); true = herramientas de la categoría. */
    var categoryOpen by mutableStateOf(false)
        private set
    /** Pista de la imagen seleccionada en la línea de tiempo (acciones: duración, formato, color…). */
    var imageSelected by mutableStateOf(false)
        private set
    /** En el catálogo: true = panel Ajustar del efecto que se está previsualizando. */
    var adjustOpen by mutableStateOf(false)
    /** La edición actual empezó tocando una miniatura del catálogo. */
    var editFromCatalog by mutableStateOf(false)
        private set
    /** Escala de la línea de tiempo en dp por segundo (<= 0: automática). */
    var timelinePps by mutableFloatStateOf(-1f)

    fun openCategory(t: EditorTab) {
        selectTab(t)
        imageSelected = false
        when (t) {
            EditorTab.EFFECTS -> { categoryOpen = false; optionsOpen = true }
            // v44: Animar abre su catálogo visual (como Efectos); ✕ deja la barra de herramientas.
            EditorTab.TOOLS -> { categoryOpen = true; optionsOpen = false; openAnimCatalog() }
            EditorTab.MASKS -> { categoryOpen = true; optionsOpen = false; protect() }
            else -> { categoryOpen = true; optionsOpen = false }
        }
    }

    /** Música y sonidos de ambiente (hoja propia). */
    fun openAudio() {
        selectTab(EditorTab.CANVAS)
        imageSelected = false
        categoryOpen = false
        settingsSection = 3
        optionsOpen = true
    }

    /** Ajustes del proyecto desde la pista de la imagen: 0 duración, 1 formato, 2 color. */
    fun openImageSetting(section: Int) {
        selectTab(EditorTab.CANVAS)
        categoryOpen = false
        settingsSection = section
        optionsOpen = true
    }

    /** Flecha «<»: vuelve a la barra principal dejando todo aplicado. */
    fun backToMain() {
        finishCropEdit()
        finishEdit(true)
        animCatalogOpen = false; animKey = null
        placingClip = false; replacingClip = null; adjustOpen = false; editFromCatalog = false
        selectedTimelineClip = null; imageSelected = false
        optionsOpen = false; animPanel = ""
        tool = Tool.PAN; showGuides = false; hub.showMask = false
        categoryOpen = false
    }

    fun selectImageTrack(selected: Boolean = true) {
        if (selected) {
            finishEdit(true)
            selectedTimelineClip = null
            placingClip = false
            optionsOpen = false
        }
        imageSelected = selected
    }

    /** Toque en una miniatura del catálogo: vista previa real; tocarla otra vez abre Ajustar. */
    fun previewFromCatalog(id: String) {
        if (editingEffect == id && editFromCatalog) { adjustOpen = true; return }
        if (editingEffect != null && editFromCatalog) finishEdit(false)
        editEffect(id)
        editFromCatalog = true
        adjustOpen = false
        tab = EditorTab.EFFECTS
        optionsOpen = true
    }

    /** «Ninguno»: descarta el efecto que se estaba probando. */
    fun cancelCatalogPreview() {
        if (editingEffect != null && editFromCatalog) finishEdit(false)
        adjustOpen = false
    }

    // ------------------------------------------------------------ v44: catálogo de Animar

    var animCatalogOpen by mutableStateOf(false)
    var animCategory by mutableStateOf(prefs.getString("animCategory", null) ?: com.zeta.fondo.model.AnimCatalog.categories.first())
    /** Entrada del catálogo que se está probando (null = ninguna). */
    var animKey by mutableStateOf<String?>(null)

    fun openAnimCatalog() {
        if (editingEffect != null) finishEdit(true)
        animCatalogOpen = true
        adjustOpen = false
        animKey = null
    }

    fun selectAnimCategory(c: String) {
        animCategory = c
        prefs.edit().putString("animCategory", c).apply()
    }

    /** Tocar una miniatura: se prueba sobre la imagen sin confirmar; tocarla otra vez = Ajustar. */
    fun previewAnim(e: com.zeta.fondo.model.AnimCatalog.Entry) {
        if (e.kind == com.zeta.fondo.model.AnimCatalog.Kind.TOOL) {
            discardAnim()
            when (e.tool) {
                "ARROW" -> { selectGuideTool(Tool.ARROW); showHint("Dibuja flechas sobre la imagen: el dibujo fluye en esa dirección") }
                "ANCHOR" -> { selectGuideTool(Tool.ANCHOR); showHint("Toca para fijar puntos que no se mueven") }
                else -> freezeZone()
            }
            return
        }
        val id = e.effectId
        if (animKey == e.key && editingEffect == id && editFromCatalog) { adjustOpen = true; return }
        if (editingEffect != null && editFromCatalog && editingEffect != id) finishEdit(false)
        if (editingEffect != id) editEffect(id, autoPaint = false)
        when {
            id == "cam" -> applyCameraPreset(e.variant)
            id == "natural" -> applyNaturalPreset(e.variant)
            id in com.zeta.fondo.model.EffectCatalog.styledPresets -> applyEffectStyle(id, e.variant)
            com.zeta.fondo.model.EffectCatalog.variants(id).isNotEmpty() -> setSetting("$id.variant", e.variant.toFloat())
        }
        animKey = e.key
        editFromCatalog = true
        adjustOpen = false
        tab = EditorTab.TOOLS
        animCatalogOpen = true
        if (!playing) togglePlay()
        if (e.needsZone && (settings["$id.mask"] ?: -2f).toInt() == -2)
            showHint("Se prueba en toda la imagen. En Ajustar › Zona pintas qué parte se mueve.", 3200L)
    }

    /** ✕ del catálogo de Animar: descarta la prueba sin tocar el proyecto. */
    fun discardAnim() {
        if (editingEffect != null && editFromCatalog) finishEdit(false)
        adjustOpen = false; editFromCatalog = false
        animKey = null
        animCatalogOpen = false
    }

    /** ✓ de una hoja: aplica lo que se estaba editando y vuelve a la línea de tiempo. */
    fun applyAndClose() {
        animCatalogOpen = false; animKey = null
        if (soundEditing != null) { soundEditing = null }
        if (editingEffect != null) finishEdit(true)
        adjustOpen = false; editFromCatalog = false
        optionsOpen = false; replacingClip = null; animPanel = ""
        finishCropEdit()
    }

    /** Restablecer: valores de fábrica del efecto (o del bloque seleccionado). */
    fun resetEffectParams(id: String) {
        val def = Effects.all.firstOrNull { it.id == id } ?: return
        val target = fxTarget(id)
        if (target != null) {
            effectClips = effectClips.map { if (it.uid == target.uid) it.copy(overrides = emptyMap()) else it }
        } else {
            val keys = def.params.map { "$id.${it.key}" }.filter { !it.endsWith(".zone") }
            settings = settings + keys.associateWith { Effects.default(it) } + ("$id.tintOn" to 0f)
        }
        hub.boostPreview()
        pushParams()
        scheduleAutosave()
    }

    /** Duración del vídeo desde el tirador de la pista de la imagen. */
    fun setVideoDuration(sec: Int) {
        val s = sec.coerceIn(2, 60)
        if (s == exportSettings.loopSec) return
        updateExport(exportSettings.copy(loopSec = s))
        saveProject()
    }

    /** Pistas de la línea de tiempo visibles también mientras hay opciones abiertas. */
    var lanesWithOptions by mutableStateOf(prefs.getBoolean("lanesWithOptions", false))
        private set
    fun toggleLanesWithOptions() {
        lanesWithOptions = !lanesWithOptions
        prefs.edit().putBoolean("lanesWithOptions", lanesWithOptions).apply()
    }
    /** Ayuda (?) de la categoría abierta; null = cerrada. */
    var helpTab by mutableStateOf<EditorTab?>(null)

    // v39: indicación corta y temporal sobre el lienzo (sustituye los textos fijos).
    var hint by mutableStateOf<String?>(null)
        private set
    private var hintJob: Job? = null
    fun showHint(text: String, ms: Long = 2600L) {
        hint = text
        hintJob?.cancel()
        hintJob = viewModelScope.launch { delay(ms); if (hint == text) hint = null }
    }

    // v39: transparencia de la máscara al pintar (que no tape la imagen). Se recuerda.
    var maskOpacity by mutableFloatStateOf(prefs.getFloat("maskOpacity", .45f))
        private set
    fun changeMaskOpacity(v: Float, persist: Boolean) {
        maskOpacity = v.coerceIn(.1f, .9f)
        hub.maskAlpha = maskOpacity
        if (persist) prefs.edit().putFloat("maskOpacity", maskOpacity).apply()
    }

    // v39: tiempos REALES de apertura medidos en el teléfono (se muestran en Ajustes).
    private var openStartNs = 0L
    private var firstZoomPending = false
    var perfImageMs by mutableStateOf(-1L); private set
    var perfZoomMs by mutableStateOf(-1L); private set
    var perfEffectsMs by mutableStateOf(-1L); private set
    private fun perfStart() {
        openStartNs = System.nanoTime(); firstZoomPending = true
        perfImageMs = -1L; perfZoomMs = -1L; perfEffectsMs = -1L
    }
    private fun perfLog(what: String, ms: Long) { android.util.Log.i("ZetaPerf", "$what: $ms ms") }
    private fun perfElapsed(): Long = if (openStartNs == 0L) -1L else (System.nanoTime() - openStartNs) / 1_000_000L

    fun protect() {
        finishEdit(true); beginEdit(); tab = EditorTab.MASKS
        if (playing) togglePlay()
        selectMask(0); eraser = false; showGuides = true; paintingZone = true
    }
    fun addElement(type: Int) {
        val slot = (0..3).firstOrNull { (settings["element$it.on"] ?: 0f) < .5f }
        if (slot == null) { message = "Hasta cuatro elementos simultáneos."; return }
        settings = settings + mapOf("element$slot.on" to 1f, "element$slot.type" to type.toFloat(),
            "element$slot.x" to .5f, "element$slot.y" to .5f, "element$slot.size" to .3f,
            "element$slot.rotation" to 0f, "element$slot.opacity" to .7f, "element$slot.cycles" to 1f)
        selectedElement = slot; pushParams()
    }
    fun selectElement(slot: Int) { selectedElement = slot }
    fun transformElement(dx: Float, dy: Float, zoom: Float, rotation: Float) {
        val id = "element$selectedElement"
        if (selectedElement < 0) return
        settings = settings + mapOf("$id.x" to ((settings["$id.x"] ?: .5f) + dx).coerceIn(0f,1f),
            "$id.y" to ((settings["$id.y"] ?: .5f) + dy).coerceIn(0f,1f),
            "$id.size" to ((settings["$id.size"] ?: .3f) * zoom).coerceIn(.04f, 1.5f),
            "$id.rotation" to ((((settings["$id.rotation"] ?: 0f) + rotation + 540f) % 360f) - 180f))
        pushParams()
    }

    // ---------------- Vista (zoom del editor)
    var viewScale by mutableFloatStateOf(1f)
        private set
    var viewX by mutableFloatStateOf(0f)
        private set
    var viewY by mutableFloatStateOf(0f)
        private set
    var cropW by mutableFloatStateOf(1f)
        private set
    var cropH by mutableFloatStateOf(1f)
        private set
    private var cropX = 0f
    private var cropY = 0f
    val previewAspect: Float get() = aspect * cropW / cropH

    // ---------------- Deshacer
    private val undoStack = ArrayList<UndoAction>()
    private val redoStack = ArrayList<UndoAction>()
    var canUndo by mutableStateOf(false)
    var canRedo by mutableStateOf(false)
        private set
    private var currentStroke: MaskStroke? = null
    private var flowJob: Job? = null

    // ---------------- Exportación
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
        private set
    private var lastProgressPost = -1f

    val aspect: Float
        get() = meta?.let { it.w.toFloat() / it.h } ?: 1f

    init {
        // v48: carpeta de los modelos de IA descargados dentro de la app.
        com.zeta.fondo.engine.ModelStore.dir = java.io.File(app.filesDir, "models_dl")
        hub.onError = { msg ->
            com.zeta.fondo.diag.ZetaLog.error("GL", msg)
            main.post { glError = msg }
        }
        hub.onGlWarning = { msg -> com.zeta.fondo.diag.ZetaLog.warn("GL", msg) }
        hub.onFramePending = { main.post { previewReady = false; effectsReady = false } }
        // Mantener la referencia del mismo bitmap que ya usa OpenGL (sin duplicar RAM).
        // Tras recrearse la superficie, se vuelve a mostrar como respaldo sin negro.
        hub.onFrameReady = { main.post {
            previewReady = true
            if (perfImageMs < 0 && meta != null) { perfImageMs = perfElapsed(); perfLog("imagen visible", perfImageMs) }
        } }
        hub.onCompiling = { busy -> main.post { effectsReady = !busy } }
        hub.onFullReady = { main.post {
            effectsReady = true
            if (perfEffectsMs < 0 && meta != null) { perfEffectsMs = perfElapsed(); perfLog("efectos listos", perfEffectsMs) }
        } }
        hub.maskAlpha = maskOpacity
        refreshProjects()
    }

    // ============================================================ Proyectos

    fun refreshProjects() {
        viewModelScope.launch {
            projects = withContext(Dispatchers.IO) { store.list() }
        }
    }

    fun importImage(uri: Uri, initialTab: EditorTab = EditorTab.TOOLS, initialCategory: String = "Populares", loopSec: Int = 6) {
        if (busy != null) return
        saveProject()
        busy = "Abriendo imagen…"
        perfStart()
        viewModelScope.launch {
            try {
                // v39: una sola decodificación; la vista previa se reutiliza al abrir y las
                // cachés (miniatura y edición) se escriben después en segundo plano.
                val created = withContext(Dispatchers.IO) {
                    store.createFast(uri, loopSec.coerceIn(2, 60), previewMaxForDevice())
                }
                busy = null
                openProject(created.id, initialTab, initialCategory, created.preview, fromImport = true)
                launch(Dispatchers.IO) { store.writeCaches(created) }
            } catch (e: Throwable) {
                busy = null
                message = "No se pudo importar: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    fun importAudio(uri: Uri) {
        val project = meta ?: return
        if (busy != null || exportState is ExportState.Running) return
        if (playing) togglePlay()
        busy = "Importando audio…"
        viewModelScope.launch {
            try {
                val decoded = withContext(Dispatchers.IO) {
                    val temp = java.io.File(project.dir, "audio-import.tmp")
                    val result = com.zeta.fondo.engine.ImportedAudio.decode(getApplication(), uri, temp)
                    java.nio.file.Files.move(temp.toPath(), java.io.File(project.dir,
                        com.zeta.fondo.engine.ImportedAudio.FILE_NAME).toPath(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING)
                    result
                }
                updateExport(exportSettings.copy(audioName = decoded.name, audioRate = decoded.rate,
                    audioChannels = decoded.channels, audioFrames = decoded.frames,
                    audioStartFrame = 0L, audioEnabled = true, soundVolume = 1f))
                saveProject()
            } catch (e: Exception) {
                message = "No se pudo importar el audio: ${e.message}"
            } finally { busy = null }
        }
    }

    fun removeAudio() {
        if (playing) togglePlay()
        updateExport(exportSettings.copy(audioName = "", audioFrames = 0L, audioStartFrame = 0L, audioEnabled = false))
        saveProject()
    }

    val lowResourceDevice: Boolean by lazy {
        val am = getApplication<Application>().getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        am.isLowRamDevice || am.memoryClass <= 128
    }

    /** La imagen de edición se dimensiona para la RAM del teléfono, no para exportar. */
    private fun previewMaxForDevice(): Int {
        val am = getApplication<Application>().getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return com.zeta.fondo.model.PreviewSizing.target(lowResourceDevice, am.memoryClass)
    }

    fun openProject(id: String, initialTab: EditorTab = EditorTab.TOOLS, initialCategory: String = "Populares",
                    preloaded: Bitmap? = null, fromImport: Boolean = false) {
        if (!fromImport) perfStart()
        busy = "Abriendo proyecto…"
        viewModelScope.launch {
            try {
                val loaded = withContext(Dispatchers.IO) { store.load(id) }

                // v26: nunca mostramos el thumbnail pequeño en el editor porque produce
                // el salto borroso -> nítido. Cada proyecto guarda una caché de edición
                // suficientemente grande para verse nítida desde el primer cuadro.
                val quickPreview: Bitmap = preloaded?.takeIf { !it.isRecycled } ?: withContext(Dispatchers.IO) {
                    store.loadOrCreateEditPreview(loaded.meta, previewMaxForDevice())
                }
                val mk = withContext(Dispatchers.Default) {
                    MaskLayers.create(loaded.meta.w, loaded.meta.h).also {
                        val dir = loaded.meta.dir
                        it.imageSource = { name -> maskImage(dir, name) }
                        it.setAll(loaded.strokes, loaded.maskNames)
                    }
                }

                autoSaveJob?.cancel()
                editSnapshot = null; editingEffect = null; paintingZone = false; selectedElement = -1; brushCursor = null
                meta = loaded.meta
                arrows.clear()
                arrows.addAll(loaded.arrows)
                anchors.clear()
                anchors.addAll(loaded.anchors)
                masks = mk
                maskNames = mk.names.toList()
                selectedMaskLayer = 0
                hub.activeMask = 0
                settings = loaded.settings
                exportSettings = loaded.export
                effectClips = loaded.effectClips.map { EffectTimeline.normalized(it, loaded.export.loopSec.toFloat()) }
                // v44: los ambientes del bucle de proyectos antiguos pasan a ser bloques de sonido
                // (mismo sonido y volumen, cubriendo todo el vídeo).
                if (loaded.export.ambient.any { it.value > .01f }) {
                    effectClips = effectClips + com.zeta.fondo.model.SoundClips.fromLegacy(loaded.export.ambient,
                        loaded.export.loopSec.toFloat(), (effectClips.maxOfOrNull { it.uid } ?: 0L) + 1L)
                    exportSettings = exportSettings.copy(ambient = emptyMap())
                }
                selectedTimelineClip = null
                undoStack.clear()
                redoStack.clear()
                canUndo = false
                canRedo = false
                currentStroke = null
                exportState = ExportState.Idle
                glError = null
                cropEditing = false
                resetView()
                tool = Tool.PAN
                showGuides = false
                effectsCategory = initialCategory
                animPanel = ""; effectSection = "Ajustes"; settingsSection = 0
                hub.resizing = false; hint = null
                tab = initialTab
                // v40: cada proyecto abre con el lienzo fijo y la línea de tiempo (o el catálogo).
                placingClip = false; replacingClip = null
                // v41: se abre en la barra principal con la línea de tiempo (o el catálogo).
                categoryOpen = false; imageSelected = false; adjustOpen = false; editFromCatalog = false
                optionsOpen = initialTab == EditorTab.EFFECTS
                fullscreen = false
                activeMotionEffect = null
                // v37: abrir una imagen o un proyecto deja TODO en pausa en el inicio.
                playing = false
                hub.setPlaying(false)
                scrubT = 0f
                hub.setPausedT(0f)
                if (initialTab == EditorTab.MASKS) selectMask(0)

                // Mostrar el editor con una caché ya nítida. Esta misma imagen queda como
                // placeholder sobre OpenGL hasta el primer cuadro, sin destello borroso.
                previewFallback = quickPreview
                previewReady = false
                updateOriginalPreview(false)
                hub.image = quickPreview
                hub.character = null
                hub.masks = mk
                mk.onChange = { hub.invalidate(); main.post { maskRevision++ } }
                hub.flow = null
                resetDepth()
                resetCutout()
                tapSelectFor = null; regionState = AiJob.Idle; sceneSuggestions = emptyList(); srCompare = null; srState = AiJob.Idle
                loadDepthCache(loaded.meta)
                loadPlateCache(loaded.meta, mk)
                hub.showMask = showMasks && !playing
                pushParams()
                recomputeFlow()
                refreshEffectBoxes()
                screen = Screen.EDITOR
                busy = null

                // v28: no reemplazar la textura de la imagen unos segundos después de abrir.
                // Ese cambio coincidía con el primer gesto de zoom y podía provocar un tirón
                // por decodificación + subida de textura. La caché nítida queda estable durante
                // toda la edición; la imagen original completa sigue reservada para exportar.
                launch {
                    val character = try {
                        withContext(Dispatchers.IO) { loadCharacter(loaded.meta.dir) }
                    } catch (_: Throwable) { null }
                    if (screen == Screen.EDITOR && meta?.id == loaded.meta.id) {
                        hub.character = character
                    }
                }
            } catch (e: Throwable) {
                busy = null
                message = "No se pudo abrir: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    fun saveProject(forceCurrent: Boolean = false) {
        val m = meta ?: return
        val mk = masks ?: return
        // El guardado explícito de fondo incluye lo que se está pintando.
        // Un cierre inesperado no debe volver a la configuración anterior.
        val pending = if (forceCurrent) null else editSnapshot
        val a = ArrayList(pending?.arrows ?: arrows)
        val an = ArrayList(pending?.anchors ?: anchors)
        val st = pending?.strokes ?: mk.snapshot()
        val labels = pending?.names ?: mk.names.toList()
        val s = pending?.settings ?: settings
        val ex = exportSettings
        val clips = effectClips.toList()
        viewModelScope.launch {
            saveMutex.withLock {
                try { withContext(Dispatchers.IO) { store.save(m, a, an, st, s, ex, labels, clips) } }
                catch (e: Exception) { message = "No se pudo guardar el proyecto: ${e.message}" }
            }
        }
    }

    fun closeEditor() {
        autoSaveJob?.cancel()
        if (busy != null) return
        if (exportState is ExportState.Running) {
            message = "Espera a que termine la exportación o cancélala."
            return
        }
        fullscreen = false
        finishEdit(true)
        saveProject()
        soloClip = null
        resetDepth()
        resetCutout()
        tapSelectFor = null; regionState = AiJob.Idle; sceneSuggestions = emptyList(); srCompare = null; srJob?.cancel(); srState = AiJob.Idle
        screen = Screen.HOME
        meta = null
        effectClips = emptyList()
        selectedTimelineClip = null
        previewFallback = null
        previewReady = false
        updateOriginalPreview(false)
        hub.image = null
        refreshProjects()
    }

    fun deleteProject(id: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { store.delete(id) }
            refreshProjects()
        }
    }

    // ============================================================ Efectos

    fun selectTab(t: EditorTab) {
        finishCropEdit()
        finishEdit(true)
        placingClip = false
        replacingClip = null
        selectedTimelineClip = null
        optionsOpen = t == EditorTab.EFFECTS || t == EditorTab.CANVAS || t == EditorTab.MASKS
        tab = t
        if (t == EditorTab.MASKS && playing) togglePlay()
        showGuides = !playing && (t == EditorTab.TOOLS || t == EditorTab.MASKS)
        hub.showMask = false
    }

    fun protectPoints(erase: Boolean = false) {
        finishEdit(true); tab = EditorTab.MASKS
        if (playing) togglePlay()
        tool = if (erase) Tool.ERASE_GUIDE else Tool.ANCHOR
        showGuides = true; hub.showMask = false
    }

    fun editZoneMotion() { editEffect("zonemotion") }

    val activeEffectsCount: Int get() = com.zeta.fondo.model.EffectSwitches.active(settings).size
    fun removeAllEffects() {
        finishEdit(true)
        val before = com.zeta.fondo.model.EffectSwitches.active(settings)
        if (before.isEmpty()) return
        val after = com.zeta.fondo.model.EffectSwitches.disabled(settings)
        val beforeClips = effectClips.toList()
        settings = settings + after
        effectClips = emptyList()
        selectedTimelineClip = null
        pushUndo(UndoAction.EffectSwitches(before, after, beforeClips, emptyList())); pushParams(); saveProject()
    }

    fun addMask() {
        val mk = masks ?: return
        val i = mk.addLayer("Máscara ${maskNames.size - 2}")
        if (i < 0) { message = "Máximo ${MaskLayers.MAX_MASKS} máscaras para cuidar la memoria del dispositivo."; return }
        maskNames = mk.names.toList()
        selectMask(i)
    }

    fun selectMask(index: Int) {
        if (index !in maskNames.indices) return
        selectedMaskLayer = index
        hub.activeMask = index
        tool = when (index) {
            0 -> Tool.FREEZE
            1 -> Tool.ZONE1
            2 -> Tool.ZONE2
            else -> Tool.MASK
        }
        showMasks = true
        hub.showMask = true
    }

    fun renameMask(index: Int, label: String) {
        val mk = masks ?: return
        mk.renameLayer(index, label)
        maskNames = mk.names.toList()
    }

    fun setEffectMask(id: String, index: Int) {
        setSetting("$id.mask", index.toFloat())
        if (id == "natural" || id == "flame") refreshEffectBoxes()
    }

    fun resetColor() {
        settings = settings.filterKeys { !it.startsWith("adjust.") }
        pushParams()
        scheduleAutosave()
    }

    /** v44: varios ajustes a la vez (p. ej. dirección + fuerza del joystick) en un solo cambio. */
    fun setSettingsBatch(values: Map<String, Float>) {
        for ((id, group) in values.entries.groupBy({ it.key.substringBefore('.') }, { it.key to it.value }))
            updateFx(id, group.toMap())
    }

    fun setSetting(key: String, value: Float) {
        val v = if ((settings["loop.perfect"] ?: 0f) > .5f && key.endsWith(".cycles"))
            kotlin.math.round(value).coerceAtLeast(1f) else value
        if (canKeyframe(key) && autoKey(key, v)) return
        updateFx(key.substringBefore('.'), mapOf(key to v))
        if (key == "flow.reach") recomputeFlow()
    }

    // ============================================================ v40: ajustes por bloque

    /**
     * Lectura de ajustes de efecto que respeta el bloque en edición: con varios bloques del
     * mismo efecto, cada uno muestra y edita SUS valores (vm.fx["humo.size"]).
     */
    inner class FxView {
        operator fun get(key: String): Float? = ClipEdits.value(settings, fxTarget(key.substringBefore('.')), key)
    }
    val fx = FxView()

    /** Bloque cuyos ajustes se editan (null = el efecto entero). */
    fun fxTarget(id: String): EffectClip? = ClipEdits.target(clipsForEffect(id), selectedTimelineClip)

    /** Cambia ajustes de [id]: van al bloque en edición o, si no hay, al efecto entero. */
    private fun updateFx(id: String, values: Map<String, Float>, clip: EffectClip? = fxTarget(id)) {
        if (clip == null) settings = settings + values
        else {
            val own = values.filterKeys { ClipEdits.isClipKey(id, it) }
            val shared = values - own.keys
            if (shared.isNotEmpty()) settings = settings + shared
            if (own.isNotEmpty()) effectClips = effectClips.map {
                if (it.uid == clip.uid) it.copy(overrides = it.overrides + own) else it
            }
        }
        hub.boostPreview()
        pushParams()
        scheduleAutosave()
    }

    /** ¿El efecto [id] se puede colocar tocando la imagen (tiene origen en el motor)? */
    fun canPlace(id: String): Boolean = id in placeableEffects
    fun canScale(id: String): Boolean = Effects.all.firstOrNull { it.id == id }?.params?.any { it.key == "size" } == true &&
        id in placeableEffects
    fun canAim(id: String): Boolean = id in aimEffects

    /** Herramienta Posición: mover / agrandar / girar el bloque seleccionado sobre la imagen. */
    var placingClip by mutableStateOf(false)
        private set
    fun togglePlacing() {
        val clip = selectedClip() ?: return
        if (!canPlace(clip.effectId)) {
            // v40.1: efectos que viven en una zona pintada (fuego, agua, nubes…): Mover abre
            // directamente su sección Zona, donde se pinta o se elige dónde actúa.
            val uid = clip.uid
            editEffect(clip.effectId)
            selectedTimelineClip = uid
            effectSection = "Zona"
            showHint("Este efecto se coloca pintando su zona")
            return
        }
        if (playing) togglePlay()
        placingClip = !placingClip
        if (placingClip) showHint("Arrastra el punto · aro = tamaño · flecha = dirección")
    }
    fun selectedClip(): EffectClip? = effectClips.firstOrNull { it.uid == selectedTimelineClip }

    /** Valor efectivo de un ajuste para un bloque concreto. */
    fun clipValue(clip: EffectClip, suffix: String): Float? {
        val key = "${clip.effectId}.$suffix"
        val target = ClipEdits.target(clipsForEffect(clip.effectId), clip.uid)
        return ClipEdits.value(settings, target, key) ?: Effects.all.firstOrNull { it.id == clip.effectId }
            ?.params?.firstOrNull { it.key == suffix }?.def
    }

    private var transformBefore: Pair<Map<String, Float>, List<EffectClip>>? = null
    fun beginClipTransform() {
        if (transformBefore == null) transformBefore = settings to effectClips.toList()
        hub.gestureActive = false
    }
    /** Mueve, escala o gira el bloque sobre la imagen (no toca el zoom del lienzo). */
    fun transformClip(uid: Long, originX: Float? = null, originY: Float? = null, size: Float? = null, direction: Float? = null) {
        val clip = effectClips.firstOrNull { it.uid == uid } ?: return
        val id = clip.effectId
        val values = HashMap<String, Float>()
        if (originX != null && originY != null) {
            values["$id.origin"] = 0f
            values["$id.originX"] = originX.coerceIn(0f, 1f)
            values["$id.originY"] = originY.coerceIn(0f, 1f)
        }
        if (size != null) {
            val def = Effects.all.firstOrNull { it.id == id }?.params?.firstOrNull { it.key == "size" }
            if (def != null) values["$id.size"] = size.coerceIn(def.min, def.max)
        }
        if (direction != null) values["$id.direction"] = ((direction % 360f) + 360f) % 360f
        if (values.isEmpty()) return
        updateFx(id, values, ClipEdits.target(clipsForEffect(id), uid))
        hub.boostPreview(320)
    }
    fun endClipTransform() {
        val before = transformBefore ?: return
        transformBefore = null
        if (before.first === settings && before.second == effectClips) return
        pushUndo(settingsUndo(before.first, before.second))
        saveProject()
    }

    /** Sustituir: el catálogo elige el efecto nuevo para este bloque. */
    var replacingClip by mutableStateOf<Long?>(null)
        private set
    fun startReplace() {
        val clip = selectedClip() ?: return
        finishEdit(true)
        selectedTimelineClip = clip.uid
        replacingClip = clip.uid
        placingClip = false
        tab = EditorTab.EFFECTS
        optionsOpen = true
    }

    /** Aviso con botón Deshacer (p. ej. tras eliminar un bloque). */
    var undoNotice by mutableStateOf<String?>(null)
        private set
    private var undoNoticeJob: Job? = null
    private fun showUndoNotice(text: String) {
        undoNotice = text
        undoNoticeJob?.cancel()
        undoNoticeJob = viewModelScope.launch { delay(4500); if (undoNotice == text) undoNotice = null }
    }
    fun undoFromNotice() { undoNotice = null; undo() }

    /** Registra en Deshacer un cambio de bloques (y de ajustes, si los hubo). */
    private fun commitTimeline(beforeClips: List<EffectClip>, beforeSettings: Map<String, Float> = settings) {
        if (beforeClips == effectClips && beforeSettings === settings) return
        pushUndo(settingsUndo(beforeSettings, beforeClips))
    }

    /**
     * v40.1: entrada de Deshacer con SOLO las claves que cambiaron. Una clave que no
     * existía antes se quita al deshacer (no se pone a 0: "mask" = 0 sería la capa Proteger).
     */
    private fun settingsUndo(beforeSettings: Map<String, Float>, beforeClips: List<EffectClip>): UndoAction.EffectSwitches {
        val keys = if (beforeSettings === settings) emptyList()
            else (settings.keys + beforeSettings.keys).filter { beforeSettings[it] != settings[it] }
        return UndoAction.EffectSwitches(
            keys.mapNotNull { k -> beforeSettings[k]?.let { k to it } }.toMap(),
            keys.mapNotNull { k -> settings[k]?.let { k to it } }.toMap(),
            beforeClips, effectClips.toList(),
            absentBefore = keys.filterTo(HashSet()) { !beforeSettings.containsKey(it) },
            absentAfter = keys.filterTo(HashSet()) { !settings.containsKey(it) })
    }

    /**
     * Bucle perfecto: usa trayectorias periódicas y velocidades enteras para que el
     * primer y último fotograma coincidan sin tener que ajustar cada efecto a mano.
     */
    fun setPerfectLoop(enabled: Boolean) {
        val next = HashMap(settings)
        next["loop.perfect"] = if (enabled) 1f else 0f
        if (enabled) {
            next["flow.mode"] = 1f       // ida y vuelta seno/coseno: mismo inicio y final
            next["flow.phase"] = 0f
            next["flow.blend"] = 1f
            val keys = next.keys.filter { it.endsWith(".cycles") }
            for (k in keys) next[k] = kotlin.math.round(next[k] ?: 1f).coerceAtLeast(1f)
        }
        settings = next
        pushParams(); saveProject()
        message = if (enabled) "Bucle perfecto activado" else "Bucle perfecto desactivado"
    }

    /** Pinta una de las zonas base sin crear una máscara extra. Útil para el parallax 2.5D. */
    fun paintBuiltinMask(index: Int) {
        if (index !in 1..2) return
        if (playing) togglePlay()
        selectMask(index)
        eraser = false
        paintingZone = true
        showGuides = true
        hub.showMask = true
    }

    fun maskHasPaint(index: Int): Boolean {
        val mk = masks ?: return false
        return synchronized(mk.lock) { mk.strokes.getOrNull(index)?.any { !it.erase } == true }
    }

    /** Cambia con cada trazo: permite que la interfaz recalcule los avisos de zona. */
    var maskRevision by mutableIntStateOf(0)
        private set

    private val zoneLegacy1 = setOf("drift", "ripple", "glint", "eyes", "blink", "water")
    private val zoneLegacy2 = setOf("sway", "heat", "flame", "cloth", "natural", "mesh")
    private val needsZone = zoneLegacy1 + zoneLegacy2 + setOf("zonemotion", "waterfall", "reflect", "shore",
        "reveal", "dispersion", "sky")

    // ============================================================ v45 · Profundidad IA (2.5D)

    sealed class DepthState {
        object Idle : DepthState()
        data class Running(val stage: String) : DepthState()
        data class Ready(val model: String, val ms: Long, val contrast: Float, val fromCache: Boolean) : DepthState()
        data class Failed(val reason: String) : DepthState()
    }
    var depthState by mutableStateOf<DepthState>(DepthState.Idle)
        private set
    var depthView by mutableStateOf(false)
        private set
    private var depthJob: Job? = null
    private val depthEstimator by lazy { com.zeta.fondo.engine.DepthEstimator(getApplication()) }
    /** ¿Hay algún modelo de profundidad (descargado o en el APK)? Si no, solo 2.5D manual. */
    val depthAvailable: Boolean get() { modelsRevision; return depthEstimator.available().isNotEmpty() }

    // ============================================================ v48 · Modelos de IA descargables

    /** Cambia al terminar o borrar una descarga: la interfaz vuelve a mirar qué hay instalado. */
    var modelsRevision by mutableIntStateOf(0)
        private set
    /** Progreso 0..1 de cada descarga en curso (por id de modelo). */
    val downloadProgress = androidx.compose.runtime.mutableStateMapOf<String, Float>()
    val downloadError = androidx.compose.runtime.mutableStateMapOf<String, String>()
    private val downloadJobs = HashMap<String, Job>()
    private val downloadCancel = HashMap<String, java.util.concurrent.atomic.AtomicBoolean>()

    fun modelInstalled(spec: com.zeta.fondo.engine.ModelStore.Spec): Boolean { modelsRevision; return com.zeta.fondo.engine.ModelStore.installed(spec) }
    fun modelPartial(spec: com.zeta.fondo.engine.ModelStore.Spec): Long { modelsRevision; return com.zeta.fondo.engine.ModelStore.partialBytes(spec) }

    /** ¿Conexión de datos móviles (de pago)? Para avisar antes de bajar cientos de MB. */
    fun onMeteredNetwork(): Boolean = try {
        (getApplication<Application>().getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager).isActiveNetworkMetered
    } catch (_: Throwable) { false }

    fun downloadModel(spec: com.zeta.fondo.engine.ModelStore.Spec) {
        if (downloadJobs[spec.id]?.isActive == true) return
        val cancel = java.util.concurrent.atomic.AtomicBoolean(false)
        downloadCancel[spec.id] = cancel
        downloadError.remove(spec.id)
        downloadProgress[spec.id] = (com.zeta.fondo.engine.ModelStore.partialBytes(spec).toFloat() / spec.bytes).coerceIn(0f, 1f)
        downloadJobs[spec.id] = viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    com.zeta.fondo.engine.ModelStore.download(spec,
                        progress = { d, t -> main.post { if (downloadProgress.containsKey(spec.id)) downloadProgress[spec.id] = d.toFloat() / t } },
                        cancelled = { cancel.get() })
                }
                com.zeta.fondo.diag.ZetaLog.info("models", "${spec.id} descargado y verificado")
                showHint("${spec.label}: descargado y verificado.", 3200L)
            } catch (e: com.zeta.fondo.engine.ModelStore.Cancelled) {
                Unit
            } catch (e: Throwable) {
                com.zeta.fondo.diag.ZetaLog.warn("models", "${spec.id}: ${e.message}")
                downloadError[spec.id] = when (e) {
                    is java.net.UnknownHostException, is java.net.ConnectException, is java.net.SocketTimeoutException ->
                        "Sin conexión. Vuelve a intentarlo: continuará donde se quedó."
                    else -> e.message ?: e.javaClass.simpleName
                }
            } finally {
                downloadProgress.remove(spec.id)
                downloadJobs.remove(spec.id)
                modelsRevision++
            }
        }
    }

    fun cancelDownload(spec: com.zeta.fondo.engine.ModelStore.Spec) { downloadCancel[spec.id]?.set(true) }

    fun removeModel(spec: com.zeta.fondo.engine.ModelStore.Spec) {
        cancelDownload(spec)
        com.zeta.fondo.engine.ModelStore.remove(spec)
        modelsRevision++
    }
    /** Hay mapa y el interruptor «Usar profundidad IA» está activo. */
    val depthUsable: Boolean get() = depthState is DepthState.Ready && (settings["parallax.ai"] ?: 1f) > .5f

    private fun resetDepth() {
        depthJob?.cancel(); depthJob = null
        hub.depth = null
        hub.depthView = false
        depthView = false
        depthState = DepthState.Idle
    }

    /** Al abrir: usa el mapa guardado si es de la misma imagen (no se repite la IA). */
    private fun loadDepthCache(m: com.zeta.fondo.model.ProjectMeta) {
        depthJob = viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { depthEstimator.loadCached(m.dir, m.imageFile) }
            if (r != null && meta?.id == m.id) {
                hub.depth = com.zeta.fondo.engine.DepthMap(r.w, r.h, r.map, r.meta.model)
                depthState = DepthState.Ready(r.meta.model, r.meta.ms, r.meta.contrast, true)
            }
        }
    }

    /** Si el 2.5D está activo, con IA y sin mapa, lo calcula una vez (en segundo plano). */
    fun ensureDepth() {
        if (!depthAvailable || depthState !is DepthState.Idle || hub.depth != null) return
        if ((settings["parallax.ai"] ?: 1f) <= .5f || !isEffectOn("parallax")) return
        computeDepth()
    }

    fun computeDepth() {
        val m = meta ?: return
        if (depthState is DepthState.Running) return
        if (!depthAvailable) { depthState = DepthState.Failed("Primero descarga la IA de profundidad (arriba) o usa Zona azul y Zona verde."); return }
        depthJob?.cancel()
        val before = if (hub.depth != null) depthState else DepthState.Idle
        depthState = DepthState.Running("Preparando…")
        depthJob = viewModelScope.launch {
            try {
                val r = depthEstimator.estimate(m.dir, m.imageFile) { stage -> main.post { if (depthState is DepthState.Running) depthState = DepthState.Running(stage) } }
                if (meta?.id != m.id) return@launch
                hub.depth = com.zeta.fondo.engine.DepthMap(r.w, r.h, r.map, r.meta.model)
                depthState = DepthState.Ready(r.meta.model, r.meta.ms, r.meta.contrast, false)
                pushParams()
            } catch (e: kotlinx.coroutines.CancellationException) {
                if (depthState is DepthState.Running) depthState = before
                throw e
            } catch (e: Throwable) {
                com.zeta.fondo.diag.ZetaLog.error("depth", "profundidad IA falló", e)
                depthState = DepthState.Failed("No se pudo calcular (${e.javaClass.simpleName}). Se usa el 2.5D manual.")
            }
        }
    }

    fun cancelDepth() {
        depthJob?.cancel()
        depthJob = null
    }

    /** Borra el mapa guardado (vuelve al 2.5D manual hasta recalcular). */
    fun discardDepth() {
        val m = meta ?: return
        resetDepth()
        viewModelScope.launch(Dispatchers.IO) { com.zeta.fondo.engine.DepthEstimator.clear(m.dir) }
        pushParams()
    }

    fun toggleDepthView() {
        depthView = !depthView
        hub.depthView = depthView
    }

    // ============================================================ v46 · Recorte de personaje y relleno del fondo

    sealed class AiJob {
        object Idle : AiJob()
        data class Running(val stage: String) : AiJob()
        data class Done(val text: String, val warning: String? = null) : AiJob()
        data class Failed(val reason: String) : AiJob()
    }
    var cutState by mutableStateOf<AiJob>(AiJob.Idle)
        private set
    var plateState by mutableStateOf<AiJob>(AiJob.Idle)
        private set
    private var cutJob: Job? = null
    private var plateJob: Job? = null
    /** Versión de la capa Proteger con la que se hizo la placa (para avisar si cambió). */
    private var plateProtectCrc = 0L
    private val segmenter by lazy { com.zeta.fondo.engine.CharacterSegmenter(getApplication()) }
    /** ¿Este APK trae el modelo de recorte de personaje? */
    val segAvailable: Boolean get() { modelsRevision; return segmenter.segAvailable }
    var miganInstalled by mutableStateOf(false)
        private set
    var miganSha by mutableStateOf<String?>(null)
        private set

    fun refreshMigan() {
        miganInstalled = segmenter.miganAvailable
        miganSha = if (miganInstalled) segmenter.miganSha() else null
    }

    private fun maskImage(dir: java.io.File, name: String): Bitmap? = try {
        BitmapFactory.decodeFile(java.io.File(dir, name).path)
    } catch (_: Throwable) { null }

    /** Bytes (0..255) de una capa de máscara, sin el relleno de fila. */
    private fun layerBytes(mk: MaskLayers, layer: Int): ByteArray = synchronized(mk.lock) {
        val bmp = mk.bitmaps[layer]
        val row = bmp.rowBytes
        val buf = java.nio.ByteBuffer.allocate(row * bmp.height)
        bmp.copyPixelsToBuffer(buf)
        val raw = buf.array()
        ByteArray(mk.w * mk.h) { i -> raw[(i / mk.w) * row + (i % mk.w)] }
    }

    private fun crcOf(b: ByteArray): Long = java.util.zip.CRC32().also { it.update(b) }.value

    /**
     * Recorta el personaje con IA (isnetis) y lo añade a Proteger como una máscara más:
     * se deshace con ↶ y se repasa con el pincel. En manga B/N avisa si el recorte es dudoso.
     */
    fun cutoutCharacter() {
        val m = meta ?: return
        val mk = masks ?: return
        if (cutState is AiJob.Running) return
        if (!segAvailable) {
            cutState = AiJob.Failed("Primero descarga la IA de recorte (Ajustes › IA, 176 MB) o pinta Proteger con el pincel.")
            showHint("Descarga la IA de recorte en Ajustes › IA (176 MB, una sola vez).", 4200L)
            return
        }
        if (playing) togglePlay()
        cutState = AiJob.Running("Buscando el personaje…")
        cutJob = viewModelScope.launch {
            try {
                val src = withContext(Dispatchers.IO) { BitmapUtil.decodeAtMost(m.imageFile, 1600) }
                val r = try { segmenter.segment(src, mk.w, mk.h) } finally { src.recycle() }
                if (meta?.id != m.id) return@launch
                if (r.coverage < 0.01f) {
                    cutState = AiJob.Failed("No se encontró ningún personaje. Pinta Proteger con el pincel.")
                    showHint("No se encontró ningún personaje. Pinta Proteger con el pincel.", 4200L)
                    return@launch
                }
                val name = "mask_ai_${System.currentTimeMillis()}.png"
                val bmp = withContext(Dispatchers.Default) {
                    val px = IntArray(r.w * r.h) { i -> ((r.alpha[i].toInt() and 0xFF) shl 24) or 0xFFFFFF }
                    Bitmap.createBitmap(px, r.w, r.h, Bitmap.Config.ARGB_8888)
                }
                withContext(Dispatchers.IO) {
                    val tmp = java.io.File(m.dir, "$name.tmp")
                    tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    tmp.renameTo(java.io.File(m.dir, name))
                }
                mk.putImage(name, bmp)
                val stroke = MaskStroke(0, 0f, 0f, false, image = name)
                mk.addStroke(stroke)
                pushUndo(UndoAction.AddStroke(stroke))
                scheduleAutosave()
                refreshEffectBoxes()
                val secs = String.format(java.util.Locale.US, "%.1f", r.ms / 1000f)
                val warn = if (r.uncertainty > 0.15f) "Recorte dudoso (habitual en manga B/N con tramas): repásalo con el pincel Proteger." else null
                cutState = AiJob.Done("Personaje recortado en $secs s (${(r.coverage * 100).toInt()} % de la imagen).", warn)
                showHint(warn ?: "Personaje recortado y añadido a Proteger. Repásalo con el pincel si hace falta.", 4200L)
                if (isEffectOn("parallax")) computePlate()
            } catch (e: kotlinx.coroutines.CancellationException) {
                cutState = AiJob.Idle
                throw e
            } catch (e: Throwable) {
                com.zeta.fondo.diag.ZetaLog.error("cutout", "recorte IA falló", e)
                cutState = AiJob.Failed("No se pudo recortar (${e.javaClass.simpleName}). Pinta Proteger con el pincel.")
                message = "No se pudo recortar al personaje: usa el pincel Proteger."
            }
        }
    }

    fun cancelCutout() { cutJob?.cancel(); cutJob = null }

    /** ¿Cambió Proteger desde que se hizo la placa? */
    val plateStale: Boolean get() {
        val mk = masks ?: return false
        if (hub.plate == null) return false
        maskRevision // se relee al cambiar los trazos
        return crcOf(layerBytes(mk, 0)) != plateProtectCrc
    }

    /**
     * Fondo sin el personaje para el 2.5D: el hueco de Proteger se rellena (MI-GAN si el
     * usuario lo importó; si no, relleno pull-push). Se guarda en el proyecto.
     */
    fun computePlate() {
        val m = meta ?: return
        val mk = masks ?: return
        if (!maskHasPaint(0)) { plateState = AiJob.Failed("Primero recorta o pinta al personaje en Proteger."); return }
        plateJob?.cancel()
        plateState = AiJob.Running(if (segmenter.miganAvailable) "Rellenando el fondo con MI-GAN…" else "Rellenando el fondo…")
        plateJob = viewModelScope.launch {
            try {
                val hole = withContext(Dispatchers.Default) { layerBytes(mk, 0) }
                val src = withContext(Dispatchers.IO) {
                    val b = BitmapUtil.decodeAtMost(m.imageFile, maxOf(mk.w, mk.h) * 2)
                    Bitmap.createScaledBitmap(b, mk.w, mk.h, true).also { if (it !== b) b.recycle() }
                }
                val t0 = System.nanoTime()
                val (argb, ai) = try { segmenter.fillBackground(src, hole) } finally { src.recycle() }
                if (meta?.id != m.id) return@launch
                val crc = crcOf(hole)
                withContext(Dispatchers.IO) { savePlate(m.dir, mk.w, mk.h, argb, crc, ai) }
                plateProtectCrc = crc
                hub.plate = com.zeta.fondo.engine.PlateMap(mk.w, mk.h, argb, ai)
                val ms = (System.nanoTime() - t0) / 1_000_000
                plateState = AiJob.Done((if (ai) "Fondo rellenado con MI-GAN" else "Fondo rellenado (básico)") + " en ${ms} ms.")
                pushParams()
            } catch (e: kotlinx.coroutines.CancellationException) {
                if (plateState is AiJob.Running) plateState = AiJob.Idle
                throw e
            } catch (e: Throwable) {
                com.zeta.fondo.diag.ZetaLog.error("cutout", "relleno falló", e)
                plateState = AiJob.Failed("No se pudo rellenar el fondo (${e.javaClass.simpleName}).")
            }
        }
    }

    /** Al abrir el 2.5D: si hay personaje en Proteger y no hay placa, se hace (es rápido). */
    fun ensurePlate() {
        if (hub.plate == null && plateState is AiJob.Idle && maskHasPaint(0) && isEffectOn("parallax") &&
            (settings["parallax.plate"] ?: 1f) > .5f) computePlate()
    }

    private fun savePlate(dir: java.io.File, w: Int, h: Int, argb: IntArray, crc: Long, ai: Boolean) {
        val bmp = Bitmap.createBitmap(argb, w, h, Bitmap.Config.ARGB_8888)
        val tmp = java.io.File(dir, "$PLATE_FILE.tmp")
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        tmp.renameTo(java.io.File(dir, PLATE_FILE))
        java.io.File(dir, PLATE_META).writeText("version=1\nw=$w\nh=$h\ncrc=$crc\nai=$ai\n")
    }

    /** Al abrir el proyecto: placa guardada si corresponde a la Proteger actual. */
    private fun loadPlateCache(m: com.zeta.fondo.model.ProjectMeta, mk: MaskLayers) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                try {
                    val metaF = java.io.File(m.dir, PLATE_META)
                    val png = java.io.File(m.dir, PLATE_FILE)
                    if (!metaF.isFile || !png.isFile) return@withContext null
                    val kv = metaF.readLines().mapNotNull { l -> l.split('=', limit = 2).takeIf { it.size == 2 }?.let { it[0] to it[1] } }.toMap()
                    val w = kv["w"]?.toIntOrNull() ?: return@withContext null
                    val h = kv["h"]?.toIntOrNull() ?: return@withContext null
                    val crc = kv["crc"]?.toLongOrNull() ?: return@withContext null
                    if (w != mk.w || h != mk.h || crcOf(layerBytes(mk, 0)) != crc) return@withContext null
                    val bmp = BitmapFactory.decodeFile(png.path) ?: return@withContext null
                    val px = IntArray(w * h)
                    bmp.getPixels(px, 0, w, 0, 0, w, h)
                    bmp.recycle()
                    Triple(com.zeta.fondo.engine.PlateMap(w, h, px, kv["ai"] == "true"), crc, kv["ai"] == "true")
                } catch (_: Throwable) { null }
            }
            if (r != null && meta?.id == m.id) {
                hub.plate = r.first
                plateProtectCrc = r.second
                plateState = AiJob.Done(if (r.third) "Fondo rellenado con MI-GAN (guardado)." else "Fondo rellenado (guardado).")
            }
        }
    }

    private fun resetCutout() {
        cutJob?.cancel(); cutJob = null
        plateJob?.cancel(); plateJob = null
        hub.plate = null
        cutState = AiJob.Idle
        plateState = AiJob.Idle
        plateProtectCrc = 0L
    }

    /** MI-GAN elegido por el usuario (archivo .onnx «pipeline» descargado por él). */
    fun importMigan(uri: Uri) {
        if (busy != null) return
        busy = "Comprobando el modelo MI-GAN…"
        viewModelScope.launch {
            try {
                val sha = withContext(Dispatchers.IO) {
                    val input = getApplication<Application>().contentResolver.openInputStream(uri)
                        ?: throw IllegalStateException("No se pudo leer el archivo")
                    segmenter.importMigan(input)
                }
                refreshMigan()
                message = "MI-GAN instalado (SHA-256 ${sha.take(12)}…). Se usará al rellenar el fondo."
                if (hub.plate != null) computePlate()
            } catch (e: Throwable) {
                message = "No se pudo usar ese archivo: ${e.message ?: e.javaClass.simpleName}"
            } finally { busy = null }
        }
    }

    fun removeMigan() {
        segmenter.removeMigan()
        refreshMigan()
    }

    // ============================================================ v47 · Caras, ojos, cielo, agua, sugerencias y mejora

    private val faceDetector by lazy {
        try {
            com.zeta.fondo.engine.AnimeFaceDetector.parse(
                getApplication<Application>().assets.open("detect/lbpcascade_animeface.xml").bufferedReader().use { it.readText() })
        } catch (e: Throwable) { com.zeta.fondo.diag.ZetaLog.error("faces", "cascada no disponible", e); null }
    }
    var regionState by mutableStateOf<AiJob>(AiJob.Idle)
        private set
    /** Efecto que recibirá la región del próximo toque en la imagen («Tocar para seleccionar»). */
    var tapSelectFor by mutableStateOf<String?>(null)
        private set
    var tapTolerance by mutableFloatStateOf(.5f)
    var sceneSuggestions by mutableStateOf<List<String>>(emptyList())
        private set

    /** Imagen del proyecto a tamaño de máscara (ARGB) para las herramientas de región. */
    private suspend fun imageAtMaskSize(m: com.zeta.fondo.model.ProjectMeta, mk: MaskLayers): IntArray = withContext(Dispatchers.IO) {
        val b = BitmapUtil.decodeAtMost(m.imageFile, maxOf(mk.w, mk.h) * 2)
        val s = Bitmap.createScaledBitmap(b, mk.w, mk.h, true)
        if (s !== b) b.recycle()
        IntArray(mk.w * mk.h).also { s.getPixels(it, 0, mk.w, 0, 0, mk.w, mk.h); s.recycle() }
    }

    /** Mapa de profundidad (si lo hay) reescalado al tamaño de las máscaras. */
    private fun depthAtMaskSize(mk: MaskLayers): ByteArray? = hub.depth?.let {
        com.zeta.fondo.engine.DepthMath.resize(it.map, it.w, it.h, mk.w, mk.h)
    }

    /**
     * Pone [alpha] (0..255, tamaño de capa) como zona PROPIA del efecto [id], igual que si se
     * hubiera pintado: se deshace con ↶ y se repasa con el pincel. Devuelve false si no cabe.
     */
    private suspend fun applyAiZone(id: String, alpha: ByteArray, tag: String): Boolean {
        val m = meta ?: return false
        val mk = masks ?: return false
        var layer = (settings["$id.ownedMask"] ?: -1f).toInt()
        if (layer !in 3 until mk.count) {
            layer = mk.addLayer(Effects.all.firstOrNull { it.id == id }?.title ?: id)
            if (layer < 0) { message = "Límite de nueve zonas independientes por proyecto."; return false }
            setSetting("$id.ownedMask", layer.toFloat())
        }
        val name = "mask_${tag}_${System.currentTimeMillis()}.png"
        val bmp = withContext(Dispatchers.Default) {
            Bitmap.createBitmap(IntArray(mk.w * mk.h) { i -> ((alpha[i].toInt() and 0xFF) shl 24) or 0xFFFFFF }, mk.w, mk.h, Bitmap.Config.ARGB_8888)
        }
        withContext(Dispatchers.IO) {
            val tmp = java.io.File(m.dir, "$name.tmp")
            tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            tmp.renameTo(java.io.File(m.dir, name))
        }
        mk.putImage(name, bmp)
        val stroke = MaskStroke(layer, 0f, 0f, false, image = name)
        mk.addStroke(stroke)
        pushUndo(UndoAction.AddStroke(stroke))
        maskNames = mk.names.toList()
        setEffectMask(id, layer)
        scheduleAutosave()
        refreshEffectBoxes()
        return true
    }

    /** Caras anime: primero con el criterio del README (5 vecinos); si no hay, más permisivo. */
    private suspend fun detectFaces(px: IntArray, w: Int, h: Int): Pair<List<com.zeta.fondo.engine.AnimeFaceDetector.Face>, Boolean> =
        withContext(Dispatchers.Default) {
            val det = faceDetector ?: return@withContext emptyList<com.zeta.fondo.engine.AnimeFaceDetector.Face>() to false
            val gray = com.zeta.fondo.engine.FaceRegions.gray(px)
            for (n in intArrayOf(5, 3, 2)) {
                val f = det.detect(gray, w, h, minNeighbors = n)
                if (f.isNotEmpty()) return@withContext f.take(3) to (n < 5)
            }
            emptyList<com.zeta.fondo.engine.AnimeFaceDetector.Face>() to false
        }

    /**
     * Propone los ojos (efectos «eyes» o «blink») o el pecho para la respiración («zonemotion»
     * en estilo Respiración) a partir de las caras detectadas. La cara nunca se deforma: solo
     * se crea la ZONA del efecto, editable con el pincel.
     */
    fun aiFaceZone(id: String) {
        val m = meta ?: return
        val mk = masks ?: return
        if (regionState is AiJob.Running) return
        regionState = AiJob.Running("Buscando caras…")
        viewModelScope.launch {
            try {
                val px = imageAtMaskSize(m, mk)
                val (faces, weak) = detectFaces(px, mk.w, mk.h)
                if (faces.isEmpty()) {
                    regionState = AiJob.Failed("No encontré ninguna cara (habitual en manga con tramas o caras de perfil). Pinta la zona con el pincel.")
                    return@launch
                }
                val gray = com.zeta.fondo.engine.FaceRegions.gray(px)
                val alpha = withContext(Dispatchers.Default) {
                    if (id == "zonemotion") {
                        val masksList = faces.map { com.zeta.fondo.engine.FaceRegions.rectMask(com.zeta.fondo.engine.FaceRegions.breathing(it, mk.w, mk.h), mk.w, mk.h) }
                        ByteArray(mk.w * mk.h) { i -> masksList.maxOf { it[i].toInt() and 0xFF }.toByte() }
                    } else com.zeta.fondo.engine.FaceRegions.ellipseMask(
                        faces.flatMap { com.zeta.fondo.engine.FaceRegions.eyes(gray, mk.w, mk.h, it) }, mk.w, mk.h)
                }
                if (!isEffectOn(id)) toggleEffect(id)
                if (id == "zonemotion") setSetting("zonemotion.variant", 2f)
                if (applyAiZone(id, alpha, if (id == "zonemotion") "pecho" else "ojos")) {
                    val what = if (id == "zonemotion") "pecho" else "ojos"
                    regionState = AiJob.Done("${faces.size} cara(s): zona de $what propuesta. Repásala con el pincel si hace falta.",
                        if (weak) "Detección dudosa: revisa que la zona esté sobre la cara correcta." else null)
                }
            } catch (e: Throwable) {
                com.zeta.fondo.diag.ZetaLog.error("faces", "detección falló", e)
                regionState = AiJob.Failed("No se pudo buscar caras (${e.javaClass.simpleName}).")
            }
        }
    }

    /** Cielo o agua automáticos como zona del efecto [id] (nunca sobre Proteger). */
    fun aiSkyOrWater(id: String, water: Boolean) {
        val m = meta ?: return
        val mk = masks ?: return
        if (regionState is AiJob.Running) return
        regionState = AiJob.Running(if (water) "Buscando el agua…" else "Buscando el cielo…")
        viewModelScope.launch {
            try {
                val px = imageAtMaskSize(m, mk)
                val prot = withContext(Dispatchers.Default) { layerBytes(mk, 0) }
                val depth = depthAtMaskSize(mk)
                val r = withContext(Dispatchers.Default) {
                    if (water) com.zeta.fondo.engine.RegionTools.autoWater(px, mk.w, mk.h, depth, prot)
                    else com.zeta.fondo.engine.RegionTools.autoSky(px, mk.w, mk.h, depth, prot)
                }
                if (r == null) {
                    regionState = AiJob.Failed(if (water) "No encontré agua clara. Usa «Tocar para seleccionar» o el pincel." else "No encontré cielo. Usa «Tocar para seleccionar» o el pincel.")
                    return@launch
                }
                if (applyAiZone(id, r, if (water) "agua" else "cielo"))
                    regionState = AiJob.Done("${if (water) "Agua" else "Cielo"}: ${(com.zeta.fondo.engine.RegionTools.coverage(r) * 100).toInt()} % de la imagen. Repásalo con el pincel si hace falta.")
            } catch (e: Throwable) {
                regionState = AiJob.Failed("No se pudo seleccionar (${e.javaClass.simpleName}).")
            }
        }
    }

    /** Activa «Tocar para seleccionar»: el siguiente toque en la imagen crea la zona del efecto. */
    fun startTapSelect(id: String) {
        tapSelectFor = id
        if (playing) togglePlay()
        tool = Tool.PAN
        showHint("Toca la zona de la imagen (cielo, agua, pared…). Se selecciona lo parecido y conectado.", 3600L)
    }

    fun cancelTapSelect() { tapSelectFor = null }

    /** Toque en la imagen con «Tocar para seleccionar» activo. [uv] en 0..1 de la imagen. */
    fun tapSelectAt(uv: PointN) {
        val id = tapSelectFor ?: return
        tapSelectFor = null
        val m = meta ?: return
        val mk = masks ?: return
        regionState = AiJob.Running("Seleccionando…")
        viewModelScope.launch {
            try {
                val px = imageAtMaskSize(m, mk)
                val prot = withContext(Dispatchers.Default) { layerBytes(mk, 0) }
                val depth = depthAtMaskSize(mk)
                val x = (uv.x * mk.w).toInt().coerceIn(0, mk.w - 1); val y = (uv.y * mk.h).toInt().coerceIn(0, mk.h - 1)
                if ((prot[y * mk.w + x].toInt() and 0xFF) >= 128) {
                    regionState = AiJob.Failed("Ese punto está en Proteger (el personaje). Toca el fondo.")
                    return@launch
                }
                val r = withContext(Dispatchers.Default) {
                    com.zeta.fondo.engine.RegionTools.grow(px, mk.w, mk.h, x, y, tapTolerance, depth, prot)
                }
                val cov = com.zeta.fondo.engine.RegionTools.coverage(r)
                if (cov < .002f) { regionState = AiJob.Failed("Zona demasiado pequeña: sube la tolerancia o usa el pincel."); return@launch }
                if (applyAiZone(id, r, "toque")) regionState = AiJob.Done("Zona seleccionada (${(cov * 100).toInt()} % de la imagen). Toca otra vez para añadir más.")
            } catch (e: Throwable) {
                regionState = AiJob.Failed("No se pudo seleccionar (${e.javaClass.simpleName}).")
            }
        }
    }

    /** Sugerencias de escenas por reglas sencillas (color, cielo, agua, caras). Sin IA pesada. */
    fun computeSceneSuggestions() {
        val m = meta ?: return
        val mk = masks ?: return
        viewModelScope.launch {
            try {
                val names = withContext(Dispatchers.Default) {
                    val b = BitmapUtil.decodeAtMost(m.imageFile, 256)
                    val s = Bitmap.createScaledBitmap(b, 128, 128, true)
                    if (s !== b) b.recycle()
                    val px = IntArray(128 * 128).also { s.getPixels(it, 0, 128, 0, 0, 128, 128); s.recycle() }
                    val prot = layerBytes(mk, 0).let { com.zeta.fondo.engine.DepthMath.resize(it, mk.w, mk.h, 128, 128) }
                    val faces = faceDetector?.detect(com.zeta.fondo.engine.FaceRegions.gray(px), 128, 128)?.size ?: 0
                    com.zeta.fondo.engine.RegionTools.suggest(com.zeta.fondo.engine.RegionTools.traits(px, 128, 128, faces, prot))
                }
                sceneSuggestions = names.filter { n -> com.zeta.fondo.model.Presets.scenes.any { it.name == n } }
            } catch (_: Throwable) { sceneSuggestions = emptyList() }
        }
    }

    // ---- Mejorar imagen (superresolución, opcional y reversible)
    private val superRes by lazy { com.zeta.fondo.engine.SuperResolver(getApplication()) }
    val superResAvailable: Boolean by lazy { superRes.available }
    var srState by mutableStateOf<AiJob>(AiJob.Idle)
        private set
    var srProgress by mutableFloatStateOf(0f)
        private set
    private var srJob: Job? = null
    /** Recortes «antes/después» (misma zona, mismo tamaño) para comparar la línea fina. */
    var srCompare by mutableStateOf<Pair<Bitmap, Bitmap>?>(null)
        private set

    fun srFile(): java.io.File? = meta?.let { java.io.File(it.dir, com.zeta.fondo.engine.SuperResolver.FILE) }?.takeIf { it.isFile }
    /** ¿Se exporta con la imagen mejorada? (el original nunca se toca) */
    val srEnabled: Boolean get() = (settings["image.sr"] ?: 0f) > .5f && srFile() != null

    fun enhanceImage() {
        val m = meta ?: return
        if (srState is AiJob.Running) return
        if (!superResAvailable) { srState = AiJob.Failed("Este APK no incluye el modelo de mejora."); return }
        srState = AiJob.Running("Mejorando la imagen…"); srProgress = 0f
        srJob = viewModelScope.launch {
            try {
                val src = withContext(Dispatchers.IO) { BitmapUtil.decodeAtMost(m.imageFile, 4096) }
                val t0 = System.nanoTime()
                val out = java.io.File(m.dir, com.zeta.fondo.engine.SuperResolver.FILE)
                val (w, h) = try {
                    superRes.enhance(src, out) { p -> main.post { srProgress = p } }
                } finally { src.recycle() }
                setSetting("image.sr", 1f)
                buildSrCompare(m)
                val secs = (System.nanoTime() - t0) / 1_000_000_000f
                srState = AiJob.Done("Imagen mejorada a ${w}×$h en ${String.format(java.util.Locale.US, "%.0f", secs)} s. El original se conserva.")
            } catch (e: kotlinx.coroutines.CancellationException) {
                srState = AiJob.Idle; throw e
            } catch (e: Throwable) {
                com.zeta.fondo.diag.ZetaLog.error("superres", "mejora falló", e)
                srState = AiJob.Failed("No se pudo mejorar (${e.javaClass.simpleName}). Se sigue usando el original.")
            }
        }
    }

    fun cancelEnhance() { srJob?.cancel(); srJob = null }

    fun setUseEnhanced(on: Boolean) { setSetting("image.sr", if (on) 1f else 0f) }

    /** Borra la imagen mejorada (vuelve al original). */
    fun discardEnhanced() {
        val f = srFile()
        setSetting("image.sr", 0f)
        srCompare = null
        srState = AiJob.Idle
        viewModelScope.launch(Dispatchers.IO) { f?.delete() }
    }

    private suspend fun buildSrCompare(m: com.zeta.fondo.model.ProjectMeta) {
        val sr = srFile() ?: return
        srCompare = withContext(Dispatchers.IO) {
            try {
                val (sw, sh) = BitmapUtil.bounds(sr)
                // Zona central de 160 px de la imagen mejorada y la misma zona del original ampliada.
                val side = minOf(160, sw, sh)
                val cx = sw / 2 - side / 2; val cy = sh / 3 - side / 2
                val dec = android.graphics.BitmapRegionDecoder.newInstance(sr.path, false)
                val after = dec!!.decodeRegion(android.graphics.Rect(cx, cy.coerceAtLeast(0), cx + side, cy.coerceAtLeast(0) + side), null)
                dec.recycle()
                val (ow, oh) = BitmapUtil.bounds(m.imageFile)
                val k = ow.toFloat() / sw
                val orig = BitmapUtil.decodeAtMost(m.imageFile, maxOf(ow, oh))
                val ox = (cx * k).toInt(); val oy = (cy.coerceAtLeast(0) * k).toInt(); val os = (side * k).toInt().coerceAtLeast(1)
                val crop = Bitmap.createBitmap(orig, ox.coerceIn(0, orig.width - os), oy.coerceIn(0, orig.height - os), os, os)
                val before = Bitmap.createScaledBitmap(crop, side, side, true)
                if (crop !== orig) crop.recycle(); orig.recycle()
                before to after
            } catch (_: Throwable) { null }
        }
    }

    /** Imagen que usa la exportación: la mejorada si está activa; si no, el original. */
    private fun exportImage(m: com.zeta.fondo.model.ProjectMeta): Triple<java.io.File, Int, Int> {
        val f = srFile()
        if (srEnabled && f != null) {
            val (w, h) = BitmapUtil.bounds(f)
            if (w > 0 && h > 0) return Triple(f, w, h)
        }
        return Triple(m.imageFile, m.w, m.h)
    }

    /**
     * Motivo por el que un efecto activo NO se verá (le falta su zona pintada) o null.
     * Así la app no aparenta aplicar un efecto que en realidad no actúa.
     */
    fun zoneProblem(id: String): String? {
        if (!isEffectOn(id)) return null
        val title = Effects.all.firstOrNull { it.id == id }?.title?.substringBefore(" (") ?: id
        if (id == "parallax") return if (!maskHasPaint(1) && !maskHasPaint(2) && !depthUsable)
            (if (depthAvailable) "2.5D: calcula la profundidad IA o pinta fondo (azul) y primer plano (verde)."
             else "2.5D: pinta el fondo (azul) y el primer plano (verde).") else null
        if (id == "energy" && (settings["energy.shape"] ?: 0f).toInt() in setOf(1, 3) && !maskHasPaint(0))
            return "Aura: pinta al personaje en Proteger."
        if (id !in needsZone) return null
        val slot = (settings["$id.mask"] ?: -1f).toInt()
        val layer = when {
            slot >= 128 -> slot - 128
            slot >= 0 -> slot
            slot == -2 || slot == 126 -> return null
            id in zoneLegacy1 -> 1
            id in zoneLegacy2 -> 2
            else -> return null
        }
        return if (layer < 0 || maskHasPaint(layer)) null else "«$title» necesita una zona: toca Pintar zona."
    }

    /** Aviso visible sobre el lienzo (efecto en edición o el primero con problema). */
    val zoneWarning: String?
        get() {
            maskRevision; settings
            if (paintingZone) return null
            val id = editingEffect
            return if (id != null) zoneProblem(id) else Effects.all.firstNotNullOfOrNull { zoneProblem(it.id) }
        }

    fun moveEffectOrigin(p: PointN) {
        val id = activeMotionEffect ?: return
        updateFx(id, mapOf("$id.origin" to 0f, "$id.originX" to p.x, "$id.originY" to p.y))
    }

    fun setMotionOrigin(id: String, origin: Int) {
        val angles = floatArrayOf(Float.NaN, 90f, 270f, 0f, 180f, 45f, 135f, 315f, 225f)
        val update = mapOf("$id.origin" to origin.coerceIn(0, 8).toFloat())
        updateFx(id, update + (if (origin in 1..8) mapOf("$id.direction" to angles[origin]) else emptyMap()))
    }

    fun applyPreset(p: Preset) {
        val beforeClips = effectClips.toList()
        val beforeSettings = settings
        settings = settings + p.values
        // v44: los sonidos de la escena entran como bloques que cubren todo el vídeo.
        if (p.sounds.isNotEmpty()) {
            val total = exportSettings.loopSec.toFloat()
            var uid = nextClipUid()
            for ((sound, vol) in p.sounds) {
                val id = com.zeta.fondo.model.SoundClips.clipId(sound)
                if (effectClips.any { it.effectId == id }) continue
                effectClips = effectClips + EffectClip(uid++, id, 0f, total, overrides = mapOf("$id.vol" to vol))
            }
            commitTimeline(beforeClips, beforeSettings)
        }
        hub.boostPreview()
        pushParams()
        scheduleAutosave()
        message = "${p.emoji} ${p.name} aplicado"
    }

    /**
     * v24: estilos de un toque para los efectos que la gente usa como familias
     * (viento, lluvia, nieve, hojas y olas). Cambia varios parámetros juntos sin
     * crear otro efecto ni mover el bloque de la línea de tiempo.
     */
    /** Activa una familia visual. Las olas se editan por zona la primera vez para evitar franjas sobre toda la pantalla. */
    fun activateEffectStyle(id: String, style: Int) {
        if (id !in setOf("gust", "shore", "leaves", "rain", "snow")) return
        applyEffectStyle(id, style)
        if (id == "shore" && (!settings.containsKey("$id.mask") || (settings["$id.mask"] ?: -2f).toInt() == -2)) {
            editEffect(id)
            return
        }
        if (!settings.containsKey("$id.mask")) settings = settings + ("$id.mask" to -2f)
        activateOrSelectEffect(id)
        saveProject()
    }

    fun applyEffectStyle(id: String, style: Int) {
        val i = style.coerceIn(0, 3)
        val values: Map<String, Float> = when (id) {
            "gust" -> when (i) {
                0 -> mapOf("gust.int" to .25f, "gust.debris" to .12f, "gust.cycles" to 2f)
                1 -> mapOf("gust.int" to .65f, "gust.debris" to .32f, "gust.cycles" to 3f)
                2 -> mapOf("gust.int" to 1.0f, "gust.debris" to .62f, "gust.cycles" to 5f)
                else -> mapOf("gust.int" to 1.35f, "gust.debris" to .9f, "gust.cycles" to 7f)
            }
            "rain" -> when (i) {
                0 -> mapOf("rain.int" to .30f, "rain.angle" to 5f, "rain.cycles" to 4f)
                1 -> mapOf("rain.int" to .65f, "rain.angle" to 10f, "rain.cycles" to 7f)
                2 -> mapOf("rain.int" to .95f, "rain.angle" to 18f, "rain.cycles" to 11f)
                else -> mapOf("rain.int" to 1.15f, "rain.angle" to 28f, "rain.cycles" to 15f)
            }
            "snow" -> when (i) {
                0 -> mapOf("snow.int" to .35f, "snow.size" to .75f, "snow.cycles" to 1f, "snow.direction" to 90f)
                1 -> mapOf("snow.int" to .70f, "snow.size" to 1.0f, "snow.cycles" to 2f, "snow.direction" to 90f)
                2 -> mapOf("snow.int" to 1.0f, "snow.size" to 1.15f, "snow.cycles" to 4f, "snow.direction" to 105f)
                else -> mapOf("snow.int" to 1.15f, "snow.size" to .70f, "snow.cycles" to 8f, "snow.direction" to 135f)
            }
            "shore" -> when (i) {
                0 -> mapOf("shore.int" to .35f, "shore.freq" to 2f, "shore.cycles" to 1f)
                1 -> mapOf("shore.int" to .70f, "shore.freq" to 3f, "shore.cycles" to 2f)
                2 -> mapOf("shore.int" to 1.05f, "shore.freq" to 5f, "shore.cycles" to 3f)
                else -> mapOf("shore.int" to 1.35f, "shore.freq" to 7f, "shore.cycles" to 5f)
            }
            "leaves" -> emptyMap()
            else -> emptyMap()
        }
        updateFx(id, values + mapOf("$id.variant" to i.toFloat()))
    }

    /**
     * v25: cada material de Movimiento natural trae un comportamiento completo.
     * Conserva la máscara pintada; solo cambia física, fuerza y borde fijo recomendados.
     */
    fun applyNaturalPreset(style: Int) {
        val i = style.coerceIn(0, 5)
        val values = when (i) {
            0 -> mapOf( // Árbol: base firme, ramas suaves y hojas con variación amplia.
                "natural.variant" to 0f, "natural.anchor" to 3f, "natural.int" to .0062f,
                "natural.cycles" to 2f, "natural.flex" to .62f, "natural.variation" to .84f,
                "natural.gust" to .30f, "natural.weight" to 0.60f, "natural.spring" to 0.40f,
                "natural.direction" to 0f)
            1 -> mapOf( // Bandera: borde del poste firme y tela muy flexible.
                "natural.variant" to 1f, "natural.anchor" to 1f, "natural.int" to .0085f,
                "natural.cycles" to 2f, "natural.flex" to .94f, "natural.variation" to .46f,
                "natural.gust" to .44f, "natural.weight" to 0.25f, "natural.spring" to 0.85f,
                "natural.direction" to 0f)
            2 -> mapOf( // Pasto: raíz abajo, grupos pequeños fuera de fase.
                "natural.variant" to 2f, "natural.anchor" to 3f, "natural.int" to .0045f,
                "natural.cycles" to 3f, "natural.flex" to .74f, "natural.variation" to .90f,
                "natural.gust" to .24f, "natural.weight" to 0.30f, "natural.spring" to 0.75f,
                "natural.direction" to 0f)
            3 -> mapOf( // Cortina: fija arriba, ondulación larga.
                "natural.variant" to 3f, "natural.anchor" to 4f, "natural.int" to .0052f,
                "natural.cycles" to 2f, "natural.flex" to .90f, "natural.variation" to .34f,
                "natural.gust" to .18f, "natural.weight" to 0.35f, "natural.spring" to 0.70f,
                "natural.direction" to 0f)
            4 -> mapOf( // Cabello: raíz fija y puntas suaves, sin exagerar.
                "natural.variant" to 4f, "natural.anchor" to 4f, "natural.int" to .0044f,
                "natural.cycles" to 2f, "natural.flex" to .80f, "natural.variation" to .56f,
                "natural.gust" to .20f, "natural.weight" to 0.45f, "natural.spring" to 0.72f,
                "natural.direction" to 0f)
            else -> mapOf( // Ropa: unión al cuerpo firme y extremo libre más pesado.
                "natural.variant" to 5f, "natural.anchor" to 4f, "natural.int" to .0040f,
                "natural.cycles" to 2f, "natural.flex" to .64f, "natural.variation" to .44f,
                "natural.gust" to .20f, "natural.weight" to 0.75f, "natural.spring" to 0.34f,
                "natural.direction" to 0f)
        }
        settings = settings + values
        hub.boostPreview(360)
        pushParams()
    }

    fun clearEffects() {
        settings = Effects.allOff(settings)
        effectClips = emptyList()
        selectedTimelineClip = null
        pushParams()
    }

    fun updateExport(e: ExportSettings) {
        val old = exportSettings
        exportSettings = e
        val cropChanged = old.framing != e.framing || old.cropPos != e.cropPos || old.res != e.res ||
            old.customW != e.customW || old.customH != e.customH || old.cropCx != e.cropCx ||
            old.cropCy != e.cropCy || old.cropZoom != e.cropZoom
        if (cropChanged && !cropEditing) {
            val animate = old.framing != e.framing || old.res != e.res
            resetView(animate)
        }
        if (old.loopSec != e.loopSec) {
            val oldSec = old.loopSec.toFloat()
            val newSec = e.loopSec.toFloat()
            effectClips = effectClips.map { clip ->
                // v42: todo bloque que llegaba al final del vídeo sigue llegando al final
                // (antes solo los que cubrían el vídeo entero): alargar el vídeo alarga sus efectos.
                val reachedEnd = clip.startSec + clip.durationSec >= oldSec - .02f
                when {
                    reachedEnd && clip.startSec <= .01f -> clip.copy(startSec = 0f, durationSec = newSec)
                    reachedEnd && clip.startSec < newSec - .1f -> clip.copy(durationSec = newSec - clip.startSec)
                    else -> EffectTimeline.normalized(clip, newSec)
                }
            }
            hub.params = RenderParams.from(settings, aspect, newSec, renderClips(), soloActive)
        }
        if (exportState is ExportState.Done || exportState is ExportState.Failed) exportState = ExportState.Idle
        hub.setLoopSec(e.loopSec.toFloat())
        hub.setFrameRate(e.fps)
    }

    // v38: los deslizadores envían decenas de cambios por segundo. Los parámetros del
    // shader se recalculan como mucho una vez por mensaje del hilo principal (≈ un cuadro):
    // la interfaz no se traba y la vista previa siempre recibe el último valor.
    private var paramsPosted = false
    private val paramsTask = Runnable {
        paramsPosted = false
        // v44: durante la prueba de rendimiento la vista previa muestra los efectos de la prueba.
        if (benchmark?.running != true) hub.params = RenderParams.from(settings, aspect, exportSettings.loopSec.toFloat(), renderClips(), soloActive)
    }
    private fun pushParams() {
        hub.setLoopSec(exportSettings.loopSec.toFloat())
        hub.setFrameRate(exportSettings.fps)
        if (!paramsPosted) { paramsPosted = true; main.post(paramsTask) }
    }
    /** Para exportar: asegura que hub.params refleja ya el último ajuste. */
    private fun flushParams() {
        if (paramsPosted) { main.removeCallbacks(paramsTask); paramsTask.run() }
    }

    // ============================================================ v36: zonas, color y modo


    /** Modo fácil: solo los controles principales. Avanzado: todos los parámetros finos. */
    var advancedMode by mutableStateOf(prefs.getBoolean("advanced", false))
        private set

    fun toggleAdvancedMode() {
        advancedMode = !advancedMode
        prefs.edit().putBoolean("advanced", advancedMode).apply()
        message = if (advancedMode) "Modo avanzado" else "Modo fácil"
    }

    private var boxJob: Job? = null

    /**
     * Mide el rectángulo realmente pintado de las zonas de Movimiento natural y Fuego.
     * El shader fija la raíz (o la base de las llamas) en el borde de ESA zona, no en
     * el borde de la imagen completa. Se guarda en los ajustes para que la
     * exportación use exactamente lo mismo que la vista previa.
     */
    private fun refreshEffectBoxes() {
        val mk = masks ?: return
        val snapshot = settings
        boxJob?.cancel()
        boxJob = viewModelScope.launch {
            delay(120L)
            val updates = withContext(Dispatchers.Default) {
                val out = HashMap<String, Float>()
                for (id in listOf("natural", "flame")) {
                    val slot = (snapshot["$id.mask"] ?: -1f).toInt()
                    val layer = when {
                        slot >= 0 -> slot
                        slot == -1 -> 2   // zona verde heredada
                        else -> -1        // toda la imagen
                    }
                    val b = if (layer >= 0) mk.paintedBounds(layer) else null
                    val v = b ?: floatArrayOf(0f, 0f, 0f, 0f)
                    out["$id.boxX0"] = v[0]; out["$id.boxY0"] = v[1]
                    out["$id.boxX1"] = v[2]; out["$id.boxY1"] = v[3]
                }
                out
            }
            if (updates.any { (k, v) -> settings[k] != v }) {
                settings = settings + updates
                pushParams()
            }
        }
    }

    fun tintOf(id: String): Int? {
        if ((fx["$id.tintOn"] ?: 0f) <= .5f) return null
        fun c(k: String) = ((fx["$id.$k"] ?: 1f).coerceIn(0f, 1f) * 255f + .5f).toInt()
        return (c("tintR") shl 16) or (c("tintG") shl 8) or c("tintB")
    }

    /** Color propio del efecto (0xRRGGBB) o null para volver a la paleta del estilo. */
    fun setTint(id: String, rgb: Int?) {
        updateFx(id, if (rgb == null) mapOf("$id.tintOn" to 0f) else mapOf(
            "$id.tintOn" to 1f,
            "$id.tintR" to ((rgb shr 16) and 0xFF) / 255f,
            "$id.tintG" to ((rgb shr 8) and 0xFF) / 255f,
            "$id.tintB" to (rgb and 0xFF) / 255f))
    }

    fun isBehind(id: String): Boolean = (fx["$id.behind"] ?: 0f) > .5f

    /** Coloca el efecto detrás del personaje pintado en Proteger (o delante). */
    fun setBehind(id: String, behind: Boolean) {
        setSetting("$id.behind", if (behind) 1f else 0f)
        if (behind && !maskHasPaint(0)) message = "Pinta al personaje en Proteger para que el efecto pase por detrás."
    }

    /**
     * v42 · La animación por rutas (Animar › Ruta) aparece en la línea de tiempo como un
     * bloque «Animación», igual que un efecto: se puede mover, recortar, dividir o borrar.
     * Nace cubriendo todo el vídeo, así el movimiento no cambia al aparecer el bloque.
     */
    private fun syncMotionClip(): Boolean {
        val has = arrows.isNotEmpty()
        val own = effectClips.filter { it.effectId == "flow" }
        if (has && own.isEmpty()) {
            val total = exportSettings.loopSec.toFloat()
            effectClips = effectClips + EffectClip(nextClipUid(), "flow", 0f, total)
            if (!isEffectOn("flow")) settings = settings + ("flow.on" to 1f)
            return true
        }
        if (!has && own.isNotEmpty()) {
            effectClips = effectClips.filter { it.effectId != "flow" }
            if (selectedTimelineClip in own.map { it.uid }) selectedTimelineClip = null
            return true
        }
        return false
    }

    private fun recomputeFlow() {
        if (syncMotionClip()) pushParams()
        val a = ArrayList(arrows)
        val an = ArrayList(anchors)
        val asp = aspect
        val reach = settings["flow.reach"] ?: Effects.default("flow.reach")
        flowJob?.cancel()
        flowJob = viewModelScope.launch {
            val data: FlowField.Data = withContext(Dispatchers.Default) { FlowField.compute(a, an, asp, reach) }
            hub.flow = data
        }
    }

    // ============================================================ Reproducción

    fun togglePlay() {
        if (paintingZone) finishPainting()
        if (playing) scrubT = hub.currentT()
        playing = !playing
        hub.setPlaying(playing)
        if (!playing) scrubT = hub.pausedT()
        showGuides = !playing && (tab == EditorTab.MASKS || (tab == EditorTab.TOOLS && tool != Tool.PAN))
        hub.showMask = showMasks && !playing && tool.isBrush
    }

    fun scrubTo(t: Float) {
        scrubT = t
        hub.boostPreview(260)
        hub.setPausedT(t)
    }

    fun toggleMasks() {
        showMasks = !showMasks
        hub.showMask = showMasks && !playing
    }

    // ============================================================ Vista

    fun resetView(animate: Boolean = false) {
        val m = meta
        val crop = if (m != null && !cropEditing) ExportPlanner.cropForSettings(m.w, m.h, exportSettings)
            else floatArrayOf(0f, 0f, 1f, 1f)
        animateCropTo(crop, animate)
    }

    private var cropAnim: Job? = null

    /** Cambia el encuadre mostrado; con animación suave (sin recrear la vista OpenGL). */
    private fun animateCropTo(target: FloatArray, animate: Boolean) {
        cropAnim?.cancel()
        if (!animate || meta == null) {
            cropX = target[0]; cropY = target[1]; cropW = target[2]; cropH = target[3]
            viewScale = 1f; viewX = cropX; viewY = cropY
            syncView()
            return
        }
        val from = floatArrayOf(cropX, cropY, cropW, cropH)
        cropAnim = viewModelScope.launch {
            val start = System.nanoTime()
            val durationMs = 260f
            while (true) {
                val k = ((System.nanoTime() - start) / 1e6f / durationMs).coerceIn(0f, 1f)
                val e = 1f - (1f - k) * (1f - k) * (1f - k)
                cropX = from[0] + (target[0] - from[0]) * e
                cropY = from[1] + (target[1] - from[1]) * e
                cropW = from[2] + (target[2] - from[2]) * e
                cropH = from[3] + (target[3] - from[3]) * e
                viewScale = 1f; viewX = cropX; viewY = cropY
                syncView()
                if (k >= 1f) break
                kotlinx.coroutines.delay(16)
            }
        }
    }

    // ---------------- Encuadre libre (arrastrar y pellizcar el marco)
    var cropEditing by mutableStateOf(false)
        private set

    fun startCropEdit() {
        if (meta == null) return
        if (!cropEditing) {
            cropEditing = true
            if (playing) togglePlay()
            animateCropTo(floatArrayOf(0f, 0f, 1f, 1f), true)
        }
    }

    fun finishCropEdit() {
        if (!cropEditing) return
        cropEditing = false
        resetView(true)
        saveProject()
    }

    /** Marco del encuadre en coordenadas de imagen: [x, y, ancho, alto]. */
    fun cropFrame(): FloatArray {
        val m = meta ?: return floatArrayOf(0f, 0f, 1f, 1f)
        return ExportPlanner.cropForSettings(m.w, m.h, exportSettings)
    }

    /** dx, dy en fracción de imagen; zoom multiplicativo (pellizco). */
    fun moveCrop(dx: Float, dy: Float, zoom: Float) {
        val m = meta ?: return
        val e = exportSettings
        val frame = ExportPlanner.cropForSettings(m.w, m.h, e)
        val newZoom = (e.cropZoom * zoom).coerceIn(1f, 6f)
        val base = ExportPlanner.baseCropSize(m.w, m.h, e)
        val sx = base[0] / newZoom
        val sy = base[1] / newZoom
        val cx = (frame[0] + frame[2] / 2f + dx).coerceIn(sx / 2f, 1f - sx / 2f)
        val cy = (frame[1] + frame[3] / 2f + dy).coerceIn(sy / 2f, 1f - sy / 2f)
        exportSettings = e.copy(cropCx = cx, cropCy = cy, cropZoom = newZoom)
        hub.invalidate()
    }

    fun resetCrop() {
        exportSettings = exportSettings.copy(cropCx = -1f, cropCy = -1f, cropZoom = 1f, cropPos = 0.5f)
        if (!cropEditing) resetView(true) else hub.invalidate()
    }

    private fun syncView() {
        // Una sola invalidación por gesto. Antes se invalidaba 4 veces por cada paso
        // de pinch/pan (aspecto, escala, X, Y), generando trabajo inútil en OpenGL.
        hub.updateView(
            displayAspect = previewAspect,
            width = cropW / viewScale,
            height = cropH / viewScale,
            scale = viewScale,
            x = viewX,
            y = viewY
        )
    }

    /** zoom = factor, pan y centroide en fracción del tamaño de la vista. */
    fun transformView(zoom: Float, panX: Float, panY: Float, cx: Float, cy: Float) {
        // Eventos sin movimiento y valores inválidos no deben activar renderizados.
        if (!zoom.isFinite() || !panX.isFinite() || !panY.isFinite() ||
            !cx.isFinite() || !cy.isFinite() || zoom <= 0f) return
        if (kotlin.math.abs(zoom - 1f) < .00008f &&
            kotlin.math.abs(panX) + kotlin.math.abs(panY) < .00006f) return
        val s0 = viewScale
        val s1 = (s0 * zoom).coerceIn(1f, 10f)
        val x = cx.coerceIn(0f, 1f)
        val y = cy.coerceIn(0f, 1f)
        val ux = viewX + x * cropW / s0
        val uy = viewY + y * cropH / s0
        val nx = (ux - (x + panX) * cropW / s1).coerceIn(cropX, (cropX + cropW - cropW / s1).coerceAtLeast(cropX))
        val ny = (uy - (y + panY) * cropH / s1).coerceIn(cropY, (cropY + cropH - cropH / s1).coerceAtLeast(cropY))
        if (kotlin.math.abs(nx - viewX) + kotlin.math.abs(ny - viewY) < .000005f &&
            kotlin.math.abs(s1 - s0) < .00005f) return
        viewX = nx
        viewY = ny
        viewScale = s1
        if (firstZoomPending) { firstZoomPending = false; perfZoomMs = perfElapsed(); perfLog("primer zoom", perfZoomMs) }
        hub.boostPreview(320)
        syncView()
    }

    fun screenToUv(nx: Float, ny: Float): PointN = PointN(
        (viewX + nx * cropW / viewScale).coerceIn(0f, 1f),
        (viewY + ny * cropH / viewScale).coerceIn(0f, 1f)
    )

    // ============================================================ Edición

    private fun pushUndo(a: UndoAction) {
        undoStack.add(a)
        if (undoStack.size > 200) undoStack.removeAt(0)
        redoStack.clear()
        canRedo = false
        canUndo = true
    }

    fun addArrow(a: Arrow) {
        arrows.add(a)
        pushUndo(UndoAction.AddArrow(a))
        recomputeFlow()
        scheduleAutosave()
    }

    fun addQuickDirection(direction: Int) {
        val vectors = arrayOf(
            PointN(0f, -0.22f), PointN(0.22f, -0.22f), PointN(0.22f, 0f),
            PointN(0.22f, 0.22f), PointN(0f, 0.22f), PointN(-0.22f, 0.22f),
            PointN(-0.22f, 0f), PointN(-0.22f, -0.22f)
        )
        val v = vectors[direction.coerceIn(0, 7)]
        addArrow(Arrow(0.5f - v.x * 0.5f, 0.5f - v.y * 0.5f, 0.5f + v.x * 0.5f, 0.5f + v.y * 0.5f))
        tool = Tool.ARROW
        message = "Flecha añadida: arrástrala o añade anclas."
    }

    fun addAnchor(p: PointN) {
        anchors.add(p)
        pushUndo(UndoAction.AddAnchor(p))
        recomputeFlow()
        scheduleAutosave()
    }

    fun removeArrowAt(i: Int) {
        if (i !in arrows.indices) return
        val a = arrows.removeAt(i)
        pushUndo(UndoAction.RemoveArrow(i, a))
        recomputeFlow()
        scheduleAutosave()
    }

    fun removeAnchorAt(i: Int) {
        if (i !in anchors.indices) return
        val p = anchors.removeAt(i)
        pushUndo(UndoAction.RemoveAnchor(i, p))
        recomputeFlow()
        scheduleAutosave()
    }

    fun clearGuides() {
        if (arrows.isEmpty() && anchors.isEmpty()) return
        pushUndo(UndoAction.ClearGuides(ArrayList(arrows), ArrayList(anchors)))
        arrows.clear()
        anchors.clear()
        recomputeFlow()
        scheduleAutosave()
    }

    /** radiusUv: radio del pincel en fracción de la altura de la imagen. */
    fun beginStroke(p: PointN, radiusUv: Float) {
        val mk = masks ?: return
        val layer = if (tool == Tool.MASK) selectedMaskLayer else tool.layer
        if (layer < 0) return
        val s = MaskStroke(layer, radiusUv, feather, eraser)
        s.points.add(p)
        mk.addStroke(s)
        hub.boostPreview(320)
        currentStroke = s
        pushUndo(UndoAction.AddStroke(s))
    }

    fun continueStroke(p: PointN) {
        val s = currentStroke ?: return
        val last = s.points.lastOrNull()
        if (last != null && hypot((p.x - last.x).toDouble(), (p.y - last.y).toDouble()) < 0.0015) return
        masks?.extendStroke(s, p)
        hub.boostPreview(320)
    }

    fun endStroke() {
        if (currentStroke != null) { scheduleAutosave(); refreshEffectBoxes() }
        currentStroke = null
    }

    fun cancelStroke() {
        val s = currentStroke ?: return
        currentStroke = null
        masks?.removeStroke(s)
        val last = undoStack.lastOrNull()
        if (last is UndoAction.AddStroke && last.stroke === s) undoStack.removeAt(undoStack.size - 1)
        canUndo = undoStack.isNotEmpty()
    }

    /** Rellena (clear=false) o vacía (clear=true) toda la capa de la herramienta actual. */
    fun fillLayer(clear: Boolean) {
        val mk = masks ?: return
        val layer = if (tool == Tool.MASK) selectedMaskLayer else tool.layer
        if (layer < 0) return
        val s = MaskStroke(layer, 0f, 0f, clear, fill = true)
        mk.addStroke(s)
        pushUndo(UndoAction.AddStroke(s))
        scheduleAutosave()
        refreshEffectBoxes()
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val a = undoStack.removeAt(undoStack.size - 1)
        when (a) {
            is UndoAction.EffectSwitches -> {
                settings = settings + a.before - a.absentBefore
                a.beforeClips?.let { clips -> effectClips = clips; selectedTimelineClip = selectedTimelineClip?.takeIf { uid -> clips.any { it.uid == uid } } }
                pushParams()
            }
            is UndoAction.AddArrow -> {
                val i = arrows.lastIndexOf(a.arrow)
                if (i >= 0) arrows.removeAt(i)
                recomputeFlow()
            }
            is UndoAction.AddAnchor -> {
                val i = anchors.lastIndexOf(a.point)
                if (i >= 0) anchors.removeAt(i)
                recomputeFlow()
            }
            is UndoAction.AddStroke -> masks?.removeStroke(a.stroke)
            is UndoAction.RemoveArrow -> {
                arrows.add(a.index.coerceIn(0, arrows.size), a.arrow)
                recomputeFlow()
            }
            is UndoAction.RemoveAnchor -> {
                anchors.add(a.index.coerceIn(0, anchors.size), a.point)
                recomputeFlow()
            }
            is UndoAction.ClearGuides -> {
                arrows.addAll(a.arrows)
                anchors.addAll(a.anchors)
                recomputeFlow()
            }
        }
        redoStack.add(a)
        if (redoStack.size > 200) redoStack.removeAt(0)
        canRedo = true
        canUndo = undoStack.isNotEmpty()
        scheduleAutosave()
        if (a is UndoAction.AddStroke) refreshEffectBoxes()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val a = redoStack.removeAt(redoStack.size - 1)
        when (a) {
            is UndoAction.EffectSwitches -> {
                settings = settings + a.after - a.absentAfter
                a.afterClips?.let { clips -> effectClips = clips; selectedTimelineClip = selectedTimelineClip?.takeIf { uid -> clips.any { it.uid == uid } } }
                pushParams()
            }
            is UndoAction.AddArrow -> {
                arrows.add(a.arrow)
                recomputeFlow()
            }
            is UndoAction.AddAnchor -> {
                anchors.add(a.point)
                recomputeFlow()
            }
            is UndoAction.AddStroke -> masks?.addStroke(a.stroke)
            is UndoAction.RemoveArrow -> {
                val i = arrows.indexOf(a.arrow)
                if (i >= 0) arrows.removeAt(i)
                recomputeFlow()
            }
            is UndoAction.RemoveAnchor -> {
                val i = anchors.indexOf(a.point)
                if (i >= 0) anchors.removeAt(i)
                recomputeFlow()
            }
            is UndoAction.ClearGuides -> {
                arrows.clear()
                anchors.clear()
                recomputeFlow()
            }
        }
        undoStack.add(a)
        if (undoStack.size > 200) undoStack.removeAt(0)
        canUndo = true
        canRedo = redoStack.isNotEmpty()
        scheduleAutosave()
        if (a is UndoAction.AddStroke) refreshEffectBoxes()
    }

    // ============================================================ v16: escenas, personaje, ambiente

    /**
     * Efectos localizados. La primera vez se abre una zona propia en vez de cubrir toda la imagen.
     * La misma máscara también puede reutilizarse en otros efectos desde su panel.
     */
    val zoneEffects = setOf(
        "sky", "water", "dispersion", "zonemotion", "clouds3", "shore", "sunpath", "tornado", "mesh", "natural",
        "ripple", "glint", "sway", "heat", "flame", "eyes", "blink", "cloth", "smoke",
        "energy", "electric", "shock", "pulse", "runes", "bokeh", "sparkle", "lightleak",
        "waterfall", "reflect", "blackaura", "inkdrip", "dramatic",
        "blast", "blood", "slash", "reveal"
    )

    /** v40: efectos con origen en el motor (se colocan tocando la imagen). */
    private val placeableEffects = setOf("tornado", "blast", "blood", "slash", "smoke", "energy", "rays",
        "focus", "speed", "electric", "shock", "runes", "birds", "lensflare", "citylights")
    /** v40: efectos con dirección propia (flecha en la herramienta Posición). */
    private val aimEffects = setOf("smoke", "blast", "blood", "slash", "speed")

    /** Efectos con momento en la línea de tiempo heredada. */
    val eventEffects = listOf("gust", "appear", "impact")

    /** Todos los bloques de un efecto, ordenados como aparecen en el vídeo. */
    // ------------------------------------------------------------ v44: imán de la línea de tiempo
    var magnetOn by mutableStateOf(prefs.getBoolean("magnetOn", true)); private set
    var magnetHaptic by mutableStateOf(prefs.getBoolean("magnetHaptic", true)); private set
    var magnetDp by mutableFloatStateOf(prefs.getFloat("magnetDp", com.zeta.fondo.ui.MagnetState.DEFAULT_DP)); private set

    fun toggleMagnet() {
        setMagnet(on = !magnetOn)
        showHint(if (magnetOn) "Imán activado" else "Imán desactivado: los bloques quedan donde los sueltes", 1600L)
    }

    fun setMagnet(on: Boolean = magnetOn, haptic: Boolean = magnetHaptic, dp: Float = magnetDp) {
        magnetOn = on; magnetHaptic = haptic; magnetDp = dp.coerceIn(4f, 16f)
        prefs.edit().putBoolean("magnetOn", magnetOn).putBoolean("magnetHaptic", magnetHaptic)
            .putFloat("magnetDp", magnetDp).apply()
    }

    /** Bloque cuyo tiempo exacto se está editando (diálogo de 0,01 s). */
    var preciseTimeClip by mutableStateOf<Long?>(null)

    // ------------------------------------------------------------ v44: Ocultar y Solo

    /**
     * Bloque aislado con «Solo» (temporal, NO se guarda en el proyecto). Mientras está activo
     * la vista previa dibuja solo ese bloque: los demás efectos y la animación se ocultan.
     * La música sigue sonando. La exportación nunca usa «Solo»: exporta todos los bloques
     * visibles (el panel de exportar lo avisa).
     */
    var soloClip by mutableStateOf<Long?>(null)
        private set
    val soloActive: Boolean get() = soloClip != null && effectClips.any { it.uid == soloClip && !com.zeta.fondo.model.SoundClips.isSound(it.effectId) }
    /** «Solo» puesto en un bloque de sonido (solo se oye ese). */
    val soundSoloActive: Boolean get() = soloClip != null && effectClips.any { it.uid == soloClip && com.zeta.fondo.model.SoundClips.isSound(it.effectId) }

    /** Bloques que ve la VISTA PREVIA (ocultos y «Solo» aplicados). */
    fun renderClips(list: List<EffectClip> = effectClips): List<EffectClip> {
        val solo = soloClip?.takeIf { s -> list.any { it.uid == s && !com.zeta.fondo.model.SoundClips.isSound(it.effectId) } } ?: return list
        return list.map { if (it.uid != solo && !it.hidden) it.copy(hidden = true) else it }
    }

    fun toggleSolo(uid: Long) {
        soloClip = if (soloClip == uid) null else uid
        hub.params = RenderParams.from(settings, aspect, exportSettings.loopSec.toFloat(), renderClips(), soloActive)
        if (soloClip != null) showHint("Solo: se ve únicamente este bloque. Toca «Mostrar todos» para salir.")
    }

    fun clearSolo() {
        if (soloClip == null) return
        soloClip = null
        hub.params = RenderParams.from(settings, aspect, exportSettings.loopSec.toFloat(), renderClips(), soloActive)
    }

    /** Ojo del bloque: ocultar/mostrar. Se guarda en el proyecto y se puede deshacer. */
    fun toggleClipHidden(uid: Long) {
        val clip = effectClips.firstOrNull { it.uid == uid } ?: return
        val before = effectClips.toList()
        effectClips = effectClips.map { if (it.uid == uid) it.copy(hidden = !it.hidden) else it }
        commitTimeline(before)
        hub.params = RenderParams.from(settings, aspect, exportSettings.loopSec.toFloat(), renderClips(), soloActive)
        saveProject()
        val name = Effects.all.firstOrNull { it.id == clip.effectId }?.title?.substringBefore(" (") ?: "Bloque"
        showHint(if (!clip.hidden) "$name oculto (no se exporta)" else "$name visible")
    }

    // ------------------------------------------------------------ v44: fotogramas clave

    /** Bloque que recibe las claves de [id]: el seleccionado, el que se edita o el único. */
    fun keyClip(id: String): EffectClip? = selectedClip()?.takeIf { it.effectId == id }
        ?: fxTarget(id) ?: clipsForEffect(id).let { list ->
            val now = scrubT * exportSettings.loopSec
            list.firstOrNull { now >= it.startSec - .01f && now <= it.endSec + .01f } ?: list.firstOrNull()
        }

    /** Segundo local del cabezal dentro del bloque (null si está fuera). */
    fun keyLocal(clip: EffectClip): Float? {
        val now = (if (playing) hub.currentT() else scrubT) * exportSettings.loopSec
        val local = now - clip.startSec
        return if (local < -.01f || local > clip.durationSec + .01f) null else local.coerceIn(0f, clip.durationSec)
    }

    fun canKeyframe(key: String): Boolean = com.zeta.fondo.model.Keyframes.animatable(key) &&
        key.substringBefore('.') != "style" && key.substringBefore('.') != "elements"

    fun keysOf(key: String): List<com.zeta.fondo.model.Keyframe> = keyClip(key.substringBefore('.'))?.keys?.get(key).orEmpty()

    /** Valor animado de [key] en el cabezal (null si no tiene claves). */
    fun keyedValue(key: String): Float? {
        val clip = keyClip(key.substringBefore('.')) ?: return null
        val ks = clip.keys[key] ?: return null
        val local = keyLocal(clip) ?: (scrubT * exportSettings.loopSec - clip.startSec).coerceIn(0f, clip.durationSec)
        return com.zeta.fondo.model.Keyframes.valueAt(ks, local)
    }

    /** ¿Hay una clave de [key] justo en el cabezal? */
    fun keyAtPlayhead(key: String): com.zeta.fondo.model.Keyframe? {
        val clip = keyClip(key.substringBefore('.')) ?: return null
        val local = keyLocal(clip) ?: return null
        return com.zeta.fondo.model.Keyframes.at(clip.keys[key], local)
    }

    private fun updateKeys(clip: EffectClip, key: String, keys: List<com.zeta.fondo.model.Keyframe>) {
        effectClips = effectClips.map {
            if (it.uid != clip.uid) it
            else it.copy(keys = if (keys.isEmpty()) it.keys - key else it.keys + (key to keys))
        }
        hub.boostPreview()
        pushParams()
        scheduleAutosave()
    }

    /** Rombo: añade una clave en el cabezal con el valor actual, o la quita si ya hay una. */
    fun toggleKeyframe(key: String) {
        val id = key.substringBefore('.')
        val clip = keyClip(id) ?: run { message = "Primero añade el efecto a la línea de tiempo."; return }
        val local = keyLocal(clip) ?: run { message = "Coloca el cabezal dentro del bloque para poner una clave."; return }
        if (playing) togglePlay()
        val ks = clip.keys[key].orEmpty()
        if (com.zeta.fondo.model.Keyframes.at(ks, local) != null) {
            updateKeys(clip, key, com.zeta.fondo.model.Keyframes.remove(ks, local))
            showHint("Clave quitada", 1200L)
        } else {
            val v = keyedValue(key) ?: fx[key] ?: if (com.zeta.fondo.model.SoundClips.isSound(id))
                (clip.overrides[key] ?: com.zeta.fondo.model.SoundClips.defaults[key.substringAfter('.')] ?: 0f) else Effects.default(key)
            updateKeys(clip, key, com.zeta.fondo.model.Keyframes.put(ks, local, v))
            showHint(if (ks.isEmpty()) "Primera clave. Mueve el cabezal y cambia el valor: se crea otra clave sola." else "Clave añadida", 2600L)
        }
    }

    fun setKeyCurve(key: String, curve: Int) {
        val clip = keyClip(key.substringBefore('.')) ?: return
        val local = keyLocal(clip) ?: return
        val ks = clip.keys[key].orEmpty()
        val k = com.zeta.fondo.model.Keyframes.at(ks, local) ?: return
        updateKeys(clip, key, com.zeta.fondo.model.Keyframes.put(ks, k.t, k.value, curve))
    }

    fun clearKeyframes(key: String) {
        val clip = keyClip(key.substringBefore('.')) ?: return
        updateKeys(clip, key, emptyList())
        showHint("Animación de este control borrada", 1600L)
    }

    /**
     * Si [key] ya está animado, cambiar su valor crea o actualiza la clave del cabezal
     * (como en un editor de vídeo). Devuelve true si lo gestionó.
     */
    private fun autoKey(key: String, value: Float): Boolean {
        val clip = keyClip(key.substringBefore('.')) ?: return false
        val ks = clip.keys[key] ?: return false
        if (ks.isEmpty()) return false
        val local = keyLocal(clip) ?: return false
        if (playing) togglePlay()
        updateKeys(clip, key, com.zeta.fondo.model.Keyframes.put(ks, local, value))
        return true
    }

    fun clipsForEffect(id: String): List<EffectClip> = effectClips.filter { it.effectId == id }.sortedBy { it.startSec }

    private fun nextClipUid(): Long = (effectClips.maxOfOrNull { it.uid } ?: 0L) + 1L

    fun selectTimelineClip(uid: Long?) {
        val next = uid?.takeIf { id -> effectClips.any { it.uid == id } }
        if (next != selectedTimelineClip) placingClip = false
        // v40: al tocar un bloque se edita por contexto: se cierran las opciones de la
        // categoría y abajo aparecen las acciones del bloque (como en un editor de vídeo).
        if (next != null && editingEffect == null && replacingClip == null && !paintingZone) optionsOpen = false
        if (next != null) imageSelected = false
        selectedTimelineClip = next
    }

    private fun clipsOverlap(aStart: Float, aDuration: Float, bStart: Float, bDuration: Float): Boolean {
        val aEnd = aStart + aDuration
        val bEnd = bStart + bDuration
        return aStart < bEnd - .015f && bStart < aEnd - .015f
    }

    /**
     * Pistas efectivas para proyectos antiguos y nuevos. Los clips v20-v22 no guardaban
     * pista: se colocan automáticamente en el primer hueco libre sin alterar su tiempo.
     */
    private fun resolvedTimelineTracks(excludeUid: Long? = null): Map<Long, Int> {
        val assigned = LinkedHashMap<Long, Int>()
        val sorted = effectClips.filter { it.uid != excludeUid }
            .sortedWith(compareBy<EffectClip> { it.startSec }.thenBy { it.uid })
        for (clip in sorted) {
            var lane = clip.track
            fun laneFree(candidate: Int): Boolean = effectClips.none { other ->
                other.uid != clip.uid && assigned[other.uid] == candidate &&
                    clipsOverlap(clip.startSec, clip.durationSec, other.startSec, other.durationSec)
            }
            if (lane < 0 || !laneFree(lane)) {
                lane = 0
                while (!laneFree(lane)) lane++
            }
            assigned[clip.uid] = lane
        }
        return assigned
    }

    fun timelineTrackOf(uid: Long): Int = resolvedTimelineTracks()[uid] ?: 0

    /** Solo permite dejar un bloque en una pista si hay espacio temporal real. */
    fun isTimelineTrackFree(uid: Long, startSec: Float, durationSec: Float, track: Int): Boolean {
        if (track < 0) return false
        val tracks = resolvedTimelineTracks(uid)
        return effectClips.none { other ->
            other.uid != uid && tracks[other.uid] == track &&
                clipsOverlap(startSec, durationSec, other.startSec, other.durationSec)
        }
    }

    /** Busca la pista libre más cercana; nunca impone un número fijo de pistas. */
    fun suggestTimelineTrack(uid: Long, startSec: Float, durationSec: Float, preferredTrack: Int): Int {
        val preferred = preferredTrack.coerceAtLeast(0)
        if (isTimelineTrackFree(uid, startSec, durationSec, preferred)) return preferred
        val radius = effectClips.size + 2 // con N clips siempre existe una pista libre dentro de N+1
        for (d in 1..radius) {
            val up = preferred - d
            if (up >= 0 && isTimelineTrackFree(uid, startSec, durationSec, up)) return up
            val down = preferred + d
            if (isTimelineTrackFree(uid, startSec, durationSec, down)) return down
        }
        return preferred + radius
    }

    /** Confirma tiempo + pista en una sola operación para que mover arriba/abajo no salte. */
    fun setEffectClipPlacement(uid: Long, startSec: Float, durationSec: Float, track: Int) {
        val total = exportSettings.loopSec.toFloat()
        val before = effectClips.toList()
        val safeTrack = suggestTimelineTrack(uid, startSec, durationSec, track)
        effectClips = effectClips.map { clip ->
            if (clip.uid == uid) {
                // v44: recortar por la izquierda (el final no se mueve) deja las claves en su
                // tiempo real; mover el bloque entero las lleva con él.
                val leftTrim = kotlin.math.abs((startSec + durationSec) - clip.endSec) < 1e-3f &&
                    kotlin.math.abs(startSec - clip.startSec) > 1e-4f
                val keys = if (leftTrim) com.zeta.fondo.model.Keyframes.shift(clip.keys, startSec - clip.startSec) else clip.keys
                EffectTimeline.normalized(clip.copy(startSec = startSec, durationSec = durationSec, track = safeTrack, keys = keys), total)
            } else clip
        }
        selectedTimelineClip = uid
        hub.params = RenderParams.from(settings, aspect, total, renderClips(), soloActive)
        // v40: mover y recortar se pueden deshacer.
        commitTimeline(before)
    }

    private fun legacyTimelineClips(id: String): List<EffectClip> {
        val total = exportSettings.loopSec.toFloat().coerceAtLeast(2f)
        var uid = nextClipUid()
        fun clip(start: Float, dur: Float): EffectClip = EffectTimeline.normalized(
            EffectClip(uid++, id, start, dur), total)
        return when (id) {
            "gust" -> {
                val dur = (settings["gust.dur"] ?: .45f).coerceIn(.1f, 1f)
                if (dur >= .999f) listOf(clip(0f, total)) else
                    listOf(clip((settings["gust.start"] ?: .1f) * total, dur * total))
            }
            "appear" -> {
                val start = (settings["appear.start"] ?: .3f).coerceIn(0f, .95f) * total
                listOf(clip(start, (total - start).coerceAtLeast(.25f)))
            }
            "impact" -> {
                val n = (settings["impact.cycles"] ?: 1f).toInt().coerceIn(1, 4)
                val phase = (settings["impact.start"] ?: .3f).coerceIn(0f, .95f)
                (0 until n).map { k -> clip(((k + phase) / n) * total, minOf(.85f, total / n)) }
            }
            "bolt" -> {
                val n = (settings["bolt.cycles"] ?: 1f).toInt().coerceIn(1, 6)
                (0 until n).map { k -> clip(com.zeta.fondo.engine.Ambient.boltPhase(k, n) * total, minOf(.7f, total / n)) }
            }
            else -> listOf(clip(0f, total))
        }
    }

    /**
     * v37: los efectos ambientales (humo, agua, nubes, fuego, lluvia…) cubren TODO el
     * vídeo por defecto: antes nacían como un bloque de 2 s en el centro y parecía que
     * "se apagaban y volvían a empezar". Los eventos (explosión, corte…) nacen en modo
     * Una vez, en la posición del cabezal, con su duración natural.
     */
    private fun defaultExtraClip(id: String): EffectClip {
        val total = exportSettings.loopSec.toFloat().coerceAtLeast(2f)
        if (id !in Effects.eventEffects) {
            // v42: como en un editor de vídeo, el efecto nuevo empieza en el cabezal (la línea
            // blanca) y llega hasta el final; luego se estira o se acorta con sus tiradores.
            // Con el cabezal al inicio cubre todo el vídeo, como antes.
            val at = (scrubT.coerceIn(0f, 1f) * total).let { if (it < .25f) 0f else it }
            val start = if (total - at < 1f) (total - minOf(3f, total)).coerceAtLeast(0f) else at
            return EffectTimeline.normalized(EffectClip(nextClipUid(), id, start, total - start), total)
        }
        if (!settings.containsKey("$id.mode")) settings = settings + ("$id.mode" to EventMode.ONCE.toFloat())
        val duration = Effects.eventDuration(id).coerceIn(.08f, total)
        val start = (scrubT * total).coerceIn(0f, (total - duration).coerceAtLeast(0f))
        return EffectTimeline.normalized(EffectClip(nextClipUid(), id, start, duration), total)
    }

    fun eventMode(id: String): Int = (settings["$id.mode"] ?: EventMode.LOOP.toFloat()).toInt()

    /** Continuo (N veces por bucle) · Una vez (en su bloque) · Repetir (cada X s). */
    fun setEventMode(id: String, mode: Int) {
        val total = exportSettings.loopSec.toFloat()
        val before = effectClips.toList()
        settings = settings + ("$id.mode" to mode.toFloat()) +
            (if (mode == EventMode.REPEAT && !settings.containsKey("$id.every")) mapOf("$id.every" to 2f) else emptyMap())
        val clips = clipsForEffect(id)
        val target = clips.firstOrNull { it.uid == selectedTimelineClip } ?: clips.firstOrNull()
        if (target != null) {
            val placed = when (mode) {
                EventMode.ONCE -> {
                    val d = Effects.eventDuration(id).coerceAtMost(total)
                    val start = if (target.durationSec >= total - .05f) (scrubT * total).coerceIn(0f, total - d) else target.startSec
                    target.copy(startSec = start, durationSec = d)
                }
                else -> target.copy(startSec = 0f, durationSec = total)
            }
            effectClips = effectClips.map { if (it.uid == target.uid) EffectTimeline.normalized(placed, total) else it }
            selectedTimelineClip = target.uid
        }
        pushUndo(UndoAction.EffectSwitches(emptyMap(), emptyMap(), before, effectClips.toList()))
        hub.boostPreview()
        pushParams()
        scheduleAutosave()
    }

    private fun ensureTimelineActivation(id: String) {
        val wasOn = (settings["$id.on"] ?: 0f) > .5f
        if (!wasOn) settings = settings + com.zeta.fondo.model.EffectDefaults.firstActivation(id, settings) + ("$id.on" to 1f)
        if (!settings.containsKey("$id.mask") && id != "appear" && id != "impact") {
            settings = settings + ("$id.mask" to -2f)
        }
        if (clipsForEffect(id).isEmpty()) {
            // v40: un efecto NUEVO nace con su bloque natural (los eventos, en el cabezal y en
            // modo Una vez). Solo un proyecto antiguo con el efecto ya activo y sin bloques
            // se convierte con sus tiempos heredados.
            val first = if (wasOn) legacyTimelineClips(id).firstOrNull() ?: defaultExtraClip(id) else defaultExtraClip(id)
            effectClips = effectClips + first
        }
        val own = clipsForEffect(id)
        if (own.none { it.uid == selectedTimelineClip }) selectedTimelineClip = own.firstOrNull()?.uid
        pushParams()
    }

    /**
     * Duplica un bloque conservando exactamente la configuración del efecto.
     * v29: la copia nace EN EL MISMO TIEMPO que el original y en la primera pista
     * libre inmediatamente inferior. Así queda visualmente alineada, como en CapCut,
     * y luego el usuario decide si la mueve.
     */
    fun duplicateEffectClip(uid: Long): Long? {
        val source = effectClips.firstOrNull { it.uid == uid } ?: return null
        val total = exportSettings.loopSec.toFloat().coerceAtLeast(2f)
        val before = effectClips.toList()
        val newUid = nextClipUid()
        val sourceTrack = timelineTrackOf(source.uid)
        // v40.1: como en un editor de vídeo, la copia va JUSTO DESPUÉS del original (o justo
        // antes si no cabe). Solo si el bloque ocupa todo el vídeo se coloca debajo, en el
        // mismo tiempo: dos copias simultáneas del mismo efecto se ven como una más intensa.
        val dur = source.durationSec
        val after = source.endSec
        val beforeStart = source.startSec - dur
        val (start, track) = when {
            after + dur <= total + .001f ->
                after to suggestTimelineTrack(newUid, after, dur.coerceAtMost(total - after), sourceTrack)
            beforeStart >= -.001f ->
                beforeStart.coerceAtLeast(0f) to suggestTimelineTrack(newUid, beforeStart.coerceAtLeast(0f), dur, sourceTrack)
            else -> {
                var t = sourceTrack + 1
                while (!isTimelineTrackFree(newUid, source.startSec, dur, t)) t++
                source.startSec to t
            }
        }
        val copy = EffectTimeline.normalized(source.copy(uid = newUid, startSec = start, track = track), total)
        effectClips = effectClips + copy
        selectedTimelineClip = copy.uid
        pushUndo(UndoAction.EffectSwitches(emptyMap(), emptyMap(), before, effectClips.toList()))
        pushParams()
        saveProject()
        val overlaps = copy.startSec < source.endSec - .01f && source.startSec < copy.endSec - .01f
        message = if (overlaps) "Bloque duplicado debajo (mismo tiempo): se dibujan los dos." else "Bloque duplicado a continuación."
        return copy.uid
    }

    /**
     * Añade otra aparición. Si ya hay un bloque del mismo efecto, el botón + ahora
     * duplica el seleccionado (o el más cercano) en vez de crear uno con duración genérica.
     */
    fun addEffectClip(id: String) {
        if (id == "style" || id == "elements") return
        var existing = clipsForEffect(id)
        // Proyectos antiguos podían tener el efecto encendido sin bloques. Al migrar,
        // conservamos una sola aparición base y después la duplicamos.
        if (existing.isEmpty() && isEffectOn(id)) {
            legacyTimelineClips(id).firstOrNull()?.let { effectClips = effectClips + it }
            existing = clipsForEffect(id)
        }
        if (!isEffectOn(id)) settings = settings + ("$id.on" to 1f)
        if (!settings.containsKey("$id.mask") && id != "appear" && id != "impact")
            settings = settings + ("$id.mask" to -2f)

        val source = existing.firstOrNull { it.uid == selectedTimelineClip }
            ?: existing.minByOrNull { kotlin.math.abs(it.startSec - scrubT * exportSettings.loopSec) }
        if (source != null) {
            duplicateEffectClip(source.uid)
            return
        }

        val before = effectClips.toList()
        val added = defaultExtraClip(id)
        effectClips = effectClips + added
        selectedTimelineClip = added.uid
        pushUndo(UndoAction.EffectSwitches(emptyMap(), emptyMap(), before, effectClips.toList()))
        pushParams(); saveProject()
    }

    /**
     * Toque normal en una tarjeta de efecto, estilo editor de vídeo:
     * - si no existe, crea UN solo bloque;
     * - si ya existe, únicamente lo selecciona;
     * - nunca duplica ni elimina por accidente.
     * Las repeticiones se crean exclusivamente con el botón +.
     */
    fun activateOrSelectEffect(id: String) {
        if (id == "style" || id == "elements") { editEffect(id); return }
        val existing = clipsForEffect(id)
        if (existing.isNotEmpty()) {
            val total = exportSettings.loopSec.toFloat().coerceAtLeast(2f)
            val at = scrubT.coerceIn(0f, .999f) * total
            val chosen = existing.firstOrNull { at >= it.startSec && at <= it.startSec + it.durationSec }
                ?: existing.minByOrNull { kotlin.math.abs(it.startSec - at) }
                ?: existing.first()
            selectedTimelineClip = chosen.uid
            return
        }
        if (isEffectOn(id)) {
            // Compatibilidad con un proyecto previo sin timeline guardada: convertir a un único bloque.
            val migrated = legacyTimelineClips(id).firstOrNull() ?: defaultExtraClip(id)
            effectClips = effectClips + migrated
            selectedTimelineClip = migrated.uid
            pushParams(); saveProject()
            return
        }
        if (id == "appear") { editEffect(id); return }
        if (id in zoneEffects && !settings.containsKey("$id.mask")) { editEffect(id); return }
        settings = settings + ("$id.on" to 1f) +
            (if (!settings.containsKey("$id.mask") && id != "impact") mapOf("$id.mask" to -2f) else emptyMap())
        val clip = defaultExtraClip(id)
        effectClips = effectClips + clip
        selectedTimelineClip = clip.uid
        pushParams(); saveProject()
    }

    /** Convierte el bloque seleccionado en continuo; no crea una segunda copia inesperada. */
    fun addWholeVideoEffectClip(id: String) {
        if (id == "style" || id == "elements") return
        val total = exportSettings.loopSec.toFloat()
        if (!isEffectOn(id)) settings = settings + ("$id.on" to 1f)
        if (!settings.containsKey("$id.mask") && id != "appear" && id != "impact")
            settings = settings + ("$id.mask" to -2f)
        val clips = clipsForEffect(id)
        val target = clips.firstOrNull { it.uid == selectedTimelineClip } ?: clips.firstOrNull()
        if (target != null) {
            effectClips = effectClips.map { if (it.uid == target.uid) it.copy(startSec = 0f, durationSec = total) else it }
            selectedTimelineClip = target.uid
        } else {
            val clip = EffectClip(nextClipUid(), id, 0f, total)
            effectClips = effectClips + clip
            selectedTimelineClip = clip.uid
        }
        pushParams(); saveProject()
    }

    /** Intensidad propia de cada bloque, incluso cuando varios del mismo efecto se solapan. */
    fun setEffectClipStrength(uid: Long, strength: Float) {
        if (effectClips.none { it.uid == uid }) return
        effectClips = effectClips.map { clip ->
            if (clip.uid == uid) clip.copy(strength = strength.coerceIn(0f, 2f)) else clip
        }
        selectedTimelineClip = uid
        hub.boostPreview(320)
        hub.params = RenderParams.from(settings, aspect, exportSettings.loopSec.toFloat(), renderClips(), soloActive)
        // Mientras hay un panel en edición, finishEdit(true) guarda todos los cambios.
        if (editingEffect == null) saveProject()
    }

    fun setEffectClipTiming(uid: Long, startSec: Float, durationSec: Float) {
        val total = exportSettings.loopSec.toFloat()
        effectClips = effectClips.map { clip ->
            if (clip.uid == uid) EffectTimeline.normalized(clip.copy(startSec = startSec, durationSec = durationSec), total) else clip
        }
        selectedTimelineClip = uid
        hub.boostPreview(320)
        // La duración del proyecto no cambió: actualizarla aquí reiniciaba innecesariamente
        // el reloj del preview en cada píxel del arrastre. Solo reconstruimos los parámetros.
        hub.params = RenderParams.from(settings, aspect, total, renderClips(), soloActive)
    }

    /**
     * Vista previa ligera mientras se arrastra un bloque de la línea de tiempo.
     * No toca el estado Compose ni guarda el proyecto; así el dedo mueve el bloque sin
     * recomponer toda la pantalla. La posición definitiva se confirma al soltar.
     */
    fun previewEffectClipMove(uid: Long, startSec: Float) {
        val original = effectClips.firstOrNull { it.uid == uid } ?: return
        previewEffectClipTiming(uid, startSec, original.durationSec)
    }

    /** Preview sin recomposición para mover o redimensionar un bloque. */
    fun previewEffectClipTiming(uid: Long, startSec: Float, durationSec: Float) {
        val total = exportSettings.loopSec.toFloat()
        val original = effectClips.firstOrNull { it.uid == uid } ?: return
        val preview = EffectTimeline.normalized(
            original.copy(startSec = startSec, durationSec = durationSec), total)
        val previewClips = effectClips.map { if (it.uid == uid) preview else it }
        hub.boostPreview(320)
        hub.params = RenderParams.from(settings, aspect, total, renderClips(previewClips), soloActive)
    }

    fun moveEffectClip(uid: Long, startSec: Float) {
        val clip = effectClips.firstOrNull { it.uid == uid } ?: return
        setEffectClipTiming(uid, startSec, clip.durationSec)
    }

    fun removeEffectClip(uid: Long) {
        val clip = effectClips.firstOrNull { it.uid == uid } ?: return
        val beforeClips = effectClips.toList()
        val beforeSettings = settings
        effectClips = effectClips.filterNot { it.uid == uid }
        val remaining = clipsForEffect(clip.effectId)
        if (remaining.isEmpty()) settings = settings + ("${clip.effectId}.on" to 0f)
        else if (remaining.size == 1 && remaining[0].overrides.isNotEmpty()) {
            // Queda un solo bloque: sus ajustes propios pasan a ser los del efecto.
            val last = remaining[0]
            settings = settings + last.overrides.filterKeys { ClipEdits.isClipKey(last.effectId, it) }
            effectClips = effectClips.map { if (it.uid == last.uid) it.copy(overrides = emptyMap()) else it }
        }
        selectedTimelineClip = null
        placingClip = false
        commitTimeline(beforeClips, beforeSettings)
        pushParams(); saveProject()
        showUndoNotice("${Effects.all.firstOrNull { it.id == clip.effectId }?.title?.substringBefore(" (") ?: "Efecto"} eliminado")
    }

    /** v40: divide el bloque seleccionado en el cabezal (dos bloques independientes). */
    fun splitEffectClip(uid: Long) {
        val clip = effectClips.firstOrNull { it.uid == uid } ?: return
        val at = scrubT * exportSettings.loopSec
        val raw = ClipEdits.split(clip, at, nextClipUid())
        if (raw == null) { message = "Coloca el cabezal dentro del bloque para dividirlo."; return }
        // v44: las claves se reparten y ambas mitades reciben el valor exacto del corte.
        val parts = if (clip.keys.isEmpty()) raw else {
            val (kl, kr) = com.zeta.fondo.model.Keyframes.split(clip.keys, at - clip.startSec)
            raw.first.copy(keys = kl) to raw.second.copy(keys = kr)
        }
        val before = effectClips.toList()
        effectClips = effectClips.flatMap { if (it.uid == uid) listOf(parts.first, parts.second) else listOf(it) }
        selectedTimelineClip = parts.second.uid
        commitTimeline(before)
        pushParams(); saveProject()
    }

    /** v40: cambia el efecto del bloque conservando su tiempo, pista y posición. */
    fun replaceClipEffect(uid: Long, newId: String) {
        val clip = effectClips.firstOrNull { it.uid == uid } ?: return
        replacingClip = null
        if (newId == clip.effectId || newId == "elements" || newId == "style") { optionsOpen = false; return }
        val beforeClips = effectClips.toList()
        val beforeSettings = settings
        val replaced = ClipEdits.replaceEffect(clip, newId)
        effectClips = effectClips.map { if (it.uid == uid) replaced else it }
        var next = settings + ("$newId.on" to 1f)
        if (!next.containsKey("$newId.mask")) next = next + ("$newId.mask" to -2f)
        if (newId in Effects.eventEffects && !next.containsKey("$newId.mode")) next = next + ("$newId.mode" to EventMode.ONCE.toFloat())
        if (clipsForEffect(clip.effectId).isEmpty()) next = next + ("${clip.effectId}.on" to 0f)
        settings = next
        selectedTimelineClip = uid
        optionsOpen = false
        commitTimeline(beforeClips, beforeSettings)
        pushParams(); saveProject()
        message = "Efecto sustituido"
    }

    fun removeEffectClips(id: String) {
        effectClips = effectClips.filterNot { it.effectId == id }
        selectedTimelineClip = null
        settings = settings + ("$id.on" to 0f)
        pushParams(); saveProject()
    }

    val boltCount: Int get() = if ((settings["bolt.on"] ?: 0f) > .5f) (settings["bolt.cycles"] ?: 1f).toInt().coerceIn(1, 6) else 0

    fun isEffectOn(id: String): Boolean = (settings["$id.on"] ?: 0f) > .5f

    /** Toque corto en la tarjeta: activa/quita el efecto completo. El botón + añade repeticiones. */
    fun toggleEffect(id: String) {
        if (id == "elements") { editEffect(id); return }
        if (id == "appear" && !isEffectOn(id)) { editEffect(id); return }
        val on = isEffectOn(id)
        if (!on && id in zoneEffects && !settings.containsKey("$id.mask")) { editEffect(id); return }
        val before = mapOf("$id.on" to (if (on) 1f else 0f))
        val after = mapOf("$id.on" to (if (on) 0f else 1f))
        val beforeClips = effectClips.toList()
        settings = settings + after + (if (!on && !settings.containsKey("$id.mask")) mapOf("$id.mask" to -2f) else emptyMap())
        if (on) {
            effectClips = effectClips.filterNot { it.effectId == id }
            if (selectedTimelineClip?.let { uid -> effectClips.none { it.uid == uid } } != false) selectedTimelineClip = null
        } else if (clipsForEffect(id).isEmpty()) {
            val first = defaultExtraClip(id)
            effectClips = effectClips + first
            selectedTimelineClip = first.uid
        }
        pushUndo(UndoAction.EffectSwitches(before, after, beforeClips, effectClips.toList()))
        pushParams()
        saveProject()
    }

    /** Mueve el momento (0..1) de un efecto de evento desde la línea de tiempo. */
    fun setEventStart(id: String, t: Float) {
        settings = settings + ("$id.start" to t.coerceIn(0f, 0.95f))
        pushParams()
    }

    /** Toca la imagen para colocar el centro u origen del efecto. */
    fun pickOrigin(id: String) {
        activeMotionEffect = id
        tool = Tool.ORIGIN
        if (playing) togglePlay()
        showGuides = true
        message = "Toca la imagen para elegir el origen."
    }

    var hasCharacter by mutableStateOf(false)
        private set

    private fun loadCharacter(dir: java.io.File): Bitmap? {
        val f = java.io.File(dir, CHARACTER_FILE)
        val bmp = if (f.isFile) try { BitmapUtil.decodeAtMost(f, 2048) } catch (e: Exception) { null } else null
        main.post { hasCharacter = bmp != null }
        return bmp
    }

    /** Copia el PNG del personaje al proyecto (conserva la transparencia). */
    fun importCharacter(uri: Uri) {
        val project = meta ?: return
        busy = "Cargando personaje…"
        viewModelScope.launch {
            try {
                val bmp = withContext(Dispatchers.IO) {
                    val resolver = getApplication<Application>().contentResolver
                    val decoded = resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) }
                        ?: error("No se pudo leer la imagen")
                    val long = maxOf(decoded.width, decoded.height)
                    val scaled = if (long > 2048) {
                        val k = 2048f / long
                        Bitmap.createScaledBitmap(decoded, (decoded.width * k).toInt().coerceAtLeast(1),
                            (decoded.height * k).toInt().coerceAtLeast(1), true).also { if (it !== decoded) decoded.recycle() }
                    } else decoded
                    java.io.File(project.dir, CHARACTER_FILE).outputStream().use {
                        scaled.compress(Bitmap.CompressFormat.PNG, 100, it)
                    }
                    scaled
                }
                hub.character = bmp
                hasCharacter = true
                settings = settings + mapOf("appear.hasImage" to 1f, "appear.on" to 1f)
                if (clipsForEffect("appear").isEmpty()) effectClips = effectClips + legacyTimelineClips("appear")
                pushParams()
                saveProject()
                if (!bmp.hasAlpha()) message = "La imagen no tiene fondo transparente: usa un PNG recortado para mejor resultado."
            } catch (e: Exception) {
                message = "No se pudo cargar el personaje: ${e.message}"
            } finally { busy = null }
        }
    }

    fun transformCharacter(dx: Float, dy: Float, zoom: Float, rotation: Float) {
        settings = settings + mapOf(
            "appear.x" to ((settings["appear.x"] ?: .5f) + dx).coerceIn(-0.2f, 1.2f),
            "appear.y" to ((settings["appear.y"] ?: .62f) + dy).coerceIn(-0.2f, 1.2f),
            "appear.size" to ((settings["appear.size"] ?: .6f) * zoom).coerceIn(.05f, 2f),
            "appear.rot" to ((((settings["appear.rot"] ?: 0f) + rotation + 540f) % 360f) - 180f))
        pushParams()
    }

    /** Enciende o apaga un sonido de ambiente (volumen inicial 70 %). */
    fun toggleAmbient(id: String) {
        // v44: los ambientes son bloques de sonido de la línea de tiempo.
        val existing = effectClips.filter { it.effectId == com.zeta.fondo.model.SoundClips.clipId(id) }
        if (existing.isNotEmpty()) {
            val before = effectClips.toList()
            effectClips = effectClips - existing.toSet()
            commitTimeline(before); saveProject()
        } else addSound(id)
    }

    // ------------------------------------------------------------ v44: sonidos en la línea de tiempo

    /** Bloque de sonido abierto en Ajustar (null = ninguno). */
    var soundEditing by mutableStateOf<Long?>(null)
    var soundCategory by mutableStateOf(com.zeta.fondo.model.SoundCatalog.categories.first())

    /** Ajustes de audio con los bloques de sonido actuales. [forExport]: sin «Solo». */
    fun audioSettings(forExport: Boolean = false): ExportSettings {
        val solo = if (forExport) null else soloClip
        return exportSettings.copy(
            sounds = com.zeta.fondo.model.SoundClips.tracks(effectClips, settings, solo),
            soundDir = meta?.dir?.path ?: "",
            musicMuted = !forExport && com.zeta.fondo.model.SoundClips.musicMuted(effectClips, soloClip))
    }

    /** Añade un sonido en el cabezal: los ambientes hasta el final; los eventos, un golpe corto. */
    fun addSound(sound: String) {
        val total = exportSettings.loopSec.toFloat()
        val event = com.zeta.fondo.engine.Ambient.isOneShot(sound) || com.zeta.fondo.model.SoundCatalog.find(sound)?.event == true
        val now = (scrubT * total).coerceIn(0f, total)
        val start = if (event) now.coerceAtMost((total - .5f).coerceAtLeast(0f)) else if (now < .1f || total - now < 1f) 0f else now
        val dur = if (event) minOf(1.6f, total - start) else total - start
        val id = com.zeta.fondo.model.SoundClips.clipId(sound)
        val ov = if (event) mapOf("$id.fadein" to 0f, "$id.fadeout" to .05f) else emptyMap()
        val uid = nextClipUid()
        val before = effectClips.toList()
        val clip = EffectClip(uid, id, start, dur.coerceAtLeast(ClipEdits.MIN_DURATION), overrides = ov)
        effectClips = effectClips + clip.copy(track = suggestTimelineTrack(uid, clip.startSec, clip.durationSec, 0))
        selectedTimelineClip = uid
        commitTimeline(before)
        saveProject()
        showHint("${com.zeta.fondo.model.SoundCatalog.title(sound)} añadido. Arrástralo o recórtalo en la línea de tiempo.", 2200L)
    }

    fun openSoundClip(uid: Long) {
        if (effectClips.none { it.uid == uid }) return
        if (editingEffect != null) finishEdit(true)
        beginEdit()
        soundEditing = uid
        selectedTimelineClip = uid
    }

    fun closeSoundClip(commit: Boolean) {
        soundEditing = null
        finishEdit(commit)
    }

    /** Valor actual (bloque, efecto o por defecto) de un ajuste de sonido. */
    fun soundValue(clip: EffectClip, suffix: String): Float {
        val key = "${clip.effectId}.$suffix"
        val local = keyLocal(clip)
        clip.keys[key]?.takeIf { it.isNotEmpty() && local != null }?.let { return com.zeta.fondo.model.Keyframes.valueAt(it, local!!)!! }
        return clip.overrides[key] ?: settings[key] ?: com.zeta.fondo.model.SoundClips.defaults[suffix] ?: 0f
    }

    fun setSoundValue(uid: Long, suffix: String, value: Float) {
        val clip = effectClips.firstOrNull { it.uid == uid } ?: return
        val key = "${clip.effectId}.$suffix"
        if (canKeyframe(key) && autoKey(key, value)) return
        effectClips = effectClips.map { if (it.uid == uid) it.copy(overrides = it.overrides + (key to value)) else it }
        scheduleAutosave()
    }

    // ------------------------------------------------------------ v44: Beat Sync

    /** Golpes de la música dentro del vídeo (segundos). Vacío = sin analizar. */
    var beatMarkers by mutableStateOf<List<Float>>(emptyList())
        private set
    var beatSensitivity by mutableFloatStateOf(.5f)

    /** Analiza la parte de la música que suena en el vídeo (sin IA) y marca sus golpes. */
    fun detectBeats() {
        val project = meta ?: return
        val e = exportSettings
        if (e.audioName.isBlank() || e.audioFrames <= 0L) { message = "Primero importa una música."; return }
        if (busy != null) return
        busy = "Buscando los golpes de la música…"
        val sens = beatSensitivity
        viewModelScope.launch {
            try {
                val beats = withContext(Dispatchers.Default) {
                    val reader = com.zeta.fondo.engine.PcmReader(java.io.File(project.dir, com.zeta.fondo.engine.ImportedAudio.FILE_NAME), e)
                    reader.use {
                        val frames = (e.loopSec.toLong() * e.audioRate).toInt()
                        val pcm = it.read(0L, frames)
                        com.zeta.fondo.engine.BeatDetect.onsets(com.zeta.fondo.engine.BeatDetect.toMono(pcm, e.audioChannels), e.audioRate, sens)
                    }
                }
                beatMarkers = beats.filter { it < e.loopSec - .05f }
                showHint(if (beatMarkers.isEmpty()) "No se encontraron golpes claros. Sube la sensibilidad."
                    else "${beatMarkers.size} golpes marcados en la línea de tiempo (el imán se pega a ellos).", 2600L)
            } catch (t: Throwable) {
                message = "No se pudo analizar la música: ${t.message}"
            } finally { busy = null }
        }
    }

    fun clearBeats() { beatMarkers = emptyList() }

    /** Añade un bloque corto de [effectId] (destello, impacto, onda…) en cada golpe marcado. */
    fun addEffectOnBeats(effectId: String) {
        if (beatMarkers.isEmpty()) return
        val total = exportSettings.loopSec.toFloat()
        val before = effectClips.toList()
        val beforeSettings = settings
        var uid = nextClipUid()
        val dur = when (effectId) { "impact" -> .45f; "shock" -> .5f; else -> .3f }
        val clips = beatMarkers.map { t ->
            EffectClip(uid++, effectId, t.coerceAtMost(total - dur), dur)
        }
        var next = settings + ("$effectId.on" to 1f)
        if (!next.containsKey("$effectId.mask")) next = next + ("$effectId.mask" to -2f)
        if (effectId in Effects.eventEffects) next = next + ("$effectId.mode" to EventMode.ONCE.toFloat())
        settings = next
        effectClips = effectClips + clips
        commitTimeline(before, beforeSettings)
        pushParams(); saveProject()
        showHint("${clips.size} bloques añadidos en los golpes. Puedes moverlos o borrarlos como cualquier bloque.", 2600L)
    }

    /** Grabación propia del usuario (hasta 60 s) como sonido del proyecto. */
    fun importUserSound(uri: Uri) {
        val project = meta ?: return
        if (busy != null) return
        if (playing) togglePlay()
        busy = "Importando sonido…"
        viewModelScope.launch {
            try {
                val id = withContext(Dispatchers.IO) {
                    val dir = java.io.File(project.dir, com.zeta.fondo.engine.UserSounds.DIR).apply { mkdirs() }
                    val n = (dir.listFiles { f -> f.name.endsWith(".pcm") }?.size ?: 0) + 1
                    val sid = "${com.zeta.fondo.model.SoundClips.USER}$n"
                    val pcm = java.io.File(dir, "$sid.pcm")
                    val d = com.zeta.fondo.engine.ImportedAudio.decode(getApplication(), uri, pcm)
                    // Máximo 60 s: el resto se descarta (los sonidos se repiten sin clic).
                    val maxBytes = d.rate.toLong() * d.channels * 2 * com.zeta.fondo.engine.UserSounds.MAX_SECONDS
                    if (pcm.length() > maxBytes) java.io.RandomAccessFile(pcm, "rw").use { it.setLength(maxBytes) }
                    java.io.File(dir, "$sid.txt").writeText("${d.rate},${d.channels},${d.name.replace(',', ' ').take(40)}")
                    sid
                }
                addSound(id)
            } catch (e: Exception) {
                message = "No se pudo importar el sonido: ${e.message}"
            } finally { busy = null }
        }
    }

    fun setAmbientVolume(id: String, v: Float) {
        val e = exportSettings
        updateExport(e.copy(ambient = e.ambient + (id to v.coerceIn(0.02f, 1f))))
    }

    // ============================================================ v44: Diagnóstico

    /** Estado de la prueba de rendimiento (null = nunca ejecutada en esta sesión). */
    data class BenchState(
        val running: Boolean,
        val stage: Int,
        val stageSecLeft: Int,
        val waitingShader: Boolean,
        val results: List<com.zeta.fondo.diag.Benchmark.StageResult>,
        val report: String?
    )
    var benchmark by mutableStateOf<BenchState?>(null)
    private var benchJob: Job? = null

    fun appVersion(): String = try {
        val app = getApplication<Application>()
        app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "?"
    } catch (_: Throwable) { "?" }

    /**
     * Prueba 1 → 3 → 6 efectos, [com.zeta.fondo.diag.Benchmark.STAGE_SEC] s cada una, sobre la
     * imagen abierta. NO toca el proyecto: solo cambia lo que dibuja la vista previa y al
     * terminar (o al cancelar) se restaura todo. No se guarda nada mientras dura.
     */
    fun startBenchmark(stageSec: Int = com.zeta.fondo.diag.Benchmark.STAGE_SEC) {
        if (benchmark?.running == true || meta == null) return
        if (exportState is ExportState.Running) { message = "Espera a que termine la exportación."; return }
        val app = getApplication<Application>()
        val wasPlaying = playing
        benchmark = BenchState(true, 0, stageSec, true, emptyList(), null)
        hub.diagnostics = true
        benchJob = viewModelScope.launch {
            val results = ArrayList<com.zeta.fondo.diag.Benchmark.StageResult>()
            try {
                if (!playing) togglePlay()
                for ((i, count) in com.zeta.fondo.diag.Benchmark.stages.withIndex()) {
                    val ids = com.zeta.fondo.diag.Benchmark.effectsFor(count)
                    val s = Effects.defaults().mapValues { (k, v) -> if (k.endsWith(".on")) 0f else v } +
                        ids.associate { "$it.on" to 1f }
                    hub.params = RenderParams.from(s, aspect, exportSettings.loopSec.toFloat(), emptyList())
                    // Esperar a que el shader de esta combinación esté compilado (máx. 20 s).
                    val waitStart = System.nanoTime()
                    benchmark = benchmark?.copy(stage = i, stageSecLeft = stageSec, waitingShader = true)
                    val key = hub.params.variantKey
                    var waited = 0
                    while (hub.readyVariantKey != key && waited < 200) { delay(100); waited++ }
                    val waitMs = (System.nanoTime() - waitStart) / 1_000_000L
                    delay(1500) // estabilizar antes de medir
                    val thermalStart = com.zeta.fondo.diag.Benchmark.thermalName(com.zeta.fondo.diag.DeviceInfo.thermalStatus(app))
                    hub.stats.reset()
                    var left = stageSec
                    while (left > 0) {
                        benchmark = benchmark?.copy(stageSecLeft = left, waitingShader = false)
                        delay(1000); left--
                    }
                    results += com.zeta.fondo.diag.Benchmark.StageResult(count, stageSec, waitMs, hub.stats.snapshot(),
                        thermalStart, com.zeta.fondo.diag.Benchmark.thermalName(com.zeta.fondo.diag.DeviceInfo.thermalStatus(app)),
                        com.zeta.fondo.diag.DeviceInfo.ramAvailMb(app), true)
                    benchmark = benchmark?.copy(results = results.toList())
                }
            } finally {
                val partial = results.toList()
                hub.params = RenderParams.from(settings, aspect, exportSettings.loopSec.toFloat(), renderClips(), soloActive)
                if (!wasPlaying && playing) togglePlay()
                val header = com.zeta.fondo.diag.DeviceInfo.header(app, hub.gpuInfo, appVersion())
                val report = com.zeta.fondo.diag.Benchmark.report(header, partial)
                com.zeta.fondo.diag.ZetaLog.info("Prueba", "Prueba de rendimiento: ${partial.size} de 3 etapas")
                benchmark = BenchState(false, partial.size, 0, false, partial, report)
            }
        }
    }

    fun stopBenchmark() {
        if (benchmark?.running == true) benchJob?.cancel()
    }

    /** Texto del informe (prueba + registro) en un archivo compartible. */
    fun shareDiagnostics(includeLog: Boolean) {
        val app = getApplication<Application>()
        val text = buildString {
            val b = benchmark?.report
            if (b != null) append(b) else {
                append("Zeta Motion · Informe de diagnóstico\n")
                for ((k, v) in com.zeta.fondo.diag.DeviceInfo.header(app, hub.gpuInfo, appVersion())) append(k).append(": ").append(v).append('\n')
                append("(No se ha ejecutado la prueba de rendimiento en esta sesión.)\n")
            }
            if (includeLog) {
                append("\n\n==== Registro de errores ====\n")
                append(com.zeta.fondo.diag.ZetaLog.readAll().ifBlank { "(vacío)" })
            }
        }
        try {
            val dir = java.io.File(app.cacheDir, "exports").apply { mkdirs() }
            val f = java.io.File(dir, "ZetaMotion_diagnostico.txt")
            f.writeText(text)
            com.zeta.fondo.export.ShareUtil.shareText(app, f)
        } catch (t: Throwable) {
            message = "No se pudo crear el informe: ${t.message}"
        }
    }

    // ============================================================ Exportar

    fun startExport() {
        val m = meta ?: return
        val mk = masks ?: return
        if (exportState is ExportState.Running) return
        if (ExportRunner.running) { message = "Ya hay una exportación en curso."; return }
        flushParams()
        saveProject()
        lastProgressPost = -1f
        exportState = ExportState.Running(0f)
        hub.renderEnabled = false

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val req = ExportRequest(
            imageFile = exportImage(m).first,
            imgW = exportImage(m).second,
            imgH = exportImage(m).third,
            name = "ZetaMotion_$stamp",
            settings = audioSettings(forExport = true),
            params = RenderParams.from(settings, aspect, exportSettings.loopSec.toFloat(), effectClips),
            flow = hub.flow ?: FlowField.compute(ArrayList(arrows), ArrayList(anchors), aspect, settings["flow.reach"] ?: 0.25f),
            masks = mk,
            characterFile = java.io.File(m.dir, CHARACTER_FILE),
            boltCount = boltCount,
            depth = hub.depth,
            plate = hub.plate
        )
        val app = getApplication<Application>()
        val exporter = Exporter(app, vertSrc, fragSrc)
        // v44: el trabajo vive en el ámbito de la APLICACIÓN y un servicio en primer plano
        // mantiene la notificación: salir del editor o de la app ya no corta la exportación.
        ExportRunner.cancelFlag.set(false)
        ExportRunner.progress = 0f
        ExportRunner.running = true
        ExportService.start(app)
        ExportRunner.scope.launch {
            var title = "Vídeo exportado"
            var text = "Guardado en la Galería"
            try {
                val result = exporter.run(req, ExportRunner.cancelFlag) { p -> postProgress(p) }
                if (result.galleryPath.isNotBlank()) text = "Guardado en ${result.galleryPath}"
                main.post { exportState = ExportState.Done(result) }
            } catch (e: ExportCancelled) {
                title = "Exportación cancelada"; text = "No se guardó ningún vídeo"
                main.post { exportState = ExportState.Idle; message = "Exportación cancelada." }
            } catch (e: OutOfMemoryError) {
                com.zeta.fondo.diag.ZetaLog.error("Exportar", "Sin memoria al exportar", e)
                title = "No se pudo exportar"; text = "Sin memoria suficiente para esa resolución"
                main.post { exportState = ExportState.Failed("No hay memoria suficiente para esa resolución. Prueba con una menor.") }
            } catch (e: Throwable) {
                title = "No se pudo exportar"; text = e.message ?: e.toString()
                main.post { exportState = ExportState.Failed(e.message ?: e.toString()) }
            } finally {
                ExportRunner.running = false
                ExportService.stop(app)
                // Solo se avisa con notificación si el usuario no está mirando el editor.
                if (!appVisible) ExportService.finished(app, title, text)
                main.post { hub.renderEnabled = true }
            }
        }
    }

    fun notificationsAsked(): Boolean = prefs.getBoolean("notifAsked", false)
    fun markNotificationsAsked() { prefs.edit().putBoolean("notifAsked", true).apply() }

    /** v44: la app está en primer plano (lo actualiza MainActivity). */
    @Volatile var appVisible = true

    private fun postProgress(p: Float) {
        if (p - lastProgressPost < 0.005f && p < 1f) return
        val notify = (p * 100f).toInt() != (lastProgressPost * 100f).toInt()
        lastProgressPost = p
        ExportRunner.progress = p
        if (notify) ExportService.update(getApplication(), p)
        main.post {
            if (exportState is ExportState.Running) exportState = ExportState.Running(p)
        }
    }

    fun cancelExport() {
        ExportRunner.cancel()
    }

    fun dismissExportResult() {
        exportState = ExportState.Idle
    }

    /**
     * Resolución de edición adaptativa. Mantiene suficiente detalle para hacer zoom
     * sin obligar a teléfonos modestos a conservar una textura 4K durante toda la edición.
     */
    private fun previewTargetMaxSide(): Int {
        val app = getApplication<Application>()
        val dm = app.resources.displayMetrics
        val screenLong = maxOf(dm.widthPixels, dm.heightPixels).coerceAtLeast(720)
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val cap = when {
            am?.isLowRamDevice == true -> 2304
            (am?.memoryClass ?: 256) < 256 -> 2560
            else -> 3072
        }
        return (screenLong * 2).coerceIn(2048, cap)
    }

    override fun onCleared() {
        // v44: la exportación NO se cancela al cerrarse la pantalla: sigue en el servicio
        // con su notificación (Cancelar está ahí).
        super.onCleared()
    }

    companion object {
        const val EDIT_PREVIEW_MAX = 2560
        const val CHARACTER_FILE = "character.png"
        const val PLATE_FILE = "plate.png"
        const val PLATE_META = "plate.txt"
    }
}
