# Paint Zeta v8.61: Marioneta fluida, tipos de luz y acabado tipo manhwa

## 1. Marioneta
- **Causa de la traba**: cada movimiento del dedo recalculaba la malla en el hilo de la pantalla
  (hasta 8 veces si iba a doblarse). Con una página entera la malla es enorme y el dedo esperaba.
- **Ahora**: el cálculo va en otro hilo y solo cuenta el último movimiento. La pantalla dibuja la
  última copia sin esperar. El recálculo anti-doblez bajó de 7 a 4 pasos. Al Aplicar, Deshacer o
  Ampliar lienzo se termina primero lo pendiente (el último movimiento no se pierde).
- **Dos dedos**: en Marioneta y Transformar ahora también GIRAN (antes solo movían y ampliaban;
  por eso parecía congelado). Es la misma navegación de las demás herramientas.

## 2. Acabado (Colorear, paso 2)
- **Sol fluido**: mientras arrastras el sol, un retoque o la Fuerza, se calcula rápido
  (1 de cada 4 píxeles, sin resplandor); al soltar se pinta completo.
- **Tipos de luz**: Día, Tarde, Atardecer, Luna llena, Media luna, Interior. Cambian el color de
  la luz, del borde, de las sombras y del ambiente. El sol (o la luna) se sigue arrastrando.
- **Detalles tipo manhwa**: degradado suave dentro de la luz, borde cálido en la piel donde la
  luz pasa a sombra, y brillo chico en la nariz (solo si se detectan los dos ojos).
- Las partes guardan su tipo de luz.

## 3. Luz > Noche
- **Causa**: el "Tono de la escena" empujaba el color del personaje hacia el azul del cielo
  (60 %) y la luz usaba un celeste fuerte en Superponer: la cara salía celeste.
- **Ahora**: la piel casi no cambia de tono, lo blanco o gris sin pintar se tiñe poco, y la luz de
  luna es plateada.

## Lo de la 8.60 sigue igual
Acabado, Relleno con color real, sin botones repetidos (Lápiz, Manga).

## Cómo probarlo
1. Marioneta: pon puntos y arrastra rápido; gira con dos dedos.
2. Colorear > 2 Acabado: arrastra el sol (debe seguir al dedo) y prueba los 6 tipos de luz.
3. Luz > Noche sobre un dibujo: la cara no debe salir celeste.
