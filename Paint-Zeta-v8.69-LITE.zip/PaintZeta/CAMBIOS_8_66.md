# Paint Zeta v8.66: Colorear paso 1 (sombras del dibujo, capas, paletas)

## 1. El color respeta las sombras que ya trae el dibujo
- **Causa**: el paso 1 pintaba el color "liso" y BORRABA los grises del dibujo (la sombra del
  mentón en el cuello desaparecía; quedaba solo una rayita).
- **Ahora**: lo gris del dibujo queda como sombra del mismo color (piel más oscura en el cuello).
  En colores claros (piel, blanco) la base es lo claro del dibujo y lo gris es su sombra.
  En pelo y ropa también se respetan los brillos dibujados. Dibujos de solo líneas: igual que antes.

## 2. Ya no se crea una capa vacía al colorear
- **Causa**: al entrar a Colorear se creaba "Color base" (Multiplicar) para el modo manga viejo,
  pero el color va en "Color zonas": quedaba una capa vacía encima.
- **Ahora**: no se crea. Si tu obra ya tenía ese "Color base" vacío, se quita sola al entrar a Colorear.
  (El menú viejo de manga sigue igual.)

## 3. Paletas con nombres que dicen para qué sirven
- "Horikita" → **Colegiala pelo negro**, "Ayanokouji" → **Colegial pelo castaño**,
  "Fondos" → **Fondos y escenarios**. En la lista se ve qué partes trae cada una
  (pelo, piel, ojos, saco...). Al tocar una, cambian los colores de la fila.

## 4. Relleno: sombras pintadas encerradas
- Manchas de sombra gris oscuro rodeadas por la parte (sin contorno de tinta) entran a la zona.
  Ojos, botones y partes con contorno (corbata, cinturón) no entran.

## Pruebas internas (con tu imagen)
- A tamaño original y al triple: cara, cuello, pelo, camisa, saco y lazo, cada uno en su parte.
- Antes (8.62) al triple: tocar la cara pintaba cara + pelo (645 mil px); ahora solo la cara (141 mil).
- El cuello no se pasa a la camisa en tu imagen (en ningún tamaño).
- Acabado: igual que en 8.65.

Incluye todo lo de 8.63, 8.64 y 8.65 (ver CAMBIOS_8_65.md).
