package com.pacco.animecut.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

import com.pacco.animecut.ai.AiCutSession;

/**
 * v8.33: editor del recorte con IA (vista previa NO destructiva).
 *  - Muestra el recorte sobre cuadros, blanco, negro o magenta (solo para ver: no se exporta).
 *  - Mantener "comparar" muestra el original.
 *  - Un dedo: la herramienta elegida (pincel Quitar/Anadir, toque Quitar zona/Anadir zona,
 *    Solo este). Dos dedos: acercar y mover; si entra el segundo dedo a mitad de un trazo, el
 *    trazo se deshace (sin trazos fantasma).
 *  - La vista es una copia reducida (lado mayor <= 2048) que se actualiza solo en lo que cambia.
 */
public class AiCutView extends View {
    public static final int T_REMOVE = 0, T_ADD = 1, T_ZONE_REMOVE = 2, T_ZONE_ADD = 3, T_KEEP_ONLY = 4;

    public interface Host {
        /** Algo cambio (para habilitar deshacer, etc.). */
        void onChanged();
        void onHud(String text);
        /** v8.33: toque con 2 dedos = Deshacer, con 3 = Rehacer (como en la pantalla principal). */
        void onFingerTap(int fingers);
    }

    private AiCutSession s;
    private Host host;
    private Bitmap disp;
    private float ds = 1f;          // pixeles de imagen por pixel de la vista
    private final Matrix m = new Matrix(), inv = new Matrix();
    private final Paint bmp = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring2 = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int tool = T_REMOVE;
    private int bg = 0;
    private boolean compare;
    /** v8.33: ver lo QUITADO a esta opacidad (0 = no), con un tinte rojo. Solo para ver. */
    private float ghost;

    public void setGhost(float g) { ghost = Math.max(0f, Math.min(0.9f, g)); refreshAll(); }
    public float getGhost() { return ghost; }
    private float sizeDp = 26f, hard = 0.8f;
    private int tol = 30;
    private boolean fitted;
    private volatile boolean busy;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final java.util.concurrent.ExecutorService work = java.util.concurrent.Executors.newSingleThreadExecutor();

    public AiCutView(Context c) {
        super(c);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(2f * dp());
        ring.setColor(0xFFFFFFFF);
        ring2.setStyle(Paint.Style.STROKE);
        ring2.setStrokeWidth(1f * dp());
        ring2.setColor(0xFF000000);
        setBackgroundColor(0xFF121214);
    }

    private float dp() { return getResources().getDisplayMetrics().density; }

    public void setHost(Host h) { host = h; }

    public void setSession(AiCutSession ses) {
        s = ses;
        float max = Math.max(ses.W, ses.H);
        ds = max > 2048 ? max / 2048f : 1f;
        int dw = Math.max(1, Math.round(ses.W / ds)), dh = Math.max(1, Math.round(ses.H / ds));
        if (disp != null) disp.recycle();
        disp = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888);
        ds = (float) ses.W / dw;
        redraw(0, 0, ses.W, ses.H);
        fitted = false;
        invalidate();
    }

    public AiCutSession session() { return s; }

    public void setTool(int t) { tool = t; invalidate(); }
    public int getTool() { return tool; }
    public void setSizeDp(float v) { sizeDp = Math.max(2f, v); invalidate(); }
    public float getSizeDp() { return sizeDp; }
    public void setHard(float h) { hard = h; }
    public void setTolerance(int t) { tol = t; }
    public int getTolerance() { return tol; }
    public boolean isBusy() { return busy; }

    /** 0 cuadros, 1 blanco, 2 negro, 3 magenta. Solo para ver. */
    public int cycleBg() { bg = (bg + 1) % 4; redraw(0, 0, s.W, s.H); invalidate(); return bg; }

    public void setCompare(boolean on) { compare = on; redraw(0, 0, s.W, s.H); invalidate(); }

    /** Vuelve a pintar todo (despues de cambiar ajustes, deshacer...). */
    public void refreshAll() { if (s != null) { s.takeDirty(); redraw(0, 0, s.W, s.H); invalidate(); } }

    private int bgAt(int x, int y) {
        switch (bg) {
            case 1: return 0xFFFFFFFF;
            case 2: return 0xFF000000;
            case 3: return 0xFFFF00FF;
            default: return (((x / 12) + (y / 12)) & 1) == 0 ? 0xFFC8C8C8 : 0xFF9A9A9A;
        }
    }

    /** Repinta la zona (en pixeles de imagen) en la copia de la vista. */
    private void redraw(int x0, int y0, int x1, int y1) {
        if (disp == null || s == null) return;
        int dw = disp.getWidth(), dh = disp.getHeight();
        int a0 = Math.max(0, (int) (x0 / ds) - 1), b0 = Math.max(0, (int) (y0 / ds) - 1);
        int a1 = Math.min(dw, (int) Math.ceil(x1 / ds) + 1), b1 = Math.min(dh, (int) Math.ceil(y1 / ds) + 1);
        if (a0 >= a1 || b0 >= b1) return;
        int rw = a1 - a0;
        int[] row = new int[rw];
        for (int y = b0; y < b1; y++) {
            int sy = Math.min(s.H - 1, (int) (y * ds));
            for (int x = a0; x < a1; x++) {
                int sx = Math.min(s.W - 1, (int) (x * ds));
                int i = sy * s.W + sx;
                int c;
                int back = bgAt(x, y);
                if (compare) c = s.px[i];
                else {
                    int a = s.alphaAt(i);
                    c = a == 0 ? 0 : (a << 24) | s.rgbAt(i);
                    if (ghost > 0f) {
                        // lo quitado se ve tenue y rojizo para saber que devolver con Anadir
                        int o = s.px[i], oa = o >>> 24;
                        if (oa > a) {
                            int ga = Math.round((oa - a) * ghost);
                            int r = (((o >> 16) & 255) * 2 + 255) / 3, g = ((o >> 8) & 255) * 2 / 3, b = (o & 255) * 2 / 3;
                            back = over((ga << 24) | (r << 16) | (g << 8) | b, back);
                        }
                    }
                }
                row[x - a0] = over(c, back);
            }
            disp.setPixels(row, 0, rw, a0, y, rw, 1);
        }
    }

    private static int over(int c, int bg) {
        int a = c >>> 24;
        if (a >= 255) return c | 0xFF000000;
        if (a == 0) return bg;
        int r = (((c >> 16) & 255) * a + ((bg >> 16) & 255) * (255 - a)) / 255;
        int g = (((c >> 8) & 255) * a + ((bg >> 8) & 255) * (255 - a)) / 255;
        int b = ((c & 255) * a + (bg & 255) * (255 - a)) / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private void flushDirty() {
        int[] d = s.takeDirty();
        if (d != null) redraw(d[0], d[1], d[2], d[3]);
        invalidate();
    }

    public void fit() {
        if (s == null || getWidth() == 0) return;
        float sc = Math.min(getWidth() / (float) s.W, getHeight() / (float) s.H) * 0.96f;
        m.reset();
        m.postScale(sc, sc);
        m.postTranslate((getWidth() - s.W * sc) / 2f, (getHeight() - s.H * sc) / 2f);
        fitted = true;
        invalidate();
    }

    private float scale() {
        float[] v = new float[9];
        m.getValues(v);
        return (float) Math.hypot(v[Matrix.MSCALE_X], v[Matrix.MSKEW_Y]);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) { fitted = false; }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (s == null || disp == null) return;
        if (!fitted) fit();
        c.save();
        c.concat(m);
        c.scale(ds, ds);
        bmp.setFilterBitmap(scale() * ds < 2f);
        c.drawBitmap(disp, 0, 0, bmp);
        c.restore();
        if (showRing && (tool == T_REMOVE || tool == T_ADD)) {
            float r = sizeDp * dp();
            c.drawCircle(ringX, ringY, r, ring2);
            c.drawCircle(ringX, ringY, r, ring);
        }
    }

    // ------------------------------------------------------------------ toque
    private boolean stroking, gesture, moved, showRing;
    private int gMax;
    private long gDown;
    private float gMoved;
    private float lastX, lastY, downX, downY, ringX, ringY;
    private float g0x, g0y, g0d;
    private final float[] pt = new float[2];

    private void toImage(float x, float y) {
        m.invert(inv);
        pt[0] = x; pt[1] = y;
        inv.mapPoints(pt);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (s == null) return false;
        int act = e.getActionMasked();
        switch (act) {
            case MotionEvent.ACTION_DOWN:
                gMax = 1;
                gDown = e.getEventTime();
                gMoved = 0f;
                gesture = false;
                moved = false;
                downX = lastX = e.getX();
                downY = lastY = e.getY();
                ringX = e.getX(); ringY = e.getY();
                showRing = true;
                if (!busy && (tool == T_REMOVE || tool == T_ADD)) {
                    s.beginEdit();
                    stroking = true;
                    toImage(e.getX(), e.getY());
                    s.stamp(pt[0], pt[1], radiusImg(), hard, tool == T_ADD);
                    flushDirty();
                }
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                gMax = Math.max(gMax, e.getPointerCount());
                if (stroking) {
                    // segundo dedo: el trazo se deshace (nada de trazos fantasma)
                    s.cancelEdit();
                    stroking = false;
                    refreshAll();
                }
                gesture = true;
                showRing = false;
                startGesture(e);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (gesture && e.getPointerCount() >= 2) { moveGesture(e); return true; }
                if (gesture) return true;
                if (Math.hypot(e.getX() - downX, e.getY() - downY) > 8 * dp()) moved = true;
                ringX = e.getX(); ringY = e.getY();
                if (stroking) {
                    // historial de puntos + espaciado de 1/4 del radio
                    int n = e.getHistorySize();
                    for (int k = 0; k <= n; k++) {
                        float x = k < n ? e.getHistoricalX(k) : e.getX();
                        float y = k < n ? e.getHistoricalY(k) : e.getY();
                        strokeTo(x, y);
                    }
                    flushDirty();
                } else invalidate();
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                if (e.getPointerCount() == 2) gesture = true;   // queda uno: no pinta hasta soltar
                return true;
            case MotionEvent.ACTION_UP:
                showRing = false;
                if (gMax >= 2) {
                    // toque corto con 2 dedos = Deshacer, con 3 = Rehacer
                    if (e.getEventTime() - gDown < 300 && gMoved < 30f * dp() && host != null) host.onFingerTap(gMax);
                    gesture = false;
                    invalidate();
                    return true;
                }
                if (stroking) {
                    stroking = false;
                    s.endEdit(tool == T_ADD ? "Anadir" : "Quitar");
                    if (host != null) host.onChanged();
                    invalidate();
                } else if (!gesture && !moved && !busy) {
                    toImage(e.getX(), e.getY());
                    tap((int) pt[0], (int) pt[1]);
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
                if (stroking) { s.cancelEdit(); stroking = false; refreshAll(); }
                showRing = false;
                invalidate();
                return true;
        }
        return true;
    }

    private float radiusImg() { return Math.max(0.5f, sizeDp * dp() / scale()); }

    private void strokeTo(float x, float y) {
        float dx = x - lastX, dy = y - lastY;
        float dist = (float) Math.hypot(dx, dy);
        float step = Math.max(1f, sizeDp * dp() * 0.25f);
        int n = (int) (dist / step);
        for (int k = 1; k <= n; k++) {
            float t = k * step / dist;
            toImage(lastX + dx * t, lastY + dy * t);
            s.stamp(pt[0], pt[1], radiusImg(), hard, tool == T_ADD);
        }
        if (n > 0) {
            float t = n * step / dist;
            lastX = lastX + dx * t;
            lastY = lastY + dy * t;
        }
    }

    private void tap(final int x, final int y) {
        if (x < 0 || y < 0 || x >= s.W || y >= s.H) return;
        if (tool != T_ZONE_REMOVE && tool != T_ZONE_ADD && tool != T_KEEP_ONLY) return;
        busy = true;
        if (host != null) host.onHud("...");
        final int t = tool, tl = tol;
        work.execute(new Runnable() {
            @Override public void run() {
                int n;
                String label;
                try {
                    s.beginEdit();
                    if (t == T_KEEP_ONLY) { n = s.keepOnly(x, y); label = "Solo este"; }
                    else { n = s.zone(x, y, t == T_ZONE_ADD, tl); label = t == T_ZONE_ADD ? "Anadir zona" : "Quitar zona"; }
                    s.endEdit(label);
                } catch (OutOfMemoryError oom) {
                    s.cancelEdit();
                    n = -2;
                    label = null;
                }
                final int res = n;
                ui.post(new Runnable() {
                    @Override public void run() {
                        busy = false;
                        flushDirty();
                        if (host != null) {
                            host.onChanged();
                            if (res == -2) host.onHud("Falta memoria");
                            else if (t == T_KEEP_ONLY) host.onHud(res > 0 ? "Listo: solo este" : res == 0 ? "Se tocan: usa Quitar" : "Toca un personaje");
                            else host.onHud(res > 0 ? "Listo" : "Nada parecido aqui");
                        }
                    }
                });
            }
        });
    }

    private void startGesture(MotionEvent e) {
        g0x = (e.getX(0) + e.getX(1)) / 2f;
        g0y = (e.getY(0) + e.getY(1)) / 2f;
        g0d = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
    }

    private void moveGesture(MotionEvent e) {
        float cx = (e.getX(0) + e.getX(1)) / 2f, cy = (e.getY(0) + e.getY(1)) / 2f;
        float d = (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
        gMoved += Math.abs(cx - g0x) + Math.abs(cy - g0y) + Math.abs(d - g0d);
        m.postTranslate(cx - g0x, cy - g0y);
        if (g0d > 10f && d > 10f) {
            float f = d / g0d;
            float sc = scale();
            if (sc * f > 40f) f = 40f / sc;
            if (sc * f < 0.05f) f = 0.05f / sc;
            m.postScale(f, f, cx, cy);
        }
        g0x = cx; g0y = cy; g0d = d;
        invalidate();
    }

    /** Corre algo pesado de la sesion en el hilo del editor y repinta al final. */
    public void runWork(final Runnable bg, final Runnable after) {
        busy = true;
        work.execute(new Runnable() {
            @Override public void run() {
                Throwable err = null;
                try { bg.run(); } catch (Throwable t) { err = t; }
                final Throwable fe = err;
                ui.post(new Runnable() {
                    @Override public void run() {
                        busy = false;
                        refreshAll();
                        if (fe instanceof OutOfMemoryError && host != null) host.onHud("Falta memoria");
                        if (after != null) after.run();
                    }
                });
            }
        });
    }

    public void release() {
        work.shutdown();
        if (disp != null) disp.recycle();
        disp = null;
        if (s != null) s.release();
    }

    /** Color de fondo de vista actual (para el icono). */
    public int bgMode() { return bg; }
}
