package com.pacco.animecut.core;

/**
 * v8.48 "Estilo de edicion" (como los edits de anime y manhwa): sobre la imagen ya hecha.
 *  - Para B/N: MAPA DE DEGRADADO (cada gris pasa a un color: sombra -> medio -> luz), como los
 *    edits de manga azul-violeta, gris-celeste con grano o celeste brillante de manhwa.
 *  - Para color: "Anime": contraste suave, sombras un poco levantadas y tinte calido en las luces.
 *  - Extras, cada uno en su capa: brillo (bloom), grano de pelicula, particulas de luz y borde RGB
 *    (aberracion cromatica). "Conservar colores vivos": lo que pintaste de color (ojos rojos)
 *    se queda de color sobre el B/N.
 * Java puro: la app y las pruebas de PC.
 */
public final class Looks {
    private Looks() { }

    public static final class Look {
        public final String name;
        public final boolean map;          // true = mapa de degradado (para B/N)
        public final int dark, mid, light, glow;
        public final float contrast;       // 1 = igual
        Look(String n, boolean map, int dark, int mid, int light, int glow, float contrast) {
            name = n; this.map = map; this.dark = dark; this.mid = mid; this.light = light; this.glow = glow; this.contrast = contrast;
        }
    }

    public static final Look[] LOOKS = {
            new Look("Anime", false, 0xFF2A2440, 0xFF000000, 0xFFFFF0E6, 0xFFFFE6D8, 0.92f),
            new Look("Noche violeta", true, 0xFF0A0D26, 0xFF46508E, 0xFFF2D6F2, 0xFFE89AD8, 1.10f),
            new Look("Frio con grano", true, 0xFF071216, 0xFF5E7E84, 0xFFE4EEF0, 0xFFC8E6EC, 1.15f),
            new Look("Luz celeste", true, 0xFF15204A, 0xFF7EA6DA, 0xFFF6FBFF, 0xFFCFE8FF, 0.95f),
            new Look("Dorado", true, 0xFF241608, 0xFFA88050, 0xFFFFF4DC, 0xFFFFD890, 1.0f),
            new Look("Sepia", true, 0xFF1C140E, 0xFF8C7458, 0xFFF4E8D2, 0xFFF0D8B0, 1.0f),
            new Look("B/N fuerte", true, 0xFF000000, 0xFF7A7A7A, 0xFFFFFFFF, 0xFFFFFFFF, 1.25f)
    };

    public static final int GRADE = 0, GLOW = 1, GRAIN = 2, PARTICLES = 3, N = 4;
    public static final String[] NAMES = {"Estilo", "Brillo", "Grano", "Particulas"};
    /** Layer.MODE_*: Normal, Pantalla, Superponer, Anadir. */
    public static final int[] MODES = {0, 2, 4, 3};

    public static final class Params {
        public Look look = LOOKS[1];
        public int strength = 100, glow = 35, grain = 0, particles = 0, rgb = 0, vignette = 35;
        public boolean keepColor = true;
        public long seed = 11;

        public Params copy() {
            Params q = new Params();
            q.look = look; q.strength = strength; q.glow = glow; q.grain = grain; q.particles = particles; q.rgb = rgb; q.vignette = vignette;
            q.keepColor = keepColor; q.seed = seed;
            return q;
        }
    }

    /** Elige el estilo segun la imagen: B/N -> Noche violeta; color -> Anime. */
    public static boolean isMono(int[] px) {
        int step = Math.max(1, px.length / 30000), col = 0, n = 0;
        for (int i = 0; i < px.length; i += step) {
            int c = px[i];
            if ((c >>> 24) < 128) continue;
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            if (Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b)) > 40) col++;
            n++;
        }
        return n == 0 || col < n / 25;
    }

    public static int[][] render(int[] src, int W, int H, Params p) {
        int n = W * H;
        Look L = p.look;
        int[][] out = new int[N][];
        int[] g = new int[n];
        float s = p.strength / 100f;
        float[] kD = ZoneTone.oklab(L.dark), kM = ZoneTone.oklab(L.mid), kL = ZoneTone.oklab(L.light);
        int[] lut = new int[256];
        for (int v = 0; v < 256; v++) {
            float t = v / 255f;
            t = clamp01(0.5f + (t - 0.5f) * L.contrast);
            if (L.map) {
                float[] k = t < 0.5f ? mix(kD, kM, ease(t / 0.5f)) : mix(kM, kL, ease((t - 0.5f) / 0.5f));
                lut[v] = ZoneTone.fromOklab(k[0], k[1], k[2]);
            }
        }
        float[] sat = new float[n];
        for (int i = 0; i < n; i++) {
            int c = src[i], a = c >>> 24;
            if (a == 0) continue;
            int r = (c >> 16) & 255, gg = (c >> 8) & 255, b = c & 255;
            int col;
            if (L.map) {
                col = lut[ZoneTone.lum(c)];
                int ch = Math.max(r, Math.max(gg, b)) - Math.min(r, Math.min(gg, b));
                if (p.keepColor && ch > 60) {      // lo pintado de color vivo (ojos) se queda, un poco brillante
                    float k = Math.min(1f, (ch - 60) / 60f);
                    col = ZoneTone.mixRgb(col, brighten(c, 1.15f), k);
                    sat[i] = k;
                }
            } else {
                // Anime: contraste suave, sombras levantadas hacia violeta, luces calidas, +saturacion
                float[] k = ZoneTone.oklab(c | 0xFF000000);
                float l = 0.5f + (k[0] - 0.5f) * L.contrast;
                float sh = 1f - ease(k[0] / 0.45f);
                float hi = ease((k[0] - 0.6f) / 0.4f);
                float A = k[1] * 1.12f, B = k[2] * 1.12f;
                A += (kD[1] - A) * 0.25f * sh; B += (kD[2] - B) * 0.25f * sh; l += 0.04f * sh;
                A += (kL[1] - A) * 0.18f * hi; B += (kL[2] - B) * 0.18f * hi;
                col = ZoneTone.fromOklab(clamp01(l), A, B);
            }
            if (p.vignette > 0) {   // orillas mas oscuras: el centro (la cara) resalta
                int x = i % W, y = i / W;
                float u = (x - W / 2f) / (W / 2f), w = (y - H / 2f) / (H / 2f);
                float e = ease(((float) Math.sqrt(u * u + w * w) / 1.414f - 0.35f) / 0.65f) * p.vignette / 100f;
                if (e > 0f) col = ZoneTone.mixRgb(col, L.dark, e * 0.8f);
            }
            g[i] = (Math.round(a * s) << 24) | (col & 0xFFFFFF);
        }
        if (p.rgb > 0) g = rgbSplit(g, W, H, Math.max(1, Math.round(Math.min(W, H) * 0.004f * p.rgb / 50f)));
        out[GRADE] = g;
        // imagen ya estilizada (para medir el brillo)
        int[] full = new int[n];
        for (int i = 0; i < n; i++) full[i] = ZoneTone.over(src[i] | 0xFF000000, g[i], g[i] >>> 24);
        if (p.glow > 0) out[GLOW] = glow(full, W, H, L.glow, p.glow / 100f);
        if (p.grain > 0) {
            java.util.Random r = new java.util.Random(p.seed);
            int[] gr = new int[n];
            int a = Math.round(255 * Math.min(1f, p.grain / 100f * 0.55f));
            for (int i = 0; i < n; i++) {
                if ((src[i] >>> 24) == 0) continue;
                int v = clamp(128 + (int) (r.nextGaussian() * 42));
                gr[i] = (a << 24) | (v << 16) | (v << 8) | v;
            }
            out[GRAIN] = gr;
        }
        if (p.particles > 0) out[PARTICLES] = particles(W, H, L.glow, p.particles / 100f, p.seed);
        return out;
    }

    /** v8.51: el resultado en UNA imagen (estilo + brillo + grano + particulas). */
    public static int[] compose(int[] src, int[][] fx, int W, int H) {
        int n = W * H;
        int[] o = src.clone();
        for (int k = 0; k < N; k++) {
            if (fx[k] == null) continue;
            int[] L = fx[k];
            for (int i = 0; i < n; i++) {
                if ((src[i] >>> 24) == 0) continue;
                o[i] = Atmos.blendPx(o[i], L[i], MODES[k]);
            }
        }
        return o;
    }

    private static int brighten(int c, float f) {
        return 0xFF000000 | (clamp(Math.round(((c >> 16) & 255) * f)) << 16) | (clamp(Math.round(((c >> 8) & 255) * f)) << 8) | clamp(Math.round((c & 255) * f));
    }

    /** Borde RGB: el rojo se corre a un lado y el azul al otro, mas en las orillas (como un lente). */
    static int[] rgbSplit(int[] g, int W, int H, int d) {
        int[] o = new int[g.length];
        float cx = W / 2f, cy = H / 2f, rr = (float) Math.hypot(cx, cy);
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                int i = y * W + x, c = g[i];
                if (c == 0) continue;
                float f = (float) Math.hypot(x - cx, y - cy) / rr;
                int dd = Math.round(d * (0.3f + f));
                int cr = g[y * W + Math.max(0, x - dd)], cb = g[y * W + Math.min(W - 1, x + dd)];
                o[i] = (c & 0xFF00FF00) | (cr & 0x00FF0000) | (cb & 0x000000FF);
            }
        return o;
    }

    /** Brillo: lo claro se difumina (a media resolucion) con el color del estilo. */
    static int[] glow(int[] full, int W, int H, int tint, float a0) {
        int bw = Math.max(1, W / 2), bh = Math.max(1, H / 2);
        float[] v = new float[bw * bh];
        for (int y = 0; y < bh; y++)
            for (int x = 0; x < bw; x++) {
                float l = ZoneTone.lum(full[Math.min(H - 1, y * 2) * W + Math.min(W - 1, x * 2)]) / 255f;
                v[y * bw + x] = ease((l - 0.62f) / 0.35f);
            }
        int r = Math.max(2, Math.min(W, H) / 2 / 45);
        for (int k = 0; k < 3; k++) ZoneTone.box(v, bw, bh, r);
        int[] o = new int[W * H];
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                float t = v[Math.min(bh - 1, y / 2) * bw + Math.min(bw - 1, x / 2)] * a0;
                if (t < 0.01f) continue;
                o[y * W + x] = (Math.round(255 * Math.min(1f, t)) << 24) | (tint & 0xFFFFFF);
            }
        return o;
    }

    /** Particulas de luz: puntos suaves de varios tamanos (bokeh), mas arriba que abajo. */
    static int[] particles(int W, int H, int col, float a0, long seed) {
        java.util.Random r = new java.util.Random(seed);
        int[] o = new int[W * H];
        int cnt = Math.round(20 + 140 * a0);
        float mn = Math.min(W, H);
        for (int k = 0; k < cnt; k++) {
            float x = r.nextFloat() * W, y = (float) Math.pow(r.nextFloat(), 1.4) * H;
            float rad = mn * (0.002f + (float) Math.pow(r.nextFloat(), 3) * 0.012f);
            float br = 0.35f + r.nextFloat() * 0.65f;
            int R = (int) Math.ceil(rad * 2.2f);
            for (int dy = -R; dy <= R; dy++)
                for (int dx = -R; dx <= R; dx++) {
                    int xx = (int) x + dx, yy = (int) y + dy;
                    if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
                    float d = (float) Math.hypot(dx, dy) / rad;
                    float v = (float) Math.exp(-d * d * 1.6f) * br;
                    if (v < 0.02f) continue;
                    int i = yy * W + xx, a = Math.max(o[i] >>> 24, Math.round(255 * v));
                    o[i] = (a << 24) | (col & 0xFFFFFF);
                }
        }
        return o;
    }

    private static float[] mix(float[] a, float[] b, float t) {
        return new float[]{a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t};
    }

    private static float ease(float t) { t = clamp01(t); return t * t * (3f - 2f * t); }

    private static float clamp01(float v) { return v < 0f ? 0f : v > 1f ? 1f : v; }

    private static int clamp(int v) { return v < 0 ? 0 : v > 255 ? 255 : v; }
}
