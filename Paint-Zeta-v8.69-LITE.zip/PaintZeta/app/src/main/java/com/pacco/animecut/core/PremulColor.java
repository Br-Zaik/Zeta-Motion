package com.pacco.animecut.core;

/**
 * Mezclas de color ARGB (sin premultiplicar en memoria) calculadas en alfa
 * PREMULTIPLICADO. Un pixel transparente nunca aporta su RGB (normalmente negro)
 * a la mezcla: asi no aparecen halos ni bordes oscuros.
 * Sin dependencias de Android (probado en JVM).
 */
public final class PremulColor {
    private PremulColor() { }

    /** Bilineal en premultiplicado sobre un buffer w x h; x, y en indices de pixel. */
    public static int bilinear(int[] buf, int w, int h, float x, float y) {
        if (w <= 0 || h <= 0) return 0;
        if (x < 0f) x = 0f; else if (x > w - 1) x = w - 1;
        if (y < 0f) y = 0f; else if (y > h - 1) y = h - 1;
        int x0 = (int) x, y0 = (int) y;
        int x1 = Math.min(w - 1, x0 + 1), y1 = Math.min(h - 1, y0 + 1);
        float fx = x - x0, fy = y - y0;
        return blend4(buf[y0 * w + x0], buf[y0 * w + x1], buf[y1 * w + x0], buf[y1 * w + x1], fx, fy);
    }

    /** Interpolacion de cuatro colores en premultiplicado; devuelve sin premultiplicar. */
    public static int blend4(int a, int b, int c, int d, float fx, float fy) {
        float w0 = (1f - fx) * (1f - fy), w1 = fx * (1f - fy), w2 = (1f - fx) * fy, w3 = fx * fy;
        float aa = (a >>> 24) * w0, ab = (b >>> 24) * w1, ac = (c >>> 24) * w2, ad = (d >>> 24) * w3;
        float alpha = aa + ab + ac + ad;
        if (alpha < .0001f) return 0;
        float r = (((a >>> 16) & 255) * aa + ((b >>> 16) & 255) * ab + ((c >>> 16) & 255) * ac + ((d >>> 16) & 255) * ad) / alpha;
        float g = (((a >>> 8) & 255) * aa + ((b >>> 8) & 255) * ab + ((c >>> 8) & 255) * ac + ((d >>> 8) & 255) * ad) / alpha;
        float bl = ((a & 255) * aa + (b & 255) * ab + (c & 255) * ac + (d & 255) * ad) / alpha;
        int ia = Math.min(255, (int) (alpha + .5f));
        if (ia == 0) return 0;
        return (ia << 24) | (Math.min(255, (int) (r + .5f)) << 16)
                | (Math.min(255, (int) (g + .5f)) << 8) | Math.min(255, (int) (bl + .5f));
    }

    /**
     * Desenfoque de color con alfa PREMULTIPLICADO (sin halos oscuros en lo
     * transparente): tres pasadas de caja horizontales y verticales (aprox.
     * gaussiana). Los bordes repiten el ultimo pixel.
     * @param src ARGB sin premultiplicar, w*h
     * @param tmp buffers de trabajo de al menos 4*w*h floats (se reutilizan)
     * @return ARGB sin premultiplicar, w*h (en out si no es null)
     */
    public static int[] blur(int[] src, int w, int h, int r, float[] tmp, int[] out) {
        int n = w * h;
        if (out == null) out = new int[n];
        if (r <= 0) { System.arraycopy(src, 0, out, 0, n); return out; }
        float[] a = tmp;  // a, r, g, b intercalados: 4 floats por pixel
        for (int i = 0; i < n; i++) {
            int c = src[i];
            float al = c >>> 24;
            int k = i << 2;
            a[k] = al;
            a[k + 1] = ((c >> 16) & 255) * al;
            a[k + 2] = ((c >> 8) & 255) * al;
            a[k + 3] = (c & 255) * al;
        }
        float[] line = new float[(Math.max(w, h) + 2 * r + 2) * 4];
        for (int pass = 0; pass < 3; pass++) {
            for (int y = 0; y < h; y++) boxLine(a, y * w, 1, w, r, line);
            for (int x = 0; x < w; x++) boxLine(a, x, w, h, r, line);
        }
        for (int i = 0; i < n; i++) {
            int k = i << 2;
            float al = a[k];
            if (al < .5f) { out[i] = 0; continue; }
            int rr = Math.min(255, Math.round(a[k + 1] / al));
            int gg = Math.min(255, Math.round(a[k + 2] / al));
            int bb = Math.min(255, Math.round(a[k + 3] / al));
            out[i] = (Math.min(255, Math.round(al)) << 24) | (rr << 16) | (gg << 8) | bb;
        }
        return out;
    }

    /** Caja de radio r sobre una fila o columna (start, paso stride, len pixeles). */
    private static void boxLine(float[] a, int start, int stride, int len, int r, float[] line) {
        // copia con bordes repetidos: line[(j + r) * 4 + c]
        int ext = len + 2 * r;
        for (int j = 0; j < ext; j++) {
            int s = j - r;
            if (s < 0) s = 0; else if (s >= len) s = len - 1;
            int k = (start + s * stride) << 2, d = j << 2;
            line[d] = a[k]; line[d + 1] = a[k + 1]; line[d + 2] = a[k + 2]; line[d + 3] = a[k + 3];
        }
        float inv = 1f / (2 * r + 1);
        float s0 = 0, s1 = 0, s2 = 0, s3 = 0;
        for (int j = 0; j < 2 * r + 1; j++) { int d = j << 2; s0 += line[d]; s1 += line[d + 1]; s2 += line[d + 2]; s3 += line[d + 3]; }
        for (int x = 0; x < len; x++) {
            int k = (start + x * stride) << 2;
            a[k] = s0 * inv; a[k + 1] = s1 * inv; a[k + 2] = s2 * inv; a[k + 3] = s3 * inv;
            if (x + 1 < len) {
                int add = (x + 2 * r + 1) << 2, sub = x << 2;
                s0 += line[add] - line[sub]; s1 += line[add + 1] - line[sub + 1];
                s2 += line[add + 2] - line[sub + 2]; s3 += line[add + 3] - line[sub + 3];
            }
        }
    }
}
