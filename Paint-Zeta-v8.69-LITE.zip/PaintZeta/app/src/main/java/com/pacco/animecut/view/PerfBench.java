package com.pacco.animecut.view;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.SystemClock;
import android.view.MotionEvent;

import com.pacco.animecut.core.Layer;
import com.pacco.animecut.core.PerfStats;
import com.pacco.animecut.core.Project;

import java.util.Locale;

/**
 * v8.27: prueba de rendimiento AUTOMATICA que corre dentro del APK (Menu > Medir
 * rendimiento). Usa un CanvasView aparte con obras de prueba (nunca toca la obra del
 * usuario) y el mismo codigo de la app: brocha (normal y protegiendo contornos),
 * balde, dibujo de pantalla y Marioneta, en 720p, 1080p, 2K, 4K y A4 con 6 capas.
 *
 * Cada paso es corto y va en su propio mensaje del hilo principal (con pausas de un
 * cuadro), asi la app no se congela ni da "La aplicacion no responde". Los eventos
 * tactiles van separados 16 ms como un dedo real.
 *
 * Mide tiempos por evento (p50/p95/p99 y maximo, en PerfStats), memoria de Java y
 * nativa maxima y recolecciones de basura. Si falta memoria en un tamano, lo dice y
 * sigue con el siguiente (no cierra la app).
 */
public final class PerfBench {

    public interface Listener {
        void onProgress(String step);

        void onDone(String report);
    }

    private static final int[][] SIZES = {{1280, 720}, {1920, 1080}, {2560, 1440}, {3840, 2160}, {2480, 3508}};
    private static final String[] SIZE_NAMES = {"720p", "1080p", "2K", "4K", "A4 300 ppp"};

    private final CanvasView cv;
    private final Handler h;
    private final Listener listener;
    private final StringBuilder report = new StringBuilder();
    private final java.util.ArrayDeque<Runnable> steps = new java.util.ArrayDeque<Runnable>();
    private boolean cancelled;
    private long peakJava, peakNative;
    private int sizeIdx;
    private long t0;

    /** El CanvasView debe estar en la ventana (puede estar invisible) para recibir sus mensajes. */
    public PerfBench(CanvasView cv, Handler h, Listener l) {
        this.cv = cv;
        this.h = h;
        this.listener = l;
    }

    public void cancel() {
        cancelled = true;
        steps.clear();
    }

    public void start(boolean all) {
        t0 = SystemClock.uptimeMillis();
        report.append("Paint Zeta - prueba de rendimiento automatica\n");
        report.append("Equipo: ").append(deviceName()).append('\n');
        report.append("Memoria maxima de Java para la app: ").append(Runtime.getRuntime().maxMemory() >> 20).append(" MB\n");
        report.append("Tiempos en milisegundos por evento. p95 = el 95 % de los eventos tardo eso o menos.\n");
        report.append("Objetivo inicial (a calibrar): p95 < 33 ms al pintar y ninguna pausa > 700 ms.\n\n");
        int n = all ? SIZES.length : 2;
        for (int i = 0; i < n; i++) {
            final int idx = i;
            steps.add(new Runnable() { public void run() { beginSize(idx); } });
        }
        steps.add(new Runnable() { public void run() { finish(); } });
        next(30);
    }

    private static String deviceName() {
        try {
            return android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL + " (Android " + android.os.Build.VERSION.RELEASE + ")";
        } catch (Throwable t) {
            return "desconocido";
        }
    }

    private void next(long delay) {
        if (cancelled) return;
        h.postDelayed(new Runnable() {
            @Override public void run() {
                if (cancelled) return;
                Runnable r = steps.poll();
                if (r == null) return;
                try {
                    r.run();
                } catch (Throwable t) {
                    report.append("   FALLO en un paso: ").append(t.getClass().getSimpleName()).append(' ')
                            .append(t.getMessage()).append('\n');
                    // se descarta lo que quedaba de este tamano
                    while (!steps.isEmpty() && steps.peek() instanceof SizeStep) steps.poll();
                    cleanupSize();
                }
                next(16);
            }
        }, delay);
    }

    /** Paso que pertenece al tamano actual (se descarta si ese tamano falla). */
    private abstract static class SizeStep implements Runnable { }

    private void addFirst(java.util.List<Runnable> list) {
        for (int i = list.size() - 1; i >= 0; i--) steps.addFirst(list.get(i));
    }

    private void sample() {
        Runtime rt = Runtime.getRuntime();
        long j = rt.totalMemory() - rt.freeMemory();
        if (j > peakJava) peakJava = j;
        try {
            long nat = android.os.Debug.getNativeHeapAllocatedSize();
            if (nat > peakNative) peakNative = nat;
        } catch (Throwable ignored) { }
    }

    private static long gcCount() {
        try {
            String v = android.os.Debug.getRuntimeStat("art.gc.gc-count");
            return v == null ? -1 : Long.parseLong(v);
        } catch (Throwable t) {
            return -1;
        }
    }

    private Project project;
    private long gc0;

    private void beginSize(final int idx) {
        sizeIdx = idx;
        final int w = SIZES[idx][0], hh = SIZES[idx][1];
        listener.onProgress("Preparando " + SIZE_NAMES[idx] + " (" + w + "x" + hh + ", 6 capas)...");
        System.gc();
        peakJava = 0;
        peakNative = 0;
        gc0 = gcCount();
        try {
            project = makeProject(w, hh);
        } catch (OutOfMemoryError e) {
            project = null;
            report.append("== ").append(SIZE_NAMES[idx]).append(": SIN MEMORIA al crear la obra de prueba (no es un cierre de la app)\n\n");
            return;
        }
        cv.setProject(project);
        cv.setFillTarget(CanvasView.FILL_TARGET_CURRENT);
        cv.setBucketPreview(false);
        cv.setFillByLines(false);
        project.active = 1;
        PerfStats.reset();
        sample();
        java.util.ArrayList<Runnable> list = new java.util.ArrayList<Runnable>();
        // brocha normal (Color plano 30 px)
        list.add(new SizeStep() { public void run() {
            listener.onProgress(SIZE_NAMES[idx] + ": brocha");
            cv.setMode(CanvasView.MODE_PAINT);
            cv.setColor(0xFFE02020);
            cv.setBrushSize(30);
            cv.setHardness(1f);
            cv.setBrushOpacity(1f);
            cv.setLineStop(false);
            cv.setBrushDynamics(0, 0, 0, 0, 0, 0.10f, 0);
        } });
        addStroke(list, w, hh, 0.15f, 0.30f, 0.85f, 0.45f, 30);
        addStroke(list, w, hh, 0.20f, 0.60f, 0.80f, 0.70f, 30);
        // brocha protegiendo contornos
        list.add(new SizeStep() { public void run() {
            listener.onProgress(SIZE_NAMES[idx] + ": brocha con Proteger contornos");
            cv.setLineStop(true);
        } });
        addStroke(list, w, hh, 0.12f, 0.52f, 0.88f, 0.55f, 30);
        list.add(new SizeStep() { public void run() { cv.setLineStop(false); } });
        // balde (3 toques)
        list.add(new SizeStep() { public void run() {
            listener.onProgress(SIZE_NAMES[idx] + ": balde");
            cv.setMode(CanvasView.MODE_BUCKET);
        } });
        for (int k = 0; k < 3; k++) {
            final float fx = 0.07f + 0.3f * k, fy = 0.12f;
            list.add(new SizeStep() { public void run() { tap(fx * w, fy * hh); } });
            list.add(waitIdle(15000));
        }
        // dibujar pantalla
        list.add(new SizeStep() { public void run() {
            listener.onProgress(SIZE_NAMES[idx] + ": dibujar pantalla");
            Bitmap b = Bitmap.createBitmap(Math.max(1, cv.getWidth()), Math.max(1, cv.getHeight()), Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            for (int k = 0; k < 8; k++) cv.draw(c);
            b.recycle();
            sample();
        } });
        // Marioneta solo en 1080p (la mas comun en tu flujo)
        if (idx == 1) addPuppet(list, w, hh);
        list.add(new SizeStep() { public void run() { endSize(idx); } });
        addFirst(list);
    }

    private void addStroke(java.util.List<Runnable> list, final int w, final int hh, final float ax, final float ay,
                           final float bx, final float by, final int events) {
        list.add(new SizeStep() { public void run() { touchImg(MotionEvent.ACTION_DOWN, ax * w, ay * hh); } });
        for (int k = 1; k <= events; k++) {
            final float t = k / (float) events;
            list.add(new SizeStep() { public void run() {
                float x = (ax + (bx - ax) * t) * w, y = (ay + (by - ay) * t) * hh + (float) Math.sin(t * 6.28) * hh * 0.03f;
                touchImg(MotionEvent.ACTION_MOVE, x, y);
                if (((int) (t * events)) % 6 == 0) sample();
            } });
        }
        list.add(new SizeStep() { public void run() { touchImg(MotionEvent.ACTION_UP, bx * w, by * hh); } });
        list.add(waitIdle(8000));
    }

    private void addPuppet(java.util.List<Runnable> list, final int w, final int hh) {
        list.add(new SizeStep() { public void run() {
            listener.onProgress("1080p: Marioneta");
            // capa con un "personaje": figura opaca sobre transparente
            int[] px = new int[w * hh];
            int cx = w / 2;
            for (int y = (int) (hh * 0.1f); y < hh * 0.95f; y++) {
                float half = y < hh * 0.3f ? hh * 0.08f : hh * 0.12f;
                for (int x = (int) (cx - half); x < cx + half; x++) px[y * w + x] = 0xFF3050A0 ^ ((x ^ y) & 0x1F);
            }
            Layer fig = new Layer("figura", px);
            project.layers.add(fig);
            project.active = project.layers.size() - 1;
            cv.layersChanged();
            cv.setMode(CanvasView.MODE_PUPPET);
            cv.setTransformType(4);
        } });
        list.add(waitPuppet(20000));
        final float[][] pins = {{0.5f, 0.92f}, {0.5f, 0.55f}, {0.5f, 0.2f}};
        for (final float[] p : pins) {
            list.add(new SizeStep() { public void run() { tap(p[0] * w, p[1] * hh); } });
            list.add(pause(120));
        }
        list.add(new SizeStep() { public void run() {
            // fijar el pie: el primer punto
            if (cv.getPuppetPinCount() > 0) {
                cv.selectPuppetPinForBench(0);
                cv.togglePuppetFixed();
            }
        } });
        list.add(new SizeStep() { public void run() { touchImg(MotionEvent.ACTION_DOWN, 0.5f * w, 0.2f * hh); } });
        for (int k = 1; k <= 40; k++) {
            final float t = k / 40f;
            list.add(new SizeStep() { public void run() { touchImg(MotionEvent.ACTION_MOVE, (0.5f + 0.18f * t) * w, (0.2f + 0.05f * t) * hh); } });
        }
        list.add(new SizeStep() { public void run() { touchImg(MotionEvent.ACTION_UP, 0.68f * w, 0.25f * hh); } });
        list.add(pause(600));
        list.add(new SizeStep() { public void run() { cv.cancelTransform(); cv.setMode(CanvasView.MODE_PAINT); } });
    }

    private Runnable pause(final long ms) {
        return new SizeStep() { public void run() {
            final long until = SystemClock.uptimeMillis() + ms;
            steps.addFirst(new SizeStep() { public void run() {
                if (SystemClock.uptimeMillis() < until) steps.addFirst(this);
            } });
        } };
    }

    private Runnable waitIdle(final long maxMs) {
        return new SizeStep() { public void run() {
            final long until = SystemClock.uptimeMillis() + maxMs;
            steps.addFirst(new SizeStep() { public void run() {
                sample();
                if (cv.isBusy() && SystemClock.uptimeMillis() < until) steps.addFirst(this);
            } });
        } };
    }

    private Runnable waitPuppet(final long maxMs) {
        return new SizeStep() { public void run() {
            final long until = SystemClock.uptimeMillis() + maxMs;
            steps.addFirst(new SizeStep() { public void run() {
                sample();
                if (!cv.isPuppetReady() && SystemClock.uptimeMillis() < until) steps.addFirst(this);
            } });
        } };
    }

    private long downTime;

    private void touchImg(int action, float ix, float iy) {
        float[] s = cv.imageToScreen(ix, iy);
        long now = SystemClock.uptimeMillis();
        if (action == MotionEvent.ACTION_DOWN) downTime = now;
        MotionEvent e = MotionEvent.obtain(downTime, now, action, s[0], s[1], 0);
        try {
            cv.onTouchEvent(e);
        } finally {
            e.recycle();
        }
    }

    private void tap(float ix, float iy) {
        touchImg(MotionEvent.ACTION_DOWN, ix, iy);
        touchImg(MotionEvent.ACTION_UP, ix, iy);
    }

    private void endSize(int idx) {
        sample();
        long gc1 = gcCount();
        int w = SIZES[idx][0], hh = SIZES[idx][1];
        report.append("== ").append(SIZE_NAMES[idx]).append(" (").append(w).append('x').append(hh).append(", 6 capas) ==\n");
        report.append(PerfStats.report());
        report.append(String.format(Locale.US, "   Memoria maxima: Java %d MB, nativa %d MB", peakJava >> 20, peakNative >> 20));
        if (gc0 >= 0 && gc1 >= 0) report.append(", recolecciones de basura: ").append(gc1 - gc0);
        report.append("\n\n");
        cleanupSize();
    }

    private void cleanupSize() {
        project = null;
        try {
            Project empty = new Project(16, 16);
            empty.layers.add(new Layer("vacia", 16, 16));
            empty.active = 0;
            cv.setProject(empty);
        } catch (Throwable ignored) { }
        System.gc();
    }

    private void finish() {
        report.append("Duracion total: ").append((SystemClock.uptimeMillis() - t0) / 1000).append(" s\n");
        report.append("Nota: esto se midio en ESTE telefono. Las pruebas de la computadora no valen como telefono.\n");
        listener.onDone(report.toString());
    }

    /** Obra de prueba: dibujo tipo manga (lineas + trama) y 5 capas mas, 3 con contenido. */
    static Project makeProject(int w, int h) {
        Project p = new Project(w, h);
        int[] px = new int[w * h];
        java.util.Arrays.fill(px, 0xFFFFFFFF);
        // trama de puntos en la mitad derecha
        for (int y = 0; y < h; y += 4)
            for (int x = w / 2; x < w; x += 4) {
                px[y * w + x] = 0xFF505050;
                if (x + 1 < w) px[y * w + x + 1] = 0xFF505050;
            }
        // lineas negras de 3 px: una cuadricula de zonas
        int step = Math.max(40, Math.min(w, h) / 6);
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                if (x % step < 3 || y % step < 3) px[y * w + x] = 0xFF101010;
            }
        p.layers.add(new Layer("dibujo", px));
        p.layers.add(new Layer("capa_1", w, h));
        for (int k = 0; k < 4; k++) {
            int[] q = new int[w * h];
            int x0 = w * k / 5, y0 = h * k / 6, x1 = Math.min(w, x0 + w / 4), y1 = Math.min(h, y0 + h / 4);
            if (k < 3)
                for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) q[y * w + x] = 0x6600AA00 + (k << 16);
            Layer l = new Layer("capa_extra_" + (k + 1), q);
            l.pack(w, h);
            p.layers.add(l);
        }
        p.active = 1;
        return p;
    }
}
