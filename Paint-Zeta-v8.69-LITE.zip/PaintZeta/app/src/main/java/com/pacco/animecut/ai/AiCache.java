package com.pacco.animecut.ai;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.CRC32;

/**
 * v8.33: guarda la salida cruda de la IA de una imagen (1 MB como mucho) para REABRIR el recorte
 * sin volver a correr el modelo (misma capa, misma zona). La clave es un resumen de los pixeles.
 * Se guardan las ultimas 6.
 */
public final class AiCache {
    private static final int VERSION = 1;
    private static final int KEEP = 6;
    private final File dir;

    public AiCache(File dir) { this.dir = dir; }

    /** Resumen de la zona de la capa (CRC32 de todos sus pixeles + tamanos). */
    public static long key(int[] px, int W, int x0, int y0, int cw, int ch, int S) {
        CRC32 c = new CRC32();
        byte[] row = new byte[cw * 4];
        for (int y = y0; y < y0 + ch; y++) {
            int o = y * W + x0;
            for (int x = 0; x < cw; x++) {
                int v = px[o + x];
                row[x * 4] = (byte) (v >>> 24); row[x * 4 + 1] = (byte) (v >>> 16);
                row[x * 4 + 2] = (byte) (v >>> 8); row[x * 4 + 3] = (byte) v;
            }
            c.update(row, 0, row.length);
        }
        long h = c.getValue();
        return (h << 20) ^ ((long) cw * 73856093L) ^ ((long) ch * 19349663L) ^ ((long) x0 << 40) ^ ((long) y0 << 10) ^ S ^ ((long) VERSION << 60);
    }

    private File fileFor(long key) { return new File(dir, "ia_" + Long.toHexString(key) + ".bin"); }

    public void save(long key, AiPrep p, byte[] raw) {
        try {
            if (!dir.exists()) dir.mkdirs();
            File f = fileFor(key);
            try (DataOutputStream o = new DataOutputStream(new java.io.BufferedOutputStream(new FileOutputStream(f)))) {
                o.writeInt(VERSION);
                o.writeInt(p.S); o.writeInt(p.cropX); o.writeInt(p.cropY); o.writeInt(p.cropW); o.writeInt(p.cropH);
                o.writeInt(raw.length);
                o.write(raw);
            }
            trim();
        } catch (IOException ignored) { }
    }

    /** null si no esta o no sirve. */
    public Object[] load(long key) {
        File f = fileFor(key);
        if (!f.exists()) return null;
        try (DataInputStream in = new DataInputStream(new java.io.BufferedInputStream(new FileInputStream(f)))) {
            if (in.readInt() != VERSION) return null;
            int S = in.readInt(), x = in.readInt(), y = in.readInt(), w = in.readInt(), h = in.readInt();
            AiPrep p = AiPrep.plan(S, x, y, w, h);
            int n = in.readInt();
            if (n != p.w * p.h) return null;
            byte[] raw = new byte[n];
            in.readFully(raw);
            f.setLastModified(System.currentTimeMillis());
            return new Object[]{p, raw};
        } catch (Exception e) {
            return null;
        }
    }

    private void trim() {
        File[] fs = dir.listFiles();
        if (fs == null || fs.length <= KEEP) return;
        java.util.Arrays.sort(fs, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        for (int i = KEEP; i < fs.length; i++) if (fs[i].getName().startsWith("ia_")) fs[i].delete();
    }
}
