package com.pacco.animecut.ai;

/**
 * v8.36: "el borde sigue la linea". La IA da la IDEA (que es personaje y que es fondo) y aqui
 * el corte se pasa a las lineas del propio dibujo (implementacion propia; no copia codigo GPL):
 *
 *  1) TINTA: pixeles bastante mas oscuros que lo que los rodea (lineas, contornos, el lado
 *     oscuro de un borde fuerte). Lo demas es "espacio libre".
 *  2) ZONAS: el espacio libre se separa en zonas cerradas por la tinta. Un corte de la linea
 *     mas chico que ~ el grosor de la linea no las une (nucleo con distancia > g a la tinta,
 *     despues se crece de vuelta hasta la tinta).
 *  3) VOTO: cada zona entra o sale ENTERA segun lo que dijo la IA en ella. Si la zona esta muy
 *     mezclada (la linea tenia un hueco grande y se unio con el fondo) no se decide: queda la IA.
 *     Asi desaparecen las manchas a medias (manga) y el filo blanco de fondo pegado al contorno.
 *  4) LINEA: la tinta pegada a una zona del personaje entra con el (el contorno es del
 *     personaje), solo si la IA veia algo ahi y si es mas oscura que el fondo de al lado (en un
 *     fondo negro no se agrega nada). La tinta del fondo, lejos del personaje, sale.
 *  5) ANTIALIAS: en el limite contorno/fondo el alfa sale de DESMEZCLAR la luminancia entre el
 *     fondo de al lado y lo mas oscuro de la linea: el borde queda suave y sin escalones.
 *
 * Trabaja por bloques de 512 px con margen (memoria acotada) y solo donde hay borde de la IA.
 * Java puro: lo usan la app y las pruebas.
 */
public final class AiSnap {

    public static final class Stats {
        public int tiles, zonesIn, zonesOut, zonesMixed, blobs, changed;
        public float halfWidth;
        public long ms;
    }

    static final int TILE = 512;

    private AiSnap() { }

    /**
     * @param al alfa de la IA (W*H), se cambia en el lugar
     * @param hw medio grosor de linea medido (BgEngine.measure)
     */
    public static Stats apply(byte[] al, int[] px, int W, int H, int x0, int y0, int x1, int y1, float hw) {
        return apply(al, px, W, H, x0, y0, x1, y1, hw, Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors())));
    }

    public static Stats apply(final byte[] al, final int[] px, final int W, int H, int x0, int y0, int x1, int y1, float hw, int threads) {
        long t0 = System.nanoTime();
        Stats st = new Stats();
        hw = Math.max(0.75f, Math.min(6f, hw));
        st.halfWidth = hw;
        final int r = (int) Math.ceil(2 * hw) + 2;            // ventana de "mas oscuro que lo de al lado"
        final int g = Math.max(1, Math.round(1.5f * hw + 1));   // huecos de la linea < 2g no unen zonas
        final int reach = (int) Math.ceil(2 * hw) + 2;          // la linea del personaje: hasta ~ su grosor
        final int margin = Math.max(48, 4 * r + 2 * g + 16);
        long cropArea = (long) (x1 - x0) * (y1 - y0);
        final int smallZone = (int) Math.max(400, Math.min(Integer.MAX_VALUE, cropArea / 300));
        // se lee de una copia (los bloques vecinos leen su margen sin ver lo ya cambiado) y se
        // reparten los bloques entre los nucleos del procesador
        final byte[] src = al.clone();
        final java.util.ArrayList<int[]> jobs = new java.util.ArrayList<>();
        for (int ty = y0; ty < y1; ty += TILE)
            for (int tx = x0; tx < x1; tx += TILE) {
                int bx1 = Math.min(x1, tx + TILE), by1 = Math.min(y1, ty + TILE);
                int ex0 = Math.max(x0, tx - margin), ey0 = Math.max(y0, ty - margin);
                int ex1 = Math.min(x1, bx1 + margin), ey1 = Math.min(y1, by1 + margin);
                if (hasEdge(src, W, ex0, ey0, ex1, ey1)) jobs.add(new int[]{tx, ty, bx1, by1, ex0, ey0, ex1, ey1});
            }
        st.tiles = jobs.size();
        final java.util.concurrent.atomic.AtomicInteger next = new java.util.concurrent.atomic.AtomicInteger();
        final int fx0 = x0, fy0 = y0, fx1 = x1, fy1 = y1;
        final Stats[] part = new Stats[Math.max(1, Math.min(threads, jobs.size()))];
        final Throwable[] err = new Throwable[1];
        Thread[] th = new Thread[part.length];
        for (int t = 0; t < part.length; t++) {
            final Stats ps = part[t] = new Stats();
            Runnable job = new Runnable() {
                @Override public void run() {
                    try {
                        int j;
                        while ((j = next.getAndIncrement()) < jobs.size()) {
                            int[] b = jobs.get(j);
                            tile(src, al, px, W, b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], fx0, fy0, fx1, fy1, r, g, reach, smallZone, ps);
                        }
                    } catch (Throwable e) { synchronized (err) { err[0] = e; } }
                }
            };
            if (t == part.length - 1) job.run();
            else { th[t] = new Thread(job, "pz-borde"); th[t].start(); }
        }
        for (Thread t : th) if (t != null) try { t.join(); } catch (InterruptedException ignored) { }
        if (err[0] instanceof OutOfMemoryError) throw (OutOfMemoryError) err[0];
        if (err[0] instanceof RuntimeException) throw (RuntimeException) err[0];
        for (Stats ps : part) {
            st.zonesIn += ps.zonesIn; st.zonesOut += ps.zonesOut; st.zonesMixed += ps.zonesMixed;
            st.blobs += ps.blobs; st.changed += ps.changed;
        }
        st.ms = (System.nanoTime() - t0) / 1_000_000L;
        return st;
    }

    /** Hay borde de la IA en la zona (las dos clases o valores intermedios)? */
    static boolean hasEdge(byte[] al, int W, int x0, int y0, int x1, int y1) {
        boolean lo = false, hi = false;
        for (int y = y0; y < y1; y++) {
            int o = y * W;
            for (int x = x0; x < x1; x++) {
                int v = al[o + x] & 0xFF;
                if (v > 20 && v < 235) return true;
                if (v < 128) lo = true; else hi = true;
                if (lo && hi) return true;
            }
        }
        return false;
    }

    static int lum(int c) {
        if ((c >>> 24) < 128) return 255;   // transparente: como papel
        return (((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000;
    }

    private static void tile(byte[] src, byte[] al, int[] px, int W, int tx, int ty, int bx1, int by1,
                             int ex0, int ey0, int ex1, int ey1, int cx0, int cy0, int cx1, int cy1,
                             int r, int g, int reach, int smallZone, Stats st) {
        final int ew = ex1 - ex0, eh = ey1 - ey0, en = ew * eh;
        byte[] L = new byte[en], A = new byte[en];
        int[] C = new int[en];
        for (int y = 0; y < eh; y++) {
            int o = (ey0 + y) * W + ex0, k = y * ew;
            for (int x = 0; x < ew; x++) {
                int c = px[o + x];
                L[k + x] = (byte) lum(c);
                A[k + x] = src[o + x];
                C[k + x] = (c >>> 24) < 128 ? 0xFFFFFF : c & 0xFFFFFF;
            }
        }
        // color de referencia cerca: fondo seguro (alfa <= 25) y personaje seguro (>= 230), radio 8
        float[][] ref = refColors(C, A, ew, eh, 8);
        float[] bR = ref[0], bG = ref[1], bB = ref[2], bN = ref[3], fR = ref[4], fG = ref[5], fB = ref[6], fN = ref[7];
        ref = null;
        // ---- 1) tinta ----
        byte[] ink = inkMap(L, ew, eh, r);
        // ---- 2) zonas: nucleos (lejos de la tinta) y crecimiento hasta la tinta ----
        int[] lab = new int[en];
        int nl = zones(ink, ew, eh, g, lab);
        if (nl == 0) return;
        // ---- 3) voto por zona ----
        int[] zn = new int[nl + 1], z1 = new int[nl + 1], z0 = new int[nl + 1];
        long[] zs = new long[nl + 1];
        // zona cortada por el borde del bloque (sigue afuera): no se sabe su tamano real -> grande
        boolean[] cut = new boolean[nl + 1];
        boolean cl = ex0 > cx0, cr = ex1 < cx1, ct = ey0 > cy0, cb = ey1 < cy1;
        for (int x = 0; x < ew; x++) {
            if (ct) cut[lab[x]] = true;
            if (cb) cut[lab[(eh - 1) * ew + x]] = true;
        }
        for (int y = 0; y < eh; y++) {
            if (cl) cut[lab[y * ew]] = true;
            if (cr) cut[lab[y * ew + ew - 1]] = true;
        }
        // color medio de la zona y de las referencias que la rodean
        float[] zc = new float[(nl + 1) * 3], zb = new float[(nl + 1) * 4], zf = new float[(nl + 1) * 4];
        for (int k = 0; k < en; k++) {
            int l = lab[k];
            if (l == 0) continue;
            int a = A[k] & 0xFF;
            zn[l]++; zs[l] += a;
            if (a >= 192) z1[l]++;
            else if (a <= 64) z0[l]++;
            int c = C[k];
            zc[l * 3] += (c >> 16) & 255; zc[l * 3 + 1] += (c >> 8) & 255; zc[l * 3 + 2] += c & 255;
            if (bN[k] > 0.02f) { zb[l * 4] += bR[k] / bN[k]; zb[l * 4 + 1] += bG[k] / bN[k]; zb[l * 4 + 2] += bB[k] / bN[k]; zb[l * 4 + 3]++; }
            if (fN[k] > 0.02f) { zf[l * 4] += fR[k] / fN[k]; zf[l * 4 + 1] += fG[k] / fN[k]; zf[l * 4 + 2] += fB[k] / fN[k]; zf[l * 4 + 3]++; }
        }
        // 0 = queda la IA; 1/2 = la zona entera sale/entra (zona chica: un mechon, un hueco);
        // 3/4 = zona GRANDE: solo cambia lo que la IA dejo a medias (el filo); lo que la IA dio
        // por seguro se respeta, por si la zona se unio con otra por un hueco de la linea
        byte[] zd = new byte[nl + 1];
        for (int l = 1; l <= nl; l++) {
            int n = zn[l];
            if (n < 12) continue;
            float m = zs[l] / (255f * n);
            float f1 = z1[l] / (float) n, f0 = z0[l] / (float) n;
            if (n <= smallZone && !cut[l]) {
                if (m >= 0.5f && f1 >= 0.5f && f0 <= 0.35f) zd[l] = 2;
                else if (m < 0.5f && f0 >= 0.5f && f1 <= 0.35f) zd[l] = 1;
                // el COLOR de la zona tiene que darle la razon: un hueco de cielo entre mechones
                // que la IA tomo como pelo no entra entero (y al reves)
                if (zd[l] != 0) {
                    float cr0 = zc[l * 3] / n, cg0 = zc[l * 3 + 1] / n, cb0 = zc[l * 3 + 2] / n;
                    float db = zb[l * 4 + 3] > 0 ? dist(cr0, cg0, cb0, zb[l * 4] / zb[l * 4 + 3], zb[l * 4 + 1] / zb[l * 4 + 3], zb[l * 4 + 2] / zb[l * 4 + 3]) : -1f;
                    float df = zf[l * 4 + 3] > 0 ? dist(cr0, cg0, cb0, zf[l * 4] / zf[l * 4 + 3], zf[l * 4 + 1] / zf[l * 4 + 3], zf[l * 4 + 2] / zf[l * 4 + 3]) : -1f;
                    if (zd[l] == 2 && !agrees(df, db)) zd[l] = 0;
                    else if (zd[l] == 1 && !agrees(db, df)) zd[l] = 0;
                }
            } else {
                if (m >= 0.5f && f0 <= 0.15f) zd[l] = 4;
                else if (m < 0.5f && f1 <= 0.15f) zd[l] = 3;
            }
            if (zd[l] == 2 || zd[l] == 4) st.zonesIn++; else if (zd[l] == 1 || zd[l] == 3) st.zonesOut++; else st.zonesMixed++;
        }
        // color medio de lo SEGURO de cada lado dentro de la zona (para las manchas)
        float[] zm = new float[(nl + 1) * 8];
        for (int k = 0; k < en; k++) {
            int l = lab[k];
            if (l == 0 || zd[l] < 3) continue;
            int a = A[k] & 0xFF;
            int side = a >= 230 ? 1 : a <= 25 ? 0 : -1;
            if (side < 0) continue;
            int c = C[k], o = l * 8 + side * 4;
            zm[o] += (c >> 16) & 255; zm[o + 1] += (c >> 8) & 255; zm[o + 2] += c & 255; zm[o + 3]++;
        }
        byte[] D = new byte[en];
        // manchas: en una zona grande, un pedazo que la IA dio por seguro AL REVES de toda la
        // zona, chico y del MISMO color que la zona, es un error de la IA (manga): se corrige.
        // Un pedazo grande o de otro color (cuello pegado a una barra por un hueco) se respeta.
        {
            byte[] seen = new byte[en];
            int[] cq = new int[en];
            for (int s0 = 0; s0 < en; s0++) {
                int l = lab[s0];
                if (l == 0 || seen[s0] != 0 || zd[l] < 3) continue;
                boolean wantFg = zd[l] == 4;
                if (!minority(A[s0] & 0xFF, wantFg)) continue;
                int qh = 0, qt = 0;
                cq[qt++] = s0; seen[s0] = 1;
                long sr = 0, sg = 0, sb = 0;
                boolean edge = false;
                while (qh < qt) {
                    int k = cq[qh++];
                    int c = C[k];
                    sr += (c >> 16) & 255; sg += (c >> 8) & 255; sb += c & 255;
                    int x = k % ew, y = k / ew;
                    if (x == 0 || y == 0 || x == ew - 1 || y == eh - 1) edge = true;
                    for (int t = 0; t < 4; t++) {
                        int j;
                        if (t == 0) { if (x == 0) continue; j = k - 1; }
                        else if (t == 1) { if (x + 1 >= ew) continue; j = k + 1; }
                        else if (t == 2) { if (y == 0) continue; j = k - ew; }
                        else { if (y + 1 >= eh) continue; j = k + ew; }
                        if (seen[j] != 0 || lab[j] != l || !minority(A[j] & 0xFF, wantFg)) continue;
                        seen[j] = 1;
                        cq[qt++] = j;
                    }
                }
                int o = l * 8 + (wantFg ? 4 : 0);
                if (edge || qt > smallZone || qt * 4 > zn[l] || zm[o + 3] < 1) continue;
                float d = dist(sr / (float) qt, sg / (float) qt, sb / (float) qt, zm[o] / zm[o + 3], zm[o + 1] / zm[o + 3], zm[o + 2] / zm[o + 3]);
                if (d > 35f) continue;
                for (int t = 0; t < qt; t++) D[cq[t]] = (byte) (wantFg ? 2 : 1);
                st.blobs++;
            }
        }
        for (int k = 0; k < en; k++) {
            int l = lab[k];
            if (l == 0 || D[k] != 0) continue;
            int z = zd[l], a = A[k] & 0xFF;
            if (z == 3 || z == 4) {
                // zona grande: solo el filo a medias, y solo si su color es del lado elegido
                // (un mechon fino o una cinta de otro color se respeta)
                int c = C[k];
                float cr0 = (c >> 16) & 255, cg0 = (c >> 8) & 255, cb0 = c & 255;
                float db = bN[k] > 0.02f ? dist(cr0, cg0, cb0, bR[k] / bN[k], bG[k] / bN[k], bB[k] / bN[k]) : -1f;
                float df = fN[k] > 0.02f ? dist(cr0, cg0, cb0, fR[k] / fN[k], fG[k] / fN[k], fB[k] / fN[k]) : -1f;
                if (z == 3) z = a >= 230 || !agrees(db, df) ? 0 : 1;
                else z = a <= 25 || !agrees(df, db) ? 0 : 2;
            }
            D[k] = (byte) z;
        }
        lab = null;
        // ---- 4) tinta del personaje ----
        byte[] fgz = new byte[en];
        for (int k = 0; k < en; k++) if (ink[k] == 0 && D[k] == 2) fgz[k] = 1;
        int[] dfg = AiMatte.edt(fgz, ew, eh);
        fgz = null;
        float[] t1 = new float[en], t2 = new float[en], bgS = new float[en], bgN = new float[en], buf = new float[en];
        for (int k = 0; k < en; k++) {
            boolean b = (A[k] & 0xFF) <= 25;
            t1[k] = b ? (L[k] & 0xFF) : 0f;
            t2[k] = b ? 1f : 0f;
        }
        AiMatte.box(t1, bgS, ew, eh, 4, buf);
        AiMatte.box(t2, bgN, ew, eh, 4, buf);
        int reach2 = reach * reach;
        for (int k = 0; k < en; k++) {
            if (ink[k] == 0) continue;
            int a = A[k] & 0xFF;
            if (a >= 128) { D[k] = 2; continue; }
            if (dfg[k] <= reach2 && a >= 20 && bgN[k] > 0.05f) {
                float lb = bgS[k] / bgN[k];
                if ((L[k] & 0xFF) <= lb - 40f) { D[k] = 2; continue; }
            }
            D[k] = a <= 25 ? (byte) 1 : (byte) 0;
        }
        dfg = null;
        // ---- 5) antialias por desmezcla en el limite linea / fondo ----
        // luminancia media de lo que quedo como fondo (radio 3)
        for (int k = 0; k < en; k++) {
            boolean b = D[k] == 1;
            t1[k] = b ? (L[k] & 0xFF) : 0f;
            t2[k] = b ? 1f : 0f;
        }
        AiMatte.box(t1, bgS, ew, eh, 3, buf);
        AiMatte.box(t2, bgN, ew, eh, 3, buf);
        t1 = t2 = buf = null;
        int changed = 0;
        for (int y = ty; y < by1; y++) {
            for (int x = tx; x < bx1; x++) {
                int k = (y - ey0) * ew + (x - ex0);
                int d = D[k];
                if (d == 0) continue;
                int i = y * W + x;
                int out;
                if (d == 2) {
                    out = 255;
                    if (ink[k] != 0 && bgN[k] > 0.01f && nearD(D, ew, eh, k, 1, 2)) {
                        float lb = bgS[k] / bgN[k];
                        float lmin = minInkFg(L, D, ink, ew, eh, k, 2);
                        if (lb - lmin >= 50f) {
                            float u = (lb - (L[k] & 0xFF)) / (lb - lmin);
                            out = Math.round(Math.max(0f, Math.min(1f, u)) * 255f);
                        }
                    }
                } else {
                    out = 0;
                    if (bgN[k] > 0.01f && nearInkFg(D, ink, ew, eh, k)) {
                        float lb = bgS[k] / bgN[k];
                        float lmin = minInkFg(L, D, ink, ew, eh, k, 2);
                        float l = L[k] & 0xFF;
                        if (lb - lmin >= 50f && l < lb - 10f) {
                            float u = (lb - l) / (lb - lmin);
                            out = Math.round(Math.max(0f, Math.min(0.8f, u)) * 255f);
                        }
                    }
                }
                if ((al[i] & 0xFF) != out) { al[i] = (byte) out; changed++; }
            }
        }
        st.changed += changed;
    }

    /**
     * Zonas cerradas por la tinta: nucleos (distancia a la tinta > g, asi un hueco de la linea
     * de menos de 2g no une dos zonas) que despues crecen por el espacio libre hasta la tinta.
     * lab: etiqueta por pixel (0 = tinta o rincon angosto sin zona). Devuelve cuantas zonas.
     */
    static int zones(byte[] ink, int ew, int eh, int g, int[] lab) {
        int en = ew * eh;
        int[] d2 = AiMatte.edt(ink, ew, eh);
        int[] q = new int[en];
        int g2 = g * g;
        int nl = 0;
        for (int s = 0; s < en; s++) {
            if (lab[s] != 0 || ink[s] != 0 || d2[s] <= g2) continue;
            nl++;
            int qh = 0, qt = 0;
            q[qt++] = s; lab[s] = nl;
            while (qh < qt) {
                int k = q[qh++];
                int x = k % ew, y = k / ew;
                if (x > 0) { int j = k - 1; if (lab[j] == 0 && ink[j] == 0 && d2[j] > g2) { lab[j] = nl; q[qt++] = j; } }
                if (x + 1 < ew) { int j = k + 1; if (lab[j] == 0 && ink[j] == 0 && d2[j] > g2) { lab[j] = nl; q[qt++] = j; } }
                if (y > 0) { int j = k - ew; if (lab[j] == 0 && ink[j] == 0 && d2[j] > g2) { lab[j] = nl; q[qt++] = j; } }
                if (y + 1 < eh) { int j = k + ew; if (lab[j] == 0 && ink[j] == 0 && d2[j] > g2) { lab[j] = nl; q[qt++] = j; } }
            }
        }
        d2 = null;
        if (nl == 0) return 0;
        byte[] step = new byte[en];
        int qh = 0, qt = 0;
        for (int k = 0; k < en; k++) if (lab[k] != 0) q[qt++] = k;
        int lim = g + 2;
        while (qh < qt) {
            int k = q[qh++];
            int sv = step[k];
            if (sv >= lim) continue;
            int x = k % ew, y = k / ew;
            for (int t = 0; t < 4; t++) {
                int j;
                if (t == 0) { if (x == 0) continue; j = k - 1; }
                else if (t == 1) { if (x + 1 >= ew) continue; j = k + 1; }
                else if (t == 2) { if (y == 0) continue; j = k - ew; }
                else { if (y + 1 >= eh) continue; j = k + ew; }
                if (lab[j] != 0 || ink[j] != 0) continue;
                lab[j] = lab[k];
                step[j] = (byte) (sv + 1);
                q[qt++] = j;
            }
        }
        return nl;
    }

    /** Tinta: bastante mas oscuro que lo mas claro alrededor (radio r). */
    static byte[] inkMap(byte[] L, int ew, int eh, int r) {
        int en = ew * eh;
        byte[] mx = new byte[en];
        maxFilter(L, mx, ew, eh, r);
        byte[] ink = new byte[en];
        for (int k = 0; k < en; k++) if ((L[k] & 0xFF) + 50 <= (mx[k] & 0xFF)) ink[k] = 1;
        return ink;
    }

    /** El pixel esta seguro del lado CONTRARIO al que eligio la zona? */
    static boolean minority(int a, boolean wantFg) { return wantFg ? a <= 25 : a >= 230; }

    static float dist(float r0, float g0, float b0, float r1, float g1, float b1) {
        float dr = r0 - r1, dg = g0 - g1, db = b0 - b1;
        return (float) Math.sqrt(dr * dr + dg * dg + db * db);
    }

    /**
     * El color esta del lado elegido? dMine = distancia al color de referencia de ese lado,
     * dOther = al del otro lado (-1 = no hay referencia cerca).
     */
    static boolean agrees(float dMine, float dOther) {
        if (dMine < 0f) return dOther >= 0f && dOther > 60f;   // sin referencia propia: solo si no se parece al otro
        if (dOther < 0f) return dMine <= 45f;
        return dMine + 10f < dOther || dMine <= 18f;
    }

    /**
     * Sumas en ventana (~rad px) de los colores seguros de fondo (0..3: R, G, B, cuenta) y de
     * personaje (4..7). Se calcula en una grilla de 4x4 px (es una referencia de color, no
     * necesita detalle) y se devuelve por pixel (lo que se lee es el cociente suma / cuenta).
     */
    static float[][] refColors(int[] C, byte[] A, int ew, int eh, int rad) {
        final int c = 4;
        int gw = (ew + c - 1) / c, gh = (eh + c - 1) / c, gn = gw * gh;
        float[][] gsum = new float[8][gn];
        for (int k = 0; k < ew * eh; k++) {
            int a = A[k] & 0xFF;
            int side = a <= 25 ? 0 : a >= 230 ? 1 : -1;
            if (side < 0) continue;
            int x = k % ew, y = k / ew, gk = (y / c) * gw + x / c, col = C[k], o = side * 4;
            gsum[o][gk] += (col >> 16) & 255; gsum[o + 1][gk] += (col >> 8) & 255; gsum[o + 2][gk] += col & 255; gsum[o + 3][gk]++;
        }
        int gr = Math.max(1, (rad + c / 2) / c);
        float[] buf = new float[gn], tmp = new float[gn];
        float[][] out = new float[8][];
        int en = ew * eh;
        for (int q = 0; q < 8; q++) {
            AiMatte.box(gsum[q], tmp, gw, gh, gr, buf);
            float[] o = new float[en];
            for (int y = 0; y < eh; y++) {
                int go = (y / c) * gw, ko = y * ew;
                for (int x = 0; x < ew; x++) o[ko + x] = tmp[go + x / c];
            }
            out[q] = o;
        }
        return out;
    }

    /** Hay un pixel con decision v a distancia <= rad (Chebyshev)? */
    static boolean nearD(byte[] D, int ew, int eh, int k, int v, int rad) {
        int x0 = k % ew, y0 = k / ew;
        for (int dy = -rad; dy <= rad; dy++) {
            int y = y0 + dy;
            if (y < 0 || y >= eh) continue;
            for (int dx = -rad; dx <= rad; dx++) {
                int x = x0 + dx;
                if (x < 0 || x >= ew) continue;
                if (D[y * ew + x] == v) return true;
            }
        }
        return false;
    }

    /** Tinta del personaje pegada (3x3). */
    static boolean nearInkFg(byte[] D, byte[] ink, int ew, int eh, int k) {
        int x0 = k % ew, y0 = k / ew;
        for (int dy = -1; dy <= 1; dy++) {
            int y = y0 + dy;
            if (y < 0 || y >= eh) continue;
            for (int dx = -1; dx <= 1; dx++) {
                int x = x0 + dx;
                if (x < 0 || x >= ew) continue;
                int j = y * ew + x;
                if (D[j] == 2 && ink[j] != 0) return true;
            }
        }
        return false;
    }

    /** Lo mas oscuro de la tinta del personaje cerca (la linea misma, no su antialias). */
    static float minInkFg(byte[] L, byte[] D, byte[] ink, int ew, int eh, int k, int rad) {
        int x0 = k % ew, y0 = k / ew;
        int m = 255;
        for (int dy = -rad; dy <= rad; dy++) {
            int y = y0 + dy;
            if (y < 0 || y >= eh) continue;
            for (int dx = -rad; dx <= rad; dx++) {
                int x = x0 + dx;
                if (x < 0 || x >= ew) continue;
                int j = y * ew + x;
                if (D[j] == 2 && ink[j] != 0) { int l = L[j] & 0xFF; if (l < m) m = l; }
            }
        }
        return m;
    }

    /** Maximo en ventana (2r+1)^2, separable. */
    static void maxFilter(byte[] src, byte[] dst, int w, int h, int r) {
        byte[] tmp = new byte[w * h];
        for (int y = 0; y < h; y++) {
            int o = y * w;
            for (int x = 0; x < w; x++) {
                int a = Math.max(0, x - r), b = Math.min(w - 1, x + r), m = 0;
                for (int t = a; t <= b; t++) { int v = src[o + t] & 0xFF; if (v > m) m = v; }
                tmp[o + x] = (byte) m;
            }
        }
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int a = Math.max(0, y - r), b = Math.min(h - 1, y + r), m = 0;
                for (int t = a; t <= b; t++) { int v = tmp[t * w + x] & 0xFF; if (v > m) m = v; }
                dst[y * w + x] = (byte) m;
            }
        }
    }
}
