package com.pacco.animecut.core;

/**
 * v8.29: boton "Limpiar restos" de Borrar fondo (escoba). Un toque, se puede deshacer.
 *
 * Quita lo que queda despues de borrar el fondo (capturas de v8.28: pedazos sueltos, bordes
 * blanquecinos semitransparentes y puntitos pegados a la linea) sin tocar el personaje:
 *  1) PEDAZOS SUELTOS: grupos de pixeles visibles separados del resto por transparencia y
 *     chicos comparados con el grupo mas grande. Se conservan los trazos finos de tinta (puntas
 *     de mechones).
 *  2) AGUJEROS: si hay copia de antes (Restaurar), los agujeritos transparentes encerrados
 *     (hasta 64 px) vuelven a como estaban.
 *  3) FILO SEMITRANSPARENTE: pixeles a medio borrar (alfa < 128) pegados al fondo borrado que
 *     no son tinta: fondo a medio quitar que se ve como halo claro. Dos pasadas.
 *  4) PAPEL SUELTO: grupitos de papel claro sin color (hasta 60 px) pegados a lo borrado.
 * Con seleccion, solo dentro de lo seleccionado.
 */
public final class BgCleanup {
    private BgCleanup() { }

    public static final class Result {
        /** pares {indice, color nuevo} */
        public int[] pairs = new int[0];
        public int islands, islandPx, fringe, bits, holes;
        public int x0, y0, x1, y1;
    }

    static int lum(int c) {
        return (((c >> 16) & 255) * 77 + ((c >> 8) & 255) * 151 + (c & 255) * 28) >> 8;
    }

    static int sat(int c) {
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        return Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b));
    }

    static boolean ink(int c) {
        int l = lum(c);
        return l < 45 || (l < 80 && sat(c) < 70);
    }

    public static Result run(int[] src, int w, int h, int[] snap, byte[] sel) {
        return run(src, w, h, snap, sel, 1.5f);
    }

    /** v8.32: hLine = medio grosor de linea medido (BgEngine.measure): los tamanos se adaptan. */
    public static Result run(int[] src, int w, int h, int[] snap, byte[] sel, float hLine) {
        int n = w * h;
        int[] px = src.clone();
        Result res = new Result();
        // ---- 1) pedazos sueltos ----
        // v8.32: sin mapa de etiquetas int[] (4 bytes por pixel): se guarda solo la semilla de cada
        // grupo y se vuelve a recorrer el grupo cuando hace falta (1 byte por pixel).
        byte[] lab = new byte[n];
        int[] stack = new int[4096];
        int nComp = 0;
        int[] size = new int[64], inkN = new int[64], liteN = new int[64], maxA = new int[64], bx0 = new int[64], by0 = new int[64], bx1 = new int[64], by1 = new int[64], seed = new int[64];
        int largest = 0;
        for (int s = 0; s < n; s++) {
            if (lab[s] != 0 || (px[s] >>> 24) <= 24) continue;
            int id = ++nComp;
            if (id >= size.length) {
                int L = size.length * 2;
                size = java.util.Arrays.copyOf(size, L); inkN = java.util.Arrays.copyOf(inkN, L); liteN = java.util.Arrays.copyOf(liteN, L);
                maxA = java.util.Arrays.copyOf(maxA, L);
                bx0 = java.util.Arrays.copyOf(bx0, L); by0 = java.util.Arrays.copyOf(by0, L);
                bx1 = java.util.Arrays.copyOf(bx1, L); by1 = java.util.Arrays.copyOf(by1, L);
                seed = java.util.Arrays.copyOf(seed, L);
            }
            seed[id] = s;
            int sp = 0;
            stack[sp++] = s;
            lab[s] = 1;
            bx0[id] = w; by0[id] = h; bx1[id] = -1; by1[id] = -1;
            while (sp > 0) {
                int i = stack[--sp];
                int y = i / w, x = i - y * w;
                int c = px[i], a = c >>> 24;
                size[id]++;
                // color de ANTES (si hay copia): el filo limpio cambia de color y la tinta parece otra cosa
                int oc = snap != null && snap.length == n && (snap[i] >>> 24) != 0 ? snap[i] : c;
                if (a >= 48 && ink(oc)) inkN[id]++;
                if (a >= 48 && lum(oc) >= 150) liteN[id]++;
                if (a > maxA[id]) maxA[id] = a;
                if (x < bx0[id]) bx0[id] = x;
                if (x > bx1[id]) bx1[id] = x;
                if (y < by0[id]) by0[id] = y;
                if (y > by1[id]) by1[id] = y;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= w) continue;
                        int j = yy * w + xx;
                        if (lab[j] != 0 || (px[j] >>> 24) <= 24) continue;
                        lab[j] = 1;
                        if (sp == stack.length) stack = java.util.Arrays.copyOf(stack, sp * 2);
                        stack[sp++] = j;
                    }
                }
            }
            if (size[id] > largest) largest = size[id];
        }
        // v8.32: el tamano de "pedazo suelto" crece con el grosor de linea (imagen grande = mas px)
        float hs = Math.max(1f, hLine / 1.5f);
        int thr = Math.max(Math.round(40 * hs * hs), Math.min(Math.round(4000 * hs * hs), largest / 300));

        // cerca del dibujo principal (hasta 4 px): las puntas de mechones y los puntitos de trama
        // que quedaron sueltos son tinta del dibujo y se conservan
        int bigId = 0;
        for (int id = 1; id <= nComp; id++) if (size[id] == largest) { bigId = id; break; }
        byte[] near = new byte[n];
        if (bigId != 0) {
            java.util.Arrays.fill(lab, (byte) 0);
            stack = flood(px, w, h, seed[bigId], lab, near, stack, (byte) 1);
        }
        int nr = Math.max(4, Math.round(2 * hLine) + 1);
        for (int it = 0; it < nr; it++) {
            // dilatacion 4 vecinos en el lugar: marca 2 = nuevo de esta vuelta
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++) {
                    int i = y * w + x;
                    if (near[i] != 0) continue;
                    if ((x > 0 && near[i - 1] == 1) || (x < w - 1 && near[i + 1] == 1)
                            || (y > 0 && near[i - w] == 1) || (y < h - 1 && near[i + w] == 1)) near[i] = 2;
                }
            for (int i = 0; i < n; i++) if (near[i] == 2) near[i] = 1;
        }
        boolean[] isNear = new boolean[nComp + 1];
        java.util.Arrays.fill(lab, (byte) 0);
        for (int id = 1; id <= nComp; id++) {
            if (id == bigId || size[id] > 4 * thr) continue;
            isNear[id] = touches(px, w, h, seed[id], lab, near, stack);
        }
        near = null;
        boolean[] kill = new boolean[nComp + 1];
        for (int id = 1; id <= nComp; id++) {
            int a = size[id];
            if (a == largest) continue;
            int bw = bx1[id] - bx0[id] + 1, bh = by1[id] - by0[id] + 1;
            // tinta pegada al dibujo (punta de mechon, puntito de trama): se conserva
            // pedazo del dibujo: tinta pegada al dibujo o fina (punta de mechon), o tinta MEZCLADA con
            // papel claro (un mechon suelto con su brillo). Un pedazo de fondo oscuro es parejo.
            // v8.30: "fino" = alargado (punta de mechon de 6 px o mas). Antes un puntito de 2x2
            // contaba como fino y la Escoba lo dejaba (captura 6: "quito 55" pero quedaban puntos).
            // En imagenes a COLOR un puntito de tinta de 16 px o menos pegado a la linea es basura
            // del JPEG y se quita; sobre papel claro (manga) puede ser trama y se conserva. A color, un trazo
            // fino LEJOS del personaje (mas de 4 px) tambien es resto del fondo.
            int len = Math.max(bw, bh);
            // v8.30: lo que se borro alrededor era PAPEL claro (manga: puede ser trama) o fondo de
            // color/oscuro (un puntito ahi es basura del JPEG). Sin copia de antes: como papel.
            boolean gray = true;
            if (a <= 400 && snap != null && snap.length == n) {
                long sl = 0;
                int cnt = 0;
                for (int y = Math.max(0, by0[id] - 2); y <= Math.min(h - 1, by1[id] + 2); y++)
                    for (int x = Math.max(0, bx0[id] - 2); x <= Math.min(w - 1, bx1[id] + 2); x++) {
                        int q = y * w + x;
                        if ((px[q] >>> 24) != 0 || (snap[q] >>> 24) == 0) continue;
                        sl += lum(snap[q]);
                        cnt++;
                    }
                if (cnt > 0) gray = sl / cnt >= 170;
            }
            int thinLen = Math.max(6, Math.round(4 * hLine));
            boolean thin = len >= thinLen && a <= 3 * len;
            int small = Math.max(16, Math.round(16 * hs * hs));
            boolean inkNear = (inkN[id] * 10 >= a * 6 && ((thin && (gray || isNear[id])) || (isNear[id] && (gray || a > small))))
                    || (inkN[id] * 10 >= a * 3 && liteN[id] * 10 >= a && a > small);
            if (maxA[id] < 64 && a <= 4 * thr) kill[id] = true;          // casi invisible
            else if (a <= thr && !inkNear) kill[id] = true;               // pedazo de fondo
        }
        java.util.Arrays.fill(lab, (byte) 0);
        for (int id = 1; id <= nComp; id++) {
            if (!kill[id]) continue;
            res.islands++;
            res.islandPx += size[id];
            stack = clearComp(px, w, h, seed[id], lab, sel, stack);
        }
        lab = null;
        byte[] seen = new byte[n];
        // ---- 2) agujeritos encerrados (con la copia de antes) ----
        // v8.32: solo agujeritos (pinchazos) se rellenan; un rincon borrado a proposito queda
        int holeMax = Math.max(9, Math.round(2.25f * hLine * hLine));
        if (snap != null && snap.length == n) {
            for (int s = 0; s < n; s++) {
                if (seen[s] != 0 || (px[s] >>> 24) != 0) continue;
                int sp = 0, cnt = 0;
                boolean border = false;
                stack[sp++] = s;
                seen[s] = 1;
                java.util.ArrayList<Integer> mem = new java.util.ArrayList<Integer>();
                while (sp > 0) {
                    int i = stack[--sp];
                    cnt++;
                    if (cnt <= holeMax) mem.add(i);
                    int y = i / w, x = i - y * w;
                    if (x == 0 || y == 0 || x == w - 1 || y == h - 1) border = true;
                    if (x > 0) sp = pushClear(px, seen, stack, sp, i - 1);
                    if (sp >= stack.length - 4) stack = java.util.Arrays.copyOf(stack, stack.length * 2);
                    if (x < w - 1) sp = pushClear(px, seen, stack, sp, i + 1);
                    if (sp >= stack.length - 4) stack = java.util.Arrays.copyOf(stack, stack.length * 2);
                    if (y > 0) sp = pushClear(px, seen, stack, sp, i - w);
                    if (sp >= stack.length - 4) stack = java.util.Arrays.copyOf(stack, stack.length * 2);
                    if (y < h - 1) sp = pushClear(px, seen, stack, sp, i + w);
                    if (sp >= stack.length - 4) stack = java.util.Arrays.copyOf(stack, stack.length * 2);
                }
                if (border || cnt > holeMax) continue;
                for (int i : mem) {
                    if (sel != null && (sel[i] & 0xFF) == 0) continue;
                    if ((snap[i] >>> 24) == 0) continue;
                    px[i] = snap[i];
                    res.holes++;
                }
            }
        }
        // lo transparente "grande" (el fondo borrado): toca el borde de la imagen o mide mas de 64 px.
        // El filo semitransparente solo se quita junto a eso, no alrededor de un agujerito.
        byte[] bigClear = new byte[n];
        {
            byte[] sn = new byte[n];
            int[] st2 = new int[4096];
            for (int s0 = 0; s0 < n; s0++) {
                if (sn[s0] != 0 || (px[s0] >>> 24) != 0) continue;
                int sp = 0, cnt = 0;
                boolean border = false;
                java.util.ArrayList<Integer> mem = new java.util.ArrayList<Integer>();
                st2[sp++] = s0;
                sn[s0] = 1;
                while (sp > 0) {
                    int i = st2[--sp];
                    cnt++;
                    if (cnt <= 65) mem.add(i);
                    int y = i / w, x = i - y * w;
                    if (x == 0 || y == 0 || x == w - 1 || y == h - 1) border = true;
                    if (sp >= st2.length - 4) st2 = java.util.Arrays.copyOf(st2, st2.length * 2);
                    if (x > 0) sp = pushClear(px, sn, st2, sp, i - 1);
                    if (x < w - 1) sp = pushClear(px, sn, st2, sp, i + 1);
                    if (y > 0) sp = pushClear(px, sn, st2, sp, i - w);
                    if (y < h - 1) sp = pushClear(px, sn, st2, sp, i + w);
                }
                if (border || cnt > 64) {
                    // marcar todo el componente: se recorre de nuevo
                    int sp2 = 0;
                    st2[sp2++] = s0;
                    bigClear[s0] = 1;
                    while (sp2 > 0) {
                        int i = st2[--sp2];
                        int y = i / w, x = i - y * w;
                        if (sp2 >= st2.length - 4) st2 = java.util.Arrays.copyOf(st2, st2.length * 2);
                        int[] nb = {x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1};
                        for (int j : nb) {
                            if (j < 0 || bigClear[j] != 0 || (px[j] >>> 24) != 0) continue;
                            bigClear[j] = 1;
                            st2[sp2++] = j;
                        }
                    }
                }
            }
        }
        // ---- 3) filo semitransparente (dos pasadas) ----
        for (int pass = 0; pass < 2; pass++) {
            java.util.ArrayList<Integer> cut = new java.util.ArrayList<Integer>();
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int i = y * w + x, c = px[i], a = c >>> 24;
                    if (a == 0 || a >= 128) continue;
                    if (sel != null && (sel[i] & 0xFF) == 0) continue;
                    boolean nearClear = (x > 0 && bigClear[i - 1] != 0) || (x < w - 1 && bigClear[i + 1] != 0)
                            || (y > 0 && bigClear[i - w] != 0) || (y < h - 1 && bigClear[i + w] != 0);
                    if (!nearClear) continue;
                    if (ink(c)) continue;
                    // filo suave del personaje: su color de antes se parece al personaje opaco de al lado
                    int oc = snap != null && snap.length == n && (snap[i] >>> 24) != 0 ? snap[i] : c;
                    if (likeOpaqueNeighbor(px, w, h, x, y, oc, c)) continue;
                    cut.add(i);
                }
            }
            for (int i : cut) { px[i] &= 0x00FFFFFF; bigClear[i] = 1; }
            res.fringe += cut.size();
        }
        // ---- 4) papel suelto pegado a lo borrado ----
        java.util.Arrays.fill(seen, (byte) 0);
        int paleMax = Math.max(60, Math.round(60 * hs * hs));
        int[] comp = new int[paleMax + 1];
        for (int s = 0; s < n; s++) {
            if (seen[s] != 0 || !pale(px, snap, s)) continue;
            int sp = 0, cnt = 0;
            boolean touches = false, big = false;
            stack[sp++] = s;
            seen[s] = 1;
            while (sp > 0) {
                int i = stack[--sp];
                if (cnt < comp.length) comp[cnt] = i;
                cnt++;
                if (cnt > paleMax) big = true;
                int y = i / w, x = i - y * w;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= w || (dx == 0 && dy == 0)) continue;
                        int j = yy * w + xx;
                        if ((px[j] >>> 24) == 0) { touches = true; continue; }
                        if (seen[j] != 0 || !pale(px, snap, j)) continue;
                        seen[j] = 1;
                        if (sp == stack.length) stack = java.util.Arrays.copyOf(stack, sp * 2);
                        stack[sp++] = j;
                    }
                }
            }
            if (big || !touches || cnt > paleMax) continue;
            // no es papel suelto si es lo unico que hay (un dibujo blanco)
            for (int k = 0; k < cnt; k++) {
                int i = comp[k];
                if (sel != null && (sel[i] & 0xFF) == 0) continue;
                px[i] &= 0x00FFFFFF;
                res.bits++;
            }
        }
        // ---- 5) polvo: casi invisible (alfa 1-24) que no esta junto al dibujo ----
        {
            java.util.ArrayList<Integer> dust = new java.util.ArrayList<Integer>();
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++) {
                    int i = y * w + x, a = px[i] >>> 24;
                    if (a == 0 || a > 24) continue;
                    if (sel != null && (sel[i] & 0xFF) == 0) continue;
                    boolean nearSolid = false;
                    for (int dy = -1; dy <= 1 && !nearSolid; dy++)
                        for (int dx = -1; dx <= 1; dx++) {
                            int xx = x + dx, yy = y + dy;
                            if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                            if ((px[yy * w + xx] >>> 24) >= 128) { nearSolid = true; break; }
                        }
                    if (!nearSolid) dust.add(i);
                }
            for (int i : dust) px[i] &= 0x00FFFFFF;
            res.fringe += dust.size();
        }
        // ---- cambios ----
        int cnt = 0;
        for (int i = 0; i < n; i++) if (px[i] != src[i]) cnt++;
        int[] pairs = new int[cnt * 2];
        int k = 0, minX = w, minY = h, maxX = -1, maxY = -1;
        for (int i = 0; i < n; i++) {
            if (px[i] == src[i]) continue;
            pairs[k++] = i;
            pairs[k++] = px[i];
            int y = i / w, x = i - y * w;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }
        res.pairs = pairs;
        res.x0 = minX; res.y0 = minY; res.x1 = maxX + 1; res.y1 = maxY + 1;
        return res;
    }

    /**
     * Filo semitransparente dentro de [x0,x1)x[y0,y1) (lo usa Borrar fondo con un toque al terminar):
     * alfa < 128, pegado a lo transparente, que no es tinta ni filo suave del personaje. orig = colores
     * de antes (puede ser null). Cambia px. Devuelve cuantos se quitaron.
     */
    public static int fringeIn(int[] px, int w, int h, int x0, int y0, int x1, int y1, int[] orig, byte[] sel) {
        x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(w, x1); y1 = Math.min(h, y1);
        int total = 0;
        for (int pass = 0; pass < 2; pass++) {
            java.util.ArrayList<Integer> cut = new java.util.ArrayList<Integer>();
            for (int y = y0; y < y1; y++)
                for (int x = x0; x < x1; x++) {
                    int i = y * w + x, c = px[i], a = c >>> 24;
                    if (a == 0 || a >= 128) continue;
                    if (sel != null && (sel[i] & 0xFF) == 0) continue;
                    boolean nearClear = (x > 0 && (px[i - 1] >>> 24) == 0) || (x < w - 1 && (px[i + 1] >>> 24) == 0)
                            || (y > 0 && (px[i - w] >>> 24) == 0) || (y < h - 1 && (px[i + w] >>> 24) == 0);
                    if (!nearClear || ink(c)) continue;
                    int oc = orig != null && orig.length == px.length && (orig[i] >>> 24) != 0 ? orig[i] : c;
                    if (likeOpaqueNeighbor(px, w, h, x, y, oc, c)) continue;
                    cut.add(i);
                }
            for (int i : cut) px[i] &= 0x00FFFFFF;
            total += cut.size();
        }
        return total;
    }

    /** Hay un pixel opaco a 2 px o menos con un color parecido: es el filo suave del personaje. */
    private static boolean likeOpaqueNeighbor(int[] px, int w, int h, int x, int y, int c, int cur) {
        for (int dy = -2; dy <= 2; dy++) {
            int yy = y + dy;
            if (yy < 0 || yy >= h) continue;
            for (int dx = -2; dx <= 2; dx++) {
                int xx = x + dx;
                if (xx < 0 || xx >= w) continue;
                int q = px[yy * w + xx];
                if ((q >>> 24) < 200) continue;
                // el color de antes se parece, y el de ahora no quedo blanquecino (fondo descontaminado)
                if (ColorDist.dist(q | 0xFF000000, c | 0xFF000000, ColorDist.RGB) <= 40
                        && ColorDist.dist(q | 0xFF000000, cur | 0xFF000000, ColorDist.RGB) <= 90) return true;
            }
        }
        return false;
    }

    /** Recorre el grupo visible (8 vecinos) desde s: marca mark[]=v en dst y seen. */
    private static int[] flood(int[] px, int w, int h, int s, byte[] seen, byte[] dst, int[] stack, byte v) {
        int sp = 0;
        stack[sp++] = s;
        seen[s] = 1;
        while (sp > 0) {
            int i = stack[--sp];
            dst[i] = v;
            int y = i / w, x = i - y * w;
            for (int dy = -1; dy <= 1; dy++) {
                int yy = y + dy;
                if (yy < 0 || yy >= h) continue;
                for (int dx = -1; dx <= 1; dx++) {
                    int xx = x + dx;
                    if (xx < 0 || xx >= w) continue;
                    int j = yy * w + xx;
                    if (seen[j] != 0 || (px[j] >>> 24) <= 24) continue;
                    seen[j] = 1;
                    if (sp == stack.length) stack = java.util.Arrays.copyOf(stack, sp * 2);
                    stack[sp++] = j;
                }
            }
        }
        return stack;
    }

    /** El grupo de s toca la zona "cerca del dibujo". */
    private static boolean touches(int[] px, int w, int h, int s, byte[] seen, byte[] near, int[] stack) {
        int sp = 0;
        stack[sp++] = s;
        seen[s] = 1;
        boolean hit = false;
        while (sp > 0) {
            int i = stack[--sp];
            if (near[i] != 0) hit = true;
            int y = i / w, x = i - y * w;
            for (int dy = -1; dy <= 1; dy++) {
                int yy = y + dy;
                if (yy < 0 || yy >= h) continue;
                for (int dx = -1; dx <= 1; dx++) {
                    int xx = x + dx;
                    if (xx < 0 || xx >= w) continue;
                    int j = yy * w + xx;
                    if (seen[j] != 0 || (px[j] >>> 24) <= 24) continue;
                    seen[j] = 1;
                    if (sp == stack.length) stack = java.util.Arrays.copyOf(stack, sp * 2);
                    stack[sp++] = j;
                }
            }
        }
        return hit;
    }

    /** Borra el grupo de s (respetando la seleccion). */
    private static int[] clearComp(int[] px, int w, int h, int s, byte[] seen, byte[] sel, int[] stack) {
        int sp = 0;
        stack[sp++] = s;
        seen[s] = 1;
        int cnt = 0;
        int[] list = new int[256];
        while (sp > 0) {
            int i = stack[--sp];
            if (cnt == list.length) list = java.util.Arrays.copyOf(list, cnt * 2);
            list[cnt++] = i;
            int y = i / w, x = i - y * w;
            for (int dy = -1; dy <= 1; dy++) {
                int yy = y + dy;
                if (yy < 0 || yy >= h) continue;
                for (int dx = -1; dx <= 1; dx++) {
                    int xx = x + dx;
                    if (xx < 0 || xx >= w) continue;
                    int j = yy * w + xx;
                    if (seen[j] != 0 || (px[j] >>> 24) <= 24) continue;
                    seen[j] = 1;
                    if (sp == stack.length) stack = java.util.Arrays.copyOf(stack, sp * 2);
                    stack[sp++] = j;
                }
            }
        }
        for (int k = 0; k < cnt; k++) {
            int i = list[k];
            if (sel != null && (sel[i] & 0xFF) == 0) continue;
            px[i] &= 0x00FFFFFF;
        }
        return stack;
    }

    private static int pushClear(int[] px, byte[] seen, int[] stack, int sp, int j) {
        if (seen[j] != 0 || (px[j] >>> 24) != 0) return sp;
        seen[j] = 1;
        stack[sp++] = j;
        return sp;
    }

    /** Papel claro sin color (mirando el color de antes si hay copia: el filo limpio cambia de color). */
    private static boolean pale(int[] px, int[] snap, int i) {
        int c = px[i];
        if ((c >>> 24) == 0) return false;
        int o = snap != null && snap.length == px.length && (snap[i] >>> 24) != 0 ? snap[i] : c;
        int l = lum(o);
        return l >= 170 && sat(o) < 40;
    }
}
