package com.pacco.animecut.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * Mini animacion que muestra la herramienta trabajando: un dedo se mueve por
 * el dibujo y, por donde pasa, aparece el resultado. Se repite sola.
 * v8.69: con Zeta Pintor, y cada herramienta hace de verdad lo que dice (Transformar, Marioneta,
 * Mover, Separar, Brocha y las acciones de Colorear tienen su propia animacion).
 */
public class ToolDemoView extends View {

    private final int mode;
    private final boolean sub;
    /** Submodo de Especial: 0 arrastrar, 1 contraer, 2 expandir, 3 suavizar, 4 restaurar. */
    private final int variant;
    private Bitmap before, after, demoBlur;
    private float t = 0f;
    private ValueAnimator anim;
    private final Paint finger = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint frame = new Paint(Paint.ANTI_ALIAS_FLAG);

    private static final int KIND_BRUSH = 0, KIND_TAP = 1, KIND_TRACE = 2, KIND_FADE = 3,
            KIND_POINTS = 4, KIND_PAN = 5, KIND_BLUR = 6, KIND_LIQUIFY = 7, KIND_SMUDGE = 8,
            KIND_PAINT = 9, KIND_MOVE = 10, KIND_TRANSFORM = 11, KIND_PUPPET = 12, KIND_SEPARATE = 13,
            KIND_COLOR = 14, KIND_SOFT = 15, KIND_LIGHT = 16, KIND_STYLE = 17, KIND_IMPROVE = 18;

    /** v8.69: animaciones de las acciones de COLOREAR (no son herramientas del lienzo). */
    public static final int DEMO_COLOR = 101, DEMO_SOFT = 102, DEMO_LIGHT = 103, DEMO_STYLE = 104, DEMO_IMPROVE = 105;

    public ToolDemoView(Context c, int mode, boolean sub) {
        this(c, mode, sub, 0);
    }

    public ToolDemoView(Context c, int mode, boolean sub, int variant) {
        super(c);
        this.mode = mode;
        this.sub = sub;
        this.variant = Math.max(0, Math.min(4, variant));
        finger.setColor(0xDDFFFFFF);
        ring.setStyle(Paint.Style.STROKE);
        ring.setColor(Color.WHITE);
        ring.setStrokeWidth(3f);
        frame.setStyle(Paint.Style.STROKE);
        frame.setColor(0x66FFFFFF);
        frame.setStrokeWidth(2f);
    }

    private int kind() {
        switch (mode) {
            case CanvasView.MODE_WAND:
            case CanvasView.MODE_BUCKET:
            case CanvasView.MODE_ZONE:
            case CanvasView.MODE_PICKER:
            case CanvasView.MODE_TONE:
                return KIND_TAP;
            case CanvasView.MODE_SCISSORS:
            case CanvasView.MODE_MAGNET:
            case CanvasView.MODE_LASSO:
                return KIND_TRACE;
            case CanvasView.MODE_CURVE:
            case CanvasView.MODE_POLY:
                return KIND_POINTS;
            case CanvasView.MODE_PAN:
                return KIND_PAN;
            case CanvasView.MODE_BLUR:
                return KIND_BLUR;
            case CanvasView.MODE_LIQUIFY:
                return KIND_LIQUIFY;
            case CanvasView.MODE_SMUDGE:
                return KIND_SMUDGE;
            case CanvasView.MODE_PAINT:
                return KIND_PAINT;
            case CanvasView.MODE_MOVE:
                return KIND_MOVE;
            case CanvasView.MODE_TRANSFORM:
                return KIND_TRANSFORM;
            case CanvasView.MODE_PUPPET:
                return KIND_PUPPET;
            case CanvasView.MODE_MARKER:
                return KIND_SEPARATE;
            case DEMO_COLOR: return KIND_COLOR;
            case DEMO_SOFT: return KIND_SOFT;
            case DEMO_LIGHT: return KIND_LIGHT;
            case DEMO_STYLE: return KIND_STYLE;
            case DEMO_IMPROVE: return KIND_IMPROVE;
            default:
                return KIND_BRUSH;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        if (before != null) before.recycle();
        if (after != null) after.recycle();
        if (demoBlur != null) demoBlur.recycle();
        before = ToolArt.panel(mode, sub, false, w, h);
        after = ToolArt.panel(mode, sub, true, w, h);
        if (mode == CanvasView.MODE_BGERASE) prepareBgSeq(w, h);
        demoBlur = mode == CanvasView.MODE_BLUR ? makeSoftBlur(before, w, h) : null;
        prepareZeta(w, h);
        start();
    }

    private void start() {
        if (anim != null) anim.cancel();
        boolean seq = mode == CanvasView.MODE_BGERASE;
        anim = ValueAnimator.ofFloat(0f, seq ? 5f : 1.35f);
        anim.setDuration(seq ? 14000 : 3200);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                t = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }

    /** Recorrido del dedo para cada herramienta. */
    private Path route(float w, float h) {
        Path p = new Path();
        switch (mode) {
            case CanvasView.MODE_BGERASE:
                // borde del personaje, por afuera
                p.moveTo(w * 0.1f, h * 0.95f);
                p.lineTo(w * 0.12f, h * 0.2f);
                p.lineTo(w * 0.5f, h * 0.05f);
                p.lineTo(w * 0.88f, h * 0.2f);
                p.lineTo(w * 0.9f, h * 0.95f);
                break;
            case CanvasView.MODE_ERASER:
            case CanvasView.MODE_PAINT:
                p.moveTo(w * 0.25f, h * 0.85f);
                p.lineTo(w * 0.75f, h * 0.75f);
                p.lineTo(w * 0.3f, h * 0.95f);
                p.lineTo(w * 0.75f, h * 0.9f);
                break;
            case CanvasView.MODE_LINE:
                p.moveTo(w * 0.3f, h * 0.62f);
                p.cubicTo(w * 0.45f, h * 0.5f, w * 0.55f, h * 0.45f, w * 0.7f, h * 0.38f);
                break;
            default:
                // pasadas cortas sobre la zona de arriba (pelo y cara)
                p.moveTo(w * 0.3f, h * 0.2f);
                p.lineTo(w * 0.7f, h * 0.2f);
                p.lineTo(w * 0.3f, h * 0.35f);
                p.lineTo(w * 0.7f, h * 0.35f);
                p.lineTo(w * 0.35f, h * 0.52f);
                p.lineTo(w * 0.65f, h * 0.52f);
                p.lineTo(w * 0.5f, h * 0.8f);
                break;
        }
        return p;
    }

    private float[] tapPoint(float w, float h) {
        switch (mode) {
            case CanvasView.MODE_WAND:
                return new float[]{w * 0.80f, h * 0.62f};
            case CanvasView.MODE_TONE:
                return new float[]{w * 0.18f, h * 0.2f};
            default:
                return new float[]{w * 0.5f, h * 0.8f};
        }
    }

    private static float ease(float v) {
        v = Math.max(0f, Math.min(1f, v));
        return v * v * (3f - 2f * v);
    }

    /** Desenfoque pequeno solo para la animacion explicativa; se calcula una vez. */
    private static Bitmap makeSoftBlur(Bitmap src, int w, int h) {
        if (src == null || w <= 0 || h <= 0) return null;
        try {
            int n = w * h;
            int[] a = new int[n], b = new int[n];
            src.getPixels(a, 0, w, 0, 0, w, h);
            // Dos pasadas 3x3 dan un desenfoque visible sin depender de RenderEffect.
            for (int pass = 0; pass < 2; pass++) {
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        int aa = 0, rr = 0, gg = 0, bb = 0, count = 0;
                        for (int oy = -1; oy <= 1; oy++) {
                            int sy = Math.max(0, Math.min(h - 1, y + oy));
                            int off = sy * w;
                            for (int ox = -1; ox <= 1; ox++) {
                                int sx = Math.max(0, Math.min(w - 1, x + ox));
                                int q = a[off + sx];
                                aa += q >>> 24;
                                rr += (q >> 16) & 255;
                                gg += (q >> 8) & 255;
                                bb += q & 255;
                                count++;
                            }
                        }
                        b[y * w + x] = ((aa / count) << 24) | ((rr / count) << 16)
                                | ((gg / count) << 8) | (bb / count);
                    }
                }
                int[] tmp = a; a = b; b = tmp;
            }
            Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            out.setPixels(a, 0, w, 0, 0, w, h);
            return out;
        } catch (OutOfMemoryError e) {
            return null;
        }
    }

    private void drawBlurDemo(Canvas c, float w, float h, float p) {
        if (demoBlur == null) return;
        Path path = new Path();
        path.moveTo(w * .27f, h * .24f);
        path.cubicTo(w * .42f, h * .16f, w * .62f, h * .20f, w * .72f, h * .33f);
        path.cubicTo(w * .62f, h * .43f, w * .42f, h * .43f, w * .32f, h * .55f);
        PathMeasure pm = new PathMeasure(path, false);
        float len = pm.getLength(), drawn = Math.min(1f, p / .86f) * len;
        float br = h * .15f;
        Path reveal = new Path();
        float[] pos = new float[2];
        for (float d = 0; d <= drawn; d += Math.max(2f, br * .30f)) {
            pm.getPosTan(d, pos, null);
            reveal.addCircle(pos[0], pos[1], br, Path.Direction.CW);
        }
        c.save();
        c.clipPath(reveal);
        c.drawBitmap(demoBlur, 0, 0, null);
        c.restore();
        if (t < 1f && drawn > 0f) {
            pm.getPosTan(drawn, pos, null);
            c.drawCircle(pos[0], pos[1], br, ring);
            c.drawCircle(pos[0], pos[1], h * .035f, finger);
        }
    }

    private void drawSmudgeDemo(Canvas c, float w, float h, float p) {
        float e = ease(Math.min(1f, p / .84f));
        float sx = w * .70f, sy = h * .60f;      // v8.69: la cola de Zeta se estira hacia el cielo
        float dx = w * .20f * e;
        float fx = sx + dx;
        float br = h * .16f;
        Path clip = new Path();
        clip.addCircle(fx, sy, br, Path.Direction.CW);
        Paint smear = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        c.save();
        c.clipPath(clip);
        for (int i = 1; i <= 4; i++) {
            smear.setAlpha(42 + i * 18);
            c.save();
            c.translate(dx * (i / 4f) * .55f, 0);
            c.drawBitmap(before, 0, 0, smear);
            c.restore();
        }
        c.restore();
        if (t < 1f) {
            c.drawCircle(fx, sy, br, ring);
            c.drawCircle(fx, sy, h * .035f, finger);
        }
    }

    /** Animacion real de los cinco submodos de Especial. */
    private void drawLiquifyDemo(Canvas c, float w, float h, float p) {
        float e = ease((p - .08f) / .78f);
        float cx = w * .50f, cy = h * .37f, br = h * .27f;
        float fx = cx, fy = cy;
        Path clip = new Path();
        Paint guide = new Paint(Paint.ANTI_ALIAS_FLAG);
        guide.setStyle(Paint.Style.STROKE);
        guide.setStrokeWidth(Math.max(2f, h * .012f));
        guide.setColor(0x99FFFFFF);

        c.save();
        if (variant == 0) {
            float dx = w * .24f * e;
            fx = w * .34f + dx;
            fy = cy;
            clip.addCircle(fx, fy, br, Path.Direction.CW);
            c.clipPath(clip);
            c.translate(dx, 0);
            c.drawBitmap(before, 0, 0, null);
        } else if (variant == 1) {
            clip.addCircle(cx, cy, br, Path.Direction.CW);
            c.clipPath(clip);
            float sc = 1f - .28f * e;
            c.scale(sc, sc, cx, cy);
            c.drawBitmap(before, 0, 0, null);
        } else if (variant == 2) {
            clip.addCircle(cx, cy, br, Path.Direction.CW);
            c.clipPath(clip);
            float sc = 1f + .32f * e;
            c.scale(sc, sc, cx, cy);
            c.drawBitmap(before, 0, 0, null);
        } else if (variant == 3) {
            // Suavizar: una deformacion fuerte se relaja progresivamente sin blur.
            clip.addCircle(cx, cy, br, Path.Direction.CW);
            c.clipPath(clip);
            float u = 1f - e;
            c.translate(w * .08f * u, 0);
            c.rotate(10f * u, cx, cy);
            c.scale(1f + .10f * u, 1f - .04f * u, cx, cy);
            c.drawBitmap(before, 0, 0, null);
            fx = cx; fy = cy;
        } else {
            // Restaurar empieza deformado y vuelve progresivamente al original.
            float u = 1f - e;
            clip.addCircle(cx, cy, br, Path.Direction.CW);
            c.clipPath(clip);
            c.translate(w * .10f * u, 0);
            c.rotate(18f * u, cx, cy);
            float sc = 1f + .18f * u;
            c.scale(sc, sc, cx, cy);
            c.drawBitmap(before, 0, 0, null);
            fx = cx + w * .10f * (1f - e);
        }
        c.restore();

        // Flechas simples ayudan a entender contraer/expandir sin texto adicional.
        if (variant == 1 || variant == 2) {
            float dir = variant == 1 ? -1f : 1f;
            for (int i = 0; i < 4; i++) {
                double a = i * Math.PI / 2.0;
                float ux = (float) Math.cos(a), uy = (float) Math.sin(a);
                float r0 = br * (variant == 1 ? .82f : .34f);
                float r1 = r0 + dir * br * .28f * Math.max(.25f, e);
                c.drawLine(cx + ux * r0, cy + uy * r0, cx + ux * r1, cy + uy * r1, guide);
            }
        }
        if (t < 1f) {
            c.drawCircle(fx, fy, br, ring);
            c.drawCircle(fx, fy, h * .035f, finger);
        }
    }

    // ================= v8.32: Borrar fondo en 5 escenas (sin texto) =================
    private Bitmap seqBg, seqChk, seqChr;
    private Path seqSil;
    private final Paint seqPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

    private void prepareBgSeq(int w, int h) {
        try {
            if (seqBg != null) seqBg.recycle();
            if (seqChk != null) seqChk.recycle();
            if (seqChr != null) seqChr.recycle();
            seqBg = ToolArt.backgroundOnly(1, w, h);
            seqChk = ToolArt.backgroundOnly(0, w, h);
            seqChr = ToolArt.characterOnly(w, h);
            seqSil = ToolArt.silhouette(new RectF(0, 0, w, h));
        } catch (OutOfMemoryError e) {
            seqBg = seqChk = seqChr = null;
        }
    }

    private static final int[] SEQ_ICONS = {com.pacco.animecut.R.drawable.ic_bucket, com.pacco.animecut.R.drawable.ic_bgerase,
            com.pacco.animecut.R.drawable.ic_eraser, com.pacco.animecut.R.drawable.ic_restore_brush, com.pacco.animecut.R.drawable.ic_broom};

    /** Recorrido de cada escena (fracciones del cuadro). */
    private Path seqRoute(int k, float w, float h) {
        Path p = new Path();
        if (k == 1) {            // pincel: pegado al contorno, a veces encima del pelo (no lo borra)
            p.moveTo(w * .12f, h * .95f);
            p.cubicTo(w * .10f, h * .55f, w * .14f, h * .20f, w * .40f, h * .06f);
            p.cubicTo(w * .62f, h * .00f, w * .86f, h * .12f, w * .84f, h * .45f);
            p.lineTo(w * .90f, h * .95f);
        } else if (k == 2) {     // borrador: sobre una mancha suelta junto al hombro
            p.moveTo(w * .90f, h * .62f);
            p.lineTo(w * .78f, h * .60f);
            p.lineTo(w * .90f, h * .70f);
        } else {                 // restaurar: por la izquierda
            p.moveTo(w * .10f, h * .15f);
            p.lineTo(w * .12f, h * .55f);
            p.lineTo(w * .20f, h * .85f);
        }
        return p;
    }

    private void drawBgSeq(Canvas c, float w, float h) {
        int k = Math.min(4, (int) t);
        float f = t - k;
        float pf = Math.min(1f, f / 0.8f);          // 0..1 la accion; el resto, pausa con el resultado
        float br = h * 0.11f;
        Path chr = seqSil;
        // fondo de base de la escena
        boolean bgFirst = k <= 1;                    // balde y pincel empiezan con el fondo puesto
        c.drawBitmap(bgFirst ? seqBg : seqChk, 0, 0, seqPaint);
        if (k == 0) {
            // BALDE: un toque y el fondo se va como una onda, sin tocar al chico
            float tx = w * .14f, ty = h * .88f;
            float grow = pf < .25f ? 0f : ease((pf - .25f) / .75f);
            if (grow > 0f) {
                c.save();
                Path clip = new Path();
                clip.addCircle(tx, ty, grow * Math.max(w, h) * 1.3f, Path.Direction.CW);
                c.clipPath(clip);
                c.drawBitmap(seqChk, 0, 0, seqPaint);
                c.restore();
            }
            c.drawBitmap(seqChr, 0, 0, seqPaint);
            if (pf < 1f) {
                float press = pf < .25f ? pf / .25f : 1f;
                c.drawCircle(tx, ty, h * .045f * (1.4f - press * .4f), finger);
                c.drawCircle(tx, ty, h * .09f * press, ring);
            }
        } else if (k == 1 || k == 2 || k == 3) {
            Path route = seqRoute(k, w, h);
            PathMeasure pm = new PathMeasure(route, false);
            float len = pm.getLength(), drawn = pf * len;
            Path reveal = new Path();
            float[] pos = new float[2];
            for (float d = 0; d <= drawn; d += br * .35f) {
                pm.getPosTan(d, pos, null);
                reveal.addCircle(pos[0], pos[1], br, Path.Direction.CW);
            }
            if (k == 2) {
                // una mancha suelta del fondo pegada al hombro: el borrador la quita (borra todo)
                c.drawBitmap(seqChr, 0, 0, seqPaint);
                Paint m = new Paint(Paint.ANTI_ALIAS_FLAG);
                m.setColor(0xFF9FB3CF);
                c.save();
                if (drawn > 0) c.clipOutPath(reveal);
                c.drawCircle(w * .84f, h * .63f, h * .05f, m);
                c.drawCircle(w * .80f, h * .66f, h * .025f, m);
                c.restore();
            } else {
                Bitmap under = k == 1 ? seqChk : seqBg;   // pincel: aparece la transparencia; restaurar: vuelve el fondo
                if (drawn > 0) {
                    c.save();
                    c.clipPath(reveal);
                    c.clipOutPath(chr);   // nunca dentro del personaje
                    c.drawBitmap(under, 0, 0, seqPaint);
                    c.restore();
                }
                c.drawBitmap(seqChr, 0, 0, seqPaint);
            }
            if (pf < 1f && drawn > 0) {
                pm.getPosTan(drawn, pos, null);
                c.drawCircle(pos[0], pos[1], br, ring);
                c.drawCircle(pos[0], pos[1], h * .03f, finger);
            }
        } else {
            // ESCOBA: puntitos sueltos alrededor que se van con una pasada
            c.drawBitmap(seqChr, 0, 0, seqPaint);
            Paint d = new Paint(Paint.ANTI_ALIAS_FLAG);
            int alpha = (int) (255 * Math.max(0f, 1f - ease((pf - .3f) / .5f)));
            float[][] specks = {{.08f, .30f}, {.16f, .62f}, {.90f, .28f}, {.86f, .52f}, {.22f, .10f}, {.76f, .08f}, {.06f, .80f}, {.93f, .86f}};
            for (int i = 0; i < specks.length; i++) {
                d.setColor((i % 2 == 0 ? 0x00FFFFFF : 0x009FB3CF) | (alpha << 24));
                c.drawCircle(w * specks[i][0], h * specks[i][1], h * (.012f + .008f * (i % 3)), d);
            }
            if (pf < .85f) {
                float bx = w * (.05f + .9f * ease(pf / .85f)), by = h * .5f + (float) Math.sin(pf * 12) * h * .05f;
                drawIcon(c, SEQ_ICONS[4], bx - h * .07f, by - h * .07f, h * .14f, 0xFFFFFFFF);
            }
        }
        // icono de la herramienta de esta escena + 5 puntitos de avance (sin texto)
        Paint badge = new Paint(Paint.ANTI_ALIAS_FLAG);
        badge.setColor(0xCC1F2230);
        float bs = h * .16f;
        c.drawRoundRect(new RectF(h * .03f, h * .03f, h * .03f + bs, h * .03f + bs), bs * .25f, bs * .25f, badge);
        drawIcon(c, SEQ_ICONS[k], h * .03f + bs * .14f, h * .03f + bs * .14f, bs * .72f, 0xFFFFFFFF);
        Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        for (int i = 0; i < 5; i++) {
            dot.setColor(i == k ? 0xFFFFFFFF : 0x66FFFFFF);
            c.drawCircle(w / 2f + (i - 2) * h * .05f, h * .95f, h * (i == k ? .014f : .01f), dot);
        }
    }

    private void drawIcon(Canvas c, int res, float x, float y, float s, int tint) {
        try {
            android.graphics.drawable.Drawable d = getContext().getDrawable(res);
            if (d == null) return;
            d = d.mutate();
            d.setTint(tint);
            d.setBounds((int) x, (int) y, (int) (x + s), (int) (y + s));
            d.draw(c);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        if (before == null || after == null) return;
        float w = getWidth(), h = getHeight();
        if (mode == CanvasView.MODE_BGERASE && seqBg != null && seqChr != null && seqChk != null && seqSil != null) {
            drawBgSeq(c, w, h);
            c.drawRect(new RectF(1, 1, w - 1, h - 1), frame);
            return;
        }
        float p = Math.min(1f, t); // lo que pasa despues de 1 es la pausa con el resultado
        c.drawBitmap(before, 0, 0, null);

        switch (kind()) {
            case KIND_TAP: {
                float[] tp = tapPoint(w, h);
                float grow = p < 0.3f ? 0f : (p - 0.3f) / 0.7f;
                if (grow > 0f) {
                    Path clip = new Path();
                    clip.addCircle(tp[0], tp[1], grow * Math.max(w, h) * 1.2f, Path.Direction.CW);
                    c.save();
                    c.clipPath(clip);
                    c.drawBitmap(after, 0, 0, null);
                    c.restore();
                }
                if (t < 1f) {
                    float press = p < 0.3f ? p / 0.3f : 1f;
                    c.drawCircle(tp[0], tp[1], h * 0.05f * (1.4f - press * 0.4f), finger);
                    c.drawCircle(tp[0], tp[1], h * 0.09f * press, ring);
                }
                break;
            }
            case KIND_TRACE: {
                Path route = new Path();
                route.addCircle(w * 0.5f, h * 0.33f, h * 0.26f, Path.Direction.CW);
                PathMeasure pm = new PathMeasure(route, false);
                float len = pm.getLength();
                float drawn = Math.min(1f, p / 0.75f) * len;
                Path part = new Path();
                pm.getSegment(0, drawn, part, true);
                Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
                g.setStyle(Paint.Style.STROKE);
                g.setColor(0xFF32D74B);
                g.setStrokeWidth(h * 0.025f);
                if (p >= 0.8f) {
                    c.drawBitmap(after, 0, 0, null);
                } else {
                    c.drawPath(part, g);
                    float[] pos = new float[2];
                    pm.getPosTan(drawn, pos, null);
                    c.drawCircle(pos[0], pos[1], h * 0.045f, finger);
                }
                break;
            }
            case KIND_POINTS:
                drawPoints(c, w, h, p);
                break;
            case KIND_PAN: {
                // la mano arrastra el dibujo: se mueve junto con el dedo
                float e = p < 0.15f ? 0f : Math.min(1f, (p - 0.15f) / 0.6f);
                e = e * e * (3f - 2f * e);
                float dx = -w * 0.22f * e, dy = -h * 0.1f * e;
                c.drawColor(0xFF2A2A30);
                c.save();
                c.translate(dx, dy);
                c.drawBitmap(before, 0, 0, null);
                c.restore();
                if (t < 1f) {
                    float fx = w * 0.62f + dx, fy = h * 0.55f + dy;
                    c.drawCircle(fx, fy, h * 0.05f, finger);
                    c.drawCircle(fx, fy, h * 0.08f, ring);
                }
                break;
            }
            case KIND_FADE: {
                Paint a = new Paint();
                a.setAlpha((int) (255 * Math.max(0f, Math.min(1f, (p - 0.35f) / 0.4f))));
                c.drawBitmap(after, 0, 0, a);
                if (t < 1f && p < 0.5f) {
                    float fx = w * (0.4f + p * 0.3f), fy = h * 0.5f;
                    c.drawCircle(fx, fy, h * 0.045f, finger);
                }
                break;
            }
            case KIND_BLUR:
                drawBlurDemo(c, w, h, p);
                break;
            case KIND_LIQUIFY:
                drawLiquifyDemo(c, w, h, p);
                break;
            case KIND_SMUDGE:
                drawSmudgeDemo(c, w, h, p);
                break;
            case KIND_PAINT: drawPaintDemo(c, w, h, p); break;
            case KIND_MOVE: drawMoveDemo(c, w, h, p); break;
            case KIND_TRANSFORM: drawTransformDemo(c, w, h, p); break;
            case KIND_PUPPET: drawPuppetDemo(c, w, h, p); break;
            case KIND_SEPARATE: drawSeparateDemo(c, w, h, p); break;
            case KIND_COLOR: drawColorDemo(c, w, h, p); break;
            case KIND_SOFT: drawSoftDemo(c, w, h, p); break;
            case KIND_LIGHT: drawLightDemo(c, w, h, p); break;
            case KIND_STYLE: drawStyleDemo(c, w, h, p); break;
            case KIND_IMPROVE: drawImproveDemo(c, w, h, p); break;
            default: {
                // pincel: por donde pasa el dedo aparece el resultado
                Path route = route(w, h);
                PathMeasure pm = new PathMeasure(route, false);
                float len = pm.getLength();
                float drawn = p * len;
                float brush = h * 0.13f;
                Path reveal = new Path();
                float[] pos = new float[2];
                for (float d = 0; d <= drawn; d += brush * 0.35f) {
                    pm.getPosTan(d, pos, null);
                    reveal.addCircle(pos[0], pos[1], brush, Path.Direction.CW);
                }
                if (t >= 1f) {
                    c.drawBitmap(after, 0, 0, null);
                } else if (drawn > 0) {
                    c.save();
                    c.clipPath(reveal);
                    c.drawBitmap(after, 0, 0, null);
                    c.restore();
                    pm.getPosTan(drawn, pos, null);
                    c.drawCircle(pos[0], pos[1], brush, ring);
                    c.drawCircle(pos[0], pos[1], h * 0.035f, finger);
                }
                break;
            }
        }
        c.drawRect(new RectF(1, 1, w - 1, h - 1), frame);
    }

    // ================= v8.69: animaciones con Zeta Pintor =================
    private Bitmap zBg, zChr, zBody, zArm, zHead, zLine, zStyled, zLow;
    private Path zSil, zPartHead, zPartBody, zPartTail, zPartHair;
    private final Paint zp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint zfx = new Paint(Paint.ANTI_ALIAS_FLAG);

    private static final int P_BODY = com.pacco.animecut.core.ChibiArt.PART_BODY,
            P_HEAD = com.pacco.animecut.core.ChibiArt.PART_HEAD, P_HAIR = com.pacco.animecut.core.ChibiArt.PART_HAIR,
            P_ARM = com.pacco.animecut.core.ChibiArt.PART_ARM, P_TAIL = com.pacco.animecut.core.ChibiArt.PART_TAIL;

    /** Lo que necesita cada animacion se dibuja UNA vez (no en cada cuadro). */
    private void prepareZeta(int w, int h) {
        for (Bitmap b : new Bitmap[]{zBg, zChr, zBody, zArm, zHead, zLine, zStyled, zLow})
            if (b != null && !b.isRecycled()) b.recycle();
        zBg = zChr = zBody = zArm = zHead = zLine = zStyled = zLow = null;
        int k = kind();
        try {
            RectF r = new RectF(0, 0, w, h);
            if (k == KIND_MOVE || k == KIND_TRANSFORM || k == KIND_PUPPET || k == KIND_SEPARATE || k == KIND_COLOR
                    || k == KIND_LIGHT || k == KIND_SOFT)
                zBg = ToolArt.backgroundOnly(k == KIND_SEPARATE || k == KIND_COLOR ? 2 : 1, w, h);
            if (k == KIND_MOVE || k == KIND_TRANSFORM || k == KIND_COLOR || k == KIND_SOFT || k == KIND_LIGHT)
                zChr = ToolArt.characterOnly(w, h);
            if (k == KIND_PUPPET) {
                zBody = ToolArt.partsOnly(new int[]{P_TAIL, P_BODY}, w, h);
                zArm = ToolArt.partsOnly(new int[]{P_ARM}, w, h);
                zHead = ToolArt.partsOnly(new int[]{P_HEAD, P_HAIR}, w, h);
            }
            if (k == KIND_SEPARATE) {
                zBody = ToolArt.partsOnly(new int[]{P_TAIL, P_BODY, P_ARM}, w, h);
                zHead = ToolArt.partsOnly(new int[]{P_HEAD}, w, h);
                zArm = ToolArt.partsOnly(new int[]{P_HAIR}, w, h);
            }
            if (k == KIND_COLOR) {
                zLine = ToolArt.lineArtOnly(w, h);
                zPartHead = ToolArt.partPath(P_HEAD, r);
                zPartBody = ToolArt.partPath(P_BODY, r);
                zPartBody.op(ToolArt.partPath(P_ARM, r), Path.Op.UNION);
                zPartTail = ToolArt.partPath(P_TAIL, r);
                zPartHair = ToolArt.partPath(P_HAIR, r);
            }
            if (k == KIND_COLOR || k == KIND_LIGHT || k == KIND_SOFT) zSil = ToolArt.silhouette(r);
            if (k == KIND_STYLE) zStyled = styled(before, w, h);
            if (k == KIND_IMPROVE) zLow = degraded(before, w, h);
        } catch (OutOfMemoryError e) {
            zBg = zChr = zBody = zArm = zHead = zLine = zStyled = zLow = null;
        }
    }

    private void fingerAt(Canvas c, float x, float y, float h, boolean pressed) {
        c.drawCircle(x, y, h * (pressed ? .040f : .045f), finger);
        if (pressed) c.drawCircle(x, y, h * .075f, ring);
    }

    /** Brocha: el trazo de pintura sale de verdad por donde pasa el dedo. */
    private void drawPaintDemo(Canvas c, float w, float h, float p) {
        Path route = new Path();
        route.moveTo(w * .05f, h * .14f);
        route.cubicTo(w * .22f, h * .02f, w * .30f, h * .30f, w * .14f, h * .36f);
        route.cubicTo(w * .02f, h * .42f, w * .08f, h * .56f, w * .24f, h * .50f);
        PathMeasure pm = new PathMeasure(route, false);
        float len = pm.getLength(), drawn = Math.min(1f, p / .85f) * len;
        Path seg = new Path();
        pm.getSegment(0, drawn, seg, true);
        zfx.setStyle(Paint.Style.STROKE);
        zfx.setStrokeCap(Paint.Cap.ROUND);
        zfx.setStrokeJoin(Paint.Join.ROUND);
        zfx.setStrokeWidth(h * .055f);
        zfx.setShader(null);
        zfx.setColor(0xFFE0457B);
        c.drawPath(seg, zfx);
        zfx.setStrokeWidth(h * .016f);
        zfx.setColor(0x66FFFFFF);
        c.drawPath(seg, zfx);
        zfx.setStyle(Paint.Style.FILL);
        if (t < 1f && drawn > 0) {
            float[] pos = new float[2];
            pm.getPosTan(drawn, pos, null);
            c.drawCircle(pos[0], pos[1], h * .06f, ring);
            c.drawCircle(pos[0], pos[1], h * .03f, finger);
        }
    }

    /** Mover: el fondo se queda y Zeta se corre con el dedo. */
    private void drawMoveDemo(Canvas c, float w, float h, float p) {
        if (zBg == null || zChr == null) return;
        float e = ease((p - .12f) / .62f);
        float dx = w * .22f * e - w * .06f, dy = -h * .04f * e;
        c.drawBitmap(zBg, 0, 0, zp);
        c.save();
        c.translate(dx, dy);
        c.scale(.78f, .78f, w * .5f, h);
        c.drawBitmap(zChr, 0, 0, zp);
        c.restore();
        if (t < 1f) fingerAt(c, w * .45f + dx, h * .62f + dy, h, p > .1f);
    }

    /** Transformar: caja con esquinas; una esquina agranda y dos dedos giran. */
    private void drawTransformDemo(Canvas c, float w, float h, float p) {
        if (zBg == null || zChr == null) return;
        c.drawBitmap(zBg, 0, 0, zp);
        float sc = .62f + .22f * ease((p - .08f) / .40f);
        float rot = -12f * ease((p - .55f) / .30f);
        float px = w * .5f, py = h * .52f;
        c.save();
        c.rotate(rot, px, py);
        c.scale(sc, sc, px, py);
        c.drawBitmap(zChr, 0, 0, zp);
        // caja punteada con esquinas
        zfx.setShader(null);
        zfx.setStyle(Paint.Style.STROKE);
        zfx.setStrokeWidth(Math.max(1.5f, h * .008f) / sc);
        zfx.setColor(0xFFFFFFFF);
        zfx.setPathEffect(new android.graphics.DashPathEffect(new float[]{h * .03f / sc, h * .02f / sc}, 0));
        RectF box = new RectF(w * .05f, h * .0f, w * .95f, h * .99f);
        c.drawRect(box, zfx);
        zfx.setPathEffect(null);
        zfx.setStyle(Paint.Style.FILL);
        zfx.setColor(0xFF2F6BD8);
        float hs = h * .035f / sc;
        float[][] cs = {{box.left, box.top}, {box.right, box.top}, {box.left, box.bottom}, {box.right, box.bottom}};
        for (float[] q : cs) c.drawRect(q[0] - hs, q[1] - hs, q[0] + hs, q[1] + hs, zfx);
        c.restore();
        if (t < 1f) {
            if (p < .5f) {
                // la esquina de abajo a la derecha, ya transformada
                float bx = px + (w * .95f - px) * sc, by = py + (h * .99f - py) * sc;
                fingerAt(c, Math.min(w * .94f, bx), Math.min(h * .95f, by), h, p > .08f);
            } else if (p < .9f) {
                double a = Math.toRadians(rot);
                float r1 = h * .26f;
                for (int k = -1; k <= 1; k += 2) {
                    float fx = px + (float) Math.cos(a) * r1 * k, fy = py + (float) Math.sin(a) * r1 * k;
                    fingerAt(c, fx, fy, h, true);
                }
            }
        }
    }

    /** Marioneta: pies fijos (azul), el punto naranja de la mano sube el brazo y la cabeza se inclina. */
    private void drawPuppetDemo(Canvas c, float w, float h, float p) {
        if (zBg == null || zBody == null || zArm == null || zHead == null) return;
        c.drawBitmap(zBg, 0, 0, zp);
        float e = ease((p - .15f) / .55f);
        float armRot = 34f * e, headRot = 7f * e;
        float sx = w * com.pacco.animecut.core.ChibiArt.SHOULDER_X, sy = h * com.pacco.animecut.core.ChibiArt.SHOULDER_Y;
        float nx = w * .5f, ny = h * .51f;
        c.drawBitmap(zBody, 0, 0, zp);
        c.save();
        c.rotate(armRot, sx, sy);
        c.drawBitmap(zArm, 0, 0, zp);
        c.restore();
        c.save();
        c.rotate(headRot, nx, ny);
        c.drawBitmap(zHead, 0, 0, zp);
        c.restore();
        // puntos: azules fijos en los pies, naranja en la mano del pincel
        float pinR = h * .028f;
        float[][] blue = {{w * .38f, h * .93f}, {w * .62f, h * .93f}, {w * .5f, h * .62f}};
        for (float[] q : blue) pin(c, q[0], q[1], pinR, 0xFF2F6BD8);
        double a = Math.toRadians(armRot);
        float hx0 = w * .7222f - sx, hy0 = h * .4178f - sy;    // la mano, respecto del hombro
        float hx = sx + (float) (hx0 * Math.cos(a) - hy0 * Math.sin(a));
        float hy = sy + (float) (hx0 * Math.sin(a) + hy0 * Math.cos(a));
        pin(c, hx, hy, pinR * 1.15f, 0xFFFF8A1F);
        if (t < 1f && p > .08f && p < .8f) fingerAt(c, hx + h * .05f, hy + h * .05f, h, true);
    }

    private void pin(Canvas c, float x, float y, float r, int col) {
        zfx.setShader(null);
        zfx.setStyle(Paint.Style.FILL);
        zfx.setColor(col);
        c.drawCircle(x, y, r, zfx);
        zfx.setStyle(Paint.Style.STROKE);
        zfx.setStrokeWidth(Math.max(1.5f, r * .3f));
        zfx.setColor(0xFFFFFFFF);
        c.drawCircle(x, y, r, zfx);
        zfx.setStyle(Paint.Style.FILL);
    }

    /** Separar: un rayon por parte (boina, cara, cuerpo) y gris en el fondo; despues cada parte sale en su capa. */
    private void drawSeparateDemo(Canvas c, float w, float h, float p) {
        if (zBg == null || zBody == null || zHead == null || zArm == null) return;
        c.drawBitmap(zBg, 0, 0, zp);
        float apart = ease((p - .62f) / .25f);
        c.save(); c.translate(-w * .03f * apart, h * .06f * apart); c.drawBitmap(zBody, 0, 0, zp); c.restore();
        c.save(); c.translate(w * .02f * apart, -h * .02f * apart); c.drawBitmap(zHead, 0, 0, zp); c.restore();
        c.save(); c.translate(w * .05f * apart, -h * .08f * apart); c.drawBitmap(zArm, 0, 0, zp); c.restore();
        // rayones que se van dibujando
        float[][][] lines = {
                {{.42f, .08f}, {.50f, .05f}, {.58f, .08f}},          // boina
                {{.38f, .34f}, {.50f, .30f}, {.62f, .34f}},          // cara
                {{.42f, .70f}, {.50f, .76f}, {.58f, .70f}},          // cuerpo
                {{.10f, .10f}, {.14f, .22f}, {.10f, .34f}}};         // fondo (gris)
        int[] cols = {0xFFFF3B5C, 0xFFFFC21A, 0xFF22C55E, 0xFF8A8A8A};
        float fade = 1f - ease((p - .55f) / .12f);
        zfx.setShader(null);
        zfx.setStyle(Paint.Style.STROKE);
        zfx.setStrokeCap(Paint.Cap.ROUND);
        zfx.setStrokeWidth(h * .035f);
        float[] tip = null;
        for (int i = 0; i < 4; i++) {
            float a0 = i * .12f, f = Math.max(0f, Math.min(1f, (p - a0) / .11f));
            if (f <= 0f || fade <= 0f) continue;
            Path z = new Path();
            z.moveTo(lines[i][0][0] * w, lines[i][0][1] * h);
            z.quadTo(lines[i][1][0] * w, lines[i][1][1] * h, lines[i][2][0] * w, lines[i][2][1] * h);
            PathMeasure pm = new PathMeasure(z, false);
            Path seg = new Path();
            pm.getSegment(0, pm.getLength() * f, seg, true);
            zfx.setColor(cols[i]);
            zfx.setAlpha((int) (255 * fade));
            c.drawPath(seg, zfx);
            if (f < 1f) {
                tip = new float[2];
                pm.getPosTan(pm.getLength() * f, tip, null);
            }
        }
        zfx.setStyle(Paint.Style.FILL);
        zfx.setAlpha(255);
        if (tip != null && t < 1f) fingerAt(c, tip[0], tip[1], h, true);
        // "3 capas" (tres cuadritos apilados) cuando ya se separo
        if (apart > 0f) {
            float s0 = h * .07f;
            for (int i = 0; i < 3; i++) {
                zfx.setColor(new int[]{0xFF22C55E, 0xFFFFC21A, 0xFFFF3B5C}[i]);
                zfx.setAlpha((int) (230 * apart));
                RectF q = new RectF(w * .80f + i * s0 * .18f, h * .82f - i * s0 * .32f, w * .80f + s0 * 1.3f + i * s0 * .18f, h * .82f + s0 * .7f - i * s0 * .32f);
                c.drawRoundRect(q, s0 * .15f, s0 * .15f, zfx);
            }
            zfx.setAlpha(255);
        }
    }

    /** 1 Colorear: el dibujo en blanco y negro; cada toque pinta su parte y al final sale el acabado. */
    private void drawColorDemo(Canvas c, float w, float h, float p) {
        if (zBg == null || zLine == null || zChr == null || zSil == null) return;
        c.drawBitmap(zBg, 0, 0, zp);
        c.drawBitmap(zLine, 0, 0, zp);
        Path[] parts = {zPartHead, zPartBody, zPartTail, zPartHair};
        float[][] taps = {{.40f, .40f}, {.50f, .74f}, {.80f, .62f}, {.46f, .09f}};
        float[] tip = null;
        boolean pressed = false;
        for (int i = 0; i < 4; i++) {
            float a0 = .04f + i * .16f, g = (p - a0) / .14f;
            if (g < 0f) { if (tip == null) tip = new float[]{taps[i][0] * w, taps[i][1] * h}; continue; }
            float grow = ease(g);
            if (g < .35f) { tip = new float[]{taps[i][0] * w, taps[i][1] * h}; pressed = true; }
            c.save();
            c.clipPath(parts[i]);
            Path wave = new Path();
            wave.addCircle(taps[i][0] * w, taps[i][1] * h, grow * Math.max(w, h) * .9f, Path.Direction.CW);
            c.clipPath(wave);
            c.drawBitmap(zChr, 0, 0, zp);
            c.restore();
        }
        // paso 2: acabado (sombra de un lado y luz del otro)
        float fin = ease((p - .72f) / .2f);
        if (fin > 0f) {
            c.save();
            c.clipPath(zSil);
            zfx.setStyle(Paint.Style.FILL);
            zfx.setShader(new LinearGradient(w * .28f, 0, w * .56f, 0, 0x553A2060, 0x003A2060, Shader.TileMode.CLAMP));
            zfx.setAlpha((int) (255 * fin));
            c.drawRect(0, 0, w, h, zfx);
            zfx.setShader(new LinearGradient(w * .70f, 0, w * .90f, 0, 0x00FFF2C8, 0x88FFF2C8, Shader.TileMode.CLAMP));
            zfx.setAlpha((int) (255 * fin));
            c.drawRect(0, 0, w, h, zfx);
            zfx.setShader(null);
            zfx.setAlpha(255);
            c.restore();
            sparkle(c, w * .76f, h * .20f, h * .05f * fin, 0xFFFFFFFF);
        }
        if (t < 1f && tip != null && p < .7f) fingerAt(c, tip[0], tip[1], h, pressed);
    }

    /** 2 Toques: manchitas de rubor y sombra que se funden solas. */
    private void drawSoftDemo(Canvas c, float w, float h, float p) {
        if (zSil == null) return;
        float[][] dabs = {{.33f, .41f, 0}, {.36f, .43f, 0}, {.67f, .41f, 0}, {.64f, .43f, 0},
                {.46f, .50f, 1}, {.54f, .50f, 1}, {.42f, .63f, 1}, {.58f, .63f, 1}};
        float melt = ease((p - .72f) / .2f);
        c.save();
        c.clipPath(zSil);
        int shown = Math.min(dabs.length, (int) (p / .08f));
        for (int i = 0; i < shown; i++) {
            float x = dabs[i][0] * w, y = dabs[i][1] * h;
            boolean blush = dabs[i][2] == 0;
            float rad = h * (blush ? .045f : .055f) * (1f + .9f * melt);
            int col = blush ? 0xFFFF6F91 : 0xFF6A3C8C;
            int a = (int) ((blush ? 150 : 90) * (1f - .35f * melt));
            zfx.setShader(new RadialGradient(x, y, rad, (a << 24) | (col & 0xFFFFFF), col & 0xFFFFFF,
                    Shader.TileMode.CLAMP));
            c.drawCircle(x, y, rad, zfx);
        }
        zfx.setShader(null);
        c.restore();
        if (t < 1f && p < .7f && shown > 0) {
            int k = Math.min(dabs.length - 1, shown - 1);
            fingerAt(c, dabs[k][0] * w, dabs[k][1] * h, h, true);
        }
    }

    /** 3 Luz: el sol se mueve y la luz y la sombra de Zeta lo siguen. */
    private void drawLightDemo(Canvas c, float w, float h, float p) {
        if (zSil == null) return;
        float e = ease(p / .9f);
        float ang = (float) Math.toRadians(200 + 140 * e);
        float sunX = w * .5f + (float) Math.cos(ang) * w * .42f, sunY = h * .42f + (float) Math.sin(ang) * h * .38f;
        // ambiente calido sobre todo
        zfx.setShader(new RadialGradient(sunX, sunY, Math.max(w, h) * .8f, 0x66FFC56B, 0x00FFC56B, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, zfx);
        // en Zeta: luz del lado del sol y sombra del otro
        c.save();
        c.clipPath(zSil);
        float lx = w * .5f + (sunX - w * .5f) * .5f;
        float ox = w - lx;
        zfx.setShader(new LinearGradient(w * .5f + (lx - w * .5f) * .2f, h * .45f, ox, h * .5f, 0x00301848, 0x48301848, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, zfx);
        zfx.setShader(new LinearGradient(sunX, sunY, w * .5f, h * .5f, 0x99FFF0C0, 0x00FFF0C0, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, zfx);
        c.restore();
        zfx.setShader(null);
        // el sol
        zfx.setColor(0xFFFFD34D);
        c.drawCircle(sunX, sunY, h * .055f, zfx);
        zfx.setStyle(Paint.Style.STROKE);
        zfx.setStrokeWidth(h * .012f);
        zfx.setStrokeCap(Paint.Cap.ROUND);
        for (int k = 0; k < 8; k++) {
            double a = k * Math.PI / 4;
            c.drawLine(sunX + (float) Math.cos(a) * h * .075f, sunY + (float) Math.sin(a) * h * .075f,
                    sunX + (float) Math.cos(a) * h * .10f, sunY + (float) Math.sin(a) * h * .10f, zfx);
        }
        zfx.setStyle(Paint.Style.FILL);
        if (t < 1f && p > .05f && p < .9f) fingerAt(c, sunX + h * .06f, sunY + h * .07f, h, true);
    }

    /** 4 Estilo: una barra pasa y deja el acabado de edicion (tono anime, vineta y grano). */
    private void drawStyleDemo(Canvas c, float w, float h, float p) {
        if (zStyled == null) return;
        float x = w * ease((p - .1f) / .7f);
        c.save();
        c.clipRect(0, 0, x, h);
        c.drawBitmap(zStyled, 0, 0, zp);
        c.restore();
        if (x > 0 && x < w) {
            zfx.setShader(null);
            zfx.setColor(0xFFFFFFFF);
            c.drawRect(x - h * .006f, 0, x + h * .006f, h, zfx);
            zfx.setColor(0xFF2F6BD8);
            c.drawCircle(x, h * .5f, h * .05f, zfx);
            zfx.setColor(0xFFFFFFFF);
            c.drawCircle(x, h * .5f, h * .02f, zfx);
        }
    }

    /** Mejorar: de imagen borrosa y con cuadritos a nitida; una linea brillante la recorre. */
    private void drawImproveDemo(Canvas c, float w, float h, float p) {
        if (zLow == null) return;
        float y = h * ease((p - .12f) / .65f);
        c.save();
        c.clipRect(0, y, w, h);
        c.drawBitmap(zLow, 0, 0, zp);
        c.restore();
        if (y > 0 && y < h) {
            zfx.setShader(new LinearGradient(0, y - h * .05f, 0, y, 0x0068E1FF, 0xCC68E1FF, Shader.TileMode.CLAMP));
            c.drawRect(0, y - h * .05f, w, y, zfx);
            zfx.setShader(null);
            zfx.setColor(0xFFBFF3FF);
            c.drawRect(0, y - h * .004f, w, y + h * .004f, zfx);
        }
        float sp = ease((p - .78f) / .15f);
        if (sp > 0f) {
            sparkle(c, w * .30f, h * .22f, h * .05f * sp, 0xFFFFFFFF);
            sparkle(c, w * .74f, h * .36f, h * .04f * sp, 0xFFFFF3A8);
            sparkle(c, w * .62f, h * .12f, h * .03f * sp, 0xFFFFFFFF);
        }
    }

    private void sparkle(Canvas c, float x, float y, float s, int col) {
        if (s <= 0f) return;
        Path st = new Path();
        st.moveTo(x, y - s);
        st.quadTo(x, y, x + s, y);
        st.quadTo(x, y, x, y + s);
        st.quadTo(x, y, x - s, y);
        st.quadTo(x, y, x, y - s);
        st.close();
        zfx.setShader(null);
        zfx.setStyle(Paint.Style.FILL);
        zfx.setColor(col);
        c.drawPath(st, zfx);
    }

    /** Acabado de edicion para la animacion de Estilo: tono violeta/anime, mas contraste, vineta y grano. */
    private static Bitmap styled(Bitmap src, int w, int h) {
        if (src == null) return null;
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        ColorMatrix cm = new ColorMatrix(new float[]{
                1.10f, 0.05f, 0.10f, 0, 6,
                0.00f, 0.95f, 0.05f, 0, -4,
                0.10f, 0.05f, 1.20f, 0, 18,
                0, 0, 0, 1, 0});
        ColorMatrix sat = new ColorMatrix();
        sat.setSaturation(1.25f);
        cm.postConcat(sat);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
        p.setColorFilter(new ColorMatrixColorFilter(cm));
        c.drawBitmap(src, 0, 0, p);
        Paint v = new Paint(Paint.ANTI_ALIAS_FLAG);
        v.setShader(new RadialGradient(w * .5f, h * .5f, Math.max(w, h) * .72f, 0x00000000, 0x7720103A, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, v);
        Paint g = new Paint();
        java.util.Random rnd = new java.util.Random(7);
        int n = w * h / 90;
        for (int i = 0; i < n; i++) {
            g.setColor(rnd.nextBoolean() ? 0x22FFFFFF : 0x22000000);
            float x = rnd.nextFloat() * w, y = rnd.nextFloat() * h;
            c.drawRect(x, y, x + 1.5f, y + 1.5f, g);
        }
        return out;
    }

    /** Version "mala" para Mejorar: chica (cuadritos de JPEG) y un poco lavada. */
    private static Bitmap degraded(Bitmap src, int w, int h) {
        if (src == null) return null;
        int sw = Math.max(8, w / 7), sh = Math.max(8, h / 7);
        Bitmap small = Bitmap.createScaledBitmap(src, sw, sh, true);
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint();          // sin filtro: se ven los cuadritos
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(.7f);
        p.setColorFilter(new ColorMatrixColorFilter(cm));
        c.drawBitmap(small, new android.graphics.Rect(0, 0, sw, sh), new RectF(0, 0, w, h), p);
        small.recycle();
        Paint fog = new Paint();
        fog.setColor(0x22FFFFFF);
        c.drawRect(0, 0, w, h, fog);
        return out;
    }


    private final Paint shapeLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shapeGuide = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);

    /**
     * Curva y Polilinea: el dedo pone 4 puntos, la linea aparece entre ellos,
     * despues arrastra un punto para acomodarla y toca el check.
     */
    private void drawPoints(Canvas c, float w, float h, float p) {
        boolean curve = mode == CanvasView.MODE_CURVE;
        float[][] pts = {{0.14f, 0.78f}, {0.36f, 0.26f}, {0.62f, 0.64f}, {0.86f, 0.24f}};
        // punto 3 se arrastra hacia abajo entre 0.5 y 0.72
        float drag = p < 0.5f ? 0f : Math.min(1f, (p - 0.5f) / 0.22f);
        drag = drag * drag * (3f - 2f * drag);
        float[][] q = new float[4][2];
        for (int i = 0; i < 4; i++) {
            q[i][0] = pts[i][0] * w;
            q[i][1] = pts[i][1] * h;
        }
        q[2][0] -= w * 0.06f * drag;
        q[2][1] += h * 0.2f * drag;
        int shown = Math.min(4, (int) (p / 0.11f) + 1);
        boolean done = p >= 0.86f;

        shapeLine.setStyle(Paint.Style.STROKE);
        shapeLine.setStrokeCap(Paint.Cap.ROUND);
        shapeLine.setStrokeJoin(Paint.Join.ROUND);
        shapeLine.setColor(0xFF6A4CE0);
        shapeLine.setStrokeWidth(h * 0.035f);
        if (shown >= 2) {
            Path path = new Path();
            path.moveTo(q[0][0], q[0][1]);
            for (int i = 0; i < shown - 1; i++) {
                if (curve && shown >= 3) {
                    float[] p0 = q[Math.max(0, i - 1)], p1 = q[i], p2 = q[i + 1], p3 = q[Math.min(shown - 1, i + 2)];
                    path.cubicTo(p1[0] + (p2[0] - p0[0]) / 6f, p1[1] + (p2[1] - p0[1]) / 6f,
                            p2[0] - (p3[0] - p1[0]) / 6f, p2[1] - (p3[1] - p1[1]) / 6f, p2[0], p2[1]);
                } else {
                    path.lineTo(q[i + 1][0], q[i + 1][1]);
                }
            }
            c.drawPath(path, shapeLine);
            if (curve && !done && shown >= 3) {
                shapeGuide.setStyle(Paint.Style.STROKE);
                shapeGuide.setColor(0xAA000000);
                shapeGuide.setStrokeWidth(Math.max(1f, h * 0.006f));
                shapeGuide.setPathEffect(new android.graphics.DashPathEffect(new float[]{h * 0.03f, h * 0.02f}, 0));
                Path g = new Path();
                g.moveTo(q[0][0], q[0][1]);
                for (int i = 1; i < shown; i++) g.lineTo(q[i][0], q[i][1]);
                c.drawPath(g, shapeGuide);
            }
        }
        if (!done) {
            float r = h * 0.032f;
            int sel = drag > 0f ? 2 : shown - 1;
            for (int i = 0; i < shown; i++) {
                dot.setStyle(Paint.Style.FILL);
                dot.setColor(i == sel ? 0xFFE53935 : 0xFF1E6FE0);
                c.drawCircle(q[i][0], q[i][1], r, dot);
                dot.setStyle(Paint.Style.STROKE);
                dot.setStrokeWidth(Math.max(1.5f, h * 0.008f));
                dot.setColor(0xFFFFFFFF);
                c.drawCircle(q[i][0], q[i][1], r, dot);
            }
            // boton check abajo a la derecha
            if (p >= 0.72f) {
                float cx = w * 0.86f, cy = h * 0.86f, cr = h * 0.07f;
                dot.setStyle(Paint.Style.FILL);
                dot.setColor(0xFF2F6BD8);
                c.drawCircle(cx, cy, cr, dot);
                dot.setStyle(Paint.Style.STROKE);
                dot.setColor(0xFFFFFFFF);
                dot.setStrokeWidth(h * 0.012f);
                Path ck = new Path();
                ck.moveTo(cx - cr * 0.45f, cy);
                ck.lineTo(cx - cr * 0.1f, cy + cr * 0.35f);
                ck.lineTo(cx + cr * 0.5f, cy - cr * 0.35f);
                c.drawPath(ck, dot);
            }
            // el dedo
            float fx, fy;
            if (p < 0.5f) {
                int k = Math.min(3, (int) (p / 0.11f));
                fx = q[k][0];
                fy = q[k][1];
            } else if (p < 0.72f) {
                fx = q[2][0];
                fy = q[2][1];
            } else {
                fx = w * 0.86f;
                fy = h * 0.86f;
            }
            c.drawCircle(fx, fy, h * 0.045f, finger);
        }
    }
}
