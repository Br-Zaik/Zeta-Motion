package com.pacco.animecut.core;

/**
 * v8.62: nivel del celular (gama BAJA, MEDIA o ALTA). Java puro (se prueba en PC).
 *
 * Antes la app trataba igual a todos los celulares: abria imagenes de hasta 8 millones de pixeles
 * como minimo, usaba hasta 4+3 hilos y 64 MB de Deshacer aunque el celular tuviera poca memoria.
 * Ahora esos limites salen de la memoria real y de los nucleos del celular.
 *
 * La pantalla llama a {@link #init} al abrir (con la RAM total y si Android lo marca como "poca
 * memoria"). Si no se llamo (pruebas en PC), se decide solo con la memoria de Java y los nucleos.
 */
public final class DeviceTier {
    private DeviceTier() { }

    public static final int BAJA = 0, MEDIA = 1, ALTA = 2;
    public static final String[] NAMES = {"gama baja", "gama media", "gama alta"};

    private static volatile int tier = -1;
    private static volatile long ramMb = 0;

    /**
     * @param totalRamBytes RAM total del celular (0 = no se sabe)
     * @param lowRam        Android marca el celular como de poca memoria
     */
    public static void init(long totalRamBytes, boolean lowRam) {
        ramMb = totalRamBytes > 0 ? totalRamBytes >> 20 : 0;
        tier = decide(ramMb, lowRam, Runtime.getRuntime().maxMemory() >> 20, Runtime.getRuntime().availableProcessors());
    }

    /** Regla (tambien para pruebas): RAM del celular, memoria de Java para la app y nucleos. */
    public static int decide(long ramMb, boolean lowRam, long heapMb, int cores) {
        if (lowRam || (ramMb > 0 && ramMb < 3000) || heapMb < 200 || cores <= 2) return BAJA;
        if ((ramMb > 0 && ramMb < 6000) || heapMb < 400 || cores <= 4) return MEDIA;
        return ALTA;
    }

    public static int tier() {
        int t = tier;
        if (t < 0) {
            t = decide(0, false, Runtime.getRuntime().maxMemory() >> 20, Runtime.getRuntime().availableProcessors());
            tier = t;
        }
        return t;
    }

    /** Hilos para calculos pesados (Acabado, Filtros): gama baja 2, media 3, alta 4 (nunca mas que nucleos). */
    public static int threads() {
        int cores = Math.max(1, Runtime.getRuntime().availableProcessors());
        int want = tier() == BAJA ? 2 : tier() == MEDIA ? 3 : 4;
        return Math.max(1, Math.min(want, cores));
    }

    /** Hilos para el zoom fino (uno menos que los pesados: no se pelean). */
    public static int detailThreads() {
        return Math.max(1, Math.min(threads() - 1, Runtime.getRuntime().availableProcessors() - 1));
    }

    /**
     * Pixeles maximos al abrir una imagen. Antes: minimo 8 millones aunque no alcanzara la memoria.
     * Ahora: baja hasta ~4 MP (o menos si la memoria no da), media hasta lo que da la memoria
     * (minimo 6 MP), alta como antes.
     */
    public static long maxOpenPixels(long heapBytes) {
        long byMem = heapBytes / 14L;
        switch (tier()) {
            case BAJA: return Math.max(2_000_000L, Math.min(4_200_000L, heapBytes / 18L));
            case MEDIA: return Math.max(6_000_000L, Math.min(16_000_000L, byMem));
            default: return Math.max(8_000_000L, byMem);
        }
    }

    /** Memoria para Deshacer: baja 16-24 MB, media 24-48 MB, alta 24-64 MB (como antes). */
    public static long undoBudget(long heapBytes) {
        long tenth = heapBytes / 10;
        switch (tier()) {
            case BAJA: return Math.max(16L << 20, Math.min(24L << 20, tenth));
            case MEDIA: return Math.max(24L << 20, Math.min(48L << 20, tenth));
            default: return Math.max(24L << 20, Math.min(64L << 20, tenth));
        }
    }

    /** Texto para el registro de errores. */
    public static String describe() {
        return NAMES[tier()] + " (RAM " + (ramMb > 0 ? ramMb + " MB" : "?") + ", Java " + (Runtime.getRuntime().maxMemory() >> 20)
                + " MB, nucleos " + Runtime.getRuntime().availableProcessors() + ")";
    }
}
