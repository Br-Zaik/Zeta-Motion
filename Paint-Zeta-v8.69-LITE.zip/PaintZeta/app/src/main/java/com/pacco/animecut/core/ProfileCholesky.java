package com.pacco.animecut.core;

import java.util.Arrays;

/**
 * Cholesky disperso "de perfil" (envolvente) para matrices simetricas
 * definidas positivas, con reordenacion Cuthill-McKee inversa (RCM) para que
 * la envolvente sea estrecha. Sin bibliotecas externas.
 *
 * Uso: se factoriza UNA vez cuando cambian los puntos fijados; mientras se
 * arrastra solo se resuelve (sustitucion hacia delante y hacia atras), que es
 * muy barato.
 */
public final class ProfileCholesky {

    /** Matriz simetrica dispersa: solo se guarda la parte inferior (i &gt;= j). */
    public static final class Sym {
        public final int n;
        final int[][] cols;
        final double[][] vals;
        final int[] cnt;

        public Sym(int n) {
            this.n = n;
            cols = new int[n][];
            vals = new double[n][];
            cnt = new int[n];
        }

        public void add(int i, int j, double v) {
            if (v == 0) return;
            if (i < j) { int t = i; i = j; j = t; }
            int[] c = cols[i];
            int k = cnt[i];
            if (c == null) {
                c = cols[i] = new int[8];
                vals[i] = new double[8];
            }
            for (int q = 0; q < k; q++) {
                if (c[q] == j) { vals[i][q] += v; return; }
            }
            if (k == c.length) {
                cols[i] = c = Arrays.copyOf(c, k * 2);
                vals[i] = Arrays.copyOf(vals[i], k * 2);
            }
            c[k] = j;
            vals[i][k] = v;
            cnt[i] = k + 1;
        }

        /** Producto y = A x (para comprobaciones). */
        public void mul(double[] x, double[] y) {
            Arrays.fill(y, 0, n, 0);
            for (int i = 0; i < n; i++) {
                for (int q = 0; q < cnt[i]; q++) {
                    int j = cols[i][q];
                    double v = vals[i][q];
                    y[i] += v * x[j];
                    if (j != i) y[j] += v * x[i];
                }
            }
        }
    }

    public final int n;
    private final int[] perm;   // perm[nuevo] = viejo
    private final int[] inv;    // inv[viejo] = nuevo
    private final int[] first;  // primera columna de la fila (en orden nuevo)
    private final int[] start;  // inicio de la fila en env
    private final double[] env;
    private final double[] tmp;

    private ProfileCholesky(int n, int[] perm, int[] inv, int[] first, int[] start, double[] env) {
        this.n = n;
        this.perm = perm;
        this.inv = inv;
        this.first = first;
        this.start = start;
        this.env = env;
        this.tmp = new double[n];
    }

    /** Tamano de la envolvente (memoria y coste). */
    public int envelopeSize() {
        return env.length;
    }

    /**
     * Factoriza A. Devuelve null si A no es definida positiva (no deberia
     * pasar: siempre se agrega una regularizacion minima).
     */
    public static ProfileCholesky factor(Sym A) {
        final int n = A.n;
        int[] perm = rcm(A);
        int[] inv = new int[n];
        for (int i = 0; i < n; i++) inv[perm[i]] = i;
        int[] first = new int[n];
        for (int i = 0; i < n; i++) first[i] = i;
        for (int oi = 0; oi < n; oi++) {
            for (int q = 0; q < A.cnt[oi]; q++) {
                int a = inv[oi], b = inv[A.cols[oi][q]];
                int hi = Math.max(a, b), lo = Math.min(a, b);
                if (lo < first[hi]) first[hi] = lo;
            }
        }
        int[] start = new int[n + 1];
        long total = 0;
        for (int i = 0; i < n; i++) {
            start[i] = (int) total;
            total += i - first[i] + 1;
        }
        if (total > Integer.MAX_VALUE - 8) return null;
        start[n] = (int) total;
        double[] L = new double[(int) total];
        for (int oi = 0; oi < n; oi++) {
            for (int q = 0; q < A.cnt[oi]; q++) {
                int a = inv[oi], b = inv[A.cols[oi][q]];
                int hi = Math.max(a, b), lo = Math.min(a, b);
                L[start[hi] + lo - first[hi]] += A.vals[oi][q];
            }
        }
        // Cholesky por filas dentro de la envolvente.
        for (int i = 0; i < n; i++) {
            int fi = first[i], si = start[i];
            for (int j = fi; j < i; j++) {
                int fj = first[j], sj = start[j];
                int k0 = Math.max(fi, fj);
                double s = L[si + j - fi];
                int pi = si + k0 - fi, pj = sj + k0 - fj;
                for (int k = k0; k < j; k++) s -= L[pi++] * L[pj++];
                L[si + j - fi] = s / L[sj + j - fj];
            }
            double d = L[si + i - fi];
            for (int k = fi; k < i; k++) {
                double v = L[si + k - fi];
                d -= v * v;
            }
            if (!(d > 1e-14)) return null;
            L[si + i - fi] = Math.sqrt(d);
        }
        return new ProfileCholesky(n, perm, inv, first, start, L);
    }

    /** Resuelve A x = b (en el orden original). b y x pueden ser el mismo arreglo. */
    public void solve(double[] b, double[] x) {
        final double[] y = tmp;
        for (int i = 0; i < n; i++) y[i] = b[perm[i]];
        // L y' = y
        for (int i = 0; i < n; i++) {
            int fi = first[i], si = start[i];
            double s = y[i];
            int p = si;
            for (int k = fi; k < i; k++) s -= env[p++] * y[k];
            y[i] = s / env[si + i - fi];
        }
        // L^T x' = y'
        for (int i = n - 1; i >= 0; i--) {
            int fi = first[i], si = start[i];
            double v = y[i] / env[si + i - fi];
            y[i] = v;
            int p = si;
            for (int k = fi; k < i; k++) y[k] -= env[p++] * v;
        }
        for (int i = 0; i < n; i++) x[perm[i]] = y[i];
    }

    /** Orden Cuthill-McKee inverso por componentes. */
    static int[] rcm(Sym A) {
        final int n = A.n;
        int[] deg = new int[n];
        for (int i = 0; i < n; i++) {
            for (int q = 0; q < A.cnt[i]; q++) {
                int j = A.cols[i][q];
                if (j != i) { deg[i]++; deg[j]++; }
            }
        }
        int[] adjStart = new int[n + 1];
        for (int i = 0; i < n; i++) adjStart[i + 1] = adjStart[i] + deg[i];
        int[] adj = new int[adjStart[n]];
        int[] fill = Arrays.copyOf(adjStart, n);
        for (int i = 0; i < n; i++) {
            for (int q = 0; q < A.cnt[i]; q++) {
                int j = A.cols[i][q];
                if (j != i) { adj[fill[i]++] = j; adj[fill[j]++] = i; }
            }
        }
        int[] order = new int[n];
        boolean[] seen = new boolean[n];
        int[] level = new int[n];
        int head = 0;
        for (int s0 = 0; s0 < n; s0++) {
            if (seen[s0]) continue;
            // Nodo casi periferico: dos BFS buscando el mas lejano de menor grado.
            int root = s0;
            for (int pass = 0; pass < 2; pass++) root = farthest(root, adj, adjStart, deg, level, seen);
            int qs = head;
            order[head++] = root;
            seen[root] = true;
            while (qs < head) {
                int v = order[qs++];
                int a0 = head;
                for (int p = adjStart[v]; p < adjStart[v + 1]; p++) {
                    int u = adj[p];
                    if (!seen[u]) { seen[u] = true; order[head++] = u; }
                }
                // vecinos nuevos ordenados por grado (insercion: pocos)
                for (int i = a0 + 1; i < head; i++) {
                    int u = order[i], j = i - 1;
                    while (j >= a0 && deg[order[j]] > deg[u]) { order[j + 1] = order[j]; j--; }
                    order[j + 1] = u;
                }
            }
        }
        int[] perm = new int[n];
        for (int i = 0; i < n; i++) perm[i] = order[n - 1 - i];
        return perm;
    }

    /** BFS desde r sin marcar 'seen' global: devuelve el nodo mas lejano (menor grado). */
    private static int farthest(int r, int[] adj, int[] adjStart, int[] deg, int[] level, boolean[] seen) {
        java.util.ArrayDeque<Integer> q = new java.util.ArrayDeque<Integer>();
        java.util.HashMap<Integer, Integer> lv = new java.util.HashMap<Integer, Integer>();
        q.add(r);
        lv.put(r, 0);
        int best = r, bestL = 0;
        while (!q.isEmpty()) {
            int v = q.poll();
            int l = lv.get(v);
            if (l > bestL || (l == bestL && deg[v] < deg[best])) { bestL = l; best = v; }
            for (int p = adjStart[v]; p < adjStart[v + 1]; p++) {
                int u = adj[p];
                if (seen[u] || lv.containsKey(u)) continue;
                lv.put(u, l + 1);
                q.add(u);
            }
        }
        return best;
    }
}
