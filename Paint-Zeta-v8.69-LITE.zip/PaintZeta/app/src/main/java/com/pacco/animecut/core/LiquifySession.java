package com.pacco.animecut.core;

import java.util.ArrayDeque;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicIntegerArray;

/**
 * Motor de Especial en su PROPIO hilo (sin dependencias de Android).
 *
 *  Hilo de la interfaz                    Hilo del motor (este)
 *  -------------------                    ---------------------
 *  toque -> beginStroke/moveTo/tick  -->  cola de comandos (nunca se descartan)
 *                                         aplica TODAS las sub-estampas en orden
 *                                         renderiza bloques sucios (cerca del dedo
 *                                         y visibles primero) con LiquifyRaster
 *  cada fotograma: pollReady/copyTile <-- bloques listos (siempre el mas reciente)
 *  levantar dedo: endStroke ------------> renderiza lo pendiente, avisa "terminado"
 *
 * - El hilo de la interfaz no calcula campo ni pixeles: solo copia bloques de
 *   64x64 ya terminados a la capa.
 * - Un bloque viejo nunca pisa uno nuevo: la interfaz siempre copia el contenido
 *   ACTUAL del bloque, protegido por su propio candado.
 * - Si el motor va atrasado no se pierde ningun movimiento: se juntan fotogramas,
 *   no estampas.
 */
public final class LiquifySession {
    public interface Listener {
        /** Hay bloques listos para copiar (se llama desde el hilo del motor). */
        void onTilesReady(LiquifySession session);
        /** El trazo termino de renderizarse (o se cancelo). Hilo del motor. */
        void onStrokeFinished(LiquifySession session, int strokeId, boolean cancelled);
    }

    /** Marcas para Perfetto / System Trace (las conecta CanvasView con android.os.Trace). */
    public interface Tracer {
        void begin(String section);
        void end();
    }

    public static volatile Tracer tracer;

    public static final int TILE = LiquifySource.TILE;
    private static final int CMD_BEGIN = 1, CMD_MOVE = 2, CMD_TICK = 3, CMD_END = 4, CMD_CANCEL = 5;
    /** Presupuesto de render antes de volver a mirar si llegaron movimientos nuevos. */
    private static final long SLICE_NS = 6_000_000L;

    private static final class Cmd {
        int type, id, mode;
        float x, y, radius, strength, softness;
        long t;
        byte[] selection;
    }

    public final int width, height, tilesX, tilesY;
    public final LiquifyField field;
    public final LiquifySource source;
    private final LiquifyStroke stroke;
    private final LiquifyRaster raster = new LiquifyRaster();
    private final Listener listener;

    // Bloques de salida (ultimo estado renderizado) y su entrega a la interfaz.
    private final int[][] out;
    private final AtomicIntegerArray outGen;
    private final AtomicIntegerArray readyFlag;
    private final int[] readyQueue;
    private int readyHead, readyTail, readySize;
    private final Object readyLock = new Object();

    // Estado SOLO del hilo del motor.
    private final boolean[] dirty;
    private final int[] dirtyList;
    private int dirtyCount;
    private final int[] renderedList;
    private final boolean[] rendered;
    private int renderedCount;
    private int[][] prev; // copia previa al trazo (solo trazos con seleccion)
    private int curStroke;
    private byte[] curSelection;
    private final int[] scratch = new int[TILE * TILE];
    private final long[] order;
    private final LiquifyStroke.Sink sink = new LiquifyStroke.Sink() {
        @Override public void onDirty(int x0, int y0, int x1, int y1) { markDirty(x0, y0, x1, y1); }
    };

    // Cola de comandos.
    private final Object lock = new Object();
    private final ArrayDeque<Cmd> cmds = new ArrayDeque<Cmd>();
    private final ArrayDeque<Cmd> pool = new ArrayDeque<Cmd>();
    private boolean closed;
    private int finishedStroke;
    private volatile boolean failed;
    private volatile int visX0, visY0, visX1, visY1;
    private final Thread thread;

    // Medidas (diagnostico / pruebas de rendimiento).
    public volatile long statTilesRendered, statRenderNanos, statStampNanos, statSubStamps;

    public LiquifySession(int[] layerPx, int width, int height, int step,
            Listener listener, ThreadFactory factory) {
        this.width = width;
        this.height = height;
        this.field = new LiquifyField(width, height, step);
        this.source = new LiquifySource(layerPx, width, height);
        this.stroke = new LiquifyStroke(field);
        this.listener = listener;
        this.tilesX = source.tilesX;
        this.tilesY = source.tilesY;
        int n = tilesX * tilesY;
        out = new int[n][];
        outGen = new AtomicIntegerArray(n);
        readyFlag = new AtomicIntegerArray(n);
        readyQueue = new int[n];
        dirty = new boolean[n];
        dirtyList = new int[n];
        rendered = new boolean[n];
        renderedList = new int[n];
        order = new long[n];
        visX1 = width; visY1 = height;
        Runnable loop = new Runnable() { @Override public void run() { loop(); } };
        thread = factory != null ? factory.newThread(loop) : new Thread(loop, "PaintZeta-Especial");
        thread.setDaemon(true);
        thread.start();
    }

    public boolean isFailed() { return failed; }

    // ------------------------------------------------------------------
    // API de la interfaz (cualquier hilo, normalmente el principal)
    // ------------------------------------------------------------------

    public void setVisible(int x0, int y0, int x1, int y1) {
        visX0 = x0; visY0 = y0; visX1 = x1; visY1 = y1;
    }

    public void beginStroke(int id, int mode, float radius, float strength, float softness,
            byte[] selection, float x, float y, long timeMs) {
        Cmd c = obtain(CMD_BEGIN);
        c.id = id; c.mode = mode; c.radius = radius; c.strength = strength;
        c.softness = softness; c.selection = selection; c.x = x; c.y = y; c.t = timeMs;
        post(c);
    }

    public void moveTo(float x, float y, long timeMs) {
        Cmd c = obtain(CMD_MOVE);
        c.x = x; c.y = y; c.t = timeMs;
        post(c);
    }

    public void tick(long timeMs) {
        Cmd c = obtain(CMD_TICK);
        c.t = timeMs;
        post(c);
    }

    public void endStroke(int id) {
        Cmd c = obtain(CMD_END);
        c.id = id;
        post(c);
    }

    public void cancelStroke(int id) {
        Cmd c = obtain(CMD_CANCEL);
        c.id = id;
        post(c);
    }

    /** Espera a que el trazo id quede renderizado. true si termino a tiempo. */
    public boolean awaitStroke(int id, long timeoutMs) {
        long end = System.nanoTime() + timeoutMs * 1_000_000L;
        synchronized (lock) {
            while (finishedStroke < id && !closed && !failed) {
                long left = end - System.nanoTime();
                if (left <= 0) return false;
                try { lock.wait(Math.max(1L, left / 1_000_000L)); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
            }
            return finishedStroke >= id;
        }
    }

    /** Siguiente bloque listo o -1. */
    public int pollReady() {
        synchronized (readyLock) {
            if (readySize == 0) return -1;
            int k = readyQueue[readyHead];
            readyHead = (readyHead + 1) % readyQueue.length;
            readySize--;
            readyFlag.set(k, 0);
            return k;
        }
    }

    /** Trazo que produjo el contenido actual del bloque. */
    public int tileGeneration(int key) { return outGen.get(key); }

    /** Copia el contenido ACTUAL del bloque a la capa (stride = ancho del lienzo). */
    public void copyTile(int key, int[] layerPx) {
        int[] t = out[key];
        if (t == null) return;
        int tx = key % tilesX, ty = key / tilesX;
        int left = tx * TILE, top = ty * TILE;
        int tw = Math.min(TILE, width - left), th = Math.min(TILE, height - top);
        synchronized (t) {
            for (int y = 0; y < th; y++)
                System.arraycopy(t, y * TILE, layerPx, (top + y) * width + left, tw);
        }
    }

    public void tileRect(int key, int[] r) {
        int tx = key % tilesX, ty = key / tilesX;
        r[0] = tx * TILE; r[1] = ty * TILE;
        r[2] = Math.min(width, r[0] + TILE); r[3] = Math.min(height, r[1] + TILE);
    }

    public void close() {
        synchronized (lock) {
            closed = true;
            cmds.clear();
            lock.notifyAll();
        }
    }

    public boolean isClosed() {
        synchronized (lock) { return closed; }
    }

    // ------------------------------------------------------------------
    // Cola
    // ------------------------------------------------------------------

    private Cmd obtain(int type) {
        Cmd c;
        synchronized (lock) { c = pool.pollFirst(); }
        if (c == null) c = new Cmd();
        c.type = type;
        c.selection = null;
        return c;
    }

    private void post(Cmd c) {
        synchronized (lock) {
            if (closed) return;
            cmds.addLast(c);
            lock.notifyAll();
        }
    }

    private boolean hasCommands() {
        synchronized (lock) { return !cmds.isEmpty(); }
    }

    // ------------------------------------------------------------------
    // Hilo del motor
    // ------------------------------------------------------------------

    private void loop() {
        ArrayDeque<Cmd> batch = new ArrayDeque<Cmd>();
        try {
            while (true) {
                synchronized (lock) {
                    while (cmds.isEmpty() && dirtyCount == 0 && !closed) {
                        try { lock.wait(); } catch (InterruptedException e) { return; }
                    }
                    if (closed) return;
                    while (!cmds.isEmpty()) batch.addLast(cmds.pollFirst());
                }
                Cmd c;
                while ((c = batch.pollFirst()) != null) {
                    process(c);
                    synchronized (lock) { if (pool.size() < 256) pool.addLast(c); }
                    if (isClosedFast()) return;
                }
                if (dirtyCount > 0) renderSome(false);
            }
        } catch (Throwable t) {
            failed = true;
            synchronized (lock) { lock.notifyAll(); }
            if (listener != null) listener.onStrokeFinished(this, curStroke, true);
        }
    }

    private boolean isClosedFast() {
        synchronized (lock) { return closed; }
    }

    private void process(Cmd c) {
        Tracer tr = tracer;
        if (tr != null) tr.begin("Especial:campo");
        try {
            processCmd(c);
        } finally {
            if (tr != null) tr.end();
        }
    }

    private void processCmd(Cmd c) {
        long t0 = System.nanoTime();
        switch (c.type) {
            case CMD_BEGIN:
                curStroke = c.id;
                curSelection = c.selection;
                clearRendered();
                prev = null;
                field.beginStroke();
                stroke.begin(c.mode, c.radius, c.strength, c.softness, c.selection, c.x, c.y, c.t);
                break;
            case CMD_MOVE:
                stroke.moveTo(c.x, c.y, c.t, sink);
                break;
            case CMD_TICK:
                stroke.tick(c.t, sink);
                break;
            case CMD_END:
                if (c.id != curStroke) break;
                stroke.finish(sink);
                renderSome(true);
                field.endStroke();
                prev = null;
                clearRendered();
                finish(c.id, false);
                return;
            case CMD_CANCEL:
                if (c.id != curStroke) break;
                stroke.end();
                field.cancelStroke();
                // Los bloques de salida vuelven al estado anterior (no se entregan:
                // la interfaz ya restauro la capa desde su respaldo).
                for (int n = 0; n < renderedCount; n++) {
                    int k = renderedList[n];
                    int[] before = prev != null ? prev[k] : null;
                    if (before != null) writeOut(k, before, -c.id, false);
                    else {
                        raster.renderTile(field, source, k % tilesX, k / tilesX, null, null, scratch);
                        writeOut(k, scratch, -c.id, false);
                    }
                }
                // Lo pendiente del trazo cancelado ya no hace falta: el campo volvio atras.
                for (int n = 0; n < dirtyCount; n++) dirty[dirtyList[n]] = false;
                dirtyCount = 0;
                prev = null;
                clearRendered();
                finish(c.id, true);
                return;
        }
        statStampNanos += System.nanoTime() - t0;
        statSubStamps = stroke.subStamps;
    }

    private void finish(int id, boolean cancelled) {
        synchronized (lock) {
            if (id > finishedStroke) finishedStroke = id;
            lock.notifyAll();
        }
        if (listener != null) listener.onStrokeFinished(this, id, cancelled);
    }

    private void clearRendered() {
        for (int n = 0; n < renderedCount; n++) rendered[renderedList[n]] = false;
        renderedCount = 0;
    }

    private void markDirty(int x0, int y0, int x1, int y1) {
        if (x1 <= x0 || y1 <= y0) return;
        int tx0 = Math.max(0, x0 / TILE), ty0 = Math.max(0, y0 / TILE);
        int tx1 = Math.min(tilesX - 1, (x1 - 1) / TILE), ty1 = Math.min(tilesY - 1, (y1 - 1) / TILE);
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                int k = ty * tilesX + tx;
                if (!dirty[k]) {
                    dirty[k] = true;
                    dirtyList[dirtyCount++] = k;
                }
            }
        }
    }

    /**
     * Renderiza bloques sucios. all=true (confirmar): todos. all=false: primero
     * los visibles mas cercanos al pincel, cediendo el paso a comandos nuevos.
     */
    private void renderSome(boolean all) {
        if (dirtyCount == 0) return;
        Tracer tr = tracer;
        if (tr != null) tr.begin(all ? "Especial:render-final" : "Especial:render");
        try {
            renderSomeImpl(all);
        } finally {
            if (tr != null) tr.end();
        }
    }

    private void renderSomeImpl(boolean all) {
        float fx = stroke.lastX(), fy = stroke.lastY();
        int vx0 = visX0, vy0 = visY0, vx1 = visX1, vy1 = visY1;
        boolean anyVisible = false;
        // Ordenar: visibles primero y por distancia al pincel.
        for (int n = 0; n < dirtyCount; n++) {
            int k = dirtyList[n];
            int tx = k % tilesX, ty = k / tilesX;
            int l = tx * TILE, t = ty * TILE;
            boolean vis = l < vx1 && l + TILE > vx0 && t < vy1 && t + TILE > vy0;
            if (vis) anyVisible = true;
            float cx = l + TILE * .5f - fx, cy = t + TILE * .5f - fy;
            long d = (long) Math.min(1e9, Math.sqrt(cx * cx + cy * cy));
            order[n] = ((vis ? 0L : 1L) << 62) | (d << 24) | k;
        }
        java.util.Arrays.sort(order, 0, dirtyCount);
        long sliceStart = System.nanoTime();
        int done = 0;
        boolean posted = false;
        final int count = dirtyCount;
        for (int n = 0; n < count; n++) {
            int k = (int) (order[n] & 0xFFFFFF);
            boolean vis = (order[n] >>> 62) == 0L;
            if (!all) {
                if (!vis && anyVisible && hasCommands()) break;
                if (done > 0 && System.nanoTime() - sliceStart > SLICE_NS && hasCommands()) break;
            }
            renderTile(k);
            dirty[k] = false;
            done++;
            if (!all && done % 4 == 0) { posted = true; notifyReady(); }
        }
        // Compactar la lista de sucios.
        int m = 0;
        for (int n = 0; n < dirtyCount; n++) {
            int k = dirtyList[n];
            if (dirty[k]) dirtyList[m++] = k;
        }
        dirtyCount = m;
        if (done > 0 && (!posted || done % 4 != 0)) notifyReady();
    }

    private void renderTile(int k) {
        long t0 = System.nanoTime();
        source.tile(k); // capturar el original de ESTE bloque antes de que se escriba
        int[] before = null;
        if (curSelection != null) {
            if (prev == null) prev = new int[tilesX * tilesY][];
            before = prev[k];
            if (before == null) {
                int[] cur = out[k] != null ? out[k] : source.tile(k);
                before = new int[TILE * TILE];
                synchronized (cur) { System.arraycopy(cur, 0, before, 0, before.length); }
                prev[k] = before;
            }
        }
        raster.renderTile(field, source, k % tilesX, k / tilesX, curSelection, before, scratch);
        writeOut(k, scratch, curStroke, true);
        if (!rendered[k]) { rendered[k] = true; renderedList[renderedCount++] = k; }
        statTilesRendered++;
        statRenderNanos += System.nanoTime() - t0;
    }

    private void writeOut(int k, int[] data, int gen, boolean deliver) {
        int[] t = out[k];
        if (t == null) { t = new int[TILE * TILE]; out[k] = t; }
        synchronized (t) { System.arraycopy(data, 0, t, 0, t.length); }
        outGen.set(k, gen);
        if (!deliver) return;
        if (readyFlag.compareAndSet(k, 0, 1)) {
            synchronized (readyLock) {
                readyQueue[readyTail] = k;
                readyTail = (readyTail + 1) % readyQueue.length;
                readySize++;
            }
        }
    }

    private void notifyReady() {
        if (listener != null) listener.onTilesReady(this);
    }

    /** Solo pruebas: copia del contenido renderizado de un bloque. */
    public int[] debugOutTile(int key) {
        int[] t = out[key];
        if (t == null) return null;
        synchronized (t) { return t.clone(); }
    }
}
