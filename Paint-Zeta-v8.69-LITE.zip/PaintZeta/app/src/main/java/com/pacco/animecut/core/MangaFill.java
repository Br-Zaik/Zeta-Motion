package com.pacco.animecut.core;

import android.graphics.Rect;

import java.util.ArrayList;
import java.util.List;

/**
 * v8.26 Balde para MANGA blanco y negro (preset "Colorear manga"). Sin IA.
 *
 * Diferencia con el balde normal (BucketFill): aqui la zona NO se busca por
 * parecido de color, sino por LINEAS. Todo lo que no es tinta (papel blanco,
 * grises, antialias y, con "modo trama", los puntitos de trama) es la misma zona
 * hasta chocar con una linea. Asi una chaqueta con trama, brillos y grises se
 * rellena de un toque, y como el color va en una capa MULTIPLICAR, la tinta, los
 * grises y la trama del original se siguen viendo encima del color.
 *
 * Pasos:
 *  1. MAPA DE TINTA (lineMap, se calcula una vez y se guarda): pixel "tinta" si su
 *     brillo es menor que el umbral. Se quitan las motas de 1-2 px (ruido JPEG) y,
 *     con modo trama, los puntos chicos aislados (componentes de hasta maxDot px y
 *     lado maxSide). Una linea fina en diagonal NO se quita: sus pixeles sueltos
 *     forman una cadena larga y delgada (area <= 2.5 x largo) y esa se conserva.
 *  2. ZONA: relleno por lineas (4 vecinos) sobre todo lo que no es tinta ni zona
 *     protegida.
 *  3. CORTES: lineas abiertas: se reutiliza el cierre de cortes de BucketFill
 *     (distancia + cuencas): lo que esta detras de un corte angosto no se pinta.
 *  4. AGUJEROS: manchitas de tinta encerradas (hasta holeMax px) se cubren.
 *  5. BAJO LA LINEA: el color entra 'expand' px dentro de la tinta, solo bajando
 *     hacia lo mas oscuro (nunca pasa el centro de la linea ni llega al papel del
 *     otro lado). Evita la franja blanca entre color y linea al hacer zoom.
 */
public final class MangaFill {
    private MangaFill() { }

    public static final class Params {
        /** Brillo (0..255) por debajo del cual un pixel es tinta. */
        public int darkThr = 128;
        /** Modo trama: los puntitos aislados no cortan la zona. */
        public boolean tone = true;
        public int maxDot = 30, maxDotSide = 7;
        /** Cierre de cortes: 0 = no; Pequeno 2, Medio 3, Grande 6 (cierra ~2x px). */
        public int gap = 3;
        /** Pixeles que el color entra bajo la linea (solo tiene sentido en Multiplicar). */
        public int expand = 2;
        public int holeMax = 64;
        /** Zonas "No colorear" (puede ser null). */
        public byte[] protect;
        /**
         * Trama DENSA (opcional, apagada de fabrica): mapa de textura (textureMap). La
         * zona crece hasta denseReach px dentro de la trama tupida pegada a ella (donde
         * los puntos se tocan y forman una red). Puede entrar en la trama de la zona de
         * al lado: por eso hay vista previa y queda apagado de fabrica.
         */
        public byte[] texture;
        /**
         * v8.66 (Colorear por zonas): huecos encerrados por la zona que son casi todo gris oscuro
         * (sombras pintadas del dibujo: pliegues del saco) entran a la zona aunque sean grandes.
         * 0 = apagado. Es el brillo por debajo del cual cuenta como oscuro.
         */
        public int darkHoleLum = 0;
        public int denseReach = 24;
    }

    public static final class Result {
        public Rect bounds;
        public int area, expanded, holes, gapUsed, seedLum, dense;
        /** v8.59: pixeles sueltos (lejos del toque) que se quitaron. */
        public int strays;
    }

    /** Niveles de "Cerrar huecos" que ve el usuario. */
    public static final int[] GAP_LEVELS = {0, 2, 3, 6};
    public static final String[] GAP_NAMES = {"No", "Pequeno", "Medio", "Grande"};

    public static int lumAt(int[] ref, int i) {
        return BucketFill.lum(BucketFill.paper(ref[i]));
    }

    // ------------------------------------------------------------------
    // 1. mapa de tinta
    // ------------------------------------------------------------------

    /** 1 = tinta (barrera), 0 = se puede rellenar. */
    public static byte[] lineMap(int[] ref, int w, int h, Params p) {
        int n = w * h;
        byte[] m = new byte[n];
        int thr = p.darkThr;
        for (int i = 0; i < n; i++) if (lumAt(ref, i) < thr) m[i] = 1;
        // valores: 1 tinta sin visitar, 2 componente grande (linea), 3 componente chico
        int keep = p.tone ? Math.max(2, p.maxDot) : 2;
        int side = p.tone ? p.maxDotSide : 2;
        int[] st = new int[4096];
        int[] comp = new int[keep + 1];
        for (int i0 = 0; i0 < n; i0++) {
            if (m[i0] != 1) continue;
            int sp = 0, cnt = 0;
            int minX = i0 % w, maxX = minX, minY = i0 / w, maxY = minY;
            st[sp++] = i0;
            m[i0] = 4; // en proceso
            while (sp > 0) {
                int i = st[--sp];
                if (cnt <= keep) comp[Math.min(cnt, keep)] = i;
                cnt++;
                int x = i % w, y = i / w;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
                if (x > 0 && m[i - 1] == 1) { m[i - 1] = 4; st = push(st, sp++, i - 1); }
                if (x < w - 1 && m[i + 1] == 1) { m[i + 1] = 4; st = push(st, sp++, i + 1); }
                if (y > 0 && m[i - w] == 1) { m[i - w] = 4; st = push(st, sp++, i - w); }
                if (y < h - 1 && m[i + w] == 1) { m[i + w] = 4; st = push(st, sp++, i + w); }
            }
            boolean small = cnt <= keep && Math.max(maxX - minX, maxY - minY) + 1 <= side;
            if (small) {
                for (int k = 0; k < cnt; k++) m[comp[k]] = 3;
            } else {
                // marcar el componente grande: segundo recorrido barato sobre los 4
                sp = 0;
                st[sp++] = i0;
                m[i0] = 2;
                while (sp > 0) {
                    int i = st[--sp];
                    int x = i % w, y = i / w;
                    if (x > 0 && m[i - 1] == 4) { m[i - 1] = 2; st = push(st, sp++, i - 1); }
                    if (x < w - 1 && m[i + 1] == 4) { m[i + 1] = 2; st = push(st, sp++, i + 1); }
                    if (y > 0 && m[i - w] == 4) { m[i - w] = 2; st = push(st, sp++, i - w); }
                    if (y < h - 1 && m[i + w] == 4) { m[i + w] = 2; st = push(st, sp++, i + w); }
                }
            }
        }
        // Los chicos (3) se agrupan con 8 vecinos: una cadena larga y delgada es una
        // linea fina en diagonal (se conserva); el resto son puntos de trama o ruido.
        int[] grp = new int[1024];
        for (int i0 = 0; i0 < n; i0++) {
            if (m[i0] != 3) continue;
            int sp = 0, cnt = 0;
            int minX = i0 % w, maxX = minX, minY = i0 / w, maxY = minY;
            st[sp++] = i0;
            m[i0] = 5;
            while (sp > 0) {
                int i = st[--sp];
                if (cnt == grp.length) grp = java.util.Arrays.copyOf(grp, cnt * 2);
                grp[cnt++] = i;
                int x = i % w, y = i / w;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= w) continue;
                        int j = yy * w + xx;
                        if (m[j] == 3) { m[j] = 5; st = push(st, sp++, j); }
                    }
                }
            }
            int longSide = Math.max(maxX - minX, maxY - minY) + 1;
            boolean thinLine = longSide >= 2 * Math.max(4, side) && cnt <= 2.5f * longSide;
            byte v = thinLine ? (byte) 2 : (byte) 0;
            for (int k = 0; k < cnt; k++) m[grp[k]] = v;
        }
        for (int i = 0; i < n; i++) m[i] = m[i] == 2 ? (byte) 1 : (byte) 0;
        return m;
    }

    /**
     * Mapa de TRAMA TUPIDA (1 = textura): en una ventana de 9x9 hay al menos 8 pixeles
     * que son puntitos oscuros sueltos o huequitos claros encerrados (lo tipico de una
     * trama donde los puntos se tocan). El centro grueso de una linea (todo oscuro
     * alrededor) nunca es textura.
     */
    public static byte[] textureMap(int[] ref, byte[] line, int w, int h, Params p) {
        int n = w * h;
        byte[] small = new byte[n]; // 1 = puntito oscuro quitado o huequito claro
        // puntitos oscuros: oscuros que NO quedaron como linea
        for (int i = 0; i < n; i++) if (line[i] == 0 && lumAt(ref, i) < p.darkThr) small[i] = 1;
        // huequitos claros: componentes claras (4 vecinos) de hasta maxDot px
        byte[] seen = new byte[n];
        int[] st = new int[4096];
        int[] comp = new int[p.maxDot + 1];
        for (int i0 = 0; i0 < n; i0++) {
            if (seen[i0] != 0 || lumAt(ref, i0) < p.darkThr) continue;
            int sp = 0, cnt = 0;
            st[sp++] = i0;
            seen[i0] = 1;
            while (sp > 0) {
                int i = st[--sp];
                if (cnt <= p.maxDot) comp[Math.min(cnt, p.maxDot)] = i;
                cnt++;
                int x = i % w, y = i / w;
                if (x > 0 && seen[i - 1] == 0 && lumAt(ref, i - 1) >= p.darkThr) { seen[i - 1] = 1; st = push(st, sp++, i - 1); }
                if (x < w - 1 && seen[i + 1] == 0 && lumAt(ref, i + 1) >= p.darkThr) { seen[i + 1] = 1; st = push(st, sp++, i + 1); }
                if (y > 0 && seen[i - w] == 0 && lumAt(ref, i - w) >= p.darkThr) { seen[i - w] = 1; st = push(st, sp++, i - w); }
                if (y < h - 1 && seen[i + w] == 0 && lumAt(ref, i + w) >= p.darkThr) { seen[i + w] = 1; st = push(st, sp++, i + w); }
            }
            if (cnt <= p.maxDot) for (int k = 0; k < cnt; k++) small[comp[k]] = 1;
        }
        seen = null;
        // conteo en ventana 9x9 con tabla acumulada por filas (memoria: un int por pixel)
        int[] acc = new int[(w + 1) * (h + 1)];
        for (int y = 0; y < h; y++) {
            int row = 0;
            for (int x = 0; x < w; x++) {
                row += small[y * w + x];
                acc[(y + 1) * (w + 1) + x + 1] = acc[y * (w + 1) + x + 1] + row;
            }
        }
        byte[] tex = new byte[n];
        for (int y = 0; y < h; y++) {
            int y0 = Math.max(0, y - 4), y1 = Math.min(h, y + 5);
            for (int x = 0; x < w; x++) {
                int x0 = Math.max(0, x - 4), x1 = Math.min(w, x + 5);
                int c = acc[y1 * (w + 1) + x1] - acc[y0 * (w + 1) + x1] - acc[y1 * (w + 1) + x0] + acc[y0 * (w + 1) + x0];
                if (c < 8) continue;
                int i = y * w + x;
                if (line[i] != 0) {
                    // centro grueso de una linea: todos los vecinos son linea
                    boolean core = x > 0 && y > 0 && x < w - 1 && y < h - 1;
                    for (int dy = -1; dy <= 1 && core; dy++)
                        for (int dx = -1; dx <= 1; dx++) if (line[i + dy * w + dx] == 0) { core = false; break; }
                    if (core) continue;
                }
                tex[i] = 1;
            }
        }
        return tex;
    }

    private static int[] push(int[] st, int sp, int v) {
        if (sp == st.length) st = java.util.Arrays.copyOf(st, sp * 2);
        st[sp] = v;
        return st;
    }

    // ------------------------------------------------------------------
    // 2-5. zona
    // ------------------------------------------------------------------

    /**
     * Mascara del relleno en 'out' (w*h, debe venir en 0): 255 = pintar.
     * @return null si el toque cae sobre la tinta, sobre una zona protegida o fuera.
     */
    public static Result compute(int[] ref, byte[] line, int w, int h, int sx, int sy, Params p, byte[] out) {
        if (sx < 0 || sy < 0 || sx >= w || sy >= h) return null;
        int seed = sy * w + sx;
        byte[] prot = p.protect;
        if (line[seed] != 0) return null;
        if (prot != null && prot[seed] != 0) return null;
        Result res = new Result();
        res.seedLum = lumAt(ref, seed);

        int[] bb = flood(line, prot, w, h, sx, sy, out);
        int x0 = bb[0], y0 = bb[1], x1 = bb[2], y1 = bb[3];

        // ---- cortes (mismo metodo que el balde normal) ----
        int g = Math.max(0, p.gap);
        int m = g + 3 + Math.max(0, p.expand) + (p.texture != null ? Math.max(0, p.denseReach) : 0);
        int rx0 = Math.max(0, x0 - m), ry0 = Math.max(0, y0 - m);
        int rx1 = Math.min(w, x1 + m), ry1 = Math.min(h, y1 + m);
        int rw = rx1 - rx0, rh = ry1 - ry0;
        byte[] other = null;
        if (g > 0) {
            short[] d = BucketFill.chamfer(out, w, rx0, ry0, rw, rh, (g + 2) * 3);
            int cx = sx - rx0, cy = sy - ry0;
            for (int step = 0; step < 64; step++) {
                int best = d[cy * rw + cx], bx = cx, by = cy;
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    int nx = cx + dx, ny = cy + dy;
                    if (nx < 0 || ny < 0 || nx >= rw || ny >= rh) continue;
                    if (out[(ny + ry0) * w + nx + rx0] == 0) continue;
                    if (d[ny * rw + nx] > best) { best = d[ny * rw + nx]; bx = nx; by = ny; }
                }
                if (bx == cx && by == cy) break;
                cx = bx;
                cy = by;
            }
            int r = Math.min(g, d[cy * rw + cx] / 3 - 1);
            if (r >= 1) {
                res.gapUsed = r;
                other = BucketFill.splitAtGaps(out, w, rx0, ry0, rw, rh, d, r * 3, cx, cy);
            }
        }

        // ---- agujeros: manchitas encerradas por la zona ----
        res.holes = fillHoles(out, other, prot, w, rx0, ry0, rw, rh, p.holeMax);
        if (p.darkHoleLum > 0) res.holes += fillDarkHoles(ref, out, other, prot, w, rx0, ry0, rw, rh, p.darkHoleLum);

        // ---- trama densa (opcional) ----
        if (p.texture != null && p.denseReach > 0)
            res.dense = growTexture(p.texture, prot, other, out, w, h, rx0, ry0, rw, rh, p.denseReach);

        // ---- bajo la linea ----
        if (p.expand > 0) res.expanded = expandUnderLine(ref, line, prot, other, out, w, h, rx0, ry0, rw, rh, p.expand);

        // ---- v8.59: solo lo que esta UNIDO al lugar tocado ----
        // Al cortar por los huecos de las lineas quedaban pedacitos sueltos lejos del toque (la
        // piel aparecia en la ropa, el rojo de la ropa en el pelo). Se queda solo la pieza del toque.
        res.strays = keepSeedPiece(out, w, rx0, ry0, rx1, ry1, sx, sy);

        int minX = w, minY = h, maxX = -1, maxY = -1, area = 0;
        for (int y = ry0; y < ry1; y++) {
            int row = y * w;
            for (int x = rx0; x < rx1; x++) {
                if (out[row + x] == 0) continue;
                area++;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
        if (maxX < 0) return null;
        res.area = area;
        res.bounds = new Rect(minX, minY, maxX + 1, maxY + 1);
        return res;
    }

    /** Borra de out todo lo que no esta unido (8 vecinos) a (sx,sy). @return pixeles borrados */
    static int keepSeedPiece(byte[] out, int w, int x0, int y0, int x1, int y1, int sx, int sy) {
        int rw = x1 - x0, rh = y1 - y0;
        if (rw <= 0 || rh <= 0) return 0;
        byte[] seen = new byte[rw * rh];
        int seed = (sy - y0) * rw + (sx - x0);
        if (seed < 0 || seed >= seen.length || out[sy * w + sx] == 0) return 0;
        int[] q = new int[Math.min(rw * rh, 1 << 16)];
        int qh = 0, qt = 0;
        q[qt++] = seed;
        seen[seed] = 1;
        while (qh != qt) {
            int k = q[qh];
            qh = (qh + 1) % q.length;
            int x = k % rw, y = k / rw;
            for (int dy = -1; dy <= 1; dy++) {
                int ny = y + dy;
                if (ny < 0 || ny >= rh) continue;
                for (int dx = -1; dx <= 1; dx++) {
                    int nx = x + dx;
                    if (nx < 0 || nx >= rw) continue;
                    int nk = ny * rw + nx;
                    if (seen[nk] != 0 || out[(ny + y0) * w + nx + x0] == 0) continue;
                    seen[nk] = 1;
                    if ((qt + 1) % q.length == qh) {             // cola llena: agrandar
                        int[] nq = new int[q.length * 2];
                        int c = 0;
                        for (int i = qh; i != qt; i = (i + 1) % q.length) nq[c++] = q[i];
                        q = nq; qh = 0; qt = c;
                    }
                    q[qt] = nk;
                    qt = (qt + 1) % q.length;
                }
            }
        }
        int removed = 0;
        for (int y = 0; y < rh; y++) {
            int row = (y + y0) * w + x0;
            for (int x = 0; x < rw; x++)
                if (out[row + x] != 0 && seen[y * rw + x] == 0) { out[row + x] = 0; removed++; }
        }
        return removed;
    }

    private static boolean pass(byte[] line, byte[] prot, int i) {
        return line[i] == 0 && (prot == null || prot[i] == 0);
    }

    /** Relleno por lineas de 4 vecinos. @return {x0,y0,x1,y1} exclusivo */
    private static int[] flood(byte[] line, byte[] prot, int w, int h, int sx, int sy, byte[] out) {
        int[] st = new int[1024];
        int sp = 0;
        st[sp++] = sy * w + sx;
        int minX = sx, maxX = sx, minY = sy, maxY = sy;
        while (sp > 0) {
            int i = st[--sp];
            if (out[i] != 0 || !pass(line, prot, i)) continue;
            int y = i / w, row = y * w;
            int a = i - row, b = a;
            while (a > 0 && out[row + a - 1] == 0 && pass(line, prot, row + a - 1)) a--;
            while (b < w - 1 && out[row + b + 1] == 0 && pass(line, prot, row + b + 1)) b++;
            for (int x = a; x <= b; x++) out[row + x] = (byte) 255;
            if (a < minX) minX = a;
            if (b > maxX) maxX = b;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
            for (int dy = -1; dy <= 1; dy += 2) {
                int ny = y + dy;
                if (ny < 0 || ny >= h) continue;
                int nrow = ny * w;
                boolean run = false;
                for (int x = a; x <= b; x++) {
                    int j = nrow + x;
                    boolean ok = out[j] == 0 && pass(line, prot, j);
                    if (ok && !run) {
                        if (sp == st.length) st = java.util.Arrays.copyOf(st, sp * 2);
                        st[sp++] = j;
                    }
                    run = ok;
                }
            }
        }
        return new int[]{minX, minY, maxX + 1, maxY + 1};
    }

    /** Cubre lo NO rellenado que queda totalmente encerrado y es chico. */
    /**
     * v8.66: huecos encerrados (no tocan el borde del recuadro ni el otro lado de un corte) que son
     * casi todo oscuro y no tan grandes (hasta 1/3 de la zona): sombras pintadas, no partes aparte.
     * Los ojos no entran (tienen blanco); la tinta fina tampoco importa (es poca).
     */
    private static int fillDarkHoles(int[] ref, byte[] out, byte[] other, byte[] prot, int w, int rx0, int ry0, int rw, int rh, int darkLum) {
        int n = rw * rh, zoneA = 0;
        for (int y = ry0; y < ry0 + rh; y++) for (int x = rx0; x < rx0 + rw; x++) if (out[y * w + x] != 0) zoneA++;
        if (zoneA < 200) return 0;
        byte[] seen = new byte[n];
        int[] st = new int[1024];
        int[] comp = new int[1024];
        int filled = 0;
        for (int k0 = 0; k0 < n; k0++) {
            if (seen[k0] != 0) continue;
            int i0 = (k0 / rw + ry0) * w + k0 % rw + rx0;
            if (out[i0] != 0) { seen[k0] = 1; continue; }
            int cn = 0, dark = 0, light = 0;
            long lumSum = 0, bSum = 0;
            int bCnt = 0;
            boolean edge = false, protectedHole = false;
            int sp = 0;
            st[sp++] = k0;
            seen[k0] = 1;
            while (sp > 0) {
                int k = st[--sp];
                int x = k % rw, y = k / rw, i = (y + ry0) * w + x + rx0;
                if (cn == comp.length) comp = java.util.Arrays.copyOf(comp, cn * 2);
                comp[cn++] = i;
                if (x == 0 || y == 0 || x == rw - 1 || y == rh - 1 || (other != null && other[k] != 0)) edge = true;
                if (prot != null && prot[i] != 0) protectedHole = true;
                int l = lumAt(ref, i);
                lumSum += l;
                if (l < darkLum) dark++;
                else if (l > 170) light++;
                boolean border = false;
                for (int t = 0; t < 4; t++) {
                    int nx = x + (t == 0 ? -1 : t == 1 ? 1 : 0), ny = y + (t == 2 ? -1 : t == 3 ? 1 : 0);
                    if (nx < 0 || ny < 0 || nx >= rw || ny >= rh) continue;
                    int j = ny * rw + nx;
                    if (out[(ny + ry0) * w + nx + rx0] != 0) { border = true; continue; }
                    if (seen[j] != 0) continue;
                    seen[j] = 1;
                    st = push(st, sp++, j);
                }
                if (border) { bSum += l; bCnt++; }
            }
            if (edge || protectedHole || cn < 30) continue;
            // con contorno de tinta (mas oscuro que su adentro): es otra parte (corbata, cinturon): no
            if (bCnt > 0 && bSum / (float) bCnt < lumSum / (float) cn - 18f) continue;
            if (cn * 3 > zoneA) continue;                       // muy grande: es otra parte
            if (dark < cn * 0.85f || light > cn * 0.03f) continue; // tiene blanco (ojo, boton...): no
            for (int c = 0; c < cn; c++) out[comp[c]] = (byte) 255;
            filled += cn;
        }
        return filled;
    }

    private static int fillHoles(byte[] out, byte[] other, byte[] prot, int w, int rx0, int ry0, int rw, int rh, int holeMax) {
        if (holeMax <= 0) return 0;
        int n = rw * rh;
        byte[] seen = new byte[n];
        int[] st = new int[1024];
        int sp;
        // todo lo que toca el borde del recuadro o el otro lado de un corte queda afuera
        for (int k = 0; k < n; k++) {
            int x = k % rw, y = k / rw;
            boolean edge = x == 0 || y == 0 || x == rw - 1 || y == rh - 1 || (other != null && other[k] != 0);
            if (!edge || seen[k] != 0) continue;
            if (out[(y + ry0) * w + x + rx0] != 0) continue;
            seen[k] = 1;
            sp = 0;
            st[sp++] = k;
            while (sp > 0) {
                int c = st[--sp];
                int cx = c % rw, cy = c / rw;
                for (int t = 0; t < 4; t++) {
                    int nx = cx + (t == 0 ? -1 : t == 1 ? 1 : 0), ny = cy + (t == 2 ? -1 : t == 3 ? 1 : 0);
                    if (nx < 0 || ny < 0 || nx >= rw || ny >= rh) continue;
                    int j = ny * rw + nx;
                    if (seen[j] != 0 || out[(ny + ry0) * w + nx + rx0] != 0) continue;
                    seen[j] = 1;
                    st = push(st, sp++, j);
                }
            }
        }
        int[] comp = new int[holeMax + 1];
        int filled = 0;
        for (int k0 = 0; k0 < n; k0++) {
            if (seen[k0] != 0) continue;
            int i0 = (k0 / rw + ry0) * w + k0 % rw + rx0;
            if (out[i0] != 0) { seen[k0] = 1; continue; }
            int cn = 0;
            boolean protectedHole = false;
            sp = 0;
            st[sp++] = k0;
            seen[k0] = 1;
            while (sp > 0) {
                int k = st[--sp];
                int x = k % rw, y = k / rw, i = (y + ry0) * w + x + rx0;
                if (cn <= holeMax) comp[Math.min(cn, holeMax)] = i;
                cn++;
                if (prot != null && prot[i] != 0) protectedHole = true;
                for (int t = 0; t < 4; t++) {
                    int nx = x + (t == 0 ? -1 : t == 1 ? 1 : 0), ny = y + (t == 2 ? -1 : t == 3 ? 1 : 0);
                    if (nx < 0 || ny < 0 || nx >= rw || ny >= rh) continue;
                    int j = ny * rw + nx;
                    if (seen[j] != 0) continue;
                    if (out[(ny + ry0) * w + nx + rx0] != 0) continue;
                    seen[j] = 1;
                    st = push(st, sp++, j);
                }
            }
            if (!protectedHole && cn <= holeMax) {
                for (int c = 0; c < cn; c++) out[comp[c]] = (byte) 255;
                filled += cn;
            }
        }
        return filled;
    }

    /** Crece por la trama tupida pegada a la zona, hasta 'reach' pasos (4 vecinos). */
    private static int growTexture(byte[] tex, byte[] prot, byte[] other, byte[] out, int w, int h,
                                   int rx0, int ry0, int rw, int rh, int reach) {
        int rx1 = rx0 + rw, ry1 = ry0 + rh;
        int[] front = new int[256], next = new int[256];
        int fn = 0, count = 0;
        for (int y = ry0; y < ry1; y++)
            for (int x = rx0; x < rx1; x++) {
                int i = y * w + x;
                if (out[i] == 0) continue;
                if (fn == front.length) front = java.util.Arrays.copyOf(front, fn * 2);
                front[fn++] = i;
            }
        for (int step = 0; step < reach && fn > 0; step++) {
            int nn = 0;
            for (int f = 0; f < fn; f++) {
                int i = front[f];
                int y = i / w, x = i - y * w;
                for (int t = 0; t < 4; t++) {
                    int xx = x + (t == 0 ? -1 : t == 1 ? 1 : 0), yy = y + (t == 2 ? -1 : t == 3 ? 1 : 0);
                    if (xx < rx0 || yy < ry0 || xx >= rx1 || yy >= ry1) continue;
                    int j = yy * w + xx;
                    if (out[j] != 0 || tex[j] == 0) continue;
                    if (prot != null && prot[j] != 0) continue;
                    if (other != null && other[(yy - ry0) * rw + xx - rx0] != 0) continue;
                    out[j] = (byte) 255;
                    if (nn == next.length) next = java.util.Arrays.copyOf(next, nn * 2);
                    next[nn++] = j;
                }
            }
            count += nn;
            int[] tt = front;
            front = next;
            next = tt;
            fn = nn;
        }
        return count;
    }

    /**
     * El color entra en la tinta pegada a la zona, hasta 'steps' px, solo hacia
     * pixeles iguales o mas oscuros (bajando al centro de la linea). Pasado el
     * centro el brillo vuelve a subir y se detiene: no llega al otro lado.
     */
    private static int expandUnderLine(int[] ref, byte[] line, byte[] prot, byte[] other, byte[] out, int w, int h,
                                       int rx0, int ry0, int rw, int rh, int steps) {
        int rx1 = rx0 + rw, ry1 = ry0 + rh;
        int[] front = new int[256], next = new int[256];
        int fn = 0, count = 0;
        for (int y = ry0; y < ry1; y++) {
            for (int x = rx0; x < rx1; x++) {
                int i = y * w + x;
                if (out[i] == 0) continue;
                boolean border = (x > 0 && out[i - 1] == 0) || (x < w - 1 && out[i + 1] == 0)
                        || (y > 0 && out[i - w] == 0) || (y < h - 1 && out[i + w] == 0);
                if (!border) continue;
                if (fn == front.length) front = java.util.Arrays.copyOf(front, fn * 2);
                front[fn++] = i;
            }
        }
        for (int step = 0; step < steps && fn > 0; step++) {
            int nn = 0;
            for (int f = 0; f < fn; f++) {
                int i = front[f];
                int y = i / w, x = i - y * w;
                int li = lumAt(ref, i);
                for (int t = 0; t < 4; t++) {
                    int xx = x + (t == 0 ? -1 : t == 1 ? 1 : 0), yy = y + (t == 2 ? -1 : t == 3 ? 1 : 0);
                    if (xx < rx0 || yy < ry0 || xx >= rx1 || yy >= ry1) continue;
                    int j = yy * w + xx;
                    if (out[j] != 0 || line[j] == 0) continue;
                    if (prot != null && prot[j] != 0) continue;
                    if (other != null && other[(yy - ry0) * rw + xx - rx0] != 0) continue;
                    if (lumAt(ref, j) > li + 6) continue; // ya paso el centro de la linea
                    out[j] = (byte) 254;
                    if (nn == next.length) next = java.util.Arrays.copyOf(next, nn * 2);
                    next[nn++] = j;
                }
            }
            for (int k = 0; k < nn; k++) out[next[k]] = (byte) 255;
            count += nn;
            int[] t = front;
            front = next;
            next = t;
            fn = nn;
        }
        return count;
    }

    // ------------------------------------------------------------------
    // "Parecidas": otras zonas cerca, de tamano y tono parecido
    // ------------------------------------------------------------------

    /**
     * Busca zonas separadas parecidas a la ya elegida (por ejemplo la otra mano o el
     * cuello cuando ya se relleno la cara). NO pinta nada: devuelve puntos para que la
     * vista previa las muestre y el usuario confirme o quite cada una.
     *
     * @param taken pixeles ya incluidos en la vista previa (w*h, != 0 = tomado)
     * @return lista de {x, y} (un punto dentro de cada zona sugerida), las mas cercanas primero
     */
    public static List<int[]> similarSeeds(int[] ref, byte[] line, byte[] prot, int w, int h, byte[] taken,
                                           Rect near, int refArea, int refLum, int max) {
        List<int[]> outList = new ArrayList<int[]>();
        if (near == null || refArea <= 0) return outList;
        int ext = Math.max(near.width(), near.height());
        int wx0 = Math.max(0, near.left - ext), wy0 = Math.max(0, near.top - ext);
        int wx1 = Math.min(w, near.right + ext), wy1 = Math.min(h, near.bottom + ext);
        int ww = wx1 - wx0, wh = wy1 - wy0;
        if (ww <= 0 || wh <= 0) return outList;
        byte[] seen = new byte[ww * wh];
        int[] st = new int[4096];
        int minArea = Math.max(40, refArea / 10), maxArea = refArea * 4;
        float cx0 = near.exactCenterX(), cy0 = near.exactCenterY();
        List<float[]> found = new ArrayList<float[]>();
        for (int k0 = 0; k0 < seen.length; k0++) {
            if (seen[k0] != 0) continue;
            int x0 = k0 % ww + wx0, y0 = k0 / ww + wy0, i0 = y0 * w + x0;
            if (!pass(line, prot, i0) || (taken != null && taken[i0] != 0)) { seen[k0] = 1; continue; }
            int sp = 0, area = 0;
            long sumL = 0, sx = 0, sy = 0;
            boolean border = false, touchesTaken = false;
            st[sp++] = k0;
            seen[k0] = 1;
            while (sp > 0) {
                int k = st[--sp];
                int x = k % ww, y = k / ww, i = (y + wy0) * w + x + wx0;
                area++;
                sumL += lumAt(ref, i);
                sx += x;
                sy += y;
                if (x == 0 || y == 0 || x == ww - 1 || y == wh - 1) border = true;
                for (int t = 0; t < 4; t++) {
                    int nx = x + (t == 0 ? -1 : t == 1 ? 1 : 0), ny = y + (t == 2 ? -1 : t == 3 ? 1 : 0);
                    if (nx < 0 || ny < 0 || nx >= ww || ny >= wh) continue;
                    int kk = ny * ww + nx;
                    if (seen[kk] != 0) continue;
                    int j = (ny + wy0) * w + nx + wx0;
                    if (taken != null && taken[j] != 0) { touchesTaken = true; continue; }
                    if (!pass(line, prot, j)) continue;
                    seen[kk] = 1;
                    st = push(st, sp++, kk);
                }
            }
            if (border || area < minArea || area > maxArea) continue;
            int meanL = (int) (sumL / area);
            if (Math.abs(meanL - refLum) > 22) continue;
            // un punto de la zona: el primero encontrado (siempre es de la zona)
            float ccx = sx / (float) area + wx0, ccy = sy / (float) area + wy0;
            float dist = (float) Math.hypot(ccx - cx0, ccy - cy0);
            if (touchesTaken) dist *= .5f;
            found.add(new float[]{dist, x0, y0});
        }
        java.util.Collections.sort(found, new java.util.Comparator<float[]>() {
            @Override
            public int compare(float[] a, float[] b) {
                return Float.compare(a[0], b[0]);
            }
        });
        for (int k = 0; k < found.size() && outList.size() < max; k++)
            outList.add(new int[]{(int) found.get(k)[1], (int) found.get(k)[2]});
        return outList;
    }
}
