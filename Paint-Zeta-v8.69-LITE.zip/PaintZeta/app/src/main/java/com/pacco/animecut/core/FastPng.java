package com.pacco.animecut.core;

import java.io.ByteArrayOutputStream;
import java.util.zip.CRC32;
import java.util.zip.Deflater;

/**
 * v8.53: PNG rapido para el guardado automatico. Comprime con nivel 1 (como recomienda Krita para
 * sus bloques) directo desde los pixeles, sin crear un Bitmap recortado de la capa (eso pedia
 * decenas de MB en cada guardado). Es un PNG normal: lo abre cualquier programa y la app igual.
 * Filtro "Sub" por fila: casi el mismo tamano que el PNG de Android, varias veces mas rapido.
 */
public final class FastPng {
    private FastPng() { }

    /** Pixeles ARGB sin premultiplicar; zona (x0, y0, w, h) dentro de una imagen de ancho stride. */
    public static byte[] encode(int[] px, int stride, int x0, int y0, int w, int h) {
        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(1024, w * h / 3));
        try {
            out.write(new byte[]{(byte) 0x89, 'P', 'N', 'G', '\r', '\n', 0x1A, '\n'});
            byte[] ihdr = new byte[13];
            put32(ihdr, 0, w);
            put32(ihdr, 4, h);
            ihdr[8] = 8;      // 8 bits
            ihdr[9] = 6;      // RGBA
            chunk(out, "IHDR", ihdr, 13);
            Deflater d = new Deflater(1);
            byte[] row = new byte[1 + w * 4];
            byte[] buf = new byte[1 << 16];
            ByteArrayOutputStream idat = new ByteArrayOutputStream(Math.max(1024, w * h / 3));
            for (int y = 0; y < h; y++) {
                row[0] = 1;   // Sub
                int o = (y0 + y) * stride + x0;
                int pr = 0, pg = 0, pb = 0, pa = 0;
                for (int x = 0, j = 1; x < w; x++, j += 4) {
                    int c = px[o + x];
                    int a = c >>> 24, r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
                    if (a == 0) { r = g = b = 0; }
                    row[j] = (byte) (r - pr);
                    row[j + 1] = (byte) (g - pg);
                    row[j + 2] = (byte) (b - pb);
                    row[j + 3] = (byte) (a - pa);
                    pr = r; pg = g; pb = b; pa = a;
                }
                d.setInput(row);
                while (!d.needsInput()) {
                    int n = d.deflate(buf);
                    if (n > 0) idat.write(buf, 0, n);
                }
            }
            d.finish();
            while (!d.finished()) {
                int n = d.deflate(buf);
                if (n > 0) idat.write(buf, 0, n);
            }
            d.end();
            byte[] z = idat.toByteArray();
            chunk(out, "IDAT", z, z.length);
            chunk(out, "IEND", new byte[0], 0);
        } catch (java.io.IOException e) {
            return null;
        }
        return out.toByteArray();
    }

    private static void put32(byte[] b, int o, int v) {
        b[o] = (byte) (v >>> 24);
        b[o + 1] = (byte) (v >>> 16);
        b[o + 2] = (byte) (v >>> 8);
        b[o + 3] = (byte) v;
    }

    private static void chunk(ByteArrayOutputStream out, String type, byte[] data, int len) throws java.io.IOException {
        byte[] l = new byte[4];
        put32(l, 0, len);
        out.write(l);
        byte[] t = type.getBytes("US-ASCII");
        out.write(t);
        out.write(data, 0, len);
        CRC32 crc = new CRC32();
        crc.update(t);
        crc.update(data, 0, len);
        put32(l, 0, (int) crc.getValue());
        out.write(l);
    }

    /** Huella rapida de una zona (para no volver a comprimir una capa que no cambio). */
    public static long hash(int[] px) {
        long h = 1125899906842597L;
        int n = px.length;
        for (int i = 0; i < n; i++) h = 31 * h + px[i];
        return h ^ n;
    }
}
