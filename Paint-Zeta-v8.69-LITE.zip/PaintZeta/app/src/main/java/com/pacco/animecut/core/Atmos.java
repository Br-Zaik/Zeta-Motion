package com.pacco.animecut.core;

/**
 * v8.46 "Luz y ambiente": el acabado de las ilustraciones anime de atardecer (cielo degradado,
 * nubes iluminadas por el sol, sol con resplandor, rayos, reflejo en el agua, contraluz en el
 * borde del personaje, luz calida del lado del sol y sombra fria del otro, resplandor, destellos
 * y vineta). Cada efecto sale en SU PROPIA CAPA (se puede ocultar, bajar la opacidad, retocar a
 * mano o animar despues en Zeta Motion / Alight Motion).
 *
 * Java puro: lo usan la app y las pruebas de PC. 'comp' = lo que ya esta dibujado (el personaje,
 * con su transparencia si se le borro el fondo).
 */
public final class Atmos {
    private Atmos() { }

    public static final int SKY = 0, CLOUDS = 1, SUN = 2, RAYS = 3, REFLECT = 4, SPARK = 5,
            SHADE = 6, LIGHT = 7, RIM = 8, BLOOM = 9, VIGNETTE = 10, GROUND = 11, TONE = 12,
            /** v8.55c: luz sobre el PAPEL (manga blanco y negro): tinte calido en Multiplicar. */
            PAPER = 13, N = 14;
    public static final String[] NAMES = {"Cielo", "Nubes", "Sol", "Rayos de luz", "Reflejo en el agua", "Destellos",
            "Sombra de ambiente", "Luz del sol", "Contraluz", "Resplandor", "Vineta", "Sombra en el suelo", "Tono de la escena",
            "Luz sobre el papel"};
    /** Nombre corto para los botones. */
    public static final String[] SHORT = {"Cielo", "Nubes", "Sol", "Rayos", "Reflejo", "Destellos",
            "Sombra", "Luz", "Contraluz", "Brillo", "Vineta", "Suelo", "Tono", "Papel"};
    /** Modo de cada capa (Layer.MODE_*). */
    public static final int[] MODES = {0, 0, 3, 3, 0, 3, 1, 4, 3, 2, 1, 1, 0, 1};
    /** true = va DETRAS del personaje (debajo de sus capas). */
    public static final boolean[] BEHIND = {true, true, true, true, true, true, false, false, false, false, false, true, false, false};
    /** Orden de las capas de abajo hacia arriba. */
    public static final int[] ORDER = {SKY, CLOUDS, SUN, RAYS, REFLECT, SPARK, GROUND, TONE, PAPER, SHADE, LIGHT, RIM, BLOOM, VIGNETTE};
    /** Orden de los botones (lo mas usado primero). */
    public static final int[] BUTTONS = {TONE, LIGHT, SHADE, RIM, GROUND, BLOOM, SKY, CLOUDS, SUN, RAYS, REFLECT, SPARK, VIGNETTE};

    public static final class Preset {
        public final String name;
        public final int top, mid, horizon, sun, warm, cool, cloudLit, cloudShade;

        Preset(String n, int top, int mid, int hor, int sun, int warm, int cool, int lit, int shade) {
            name = n; this.top = top; this.mid = mid; horizon = hor; this.sun = sun; this.warm = warm; this.cool = cool;
            cloudLit = lit; cloudShade = shade;
        }
    }

    public static final Preset[] PRESETS = {
            new Preset("Atardecer", 0xFF28346E, 0xFFEE6F86, 0xFFFFA048, 0xFFFFF2C6, 0xFFFF9A50, 0xFF4E3E86, 0xFFFFB98E, 0xFF5A3A78),
            new Preset("Dorado", 0xFF4A86CC, 0xFFF2C08E, 0xFFFFD27A, 0xFFFFF8DC, 0xFFFFC25A, 0xFF5E64A2, 0xFFFFE6B8, 0xFF8E6A92),
            // v8.61: la luz de la luna es plateada (antes celeste fuerte: en Superponer volvia celeste la piel)
            new Preset("Noche", 0xFF0B1330, 0xFF2B3A70, 0xFF6C5C9E, 0xFFEAF1FF, 0xFFD6DDF2, 0xFF1C2044, 0xFF8C9ED6, 0xFF262B52),
            new Preset("Dia", 0xFF2F86E2, 0xFF86C4F2, 0xFFDDF1FA, 0xFFFFFFF2, 0xFFFFF2CF, 0xFF7392C4, 0xFFFFFFFF, 0xFFA6B6D8)
    };

    public static final class Params {
        public Preset preset = PRESETS[0];
        /** Sol (0..1 del ancho / alto). */
        public float sunX = 0.5f, sunY = 0.42f;
        /** Linea del horizonte (0..1 del alto): debajo va el agua del reflejo. */
        public float horizon = 0.62f;
        /** Fuerza de cada efecto 0..100 (0 = apagado). */
        public final int[] amount = new int[N];
        public long seed = 7;
        /** v8.47: foto de fondo (null = sin foto). Su luz y sus colores mandan en "Escena". */
        public int[] scene;
        /** v8.47: blanco y negro: todo en grises (manga), solo luz y sombra. */
        public boolean mono;

        public Params() {
            int[] def = {100, 85, 80, 40, 0, 35, 70, 45, 80, 25, 35, 0, 0, 0};
            System.arraycopy(def, 0, amount, 0, N);
        }

        public Params copy() {
            Params q = new Params();
            q.preset = preset; q.sunX = sunX; q.sunY = sunY; q.horizon = horizon; q.seed = seed;
            q.scene = scene; q.mono = mono;
            System.arraycopy(amount, 0, q.amount, 0, N);
            return q;
        }
    }

    public interface Progress { boolean step(int pct); }

    /**
     * v8.55c: dibujo casi solo blanco y negro (papel de manga): pocos grises medios. Ahi Superponer y
     * Pantalla no se notan.
     */
    static boolean paperLike(int[] comp, float[] sil) {
        int step = Math.max(1, comp.length / 30000), tot = 0, mid = 0, colored = 0;
        for (int i = 0; i < comp.length; i += step) {
            if (sil[i] < 0.5f) continue;
            int c = comp[i];
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            int l = (r * 77 + g * 151 + b * 28) >> 8;
            tot++;
            if (l > 45 && l < 205) mid++;
            if (Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b)) > 40) colored++;
        }
        return tot > 0 && mid * 100 < tot * 35 && colored * 100 < tot * 10;
    }

    /** true si lo dibujado tiene partes transparentes (si no, el cielo no se ve detras). */
    public static boolean hasTransparency(int[] comp) {
        int step = Math.max(1, comp.length / 20000);
        for (int i = 0; i < comp.length; i += step) if ((comp[i] >>> 24) < 128) return true;
        return false;
    }

    /** Devuelve una capa por efecto (null = apagado). */
    public static int[][] render(int[] comp, int W, int H, Params p, Progress pr) {
        int n = W * H;
        Preset c = p.mono ? gray(p.preset) : p.preset;
        // escena entera sin recortar: no hay "personaje contra el cielo"; la luz manda y la sombra es suave
        boolean opaque = !hasTransparency(comp);
        int[][] out = new int[N][];
        float[] sil = new float[n];
        for (int i = 0; i < n; i++) sil[i] = (comp[i] >>> 24) / 255f;
        float sx = p.sunX * W, sy = p.sunY * H, diag = (float) Math.hypot(W, H), mn = Math.min(W, H);
        float sunR = mn * 0.06f;
        int hY = Math.max(1, Math.min(H, Math.round(p.horizon * H)));
        java.util.Random rnd = new java.util.Random(p.seed);
        // ---------- fondo (detras): se arma tambien un "fondo completo" para el reflejo y el brillo
        int[] back = new int[n];
        if (on(p, SKY)) {
            int[] sky = new int[n];
            for (int y = 0; y < H; y++) {
                int row;
                if (y < hY) {
                    float t = y / (float) hY;
                    row = t < 0.55f ? mix(c.top, c.mid, ease(t / 0.55f)) : mix(c.mid, c.horizon, ease((t - 0.55f) / 0.45f));
                } else {
                    float t = (y - hY) / (float) Math.max(1, H - hY);
                    row = mix(mix(c.horizon, c.mid, 0.35f), c.cool, ease(t) * 0.8f);
                }
                for (int x = 0; x < W; x++) {
                    float d = (float) Math.hypot(x - sx, (y - sy) * 1.3f) / diag;
                    float g = (float) Math.exp(-d * d / 0.035f) * 0.5f;
                    sky[y * W + x] = mix(row, c.sun, g);
                }
            }
            out[SKY] = withAlpha(sky, p.amount[SKY]);
            System.arraycopy(sky, 0, back, 0, n);
        } else {
            java.util.Arrays.fill(back, c.horizon);
        }
        if (pr != null && !pr.step(15)) return null;
        if (on(p, CLOUDS)) {
            int[] cl = new int[n];
            float sxN = W / 2.2f, syN = mn / 7f;
            int ox = rnd.nextInt(1000), oy = rnd.nextInt(1000);
            float ux = sx, uy = sy;
            for (int y = 0; y < Math.min(H, hY + 2); y++) {
                float band = 1f - ease((y / (float) hY - 0.15f) / 0.85f) * 0.65f;     // menos nubes cerca del horizonte
                for (int x = 0; x < W; x++) {
                    float nx = x / sxN + ox, ny = y / syN + oy;
                    float v = fbm(nx, ny);
                    float dens = ease((v - 0.5f) / 0.09f) * band;
                    if (dens <= 0.01f) continue;
                    // luz: la nube es mas delgada hacia el sol -> borde iluminado
                    float dx = ux - x, dy = uy - y, dl = (float) Math.hypot(dx, dy) + 1e-3f;
                    float v2 = fbm(nx + dx / dl * 0.18f, ny + dy / dl * 0.18f * sxN / syN);
                    float lit = Math.max(0f, Math.min(1f, 0.45f + (v - v2) * 11f));
                    float near = (float) Math.exp(-(dl / diag) * (dl / diag) / 0.08f);
                    lit = Math.min(1f, lit * 0.8f + near * 0.5f);
                    int col = mix(c.cloudShade, c.cloudLit, lit);
                    col = mix(col, c.sun, near * 0.35f);
                    int a = Math.round(255 * Math.min(1f, dens) * p.amount[CLOUDS] / 100f);
                    cl[y * W + x] = (a << 24) | (col & 0xFFFFFF);
                    back[y * W + x] = over(back[y * W + x], cl[y * W + x]);
                }
            }
            out[CLOUDS] = cl;
        }
        if (pr != null && !pr.step(35)) return null;
        if (on(p, SUN)) {
            int[] s = new int[n];
            float a0 = p.amount[SUN] / 100f;
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++) {
                    float d = (float) Math.hypot(x - sx, y - sy);
                    float disc = Math.max(0f, Math.min(1f, (sunR - d) / 2f + 0.5f));
                    float g1 = (float) Math.exp(-(d / (sunR * 2.2f)) * (d / (sunR * 2.2f)));
                    float g2 = (float) Math.exp(-d / (sunR * 5f)) * 0.3f;
                    float v = Math.min(1f, disc + g1 * 0.7f + g2) * a0;
                    if (v < 0.004f) continue;
                    int col = disc > 0.5f ? c.sun : mix(c.warm, c.sun, g1);
                    s[y * W + x] = (Math.round(255 * v) << 24) | (col & 0xFFFFFF);
                    back[y * W + x] = add(back[y * W + x], col, v);
                }
            out[SUN] = s;
        }
        if (on(p, RAYS)) {
            int[] r = new int[n];
            int k = 9;
            float[] fr = new float[k], ph = new float[k], am = new float[k];
            for (int i = 0; i < k; i++) { fr[i] = 3 + rnd.nextInt(14); ph[i] = rnd.nextFloat() * 6.28f; am[i] = 0.4f + rnd.nextFloat(); }
            float a0 = p.amount[RAYS] / 100f;
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++) {
                    float dx = x - sx, dy = y - sy, d = (float) Math.hypot(dx, dy);
                    if (d < sunR * 0.8f) continue;
                    float th = (float) Math.atan2(dy, dx), s = 0;
                    for (int i = 0; i < k; i++) s += am[i] * (float) Math.sin(th * fr[i] + ph[i]);
                    s = Math.max(0f, s / k * 2.2f);
                    s = s * s * s;
                    float fall = (float) Math.exp(-d / (diag * 0.45f)) * ease((d - sunR) / (sunR * 2f));
                    float v = Math.min(1f, s * fall) * a0 * 0.6f;
                    if (v < 0.004f) continue;
                    r[y * W + x] = (Math.round(255 * v) << 24) | (c.warm & 0xFFFFFF);
                    back[y * W + x] = add(back[y * W + x], c.warm, v);
                }
            out[RAYS] = r;
        }
        if (pr != null && !pr.step(50)) return null;
        if (on(p, SPARK)) {
            int[] sp = new int[n];
            int count = Math.round(6 + 40 * p.amount[SPARK] / 100f);
            for (int s = 0; s < count; s++) {
                int x = Math.min(W - 1, (int) (rnd.nextFloat() * W)), y = Math.min(H - 1, (int) (rnd.nextFloat() * hY * 0.85f));
                if (sil[y * W + x] > 0.1f) { rnd.nextFloat(); rnd.nextFloat(); rnd.nextFloat(); continue; }
                float big = rnd.nextFloat();
                float len = mn * (0.006f + rnd.nextFloat() * (big < 0.2f ? 0.03f : 0.012f));
                float bright = 0.6f + rnd.nextFloat() * 0.4f;
                star(sp, W, H, x, y, len, c.sun, bright);
            }
            out[SPARK] = sp;
            for (int i = 0; i < n; i++) if (sp[i] != 0) back[i] = add(back[i], sp[i], (sp[i] >>> 24) / 255f);
        }
        // fondo + personaje (para reflejo y brillo)
        int[] full = new int[n];
        for (int i = 0; i < n; i++) full[i] = over(back[i] | 0xFF000000, comp[i]);
        if (on(p, REFLECT) && hY < H - 2) {
            int[] rf = new int[n];
            float a0 = p.amount[REFLECT] / 100f;
            int footY = -1;
            for (int y = H - 1; y >= 0 && footY < 0; y--)
                for (int x = 0; x < W; x += 2) if (sil[y * W + x] > 0.5f) { footY = y; break; }
            if (footY < hY) footY = H;
            for (int y = hY; y < H; y++) {
                float t = (y - hY) / (float) Math.max(1, H - hY);
                float amp = mn * 0.0022f * (0.3f + t * 1.6f);
                float rowWob = (float) Math.sin(y * 0.09f + 1.7f) * amp * 0.6f;
                for (int x = 0; x < W; x++) {
                    float wob = (float) Math.sin(y * 0.13f + x * 0.006f) * amp + rowWob;
                    int sxr = Math.max(0, Math.min(W - 1, Math.round(x + wob)));
                    int syr = Math.max(0, Math.min(hY - 1, 2 * hY - y));
                    int col = back[syr * W + sxr] | 0xFF000000;
                    if (footY < H - 4 && y > footY) {   // el personaje se refleja desde sus pies
                        int syc = 2 * footY - y;
                        if (syc >= 0) {
                            int cc = comp[syc * W + sxr];
                            if ((cc >>> 24) > 0) col = over(col, cc);
                        }
                    }
                    col = mix(col, c.cool, 0.18f + 0.25f * t);
                    float a = a0 * (0.85f - 0.4f * t);
                    rf[y * W + x] = (Math.round(255 * Math.max(0f, a)) << 24) | (col & 0xFFFFFF);
                }
            }
            out[REFLECT] = rf;
        }
        if (pr != null && !pr.step(65)) return null;
        if (on(p, GROUND)) out[GROUND] = ground(sil, W, H, sx, sy, c, p.amount[GROUND] / 100f);
        if (on(p, TONE)) out[TONE] = tone(comp, sil, W, H, p.scene, c, p.mono, p.amount[TONE] / 100f);
        // ---------- sobre el personaje
        if (on(p, SHADE)) {
            int[] sh = new int[n];
            float a0 = p.amount[SHADE] / 100f;
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++) {
                    int i = y * W + x;
                    if (sil[i] <= 0f) continue;
                    float d = (float) Math.hypot(x - sx, y - sy) / diag;
                    float t = opaque ? 0.1f + 0.55f * ease((d - 0.15f) / 0.7f)
                            : 0.6f + 0.4f * ease((d - 0.05f) / 0.6f);             // contraluz: el personaje mas oscuro, mas lejos del sol mas
                    int col = mix(0xFFFFFFFF, c.cool, Math.min(1f, t * a0));
                    sh[i] = (Math.round(255 * sil[i]) << 24) | (col & 0xFFFFFF);
                }
            out[SHADE] = sh;
        }
        if (on(p, LIGHT)) {
            int[] li = new int[n];
            // Superponer con el color de la luz bien vivo: tine y da brillo sin lavar
            int warmSat = p.mono ? 0xFFF0F0F0 : saturate(c.warm);
            float a0 = p.amount[LIGHT] / 100f;
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++) {
                    int i = y * W + x;
                    if (sil[i] <= 0f) continue;
                    float d = (float) Math.hypot(x - sx, y - sy) / diag;
                    float w = (float) Math.exp(-d * d / (opaque ? 0.25f : 0.09f));
                    float v = sil[i] * (0.25f + 0.75f * w) * a0 * (opaque ? 0.95f : 0.85f);
                    if (v < 0.004f) continue;
                    li[i] = (Math.round(255 * v) << 24) | (warmSat & 0xFFFFFF);
                }
            out[LIGHT] = li;
            // v8.55c: en un manga blanco y negro Superponer no cambia el blanco ni el negro: la luz casi
            // no se veia. Sobre el papel claro se agrega un tinte del color de la luz (Multiplicar),
            // fuerte cerca del sol y nada lejos: asi "Luz" se nota y sigue sin tapar la tinta.
            if (!p.mono && paperLike(comp, sil)) {
                int[] pt = new int[n];
                int tint = saturate(c.warm);
                for (int y = 0; y < H; y++)
                    for (int x = 0; x < W; x++) {
                        int i = y * W + x;
                        if (sil[i] <= 0f) continue;
                        float d = (float) Math.hypot(x - sx, y - sy) / diag;
                        float w = (float) Math.exp(-d * d / (opaque ? 0.22f : 0.09f));
                        float v = sil[i] * w * a0 * 0.85f;
                        if (v < 0.004f) continue;
                        pt[i] = (Math.round(255 * Math.min(1f, v)) << 24) | (tint & 0xFFFFFF);
                    }
                out[PAPER] = pt;
            }
        }
        if (pr != null && !pr.step(75)) return null;
        if (on(p, RIM)) {
            float[] rim = new float[n];
            float wR = Math.max(2f, mn / 140f);
            float a0 = p.amount[RIM] / 100f;
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++) {
                    int i = y * W + x;
                    if (sil[i] < 0.5f) continue;
                    float dx = sx - x, dy = sy - y, dl = (float) Math.hypot(dx, dy) + 1e-3f;
                    dx /= dl; dy /= dl;
                    // del lado del sol: borde que da al sol
                    float s1 = 1f - silAt(sil, W, H, x + dx * wR, y + dy * wR);
                    float s2 = 1f - silAt(sil, W, H, x + dx * wR * 0.5f, y + dy * wR * 0.5f);
                    float side = Math.max(s1, s2);
                    // contraluz: un poco en todo el contorno
                    float ring = 0f;
                    for (int k = 0; k < 8; k++) {
                        double an = k * Math.PI / 4;
                        ring = Math.max(ring, 1f - silAt(sil, W, H, x + (float) Math.cos(an) * wR * 0.6f, y + (float) Math.sin(an) * wR * 0.6f));
                    }
                    rim[i] = Math.min(1f, side + ring * 0.35f) * sil[i];
                }
            ZoneTone.box(rim, W, H, 1);
            int[] rr = new int[n];
            int col = mix(c.warm, c.sun, 0.55f);
            for (int i = 0; i < n; i++) {
                float v = Math.min(1f, rim[i] * 1.6f) * a0 * sil[i];
                if (v < 0.004f) continue;
                rr[i] = (Math.round(255 * v) << 24) | (col & 0xFFFFFF);
            }
            out[RIM] = rr;
        }
        if (pr != null && !pr.step(85)) return null;
        if (on(p, BLOOM)) {
            // brillo: lo muy claro se difumina (a media resolucion: rapido)
            int bw = Math.max(1, W / 2), bh = Math.max(1, H / 2);
            float[] rr = new float[bw * bh], gg = new float[bw * bh], bb = new float[bw * bh];
            for (int y = 0; y < bh; y++)
                for (int x = 0; x < bw; x++) {
                    int col = full[Math.min(H - 1, y * 2) * W + Math.min(W - 1, x * 2)];
                    if (out[SUN] != null) col = add(col, out[SUN][Math.min(H - 1, y * 2) * W + Math.min(W - 1, x * 2)], 1f);
                    float l = ZoneTone.lum(col) / 255f;
                    float k = ease((l - 0.80f) / 0.18f);
                    int j = y * bw + x;
                    rr[j] = ((col >> 16) & 255) * k; gg[j] = ((col >> 8) & 255) * k; bb[j] = (col & 255) * k;
                }
            int r = Math.max(2, (int) (mn / 2 / 40));
            for (int pass = 0; pass < 3; pass++) { ZoneTone.box(rr, bw, bh, r); ZoneTone.box(gg, bw, bh, r); ZoneTone.box(bb, bw, bh, r); }
            int[] bl = new int[n];
            float a0 = p.amount[BLOOM] / 100f;
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++) {
                    int j = Math.min(bh - 1, y / 2) * bw + Math.min(bw - 1, x / 2);
                    float R = rr[j], G = gg[j], B = bb[j], m = Math.max(R, Math.max(G, B));
                    if (m < 2f) continue;
                    float v = Math.min(1f, m / 255f * 1.2f) * a0 * 0.7f;
                    int col = 0xFF000000 | (clamp((int) (R * 255 / m)) << 16) | (clamp((int) (G * 255 / m)) << 8) | clamp((int) (B * 255 / m));
                    bl[y * W + x] = (Math.round(255 * v) << 24) | (col & 0xFFFFFF);
                }
            out[BLOOM] = bl;
        }
        if (on(p, VIGNETTE)) {
            int[] vg = new int[n];
            float a0 = p.amount[VIGNETTE] / 100f;
            int col = mix(c.cool, 0xFF000000, 0.25f);
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++) {
                    float u = (x - W / 2f) / (W / 2f), v = (y - H / 2f) / (H / 2f);
                    float r = (float) Math.sqrt(u * u + v * v) / 1.414f;
                    float t = ease((r - 0.45f) / 0.55f) * a0;
                    if (t < 0.004f) continue;
                    vg[y * W + x] = (Math.round(255 * t) << 24) | (col & 0xFFFFFF);
                }
            out[VIGNETTE] = vg;
        }
        if (pr != null) pr.step(100);
        return out;
    }

    // ------------------------------------------------------------------ v8.51: simple y en UNA capa
    /** Situacion de la imagen: 0 = recortada (fondo transparente), 1 = escena entera, 2 = con foto de fondo. */
    public static int situation(int[] comp, int[] scene) {
        if (scene != null) return 2;
        return hasTransparency(comp) ? 0 : 1;
    }

    /**
     * v8.51: 3 perillas en vez de 13 efectos. fondo/luz/sombra/reflejo 0..100. Lo que no aplica a la
     * situacion queda en 0 (en una escena entera no hay cielo detras que se vea: solo luz y sombra).
     */
    public static void setSimple(Params p, int sit, int fondo, int luz, int sombra, int reflejo) {
        java.util.Arrays.fill(p.amount, 0);
        float f = fondo / 100f, l = luz / 100f, s = sombra / 100f;
        if (sit == 0) {
            if (fondo > 0) {
                p.amount[SKY] = 100;
                p.amount[CLOUDS] = Math.round(85 * f);
                p.amount[SUN] = Math.round(80 * f);
                p.amount[RAYS] = Math.round(40 * f);
                p.amount[SPARK] = Math.round(35 * f);
            }
            p.amount[REFLECT] = reflejo;
            p.amount[LIGHT] = Math.round(45 * l);
            p.amount[RIM] = Math.round(85 * l);
            p.amount[BLOOM] = Math.round(25 * l);
            p.amount[SHADE] = Math.round(70 * s);
            p.amount[VIGNETTE] = Math.round(35 * s);
            p.amount[GROUND] = Math.round(60 * s);
        } else if (sit == 2) {
            p.amount[TONE] = Math.round(75 * l);
            p.amount[LIGHT] = Math.round(60 * l);
            p.amount[RIM] = Math.round(75 * l);
            p.amount[BLOOM] = Math.round(25 * l);
            p.amount[SHADE] = Math.round(45 * s);
            p.amount[VIGNETTE] = Math.round(25 * s);
            p.amount[GROUND] = Math.round(65 * s);
        } else {
            // escena entera (manga o dibujo ya pintado): luz calida del lado del sol y sombra fria
            // del otro, brillo suave y bordes. Sin "tono" (lo volvia todo gris) ni contraluz.
            p.amount[LIGHT] = Math.round(70 * l);
            p.amount[BLOOM] = Math.round(30 * l);
            p.amount[SHADE] = Math.round(45 * s);
            p.amount[VIGNETTE] = Math.round(40 * s);
        }
    }

    /** Mezcla un pixel con un modo (Layer.MODE_*): 0 Normal, 1 Multiplicar, 2 Pantalla, 3 Anadir, 4 Superponer. */
    public static int blendPx(int dst, int src, int mode) {
        int sa = src >>> 24;
        if (sa == 0) return dst;
        int da = dst >>> 24;
        if (da == 0) return mode == 1 ? 0 : src;
        float t = sa / 255f;
        int dr = (dst >> 16) & 255, dg = (dst >> 8) & 255, db = dst & 255, sr = (src >> 16) & 255, sg = (src >> 8) & 255, sb = src & 255;
        int r, g, b;
        switch (mode) {
            case 1: r = dr * sr / 255; g = dg * sg / 255; b = db * sb / 255; break;
            case 2: r = 255 - (255 - dr) * (255 - sr) / 255; g = 255 - (255 - dg) * (255 - sg) / 255; b = 255 - (255 - db) * (255 - sb) / 255; break;
            case 3: r = Math.min(255, dr + sr); g = Math.min(255, dg + sg); b = Math.min(255, db + sb); break;
            case 4:
                r = dr < 128 ? 2 * dr * sr / 255 : 255 - 2 * (255 - dr) * (255 - sr) / 255;
                g = dg < 128 ? 2 * dg * sg / 255 : 255 - 2 * (255 - dg) * (255 - sg) / 255;
                b = db < 128 ? 2 * db * sb / 255 : 255 - 2 * (255 - db) * (255 - sb) / 255;
                break;
            default: r = sr; g = sg; b = sb;
        }
        int oa = Math.max(da, sa);
        return (oa << 24) | (Math.round(dr + (r - dr) * t) << 16) | (Math.round(dg + (g - dg) * t) << 8) | Math.round(db + (b - db) * t);
    }

    // ------------------------------------------------------------------ v8.53: capas SOLO de luz
    /**
     * Las capas que quedan en la obra. NINGUNA tiene una copia del dibujo (antes ✦ Luz era el dibujo
     * entero con la luz encima: tapaba las capas de abajo y se veia mas borroso):
     *  FONDO  (Normal, debajo del personaje): cielo, nubes, sol, rayos, reflejo, sombra en el suelo;
     *  TONO   (Normal): solo con foto de fondo, el color del personaje acercado al de la foto;
     *  SOMBRA (Multiplicar): sombra de ambiente y vineta;
     *  LUZ    (Superponer): luz del sol; como en Ibis, aclara sin lavar los negros;
     *  BRILLO (Pantalla): contraluz y resplandor (color + transparencia = intensidad).
     */
    public static final int G_FONDO = 0, G_TONO = 1, G_SOMBRA = 2, G_LUZ = 3, G_BRILLO = 4, G_N = 5;
    public static final String[] G_NAMES = {"✦ Fondo", "✦ Tono", "✦ Sombra", "✦ Luz", "✦ Brillo"};
    public static final int[] G_MODES = {0, 0, 1, 4, 2};

    public static int[][] groups(int[][] fx, int W, int H) {
        int n = W * H;
        int[][] g = new int[G_N][];
        // fondo: lo de atras en orden, empezando transparente
        for (int k : ORDER) {
            if (fx[k] == null || !BEHIND[k]) continue;
            if (g[G_FONDO] == null) g[G_FONDO] = new int[n];
            int[] o = g[G_FONDO], L = fx[k];
            for (int i = 0; i < n; i++) {
                int c = L[i];
                if ((c >>> 24) == 0) continue;
                if ((o[i] >>> 24) == 0 && MODES[k] == 1) {
                    // sombra sobre nada (la foto esta en su propia capa): oscuro con transparencia
                    int a = c >>> 24, l = ZoneTone.lum(c);
                    int na = a * (255 - l) / 255;
                    if (na <= 0) continue;
                    int r = ((c >> 16) & 255) * ((c >> 16) & 255) / 255 / 2, gg = ((c >> 8) & 255) * ((c >> 8) & 255) / 255 / 2,
                            b = (c & 255) * (c & 255) / 255 / 2;
                    o[i] = (na << 24) | (r << 16) | (gg << 8) | b;
                } else o[i] = blendPx(o[i], c, MODES[k]);
            }
        }
        if (fx[TONE] != null) g[G_TONO] = fx[TONE];
        // sombra: los Multiplicar se juntan multiplicando sus factores (exacto)
        boolean anyS = false, anyL = false;
        for (int k : ORDER) if (fx[k] != null && !BEHIND[k]) {
            if (MODES[k] == 1) anyS = true;
            else if (MODES[k] == 4) g[G_LUZ] = g[G_LUZ] == null ? fx[k] : g[G_LUZ];
            else if (MODES[k] != 0) anyL = true;
        }
        if (anyS) {
            int[] o = new int[n];
            for (int i = 0; i < n; i++) {
                float fr = 1f, fg = 1f, fb = 1f;
                for (int k : ORDER) {
                    if (fx[k] == null || BEHIND[k] || MODES[k] != 1) continue;
                    int c = fx[k][i];
                    float a = (c >>> 24) / 255f;
                    if (a <= 0f) continue;
                    fr *= 1f - a * (1f - ((c >> 16) & 255) / 255f);
                    fg *= 1f - a * (1f - ((c >> 8) & 255) / 255f);
                    fb *= 1f - a * (1f - (c & 255) / 255f);
                }
                float A = Math.max(1f - fr, Math.max(1f - fg, 1f - fb));
                if (A < 1f / 255f) continue;
                int r = clamp(Math.round(255f * (1f - (1f - fr) / A))), gg = clamp(Math.round(255f * (1f - (1f - fg) / A))),
                        b = clamp(Math.round(255f * (1f - (1f - fb) / A)));
                o[i] = (clamp(Math.round(A * 255f)) << 24) | (r << 16) | (gg << 8) | b;
            }
            g[G_SOMBRA] = o;
        }
        // brillo: Pantalla y Anadir se juntan como Pantalla (1-(1-a)(1-b), exacto para Pantalla)
        if (anyL) {
            int[] o = new int[n];
            for (int i = 0; i < n; i++) {
                float tr = 0f, tg = 0f, tb = 0f;
                for (int k : ORDER) {
                    if (fx[k] == null || BEHIND[k] || MODES[k] == 1 || MODES[k] == 0 || MODES[k] == 4) continue;
                    int c = fx[k][i];
                    float a = (c >>> 24) / 255f;
                    if (a <= 0f) continue;
                    tr = 1f - (1f - tr) * (1f - a * ((c >> 16) & 255) / 255f);
                    tg = 1f - (1f - tg) * (1f - a * ((c >> 8) & 255) / 255f);
                    tb = 1f - (1f - tb) * (1f - a * (c & 255) / 255f);
                }
                float A = Math.max(tr, Math.max(tg, tb));
                if (A < 1f / 255f) continue;
                o[i] = (clamp(Math.round(A * 255f)) << 24) | (clamp(Math.round(tr / A * 255f)) << 16)
                        | (clamp(Math.round(tg / A * 255f)) << 8) | clamp(Math.round(tb / A * 255f));
            }
            g[G_BRILLO] = o;
        }
        return g;
    }

    /** Como se ve: foto, fondo, dibujo, tono, sombra y luz, con los modos de la app (para la vista previa). */
    public static int[] composeGroups(int[] comp, int[] scene, int[][] g, int W, int H) {
        int n = W * H;
        int[] o = scene != null && scene.length == n ? scene.clone() : new int[n];
        for (int k = 0; k < G_N; k++) {
            if (k == G_TONO) layerOver(o, comp, 0);
            if (g[k] != null) layerOver(o, g[k], G_MODES[k]);
        }
        return o;
    }

    /** Modo de capa de la app para G_MODES. */
    public static int layerMode(int m) {
        return m == 1 ? Layer.MODE_MULTIPLY : m == 2 ? Layer.MODE_SCREEN : m == 4 ? Layer.MODE_OVERLAY : Layer.MODE_NORMAL;
    }

    private static void layerOver(int[] o, int[] L, int mode) {
        int md = layerMode(mode);
        for (int i = 0; i < o.length; i++) {
            int c = L[i];
            int sa = c >>> 24;
            if (sa == 0) continue;
            o[i] = Project.blend(o[i], c, md, sa);
        }
    }

    /** El resultado final en UNA imagen: foto (si hay), lo de atras, el dibujo y la luz encima. */
    public static int[] compose(int[] comp, int[][] fx, int W, int H, int[] scene) {
        int n = W * H;
        int[] o = scene != null && scene.length == n ? scene.clone() : new int[n];
        for (int k : ORDER) {
            if (fx[k] == null || !BEHIND[k]) continue;
            int[] L = fx[k];
            for (int i = 0; i < n; i++) o[i] = blendPx(o[i], L[i], MODES[k]);
        }
        for (int i = 0; i < n; i++) o[i] = blendPx(o[i], comp[i], 0);
        for (int k : ORDER) {
            if (fx[k] == null || BEHIND[k]) continue;
            int[] L = fx[k];
            for (int i = 0; i < n; i++) o[i] = blendPx(o[i], L[i], MODES[k]);
        }
        return o;
    }

    // ------------------------------------------------------------------ v8.47: personaje en una foto
    /**
     * Lee la foto de fondo: donde esta la luz (lo mas brillante: farol, luna), de que color es,
     * y el color del ambiente. Devuelve el ambiente "Escena" y pone en pos[] la luz (0..1).
     */
    public static Preset analyze(int[] bg, int W, int H, float[] pos) {
        int step = Math.max(1, (int) Math.sqrt((double) W * H / 60000.0));
        int[] hist = new int[256];
        int cnt = 0;
        for (int y = 0; y < H; y += step) for (int x = 0; x < W; x += step) { hist[ZoneTone.lum(bg[y * W + x])]++; cnt++; }
        int thr = 255, acc = 0;
        while (thr > 0 && acc + hist[thr] < Math.max(1, cnt / 300)) acc += hist[thr--];
        thr = Math.max(thr, 60);
        double sx = 0, sy = 0, sw = 0, lr = 0, lg = 0, lb = 0, lw = 0;
        double ar = 0, ag = 0, ab = 0, an = 0, tr = 0, tg = 0, tb = 0, tn = 0, hr = 0, hg = 0, hb = 0, hn = 0;
        for (int y = 0; y < H; y += step)
            for (int x = 0; x < W; x += step) {
                int c = bg[y * W + x], l = ZoneTone.lum(c);
                int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                if (l >= thr) { double w = l - thr + 1; sx += x * w; sy += y * w; sw += w; }
                if (l >= thr - 70 && l < thr) {   // el halo (no el centro casi blanco) dice el color de la luz
                    double w = 1 + (Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b)));
                    lr += r * w; lg += g * w; lb += b * w; lw += w;
                }
                ar += r; ag += g; ab += b; an++;
                if (y < H / 5) { tr += r; tg += g; tb += b; tn++; }
                if (y > H * 0.5f && y < H * 0.7f) { hr += r; hg += g; hb += b; hn++; }
            }
        int light = lw > 0 ? rgb(lr / lw, lg / lw, lb / lw) : 0xFFFFF0D8;
        // la luz con su color mas vivo (el centro de un farol sale casi blanco)
        light = Atmos.mix(light, saturate(light), 0.6f);
        if (pos != null) { pos[0] = sw > 0 ? (float) (sx / sw / W) : 0.5f; pos[1] = sw > 0 ? (float) (sy / sw / H) : 0.15f; }
        int amb = rgb(ar / an, ag / an, ab / an);
        int top = tn > 0 ? rgb(tr / tn, tg / tn, tb / tn) : amb, hor = hn > 0 ? rgb(hr / hn, hg / hn, hb / hn) : amb;
        int cool = Atmos.mix(amb, 0xFF101830, 0.35f);
        return new Preset("Escena", top, amb, hor, Atmos.mix(light, 0xFFFFFFFF, 0.4f), light, cool, light, cool);
    }

    private static int rgb(double r, double g, double b) {
        return 0xFF000000 | (clamp((int) Math.round(r)) << 16) | (clamp((int) Math.round(g)) << 8) | clamp((int) Math.round(b));
    }

    private static int saturate(int c) {
        float[] k = ZoneTone.oklab(c);
        float C = (float) Math.hypot(k[1], k[2]);
        if (C < 1e-4f) return c;
        float f = Math.min(3f, 0.12f / C);
        return ZoneTone.fromOklab(Math.max(0.65f, k[0]), k[1] * f, k[2] * f);
    }

    private static Preset gray(Preset p) {
        return new Preset(p.name, g(p.top), g(p.mid), g(p.horizon), g(p.sun), g(p.warm), g(p.cool), g(p.cloudLit), g(p.cloudShade));
    }

    private static int g(int c) {
        int l = ZoneTone.lum(c);
        return 0xFF000000 | (l << 16) | (l << 8) | l;
    }

    /**
     * Tono de la escena: los colores y la luz del personaje se acercan a los de la foto (como la
     * transferencia de color de Reinhard en Lab, pero a medias: el personaje sigue legible).
     * En B/N el resultado es gris (solo cambia la luz).
     */
    static int[] tone(int[] comp, float[] sil, int W, int H, int[] scene, Preset c, boolean mono, float a0) {
        int n = W * H;
        int step = Math.max(1, (int) Math.sqrt((double) n / 80000.0));
        double[] mC = new double[3], sC = new double[3], mS = new double[3], sS = new double[3];
        int nc = 0, ns = 0;
        for (int i = 0; i < n; i += step) {
            if (sil[i] > 0.5f) {
                float[] k = ZoneTone.oklab(comp[i] | 0xFF000000);
                for (int j = 0; j < 3; j++) { mC[j] += k[j]; sC[j] += k[j] * k[j]; }
                nc++;
            } else if (scene != null) {
                float[] k = ZoneTone.oklab(scene[i] | 0xFF000000);
                for (int j = 0; j < 3; j++) { mS[j] += k[j]; sS[j] += k[j] * k[j]; }
                ns++;
            }
        }
        if (nc == 0) return null;
        if (ns == 0) {   // sin foto: el ambiente del preset
            float[] a = ZoneTone.oklab(c.mid), b = ZoneTone.oklab(c.cool);
            for (int j = 0; j < 3; j++) { mS[j] = (a[j] + b[j]) / 2; sS[j] = 0; }
            ns = 1;
            for (int j = 0; j < 3; j++) sS[j] = mS[j] * mS[j] + 0.01;
        }
        float[] mc = new float[3], sc = new float[3], ms = new float[3], ss = new float[3];
        for (int j = 0; j < 3; j++) {
            mc[j] = (float) (mC[j] / nc); sc[j] = (float) Math.sqrt(Math.max(1e-6, sC[j] / nc - mc[j] * mc[j]));
            ms[j] = (float) (mS[j] / ns); ss[j] = (float) Math.sqrt(Math.max(1e-6, sS[j] / ns - ms[j] * ms[j]));
        }
        // luz: el promedio se acerca a la foto a medias y nunca queda muy oscuro (se tiene que ver)
        float targetL = Math.max(0.30f, mc[0] + (ms[0] - mc[0]) * 0.7f);
        float rL = Math.max(0.85f, Math.min(1.25f, ss[0] / sc[0]));
        float[] k2 = ZoneTone.oklab(c.warm);
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            if (sil[i] <= 0f) continue;
            float[] k = ZoneTone.oklab(comp[i] | 0xFF000000);
            float L = targetL + (k[0] - mc[0]) * rL;
            float A, B;
            if (mono) { A = 0f; B = 0f; }
            else {
                // el color: se conserva el del personaje y se le suma el tinte de la escena
                float dA = (ms[1] - mc[1] * 0.85f) * 0.6f + k2[1] * 0.05f;
                float dB = (ms[2] - mc[2] * 0.85f) * 0.6f + k2[2] * 0.05f;
                // v8.61: el tinte de la escena no cambia el tono de la PIEL (en "Noche" la cara salia
                // celeste) y en lo demas tiene un tope: tine sin pintar encima
                float dm = (float) Math.hypot(dA, dB);
                // piel: casi nada; blanco o gris claro sin pintar (cara de un B/N): poco; lo demas: tope
                float ck = (float) Math.hypot(k[1], k[2]);
                float cap = Acabado.isSkin(comp[i] | 0xFF000000) ? 0.012f : (ck < 0.03f && k[0] > 0.7f ? 0.016f : 0.035f);
                if (dm > cap) { dA *= cap / dm; dB *= cap / dm; }
                A = k[1] * 0.85f + dA;
                B = k[2] * 0.85f + dB;
                if (Acabado.isSkin(comp[i] | 0xFF000000)) { A = k[1] * 0.95f + dA; B = k[2] * 0.95f + dB; }
            }
            int col = ZoneTone.fromOklab(Math.max(0f, Math.min(1f, L)), A, B);
            out[i] = (Math.round(255 * sil[i] * a0) << 24) | (col & 0xFFFFFF);
        }
        return out;
    }

    /**
     * Sombra en el suelo: la silueta proyectada desde sus pies, hacia el lado contrario a la luz y
     * aplastada sobre el piso, mas una sombra de contacto bajo los pies. Solo si se ven los pies.
     */
    static int[] ground(float[] sil, int W, int H, float lx, float ly, Preset c, float a0) {
        int n = W * H;
        int footY = -1, minX = W, maxX = -1, topY = H;
        for (int y = H - 1; y >= 0; y--)
            for (int x = 0; x < W; x++)
                if (sil[y * W + x] > 0.5f) {
                    if (footY < 0) footY = y;
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < topY) topY = y;
                }
        if (footY < 0 || footY > H - 3 || maxX <= minX) return null;
        float cx = (minX + maxX) / 2f, ht = Math.max(1, footY - topY);
        float dx = cx - lx;
        float len = (float) Math.hypot(dx, 1f);
        float kx = dx / Math.max(1f, Math.abs(dx) + ht * 0.3f) * 0.9f;     // mas al costado cuanto mas al costado esta la luz
        float ky = ly < footY ? 0.22f : -0.22f;
        float[] acc = new float[n];
        int step = Math.max(1, (int) (ht / 400));
        for (int y = topY; y <= footY; y += step)
            for (int x = minX; x <= maxX; x += step) {
                if (sil[y * W + x] < 0.5f) continue;
                float h = footY - y;
                int gx = Math.round(x + h * kx), gy = Math.round(footY + h * ky);
                if (gx < 0 || gy < 0 || gx >= W || gy >= H) continue;
                for (int yy = 0; yy < step; yy++) for (int xx = 0; xx < step; xx++) {
                    int q = (gy + yy) * W + gx + xx;
                    if (gy + yy < H && gx + xx < W) acc[q] = 1f;
                }
            }
        // sombra de contacto bajo los pies
        float rx = (maxX - minX) * 0.42f, ry = Math.max(3f, ht * 0.025f);
        for (int y = Math.max(0, (int) (footY - ry)); y < Math.min(H, footY + ry * 1.6f); y++)
            for (int x = Math.max(0, (int) (cx - rx)); x < Math.min(W, cx + rx); x++) {
                float u = (x - cx) / rx, v = (y - footY) / (ry * 1.3f);
                float d = 1f - (u * u + v * v);
                if (d > 0f) acc[y * W + x] = Math.max(acc[y * W + x], Math.min(1f, d * 2f));
            }
        int r = Math.max(2, (int) (Math.min(W, H) / 150));
        ZoneTone.box(acc, W, H, r);
        ZoneTone.box(acc, W, H, r);
        int col = mix(c.cool, 0xFF000000, 0.45f);
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            float v = Math.min(1f, acc[i]) * a0 * 0.7f;
            if (v < 0.01f) continue;
            out[i] = (Math.round(255 * v) << 24) | (col & 0xFFFFFF);
        }
        return out;
    }

    // ------------------------------------------------------------------ ayudas
    private static boolean on(Params p, int k) { return p.amount[k] > 0; }

    private static float silAt(float[] s, int W, int H, float x, float y) {
        int xi = (int) x, yi = (int) y;
        if (xi < 0 || yi < 0 || xi >= W || yi >= H) return 0f;
        return s[yi * W + xi];
    }

    private static void star(int[] dst, int W, int H, int cx, int cy, float len, int col, float bright) {
        int L = Math.max(2, Math.round(len));
        for (int dy = -L; dy <= L; dy++)
            for (int dx = -L; dx <= L; dx++) {
                int x = cx + dx, y = cy + dy;
                if (x < 0 || y < 0 || x >= W || y >= H) continue;
                float ax = Math.abs(dx), ay = Math.abs(dy);
                float arm = Math.max(Math.max(0f, 1f - ax / L) * (float) Math.exp(-ay * ay / 1.2f),
                        Math.max(0f, 1f - ay / L) * (float) Math.exp(-ax * ax / 1.2f));
                float core = (float) Math.exp(-(ax * ax + ay * ay) / (L * 0.08f + 1f));
                float v = Math.min(1f, (arm * arm + core) * bright);
                if (v < 0.02f) continue;
                int i = y * W + x;
                int a = Math.max(dst[i] >>> 24, Math.round(255 * v));
                dst[i] = (a << 24) | (col & 0xFFFFFF);
            }
    }

    private static int[] withAlpha(int[] px, int amount) {
        int a = Math.round(255 * amount / 100f);
        for (int i = 0; i < px.length; i++) px[i] = (a << 24) | (px[i] & 0xFFFFFF);
        return px;
    }

    private static float ease(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return t * t * (3f - 2f * t);
    }

    private static int clamp(int v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

    static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int over(int dst, int src) {
        int a = src >>> 24;
        if (a == 0) return dst;
        if (a == 255) return src | 0xFF000000;
        return mix(dst, src, a / 255f);
    }

    private static int add(int dst, int col, float v) {
        int r = clamp(((dst >> 16) & 255) + Math.round(((col >> 16) & 255) * v));
        int g = clamp(((dst >> 8) & 255) + Math.round(((col >> 8) & 255) * v));
        int b = clamp((dst & 255) + Math.round((col & 255) * v));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    // ruido suave (value noise) para las nubes
    private static float hash(int x, int y) {
        int h = x * 374761393 + y * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        return ((h ^ (h >>> 16)) & 0xFFFFFF) / (float) 0xFFFFFF;
    }

    private static float noise(float x, float y) {
        int xi = (int) Math.floor(x), yi = (int) Math.floor(y);
        float tx = x - xi, ty = y - yi;
        tx = tx * tx * (3 - 2 * tx);
        ty = ty * ty * (3 - 2 * ty);
        float a = hash(xi, yi), b = hash(xi + 1, yi), c = hash(xi, yi + 1), d = hash(xi + 1, yi + 1);
        return a + (b - a) * tx + (c - a) * ty + (a - b - c + d) * tx * ty;
    }

    private static float fbm(float x, float y) {
        float s = 0, amp = 0.5f, f = 1f;
        for (int o = 0; o < 5; o++) {
            s += amp * noise(x * f, y * f * 1.6f);
            f *= 2.03f;
            amp *= 0.5f;
        }
        return s;
    }
}
