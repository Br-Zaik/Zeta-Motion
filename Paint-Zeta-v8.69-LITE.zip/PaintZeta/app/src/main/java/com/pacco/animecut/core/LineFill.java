package com.pacco.animecut.core;

/**
 * Sombreado del relleno ("Conservar sombras", v8.24): cada pixel recibe el
 * color multiplicado por su luminosidad respecto del punto tocado. El papel
 * queda del color elegido y las sombras y lineas quedan oscuras. El resto del
 * balde esta en BucketFill.
 */
public final class LineFill {
    private LineFill() { }

    /** Luminosidad 0..255; lo transparente cuenta como papel blanco. */
    public static int lum(int c) {
        if ((c >>> 24) < 128) return 255;
        return (((c >> 16) & 0xFF) * 77 + ((c >> 8) & 0xFF) * 151 + (c & 0xFF) * 28) >> 8;
    }

    /**
     * Color con el sombreado del dibujo: color * min(1, lum(pixel) / lum(semilla)).
     * Conserva el alfa del color.
     */
    public static int shade(int color, int pixel, int seedLum) {
        int lp = lum(pixel);
        if (lp >= seedLum || seedLum <= 0) return color;
        float f = lp / (float) seedLum;
        int r = (int) (((color >> 16) & 0xFF) * f + .5f);
        int g = (int) (((color >> 8) & 0xFF) * f + .5f);
        int b = (int) ((color & 0xFF) * f + .5f);
        return (color & 0xFF000000) | (r << 16) | (g << 8) | b;
    }
}
