package com.pacco.animecut.ai;

/**
 * v8.33: convierte la mascara de la IA en un recorte "casi listo", por etapas que se pueden
 * prender y apagar (y probar una por una):
 *
 *  A) en la resolucion del modelo (rapido, ~1 MP):
 *     1. Dudoso grueso: una mancha ANCHA de valores intermedios (barras de vidrio, luz de fondo)
 *        no es un borde ni un mechon (esos son finos): se baja.
 *     2. Curva de alfa (dureza): smoothstep(lo, hi). La mascara sigue SUAVE (0..255).
 *     3. Islas: se quedan la pieza mayor, otras piezas grandes (otro personaje) y las chicas
 *        CERCANAS y seguras (aros, mechones, cintas sueltas). Se quitan las chicas lejanas o
 *        dudosas (brillos, trozos de edificio).
 *     4. Agujeros: solo se rellenan los diminutos, o los chicos cuyo color NO es el del fondo
 *        y donde la IA dudaba. Un hueco real (entre brazo y cuerpo) tiene el color del fondo y
 *        se respeta.
 *  B) en la resolucion de la capa:
 *     5. Ampliado suave (bilineal, sin escalones).
 *     6. Filtro guiado por el COLOR de la imagen original en la franja del borde: el alfa se
 *        pega a los bordes reales del dibujo.
 *     7. Linea del dibujo: el contorno oscuro pegado al recorte entra completo, con su antialias
 *        (desmezcla contra el fondo de al lado), solo si es mas oscuro que ESE fondo.
 *     8. Desplazar borde (-3..+3 px) si el usuario lo pide.
 *     9. Color del borde descontaminado: se le quita el tinte del fondo (sin halo).
 * La imagen original NO se toca: el resultado es alfa + colores corregidos del borde.
 */
public final class AiMatte {

    public static final class Params {
        /** Curva: debajo de lo = 0, encima de hi = 1. */
        public float lo = 0.12f, hi = 0.80f;
        public boolean uncertain = true, islands = true, holes = true, guided = true, lines = true, decontam = true;
        /** v8.36: el borde sigue la linea del dibujo (AiSnap). */
        public boolean snap = true;
        /**
         * v8.36: trazos del dedo sobre el personaje que se quiere (x, y, radio en pixeles de la
         * capa, de a 3). null = sin marca (se quedan todos los personajes).
         */
        public float[] hint;
        /** Pixeles para agrandar (+) o achicar (-) el recorte. */
        public int shift = 0;
        /** Guardar registro de decisiones (pruebas). */
        public boolean log;

        public Params copy() {
            Params p = new Params();
            p.lo = lo; p.hi = hi; p.uncertain = uncertain; p.islands = islands; p.holes = holes;
            p.guided = guided; p.lines = lines; p.decontam = decontam; p.shift = shift; p.log = log;
            p.snap = snap; p.hint = hint;
            return p;
        }

        /** Dureza 0..1 -> curva. 0,5 = de fabrica (lo 0,12 / hi 0,80). */
        public void setHardness(float h) {
            h = Math.max(0f, Math.min(1f, h));
            float width = 1.0f - 0.64f * h;      // 1,00 (suave) .. 0,36 (duro)
            lo = Math.max(0.01f, 0.46f - width / 2f);
            hi = Math.min(0.99f, 0.46f + width / 2f);
        }
    }

    public static final class Result {
        public int W, H;
        /** Alfa final de la IA, W*H (fuera de la zona mirada: 0). */
        public byte[] alpha;
        /** Pixeles del borde con color corregido (indice ascendente) y su color RGB. */
        public int[] bandIdx = new int[0], bandCol = new int[0];
        public int bandN;
        /** Piezas en la resolucion del modelo (para "Solo este"): etiqueta por celda, 0 = fondo. */
        public int[] comp;
        public int cw, ch, nComp;
        public int[] compArea;
        public AiPrep prep;
        public int islandsRemoved, islandsKept, holesFilled, holesKept, uncertainCells, linePx;
        /** v8.36: lo que hizo el borde por linea (null si no se uso). */
        public AiSnap.Stats snap;
        /** v8.36: lo que hizo la pintura del dedo (null sin marca). */
        public AiPick.Stats pick;
        /** v8.36: piezas que tocaba la marca del dedo (0 = sin marca). */
        public int hintPieces;
        public long ms;
        /** Registro de decisiones (pruebas); null = sin registro. */
        public StringBuilder log;

        /** Color a usar en i (corregido en el borde). */
        public int colorAt(int i, int orig) {
            int k = java.util.Arrays.binarySearch(bandIdx, 0, bandN, i);
            return k >= 0 ? (orig & 0xFF000000) | bandCol[k] : orig;
        }

        /** Pieza del modelo bajo el pixel (x,y) de la capa, 0 si es fondo. */
        public int compAt(int x, int y) {
            if (comp == null) return 0;
            int[] c = cellOf(x, y);
            return c == null ? 0 : comp[c[1] * cw + c[0]];
        }

        int[] cellOf(int x, int y) {
            AiPrep p = prep;
            int lx = x - p.cropX, ly = y - p.cropY;
            if (lx < 0 || ly < 0 || lx >= p.cropW || ly >= p.cropH) return null;
            int cx = Math.min(cw - 1, (int) ((lx + 0.5f) * cw / p.cropW));
            int cy = Math.min(ch - 1, (int) ((ly + 0.5f) * ch / p.cropH));
            return new int[]{cx, cy};
        }
    }

    private AiMatte() { }

    /**
     * @param prep el plan usado para la inferencia
     * @param m    salida recortada del modelo (prep.w * prep.h, 0..255)
     * @param px   capa original (ARGB), W*H
     */
    public static Result process(AiPrep prep, byte[] m, int[] px, int W, int H, Params p) {
        long t0 = System.nanoTime();
        Result r = new Result();
        if (p.log) r.log = new StringBuilder();
        r.W = W; r.H = H; r.prep = prep;
        int w = prep.w, h = prep.h;
        r.cw = w; r.ch = h;
        int n = w * h;
        float[] a = new float[n];
        for (int i = 0; i < n; i++) a[i] = (m[i] & 0xFF) / 255f;

        // ---- A1: dudoso grueso ----
        if (p.uncertain) r.uncertainCells = suppressThickUncertain(a, w, h);

        // ---- A2: curva ----
        float lo = p.lo, hi = Math.max(p.lo + 0.02f, p.hi);
        for (int i = 0; i < n; i++) a[i] = smooth(lo, hi, a[i]);

        // ---- A3/A4: islas y agujeros ----
        int[] lab = new int[n];
        int nc = label(a, w, h, lab, true);
        int[] area = new int[nc + 1];
        float[] maxA = new float[nc + 1];
        for (int i = 0; i < n; i++) {
            int l = lab[i];
            if (l > 0) { area[l]++; if (a[i] > maxA[l]) maxA[l] = a[i]; }
        }
        int main = 0;
        for (int l = 1; l <= nc; l++) if (main == 0 || area[l] > area[main]) main = l;
        boolean[] keep = new boolean[nc + 1];
        // v8.36: con marca del dedo se quedan SOLO las piezas que toca (y sus pedacitos cercanos)
        boolean[] touched = p.hint != null && nc > 0 ? touchedPieces(p.hint, prep, lab, nc, w, h) : null;
        if (touched != null) {
            main = 0;
            for (int l = 1; l <= nc; l++) if (touched[l]) { r.hintPieces++; if (main == 0 || area[l] > area[main]) main = l; }
        }
        if (main > 0) {
            int mainA = area[main];
            keep[main] = true;
            if (touched != null) {
                for (int l = 1; l <= nc; l++) if (touched[l]) keep[l] = true;
            } else {
                // grandes primero (otros personajes); despues las cercanas a lo que se queda
                for (int l = 1; l <= nc; l++) if (area[l] * 100L >= mainA * 4L) keep[l] = true;
            }
            if (p.islands || touched != null) {
                int near = Math.max(6, Math.round(0.025f * Math.max(w, h)));
                int[] d2 = distToKept(lab, keep, w, h);
                // mas cercana: distancia minima de cada pieza a lo que se queda
                int[] minD = new int[nc + 1];
                java.util.Arrays.fill(minD, Integer.MAX_VALUE);
                for (int i = 0; i < n; i++) { int l = lab[i]; if (l > 0 && d2[i] < minD[l]) minD[l] = d2[i]; }
                int near2 = Math.max(12, Math.round(0.06f * Math.max(w, h)));
                int tiny = Math.max(3, mainA / 5000);
                for (int l = 1; l <= nc; l++) {
                    if (keep[l]) continue;
                    long dd = minD[l];
                    // cerca de lo que se queda: es parte (aro, mechon, cinta suelta)
                    // con marca del dedo, una pieza grande cercana es OTRO personaje: no se queda
                    boolean small = touched == null || area[l] * 20L < mainA;
                    boolean k = (dd <= (long) near * near && small)
                            || (dd <= (long) near2 * near2 && maxA[l] >= 0.6f && area[l] * 20L < mainA)
                            // lejos pero la IA estaba SEGURA y no es una mota: objeto propio
                            // (con marca del dedo no: seria otro personaje)
                            || (touched == null && maxA[l] >= 0.95f && area[l] >= tiny * 4)
                            // con marca: un adorno chico y seguro algo mas lejos (mechon suelto, arete)
                            || (touched != null && small && maxA[l] >= 0.85f && dd <= 4L * near2 * near2);
                    if (k) { keep[l] = true; r.islandsKept++; }
                    else r.islandsRemoved++;
                    if (r.log != null) r.log.append(String.format("isla %d: area %d, max %.2f, dist %.0f -> %s%n", l, area[l], maxA[l], Math.sqrt(dd), k ? "queda" : "fuera"));
                }
                for (int i = 0; i < n; i++) {
                    int l = lab[i];
                    if (l > 0 && !keep[l]) a[i] = 0f;
                }
                // el borde suave de lo quitado tambien se va (lo que no llega a 0,5 alrededor)
                clearFringe(a, lab, keep, w, h);
            } else {
                for (int l = 1; l <= nc; l++) keep[l] = true;
            }
            if (p.holes) fillHoles(a, w, h, area[main], m, prep, px, W, r);
        }
        // piezas finales (para "Solo este")
        int[] lab2 = new int[n];
        int nc2 = label(a, w, h, lab2, true);
        r.comp = lab2;
        r.nComp = nc2;
        r.compArea = new int[nc2 + 1];
        for (int i = 0; i < n; i++) if (lab2[i] > 0) r.compArea[lab2[i]]++;

        // ---- B5: ampliado suave ----
        byte[] al = new byte[W * H];
        upsample(a, w, h, prep, al, W);
        r.alpha = al;

        int cx0 = prep.cropX, cy0 = prep.cropY, cx1 = cx0 + prep.cropW, cy1 = cy0 + prep.cropH;
        float scale = Math.max(prep.cropW / (float) w, prep.cropH / (float) h);
        // ---- B6: filtro guiado por color ----
        if (p.guided) {
            int rad = Math.max(2, Math.round(scale * 1.5f));
            guidedColor(al, px, W, H, cx0, cy0, cx1, cy1, rad, 2e-3f);
        }
        // ---- B7: linea del dibujo ----
        if (p.lines) r.linePx = includeLines(al, px, W, H, cx0, cy0, cx1, cy1, Math.max(3, Math.round(2 * scale) + 2));
        float hw = p.snap || p.hint != null ? com.pacco.animecut.core.BgEngine.measure(px, null, W, H).hGlobal : 1.5f;
        // ---- B7a (v8.36): pintura del dedo: solo el personaje pintado (aunque toque a otro) ----
        if (p.hint != null) r.pick = AiPick.apply(al, px, W, H, cx0, cy0, cx1, cy1, p.hint, hw);
        // ---- B7b (v8.36): el borde sigue la linea del dibujo ----
        if (p.snap) r.snap = AiSnap.apply(al, px, W, H, cx0, cy0, cx1, cy1, hw);
        // ---- B8: desplazar borde ----
        if (p.shift != 0) shift(al, W, H, cx0, cy0, cx1, cy1, p.shift);
        // ---- B9: color del borde ----
        if (p.decontam) decontaminate(al, px, W, H, cx0, cy0, cx1, cy1, Math.max(3, Math.round(2 * scale) + 2), r);
        r.ms = (System.nanoTime() - t0) / 1_000_000L;
        return r;
    }

    /**
     * v8.36: piezas (lab, en celdas del modelo) que toca la marca del dedo. Si no toca ninguna
     * (la marca cayo en el fondo) se toma la pieza mas cercana a la marca.
     */
    static boolean[] touchedPieces(float[] hint, AiPrep prep, int[] lab, int nc, int w, int h) {
        byte[] hm = new byte[w * h];
        float sx = w / (float) prep.cropW, sy = h / (float) prep.cropH;
        float px0 = Float.NaN, py0 = Float.NaN;
        for (int t = 0; t + 2 < hint.length; t += 3) {
            float x = (hint[t] - prep.cropX) * sx, y = (hint[t + 1] - prep.cropY) * sy, rr = hint[t + 2];
            if (rr < 0) { px0 = Float.NaN; continue; }          // corte entre trazos
            float rc = Math.max(1f, rr * sx);
            if (Float.isNaN(px0)) { px0 = x; py0 = y; }
            float dx = x - px0, dy = y - py0;
            int steps = Math.max(1, (int) Math.ceil(Math.sqrt(dx * dx + dy * dy) / Math.max(0.5f, rc * 0.5f)));
            for (int k = 0; k <= steps; k++) {
                float cx = px0 + dx * k / steps, cy = py0 + dy * k / steps;
                int ix0 = Math.max(0, (int) Math.floor(cx - rc)), ix1 = Math.min(w - 1, (int) Math.ceil(cx + rc));
                int iy0 = Math.max(0, (int) Math.floor(cy - rc)), iy1 = Math.min(h - 1, (int) Math.ceil(cy + rc));
                for (int yy = iy0; yy <= iy1; yy++)
                    for (int xx = ix0; xx <= ix1; xx++) {
                        float ex = xx + 0.5f - cx, ey = yy + 0.5f - cy;
                        if (ex * ex + ey * ey <= rc * rc) hm[yy * w + xx] = 1;
                    }
            }
            px0 = x; py0 = y;
        }
        boolean[] t = new boolean[nc + 1];
        boolean any = false, anyMark = false;
        for (int i = 0; i < w * h; i++) {
            if (hm[i] == 0) continue;
            anyMark = true;
            int l = lab[i];
            if (l > 0) { t[l] = true; any = true; }
        }
        if (!anyMark) return null;                 // la marca quedo fuera de la zona mirada
        if (!any) {
            int[] d = edt(hm, w, h);
            int best = 0, bd = Integer.MAX_VALUE;
            for (int i = 0; i < w * h; i++) { int l = lab[i]; if (l > 0 && d[i] < bd) { bd = d[i]; best = l; } }
            if (best == 0) return null;
            t[best] = true;
        }
        return t;
    }

    /**
     * v8.36: recuadro (x0, y0, x1, y1 en la capa) de lo que se queda con la marca del dedo,
     * mirando solo la mascara del modelo (rapido). null si no queda nada.
     */
    public static int[] hintBounds(AiPrep prep, byte[] m, int[] px, int W, int H, Params p) {
        Params q = p.copy();
        q.guided = q.lines = q.decontam = q.snap = false;
        q.shift = 0;
        Result r = process(prep, m, px, W, H, q);
        int x0 = Integer.MAX_VALUE, y0 = Integer.MAX_VALUE, x1 = -1, y1 = -1;
        for (int y = prep.cropY; y < prep.cropY + prep.cropH; y++) {
            int o = y * W;
            for (int x = prep.cropX; x < prep.cropX + prep.cropW; x++) {
                if ((r.alpha[o + x] & 0xFF) < 64) continue;
                if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
            }
        }
        if (x1 < 0) return null;
        return new int[]{x0, y0, x1 + 1, y1 + 1};
    }

    /**
     * v8.36: con marca del dedo, zona para una SEGUNDA mirada de la IA (mas detalle): el
     * recuadro de lo marcado con margen, si es bastante mas chico que lo ya mirado. null = no
     * hace falta (ya se miro con suficiente detalle) o no quedo nada.
     */
    public static int[] secondLook(AiPrep prep, byte[] m, int[] px, int W, int H, Params p) {
        if (p.hint == null) return null;
        int[] b = hintBounds(prep, m, px, W, H, p);
        if (b == null) return null;
        int bw = b[2] - b[0], bh = b[3] - b[1];
        int mg = Math.max(8, Math.round(0.06f * Math.max(bw, bh)));
        int x0 = Math.max(prep.cropX, b[0] - mg), y0 = Math.max(prep.cropY, b[1] - mg);
        int x1 = Math.min(prep.cropX + prep.cropW, b[2] + mg), y1 = Math.min(prep.cropY + prep.cropH, b[3] + mg);
        // solo vale la pena si el lado mayor baja al menos un 25 % (mas pixeles por celda)
        float before = Math.max(prep.cropW, prep.cropH), after = Math.max(x1 - x0, y1 - y0);
        if (after > 0.75f * before || x1 - x0 < 16 || y1 - y0 < 16) return null;
        return new int[]{x0, y0, x1 - x0, y1 - y0};
    }

    static float smooth(float lo, float hi, float v) {
        if (v <= lo) return 0f;
        if (v >= hi) return 1f;
        float t = (v - lo) / (hi - lo);
        return t * t * (3f - 2f * t);
    }

    // ------------------------------------------------------------------ A1
    /**
     * Manchas anchas de duda (0,1..0,8): sus celdas a 3 o mas celdas de algo seguro se bajan a 0,
     * y su anillo hasta esa distancia se baja proporcional. Bordes y mechones (finos) no cambian.
     */
    static int suppressThickUncertain(float[] a, int w, int h) {
        int n = w * h;
        byte[] sure = new byte[n];
        for (int i = 0; i < n; i++) sure[i] = (byte) ((a[i] <= 0.10f || a[i] >= 0.80f) ? 1 : 0);
        int[] d2 = edt(sure, w, h);
        final int T = 3;
        // nucleos: dudoso a >= T celdas de lo seguro
        int[] q = new int[n];
        int[] dist = new int[n];
        java.util.Arrays.fill(dist, -1);
        int qh = 0, qt = 0, cnt = 0;
        for (int i = 0; i < n; i++) if (sure[i] == 0 && d2[i] >= T * T) { dist[i] = 0; q[qt++] = i; }
        // crece dentro de lo dudoso hasta T celdas
        while (qh < qt) {
            int i = q[qh++];
            int d = dist[i];
            if (d >= T) continue;
            int x = i % w, y = i / w;
            for (int k = 0; k < 4; k++) {
                int xx = x + (k == 0 ? 1 : k == 1 ? -1 : 0), yy = y + (k == 2 ? 1 : k == 3 ? -1 : 0);
                if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                int j = yy * w + xx;
                if (sure[j] != 0 || dist[j] >= 0) continue;
                dist[j] = d + 1;
                q[qt++] = j;
            }
        }
        // solo manchas GRANDES de duda (barras, luz de fondo); una chica y compacta puede ser un
        // aro o un adorno que la IA vio a medias: se respeta
        int minArea = Math.max(400, n / 500);
        int[] lab = new int[n];
        int[] stack = new int[n];
        int next = 0;
        for (int s0 = 0; s0 < n; s0++) {
            if (sure[s0] != 0 || lab[s0] != 0) continue;
            next++;
            int sp = 0, area = 0;
            boolean core = false;
            stack[sp++] = s0; lab[s0] = next;
            int mark = 0;
            // recorrido: se guarda la lista en q (reuso) para poder deshacer la marca
            q[mark++] = s0;
            while (sp > 0) {
                int i = stack[--sp];
                area++;
                if (dist[i] >= 0) core = true;
                int x = i % w, y = i / w;
                for (int k = 0; k < 4; k++) {
                    int xx = x + (k == 0 ? 1 : k == 1 ? -1 : 0), yy = y + (k == 2 ? 1 : k == 3 ? -1 : 0);
                    if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                    int j = yy * w + xx;
                    if (sure[j] != 0 || lab[j] != 0) continue;
                    lab[j] = next;
                    stack[sp++] = j;
                    q[mark++] = j;
                }
            }
            if (!core) continue;
            boolean big = area >= minArea;
            for (int t = 0; t < mark; t++) {
                int i = q[t];
                int d = dist[i];
                if (d < 0 || !big) continue;
                cnt++;
                a[i] = d == 0 ? 0f : a[i] * (d / (float) (T + 1));
            }
        }
        return cnt;
    }

    // ------------------------------------------------------------------ A3
    /** Piezas 8-conexas de a >= 0,5 (fg=true) o 4-conexas de a < 0,5 (fg=false). */
    static int label(float[] a, int w, int h, int[] lab, boolean fg) {
        int n = w * h;
        java.util.Arrays.fill(lab, 0);
        int[] q = new int[n];
        int next = 0;
        for (int s = 0; s < n; s++) {
            if (lab[s] != 0 || ((a[s] >= 0.5f) != fg)) continue;
            next++;
            int qh = 0, qt = 0;
            q[qt++] = s;
            lab[s] = next;
            while (qh < qt) {
                int i = q[qh++];
                int x = i % w, y = i / w;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        if (dx == 0 && dy == 0) continue;
                        if (!fg && dx != 0 && dy != 0) continue;
                        int xx = x + dx;
                        if (xx < 0 || xx >= w) continue;
                        int j = yy * w + xx;
                        if (lab[j] != 0 || ((a[j] >= 0.5f) != fg)) continue;
                        lab[j] = next;
                        q[qt++] = j;
                    }
                }
            }
        }
        return next;
    }

    static int[] distToKept(int[] lab, boolean[] keep, int w, int h) {
        byte[] f = new byte[w * h];
        for (int i = 0; i < f.length; i++) f[i] = (byte) (lab[i] > 0 && keep[lab[i]] ? 1 : 0);
        return edt(f, w, h);
    }

    /** Lo suave (< 0,5) pegado a una pieza quitada (2 celdas) y no a una que se queda: a 0. */
    static void clearFringe(float[] a, int[] lab, boolean[] keep, int w, int h) {
        int n = w * h;
        byte[] gone = new byte[n], kept = new byte[n];
        for (int i = 0; i < n; i++) {
            int l = lab[i];
            if (l > 0) { if (keep[l]) kept[i] = 1; else gone[i] = 1; }
        }
        int[] dg = edt(gone, w, h), dk = edt(kept, w, h);
        for (int i = 0; i < n; i++) {
            if (lab[i] != 0 || a[i] <= 0f) continue;
            if (dg[i] <= 4 && dg[i] < dk[i]) a[i] = 0f;
        }
    }

    /** A4: agujeros encerrados. */
    static void fillHoles(float[] a, int w, int h, int mainArea, byte[] raw, AiPrep prep, int[] px, int W, Result r) {
        int n = w * h;
        int[] lab = new int[n];
        int nb = label(a, w, h, lab, false);
        if (nb == 0) return;
        boolean[] border = new boolean[nb + 1];
        for (int x = 0; x < w; x++) { border[lab[x]] = true; border[lab[(h - 1) * w + x]] = true; }
        for (int y = 0; y < h; y++) { border[lab[y * w]] = true; border[lab[y * w + w - 1]] = true; }
        int[] area = new int[nb + 1];
        long[] sr = new long[nb + 1], sg = new long[nb + 1], sb = new long[nb + 1], sq = new long[nb + 1];
        // color del fondo de afuera cerca del personaje (anillo de 2..8 celdas)
        byte[] fgm = new byte[n];
        for (int i = 0; i < n; i++) fgm[i] = (byte) (a[i] >= 0.5f ? 1 : 0);
        int[] dfg = edt(fgm, w, h);
        long br = 0, bg = 0, bb = 0, bn = 0;
        for (int i = 0; i < n; i++) {
            int l = lab[i];
            if (l == 0) continue;
            int c = cellColor(px, W, prep, i % w, i / w, w, h);
            if (border[l]) {
                if (dfg[i] >= 4 && dfg[i] <= 64) { br += (c >> 16) & 255; bg += (c >> 8) & 255; bb += c & 255; bn++; }
                continue;
            }
            area[l]++;
            sr[l] += (c >> 16) & 255; sg[l] += (c >> 8) & 255; sb[l] += c & 255;
            sq[l] += raw[i] & 0xFF;
        }
        int bgc = bn == 0 ? -1 : (int) (br / bn) << 16 | (int) (bg / bn) << 8 | (int) (bb / bn);
        int tiny = Math.max(4, mainArea / 2000);
        int small = Math.max(tiny, mainArea / 250);
        boolean[] fill = new boolean[nb + 1];
        for (int l = 1; l <= nb; l++) {
            if (border[l] || area[l] == 0) continue;
            boolean f;
            if (area[l] <= tiny) f = true;
            else if (area[l] <= small) {
                int hc = (int) (sr[l] / area[l]) << 16 | (int) (sg[l] / area[l]) << 8 | (int) (sb[l] / area[l]);
                int meanQ = (int) (sq[l] / area[l]);
                f = meanQ >= 50 && (bgc < 0 || rgbDist(hc, bgc) > 60);
            } else f = false;
            fill[l] = f;
            if (f) r.holesFilled++; else r.holesKept++;
        }
        for (int i = 0; i < n; i++) if (lab[i] > 0 && fill[lab[i]]) a[i] = 1f;
    }

    static int rgbDist(int a, int b) {
        int dr = ((a >> 16) & 255) - ((b >> 16) & 255), dg = ((a >> 8) & 255) - ((b >> 8) & 255), db = (a & 255) - (b & 255);
        return (int) Math.sqrt(dr * dr + dg * dg + db * db);
    }

    /** Color de la capa en el centro de una celda del modelo. */
    static int cellColor(int[] px, int W, AiPrep p, int cx, int cy, int w, int h) {
        int x = p.cropX + Math.min(p.cropW - 1, (int) ((cx + 0.5f) * p.cropW / w));
        int y = p.cropY + Math.min(p.cropH - 1, (int) ((cy + 0.5f) * p.cropH / h));
        return px[y * W + x];
    }

    // ------------------------------------------------------------------ B5
    static void upsample(float[] a, int w, int h, AiPrep p, byte[] out, int W) {
        float fx = w / (float) p.cropW, fy = h / (float) p.cropH;
        int[] x0 = new int[p.cropW], x1 = new int[p.cropW];
        float[] tx = new float[p.cropW];
        for (int x = 0; x < p.cropW; x++) {
            float sx = (x + 0.5f) * fx - 0.5f;
            int i0 = (int) Math.floor(sx);
            tx[x] = sx - i0;
            x0[x] = Math.max(0, Math.min(w - 1, i0));
            x1[x] = Math.max(0, Math.min(w - 1, i0 + 1));
        }
        for (int y = 0; y < p.cropH; y++) {
            float sy = (y + 0.5f) * fy - 0.5f;
            int j0 = (int) Math.floor(sy);
            float ty = sy - j0;
            int r0 = Math.max(0, Math.min(h - 1, j0)) * w, r1 = Math.max(0, Math.min(h - 1, j0 + 1)) * w;
            int o = (p.cropY + y) * W + p.cropX;
            for (int x = 0; x < p.cropW; x++) {
                float t = tx[x];
                float v0 = a[r0 + x0[x]] * (1 - t) + a[r0 + x1[x]] * t;
                float v1 = a[r1 + x0[x]] * (1 - t) + a[r1 + x1[x]] * t;
                float v = v0 * (1 - ty) + v1 * ty;
                out[o + x] = (byte) Math.round(Math.max(0f, Math.min(1f, v)) * 255f);
            }
        }
    }

    // ------------------------------------------------------------------ B6
    static final int TILE = 192;

    /** Filtro guiado con guia de COLOR (He et al. 2013), por bloques, solo donde el alfa no es plano. */
    static void guidedColor(byte[] al, int[] px, int W, int H, int x0, int y0, int x1, int y1, int r, float eps) {
        int pad = 2 * r + 1;
        int tw = TILE + 2 * pad;
        int N = tw * tw;
        float[] Ir = new float[N], Ig = new float[N], Ib = new float[N], P = new float[N];
        float[][] tmp = new float[13][N];
        float[] buf = new float[N];
        byte[] outT = new byte[TILE * TILE];
        for (int ty = y0; ty < y1; ty += TILE) {
            for (int tx = x0; tx < x1; tx += TILE) {
                int bx1 = Math.min(x1, tx + TILE), by1 = Math.min(y1, ty + TILE);
                // zona con margen
                int ex0 = Math.max(x0, tx - pad), ey0 = Math.max(y0, ty - pad);
                int ex1 = Math.min(x1, bx1 + pad), ey1 = Math.min(y1, by1 + pad);
                int ew = ex1 - ex0, eh = ey1 - ey0;
                boolean any = false;
                for (int y = ey0; y < ey1 && !any; y++) {
                    int o = y * W;
                    for (int x = ex0; x < ex1; x++) {
                        int v = al[o + x] & 0xFF;
                        if (v > 0 && v < 255) { any = true; break; }
                    }
                }
                if (!any) continue;
                int en = ew * eh;
                for (int y = 0; y < eh; y++) {
                    for (int x = 0; x < ew; x++) {
                        int i = (ey0 + y) * W + ex0 + x;
                        int c = px[i];
                        int k = y * ew + x;
                        Ir[k] = ((c >> 16) & 255) / 255f;
                        Ig[k] = ((c >> 8) & 255) / 255f;
                        Ib[k] = (c & 255) / 255f;
                        P[k] = (al[i] & 0xFF) / 255f;
                    }
                }
                // medias: I(3), p, Ip(3), II(6)
                float[] mR = tmp[0], mG = tmp[1], mB = tmp[2], mP = tmp[3];
                float[] mRP = tmp[4], mGP = tmp[5], mBP = tmp[6];
                float[] mRR = tmp[7], mRG = tmp[8], mRB = tmp[9], mGG = tmp[10], mGB = tmp[11], mBB = tmp[12];
                box(Ir, mR, ew, eh, r, buf); box(Ig, mG, ew, eh, r, buf); box(Ib, mB, ew, eh, r, buf); box(P, mP, ew, eh, r, buf);
                float[] t = new float[en];
                for (int k = 0; k < en; k++) t[k] = Ir[k] * P[k]; box(t, mRP, ew, eh, r, buf);
                for (int k = 0; k < en; k++) t[k] = Ig[k] * P[k]; box(t, mGP, ew, eh, r, buf);
                for (int k = 0; k < en; k++) t[k] = Ib[k] * P[k]; box(t, mBP, ew, eh, r, buf);
                for (int k = 0; k < en; k++) t[k] = Ir[k] * Ir[k]; box(t, mRR, ew, eh, r, buf);
                for (int k = 0; k < en; k++) t[k] = Ir[k] * Ig[k]; box(t, mRG, ew, eh, r, buf);
                for (int k = 0; k < en; k++) t[k] = Ir[k] * Ib[k]; box(t, mRB, ew, eh, r, buf);
                for (int k = 0; k < en; k++) t[k] = Ig[k] * Ig[k]; box(t, mGG, ew, eh, r, buf);
                for (int k = 0; k < en; k++) t[k] = Ig[k] * Ib[k]; box(t, mGB, ew, eh, r, buf);
                for (int k = 0; k < en; k++) t[k] = Ib[k] * Ib[k]; box(t, mBB, ew, eh, r, buf);
                // coeficientes a (3) y b, reusando arreglos
                float[] aR = mRP, aG = mGP, aB = mBP, bb = mP;
                for (int k = 0; k < en; k++) {
                    float mr = mR[k], mg = mG[k], mb = mB[k], mp = mP[k];
                    float cr = mRP[k] - mr * mp, cg = mGP[k] - mg * mp, cb = mBP[k] - mb * mp;
                    float s00 = mRR[k] - mr * mr + eps, s01 = mRG[k] - mr * mg, s02 = mRB[k] - mr * mb;
                    float s11 = mGG[k] - mg * mg + eps, s12 = mGB[k] - mg * mb, s22 = mBB[k] - mb * mb + eps;
                    // inversa 3x3 simetrica
                    float i00 = s11 * s22 - s12 * s12, i01 = s02 * s12 - s01 * s22, i02 = s01 * s12 - s02 * s11;
                    float i11 = s00 * s22 - s02 * s02, i12 = s01 * s02 - s00 * s12, i22 = s00 * s11 - s01 * s01;
                    float det = s00 * i00 + s01 * i01 + s02 * i02;
                    float ar, ag, ab;
                    if (Math.abs(det) < 1e-12f) { ar = ag = ab = 0f; }
                    else {
                        float id = 1f / det;
                        ar = (cr * i00 + cg * i01 + cb * i02) * id;
                        ag = (cr * i01 + cg * i11 + cb * i12) * id;
                        ab = (cr * i02 + cg * i12 + cb * i22) * id;
                    }
                    aR[k] = ar; aG[k] = ag; aB[k] = ab;
                    bb[k] = mp - ar * mr - ag * mg - ab * mb;
                }
                box(aR, mR, ew, eh, r, buf); box(aG, mG, ew, eh, r, buf); box(aB, mB, ew, eh, r, buf); box(bb, mRR, ew, eh, r, buf);
                int ow = bx1 - tx;
                for (int y = ty; y < by1; y++) {
                    for (int x = tx; x < bx1; x++) {
                        int k = (y - ey0) * ew + (x - ex0);
                        float v = mR[k] * Ir[k] + mG[k] * Ig[k] + mB[k] * Ib[k] + mRR[k];
                        int q = Math.round(Math.max(0f, Math.min(1f, v)) * 255f);
                        outT[(y - ty) * ow + (x - tx)] = (byte) q;
                    }
                }
                // se escribe despues (los bloques vecinos leen el alfa de antes en su margen... se
                // acepta: el margen solo afecta el promedio de coeficientes)
                for (int y = ty; y < by1; y++)
                    for (int x = tx; x < bx1; x++) {
                        int i = y * W + x;
                        int o = al[i] & 0xFF;
                        int q = outT[(y - ty) * ow + (x - tx)] & 0xFF;
                        // donde la IA estaba segura y lejos del borde no se cambia
                        if (o == 0 || o == 255) {
                            if (Math.abs(q - o) < 40) continue;
                        }
                        al[i] = (byte) q;
                    }
            }
        }
    }

    /** Media en ventana (2r+1)^2 con bordes recortados. */
    static void box(float[] src, float[] out, int w, int h, int r, float[] tmp) {
        for (int y = 0; y < h; y++) {
            int row = y * w;
            float sum = 0;
            for (int x = 0; x <= Math.min(r, w - 1); x++) sum += src[row + x];
            for (int x = 0; x < w; x++) {
                int lo = x - r - 1, hi = x + r;
                if (x > 0 && hi < w) sum += src[row + hi];
                if (lo >= 0) sum -= src[row + lo];
                int cnt = Math.min(w - 1, x + r) - Math.max(0, x - r) + 1;
                tmp[row + x] = sum / cnt;
            }
        }
        for (int x = 0; x < w; x++) {
            float sum = 0;
            for (int y = 0; y <= Math.min(r, h - 1); y++) sum += tmp[y * w + x];
            for (int y = 0; y < h; y++) {
                int lo = y - r - 1, hi = y + r;
                if (y > 0 && hi < h) sum += tmp[hi * w + x];
                if (lo >= 0) sum -= tmp[lo * w + x];
                int cnt = Math.min(h - 1, y + r) - Math.max(0, y - r) + 1;
                out[y * w + x] = sum / cnt;
            }
        }
    }

    // ------------------------------------------------------------------ B7
    static int lum(int c) {
        return (((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000;
    }

    /**
     * El contorno oscuro pegado al recorte entra completo. Solo cuenta como linea lo que es
     * bastante mas oscuro que el FONDO de al lado (en fondo oscuro no se agrega nada de mas).
     */
    static int includeLines(byte[] al, int[] px, int W, int H, int x0, int y0, int x1, int y1, int reach) {
        int added = 0;
        int R = 4;
        for (int ty = y0; ty < y1; ty += TILE) {
            for (int tx = x0; tx < x1; tx += TILE) {
                int bx1 = Math.min(x1, tx + TILE), by1 = Math.min(y1, ty + TILE);
                int pad = reach + R + 2;
                int ex0 = Math.max(x0, tx - pad), ey0 = Math.max(y0, ty - pad);
                int ex1 = Math.min(x1, bx1 + pad), ey1 = Math.min(y1, by1 + pad);
                int ew = ex1 - ex0, eh = ey1 - ey0, en = ew * eh;
                boolean any = false;
                for (int y = ty; y < by1 && !any; y++)
                    for (int x = tx; x < bx1; x++) {
                        int v = al[y * W + x] & 0xFF;
                        if (v > 0 && v < 255) { any = true; break; }
                    }
                if (!any) continue;
                // luminancia media del FONDO cercano (alfa < 0,1) en ventana (2R+1)^2
                float[] L = new float[en], bgS = new float[en], bgN = new float[en], buf = new float[en];
                float[] t1 = new float[en], t2 = new float[en];
                for (int y = 0; y < eh; y++)
                    for (int x = 0; x < ew; x++) {
                        int i = (ey0 + y) * W + ex0 + x;
                        int k = y * ew + x;
                        L[k] = lum(px[i]);
                        boolean bg = (al[i] & 0xFF) < 26;
                        t1[k] = bg ? L[k] : 0f;
                        t2[k] = bg ? 1f : 0f;
                    }
                box(t1, bgS, ew, eh, R, buf);
                box(t2, bgN, ew, eh, R, buf);
                // BFS desde lo seguro (>= 200) por pixeles de linea, hasta "reach" pasos
                int[] q = new int[en];
                byte[] st = new byte[en];
                int qh = 0, qt = 0;
                int[] step = new int[en];
                for (int k = 0; k < en; k++) {
                    int i = (ey0 + k / ew) * W + ex0 + k % ew;
                    if ((al[i] & 0xFF) >= 200) { st[k] = 1; q[qt++] = k; step[k] = 0; }
                }
                while (qh < qt) {
                    int k = q[qh++];
                    if (step[k] >= reach) continue;
                    int x = k % ew, y = k / ew;
                    for (int dy = -1; dy <= 1; dy++) {
                        int yy = y + dy;
                        if (yy < 0 || yy >= eh) continue;
                        for (int dx = -1; dx <= 1; dx++) {
                            int xx = x + dx;
                            if (xx < 0 || xx >= ew || (dx == 0 && dy == 0)) continue;
                            int j = yy * ew + xx;
                            if (st[j] != 0) continue;
                            // solo donde la IA ya veia algo (su borde suave): no se agregan tramas
                            // ni lineas del fondo que la IA dejo afuera
                            if ((al[(ey0 + yy) * W + ex0 + xx] & 0xFF) < 8) continue;
                            float nb = bgN[j];
                            if (nb < 0.05f) continue;           // sin fondo cerca: no se sabe
                            float lb = bgS[j] / nb;
                            float l = L[j];
                            if (!(l <= lb - 55f && l <= 0.6f * lb + 10f)) continue;
                            st[j] = 2;
                            step[j] = step[k] + 1;
                            q[qt++] = j;
                        }
                    }
                }
                // escribir solo dentro del bloque. Linea y su vecino exterior: alfa por DESMEZCLA
                // entre el fondo de al lado y el color mas oscuro de la linea cercana (5x5): el
                // centro de la linea queda en 1 y su antialias conserva su suavidad.
                for (int y = ty; y < by1; y++)
                    for (int x = tx; x < bx1; x++) {
                        int k = (y - ey0) * ew + (x - ex0);
                        if (st[k] == 1) continue;
                        // pegado a una linea agregada
                        int xx0 = x - ex0, yy0 = y - ey0;
                        float lmin = 1e9f;
                        boolean near = false;
                        for (int dy = -2; dy <= 2; dy++)
                            for (int dx = -2; dx <= 2; dx++) {
                                int xx = xx0 + dx, yy = yy0 + dy;
                                if (xx < 0 || yy < 0 || xx >= ew || yy >= eh) continue;
                                int j = yy * ew + xx;
                                if (st[j] == 2) near = true;
                                // color de la linea = lo mas oscuro cerca (tambien su centro, que ya
                                // era seguro); si no, el antialias pareceria la linea entera
                                if (st[j] != 0 && L[j] < lmin) lmin = L[j];
                            }
                        if (!near) continue;
                        float nb = bgN[k];
                        if (nb < 0.05f) continue;
                        float lb = bgS[k] / nb;
                        if (lb - lmin < 60f) continue;
                        float u = (lb - L[k]) / (lb - lmin);
                        int v = Math.round(Math.max(0f, Math.min(1f, u)) * 255f);
                        int i = y * W + x;
                        if (v > (al[i] & 0xFF)) { al[i] = (byte) v; added++; }
                    }
            }
        }
        return added;
    }

    // ------------------------------------------------------------------ B8
    static void shift(byte[] al, int W, int H, int x0, int y0, int x1, int y1, int s) {
        int r = Math.min(4, Math.abs(s));
        boolean grow = s > 0;
        int bw = x1 - x0, bh = y1 - y0;
        byte[] t = new byte[bw * bh];
        for (int y = y0; y < y1; y++)
            for (int x = x0; x < x1; x++) {
                int m = grow ? 0 : 255;
                for (int k = -r; k <= r; k++) {
                    int xx = x + k;
                    if (xx < x0 || xx >= x1) continue;
                    int v = al[y * W + xx] & 0xFF;
                    m = grow ? Math.max(m, v) : Math.min(m, v);
                }
                t[(y - y0) * bw + (x - x0)] = (byte) m;
            }
        for (int y = y0; y < y1; y++)
            for (int x = x0; x < x1; x++) {
                int m = grow ? 0 : 255;
                for (int k = -r; k <= r; k++) {
                    int yy = y + k;
                    if (yy < y0 || yy >= y1) continue;
                    int v = t[(yy - y0) * bw + (x - x0)] & 0xFF;
                    m = grow ? Math.max(m, v) : Math.min(m, v);
                }
                al[y * W + x] = (byte) m;
            }
    }

    // ------------------------------------------------------------------ B9
    /** Color del borde sin el tinte del fondo: F = (C - (1-a) B) / a, con B = fondo cercano. */
    static void decontaminate(byte[] al, int[] px, int W, int H, int x0, int y0, int x1, int y1, int R, Result res) {
        int[] idx = new int[1024], col = new int[1024];
        int cnt = 0;
        for (int ty = y0; ty < y1; ty += TILE) {
            for (int tx = x0; tx < x1; tx += TILE) {
                int bx1 = Math.min(x1, tx + TILE), by1 = Math.min(y1, ty + TILE);
                boolean any = false;
                for (int y = ty; y < by1 && !any; y++)
                    for (int x = tx; x < bx1; x++) {
                        int v = al[y * W + x] & 0xFF;
                        if (v > 0 && v < 250) { any = true; break; }
                    }
                if (!any) continue;
                int ex0 = Math.max(x0, tx - R), ey0 = Math.max(y0, ty - R);
                int ex1 = Math.min(x1, bx1 + R), ey1 = Math.min(y1, by1 + R);
                int ew = ex1 - ex0, eh = ey1 - ey0, en = ew * eh;
                float[][] s = new float[8][en];
                float[][] m = new float[8][en];
                float[] buf = new float[en];
                for (int y = 0; y < eh; y++)
                    for (int x = 0; x < ew; x++) {
                        int i = (ey0 + y) * W + ex0 + x;
                        int c = px[i], v = al[i] & 0xFF;
                        int k = y * ew + x;
                        float r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                        if (v <= 13) { s[0][k] = r; s[1][k] = g; s[2][k] = b; s[3][k] = 1; }
                        if (v >= 242) { s[4][k] = r; s[5][k] = g; s[6][k] = b; s[7][k] = 1; }
                    }
                for (int q = 0; q < 8; q++) box(s[q], m[q], ew, eh, R, buf);
                for (int y = ty; y < by1; y++)
                    for (int x = tx; x < bx1; x++) {
                        int i = y * W + x;
                        int v = al[i] & 0xFF;
                        if (v == 0 || v >= 250) continue;
                        int k = (y - ey0) * ew + (x - ex0);
                        int c = px[i];
                        float a = v / 255f;
                        float nB = m[3][k], nF = m[7][k];
                        float fr, fg, fb;
                        float cr = (c >> 16) & 255, cg = (c >> 8) & 255, cb = c & 255;
                        float Fr = nF > 0.01f ? m[4][k] / nF : cr, Fg = nF > 0.01f ? m[5][k] / nF : cg, Fb = nF > 0.01f ? m[6][k] / nF : cb;
                        if (nB > 0.01f && a >= 0.3f) {
                            float Br = m[0][k] / nB, Bg = m[1][k] / nB, Bb = m[2][k] / nB;
                            fr = (cr - (1 - a) * Br) / a;
                            fg = (cg - (1 - a) * Bg) / a;
                            fb = (cb - (1 - a) * Bb) / a;
                            // si se va muy afuera del rango, la mezcla no era de esos dos: se acerca
                            // al color del personaje de al lado
                            float over = Math.max(Math.max(over(fr), over(fg)), over(fb));
                            if (over > 30f && nF > 0.01f) {
                                float t = Math.min(1f, (over - 30f) / 60f);
                                fr = fr * (1 - t) + Fr * t; fg = fg * (1 - t) + Fg * t; fb = fb * (1 - t) + Fb * t;
                            }
                        } else if (nF > 0.01f) {
                            fr = Fr; fg = Fg; fb = Fb;
                        } else continue;
                        int rgb = (cl(fr) << 16) | (cl(fg) << 8) | cl(fb);
                        if (rgb == (c & 0xFFFFFF)) continue;
                        if (cnt == idx.length) {
                            idx = java.util.Arrays.copyOf(idx, cnt * 2);
                            col = java.util.Arrays.copyOf(col, cnt * 2);
                        }
                        idx[cnt] = i; col[cnt] = rgb; cnt++;
                    }
            }
        }
        // orden ascendente para buscar rapido
        sortPairs(idx, col, cnt);
        res.bandIdx = idx; res.bandCol = col; res.bandN = cnt;
    }

    static float over(float v) { return v < 0 ? -v : v > 255 ? v - 255 : 0; }

    static int cl(float v) { return v < 0 ? 0 : v > 255 ? 255 : Math.round(v); }

    static void sortPairs(int[] a, int[] b, int n) {
        long[] t = new long[n];
        for (int i = 0; i < n; i++) t[i] = ((long) a[i] << 32) | (b[i] & 0xFFFFFFFFL);
        java.util.Arrays.sort(t);
        for (int i = 0; i < n; i++) { a[i] = (int) (t[i] >>> 32); b[i] = (int) t[i]; }
    }

    // ------------------------------------------------------------------ EDT
    /** Distancia euclidiana exacta AL CUADRADO (en celdas) a la celda != 0 mas cercana. */
    static int[] edt(byte[] f, int w, int h) {
        final int INF = 1 << 28;
        int n = w * h;
        int[] g = new int[n];
        for (int x = 0; x < w; x++) {
            int d = INF;
            for (int y = 0; y < h; y++) {
                int i = y * w + x;
                if (f[i] != 0) d = 0; else if (d < INF) d++;
                g[i] = d;
            }
            d = INF;
            for (int y = h - 1; y >= 0; y--) {
                int i = y * w + x;
                if (g[i] == 0) d = 0; else if (d < INF) d++;
                if (d < g[i]) g[i] = d;
            }
        }
        int[] out = new int[n];
        int[] v = new int[w];
        float[] z = new float[w + 1];
        long[] fv = new long[w];
        for (int y = 0; y < h; y++) {
            int off = y * w;
            for (int x = 0; x < w; x++) { long gg = g[off + x]; fv[x] = gg >= INF ? (long) INF * 4 : gg * gg; }
            int k = 0;
            v[0] = 0; z[0] = Float.NEGATIVE_INFINITY; z[1] = Float.POSITIVE_INFINITY;
            for (int q = 1; q < w; q++) {
                float s;
                while (true) {
                    int p = v[k];
                    s = (float) (((fv[q] + (long) q * q) - (fv[p] + (long) p * p)) / (2.0 * (q - p)));
                    if (s <= z[k] && k > 0) { k--; continue; }
                    break;
                }
                if (s <= z[k]) { v[0] = q; z[0] = Float.NEGATIVE_INFINITY; z[1] = Float.POSITIVE_INFINITY; k = 0; continue; }
                k++;
                v[k] = q; z[k] = s; z[k + 1] = Float.POSITIVE_INFINITY;
            }
            k = 0;
            for (int q = 0; q < w; q++) {
                while (z[k + 1] < q) k++;
                int p = v[k];
                long d = (long) (q - p) * (q - p) + fv[p];
                out[off + q] = (int) Math.min(Integer.MAX_VALUE, d);
            }
        }
        return out;
    }
}
