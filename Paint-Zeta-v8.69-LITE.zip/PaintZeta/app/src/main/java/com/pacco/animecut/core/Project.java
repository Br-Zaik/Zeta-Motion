package com.pacco.animecut.core;

import android.graphics.Bitmap;
import android.graphics.Rect;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * El documento: una lista de capas del mismo tamano, mas la capa de
 * seleccion (lo azul). Igual que en Ibis.
 */
public class Project {

    /** Indice especial: la capa de seleccion esta activa y se pinta lo azul. */
    public static final int SEL = -1;

    public int w;
    public int h;
    public final List<Layer> layers = new ArrayList<Layer>();
    public byte[] selection;
    public byte[] barrier;
    public int active = 0;

    // ---------------- v8.26 Colorear manga ----------------
    /** Zonas protegidas "No colorear" (globos, rayas de velocidad...). null = ninguna. */
    public byte[] protect;
    /** El preset "Colorear manga" esta activo (se guarda con la obra). */
    public boolean mangaMode;
    /** v8.39: fondo para MIRAR elegido en esta obra (indice de CanvasView.VIEW_BG; -1 = sin elegir). */
    public int viewBg = -1;
    /**
     * v8.39: copia de "como era la capa antes de borrar el fondo" (para Restaurar). Vive aqui
     * para guardarse con la obra: Restaurar sigue funcionando al cerrar y volver a abrir.
     * restorePx = copia en memoria; restorePng = la misma copia ya comprimida (al guardar o
     * al abrir la obra); restoreVer cambia cada vez que la copia cambia.
     */
    public Layer restoreLayer;

    /** v8.40 Color por zonas: zonas aplicadas (en orden), estilo del panel y paleta de la referencia. */
    public java.util.List<ZoneTone.Zone> zones = new java.util.ArrayList<ZoneTone.Zone>();
    public ZoneTone.Style zoneStyle = new ZoneTone.Style();
    public java.util.List<ZoneTone.Group> zonePalette = new java.util.ArrayList<ZoneTone.Group>();
    public boolean zoneMode;
    /** Brillo de contorno y fondo: {color brillo, direccion, ancho 1..10, color arriba, color abajo}. */
    public int[] zoneFx = {0xFFFFB3C6, 1, 4, 0xFFF6DCE3, 0xFFB7A6B6};
    public int[] restorePx;
    public int restoreVer;
    public byte[] restorePng;
    public int restorePngVer = -1;

    /** v8.39: al girar, voltear o recortar el lienzo la copia para Restaurar ya no calza. */
    public void dropRestore() {
        restoreLayer = null;
        restorePx = null;
        restorePng = null;
        restoreVer++;
    }
    /** Sube al girar, voltear o ampliar el lienzo (para caches que dependen de la forma). */
    public int geomVersion;

    /** Muestra de color con nombre (paleta de la obra). */
    public static final class Swatch {
        public String name;
        public int color;
        public Swatch(String name, int color) {
            this.name = name == null ? "" : name;
            this.color = color;
        }
    }
    /** Paleta de la obra: se guarda con el proyecto. */
    public final List<Swatch> swatches = new ArrayList<Swatch>();
    /**
     * Copia reducida (PNG) de la imagen de referencia de colores, solo si el usuario
     * eligio guardarla con la obra. NUNCA se exporta ni se dibuja en el lienzo.
     */
    public byte[] refImagePng;

    public boolean hasProtect() {
        if (protect == null) return false;
        for (byte b : protect) if (b != 0) return true;
        return false;
    }

    private int[] ref;
    private boolean refDirty = true;

    /** Proyecto nuevo con la imagen en la primera capa. */
    public Project(Bitmap img) {
        this.w = img.getWidth();
        this.h = img.getHeight();
        int[] px = new int[w * h];
        img.getPixels(px, 0, w, 0, 0, w, h);
        layers.add(new Layer("imagen", px));
        selection = new byte[w * h];
        active = 0;
    }

    /** Proyecto vacio, para cargar desde archivo. */
    public Project(int w, int h) {
        this.w = w;
        this.h = h;
        selection = new byte[w * h];
    }

    public Layer activeLayer() {
        return active >= 0 && active < layers.size() ? layers.get(active) : null;
    }

    public boolean isSelectionLayerActive() {
        return active == SEL;
    }

    /** Sube cada vez que cambian los pixeles (para saber cuando rehacer calculos). */
    public volatile int version;

    public void markDirty() {
        refDirty = true;
        version++;
    }

    /**
     * Como se ve todo junto (sin fondo de vista). Es lo que miran la varita,
     * el gotero y el balde, igual que "Lienzo" en Ibis.
     */
    public int[] ref() {
        if (ref == null || ref.length != w * h) {
            ref = new int[w * h];
            refDirty = true;
        }
        if (!refDirty) return ref;
        Arrays.fill(ref, 0);
        boolean anyClip = false;
        for (Layer l : layers) if (l.clip) anyClip = true;
        // alfa de la capa base (para el recorte), solo si hace falta
        byte[] base = anyClip ? new byte[ref.length] : null;
        boolean baseSeen = false, baseHidden = false;
        for (Layer l : layers) {
            boolean clipped = l.clip && baseSeen;
            if (!clipped) {
                baseSeen = true;
                baseHidden = !l.visible || l.opacity <= 0;
            }
            if (clipped && baseHidden) continue;
            boolean isBase = base != null && !clipped;
            if (isBase) Arrays.fill(base, (byte) 0);
            if (!l.visible || l.opacity <= 0) continue;
            int op = l.opacity, md = l.mode;
            ColorAdjust adj = l.adjuster();
            int[] s = l.denseOrNull();
            if (s != null && s.length == ref.length) {
                for (int i = 0; i < ref.length; i++) {
                    int c = s[i];
                    if (adj != null) c = adj.apply(c);
                    int ca = c >>> 24;
                    if (isBase) base[i] = (byte) ca;
                    if (clipped) ca = ca * (base[i] & 0xFF) / 255;
                    int sa = (ca * op) / 255;
                    if (sa == 0) continue;
                    ref[i] = blend(ref[i], c, md, sa);
                }
                continue;
            }
            Layer.Packed pk = l.snapshot(w, h);
            if (pk.empty()) continue;
            int[] buf = new int[pk.w];
            for (int yy = 0; yy < pk.h; yy++) {
                pk.row(pk.y + yy, buf);
                int dst = (pk.y + yy) * w + pk.x;
                for (int xx = 0; xx < pk.w; xx++) {
                    int c = buf[xx];
                    if (adj != null) c = adj.apply(c);
                    int ca = c >>> 24;
                    int k = dst + xx;
                    if (isBase) base[k] = (byte) ca;
                    if (clipped) ca = ca * (base[k] & 0xFF) / 255;
                    int sa = (ca * op) / 255;
                    if (sa == 0) continue;
                    ref[k] = blend(ref[k], c, md, sa);
                }
            }
        }
        refDirty = false;
        return ref;
    }

    // ---------------- modos de mezcla (como Ibis) ----------------

    private static int ch(int b, int s, int mode) {
        switch (mode) {
            case Layer.MODE_MULTIPLY:
                return b * s / 255;
            case Layer.MODE_SCREEN:
                return 255 - (255 - b) * (255 - s) / 255;
            case Layer.MODE_ADD:
            case Layer.MODE_ADD_GLOW:
                return Math.min(255, b + s);
            case Layer.MODE_OVERLAY:
                return b < 128 ? 2 * b * s / 255 : 255 - 2 * (255 - b) * (255 - s) / 255;
            case Layer.MODE_DARKEN:
                return Math.min(b, s);
            case Layer.MODE_LIGHTEN:
                return Math.max(b, s);
            case Layer.MODE_COLOR_BURN:
                return burn(b, s);
            case Layer.MODE_LINEAR_BURN:
                return Math.max(0, b + s - 255);
            case Layer.MODE_COLOR_DODGE:
            case Layer.MODE_GLOW_DODGE:
                return dodge(b, s);
            case Layer.MODE_SOFT_LIGHT: {
                // W3C: suave, nunca quema ni lava
                float cb = b / 255f, cs = s / 255f, r;
                if (cs <= 0.5f) r = cb - (1f - 2f * cs) * cb * (1f - cb);
                else {
                    float d = cb <= 0.25f ? ((16f * cb - 12f) * cb + 4f) * cb : (float) Math.sqrt(cb);
                    r = cb + (2f * cs - 1f) * (d - cb);
                }
                return clamp255(Math.round(r * 255f));
            }
            case Layer.MODE_HARD_LIGHT:
                return s < 128 ? 2 * b * s / 255 : 255 - 2 * (255 - b) * (255 - s) / 255;
            case Layer.MODE_VIVID_LIGHT:
                return s < 128 ? burn(b, 2 * s) : dodge(b, 2 * s - 255);
            case Layer.MODE_LINEAR_LIGHT:
                return clamp255(b + 2 * s - 255);
            case Layer.MODE_PIN_LIGHT:
                return s < 128 ? Math.min(b, 2 * s) : Math.max(b, 2 * (s - 128));
            case Layer.MODE_HARD_MIX:
                return b + s >= 255 ? 255 : 0;
            case Layer.MODE_DIFFERENCE:
                return Math.abs(b - s);
            case Layer.MODE_EXCLUSION:
                return b + s - 2 * b * s / 255;
            case Layer.MODE_SUBTRACT:
                return Math.max(0, b - s);
            case Layer.MODE_DIVIDE:
                return s == 0 ? 255 : Math.min(255, b * 255 / s);
            default:
                return s;
        }
    }

    private static int clamp255(int v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

    private static int burn(int b, int s) {
        if (b >= 255) return 255;
        if (s <= 0) return 0;
        return Math.max(0, 255 - (255 - b) * 255 / Math.min(255, s));
    }

    private static int dodge(int b, int s) {
        if (b <= 0) return 0;
        if (s >= 255) return 255;
        return Math.min(255, b * 255 / (255 - s));
    }

    /** v8.52: modos que miran el color entero (Tono, Saturacion, Luminosidad), segun la norma W3C. */
    private static int nonSeparable(int mode, int br, int bg, int bb, int sr, int sg, int sb) {
        if (mode == Layer.MODE_LUMINOSITY) return colorBlend(sr, sg, sb, br, bg, bb);
        int satOf, hr, hg, hb;
        if (mode == Layer.MODE_HUE) { hr = sr; hg = sg; hb = sb; satOf = sat(br, bg, bb); }
        else { hr = br; hg = bg; hb = bb; satOf = sat(sr, sg, sb); }
        int c = setSat(hr, hg, hb, satOf);
        return colorBlend(br, bg, bb, (c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF);
    }

    private static int sat(int r, int g, int b) {
        return Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b));
    }

    /** SetSat: misma forma de color, con la saturacion pedida (0..255). */
    private static int setSat(int r, int g, int b, int s) {
        int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
        if (mx <= mn) return 0;
        int d = mx - mn;
        int nr = (r - mn) * s / d, ng = (g - mn) * s / d, nb = (b - mn) * s / d;
        return (nr << 16) | (ng << 8) | nb;
    }

    /**
     * El color de src ya mezclado con lo de abajo segun el modo. Donde abajo
     * es transparente se usa el color propio (como en Ibis). Guarda el alfa de src.
     */
    public static int mixMode(int dst, int src, int mode) {
        if (mode == Layer.MODE_NORMAL) return src;
        int da = dst >>> 24;
        if (da == 0) return src;
        int sr = (src >> 16) & 0xFF, sg = (src >> 8) & 0xFF, sb = src & 0xFF;
        int br = (dst >> 16) & 0xFF, bg = (dst >> 8) & 0xFF, bb = dst & 0xFF;
        int r, g, b;
        if (mode == Layer.MODE_DARKER_COLOR || mode == Layer.MODE_LIGHTER_COLOR) {
            // v8.57: el color entero de la capa o el de abajo, el de menor (o mayor) luminosidad
            int ls = 30 * sr + 59 * sg + 11 * sb, lb = 30 * br + 59 * bg + 11 * bb;
            boolean takeSrc = mode == Layer.MODE_DARKER_COLOR ? ls < lb : ls > lb;
            r = takeSrc ? sr : br;
            g = takeSrc ? sg : bg;
            b = takeSrc ? sb : bb;
        } else if (mode == Layer.MODE_COLOR || mode >= Layer.MODE_HUE && mode <= Layer.MODE_LUMINOSITY) {
            int c = mode == Layer.MODE_COLOR ? colorBlend(br, bg, bb, sr, sg, sb) : nonSeparable(mode, br, bg, bb, sr, sg, sb);
            r = (c >> 16) & 0xFF;
            g = (c >> 8) & 0xFF;
            b = c & 0xFF;
        } else {
            r = ch(br, sr, mode);
            g = ch(bg, sg, mode);
            b = ch(bb, sb, mode);
        }
        if (da < 255) {
            r = (sr * (255 - da) + r * da) / 255;
            g = (sg * (255 - da) + g * da) / 255;
            b = (sb * (255 - da) + b * da) / 255;
        }
        return (src & 0xFF000000) | (r << 16) | (g << 8) | b;
    }

    /**
     * Modo "Color" de la norma W3C (Compositing and Blending): SetLum(Cs, Lum(Cb)).
     * Toma tono y saturacion de la capa y la luminosidad de lo de abajo: tiñe
     * grises y tramas sin oscurecerlos mas. Lum = 0.3 R + 0.59 G + 0.11 B.
     */
    public static int colorBlend(int br, int bg, int bb, int sr, int sg, int sb) {
        float lb = (0.3f * br + 0.59f * bg + 0.11f * bb) / 255f;
        float r = sr / 255f, g = sg / 255f, b = sb / 255f;
        float d = lb - (0.3f * r + 0.59f * g + 0.11f * b);
        r += d;
        g += d;
        b += d;
        // ClipColor
        float l = 0.3f * r + 0.59f * g + 0.11f * b;
        float n = Math.min(r, Math.min(g, b)), x = Math.max(r, Math.max(g, b));
        if (n < 0f) {
            float k = l - n;
            if (k > 1e-6f) {
                r = l + (r - l) * l / k;
                g = l + (g - l) * l / k;
                b = l + (b - l) * l / k;
            }
        }
        if (x > 1f) {
            float k = x - l;
            if (k > 1e-6f) {
                r = l + (r - l) * (1f - l) / k;
                g = l + (g - l) * (1f - l) / k;
                b = l + (b - l) * (1f - l) / k;
            }
        }
        int ir = Math.round(r * 255f), ig = Math.round(g * 255f), ib = Math.round(b * 255f);
        ir = ir < 0 ? 0 : ir > 255 ? 255 : ir;
        ig = ig < 0 ? 0 : ig > 255 ? 255 : ig;
        ib = ib < 0 ? 0 : ib > 255 ? 255 : ib;
        return (ir << 16) | (ig << 8) | ib;
    }

    /** Bloquear alfa: cambia el color pero deja la transparencia como estaba. */
    public static int lockOver(int dst, int src, int sa) {
        int da = dst >>> 24;
        if (da == 0 || sa <= 0) return dst;
        int r = (((src >> 16) & 0xFF) * sa + ((dst >> 16) & 0xFF) * (255 - sa)) / 255;
        int g = (((src >> 8) & 0xFF) * sa + ((dst >> 8) & 0xFF) * (255 - sa)) / 255;
        int b = ((src & 0xFF) * sa + (dst & 0xFF) * (255 - sa)) / 255;
        return (da << 24) | (r << 16) | (g << 8) | b;
    }

    /**
     * Pintado "plano" (Saturacion de opacidad de Ibis): repasar con el mismo
     * color no oscurece; la opacidad nunca pasa de la elegida.
     */
    public static int flatOver(int dst, int src, int sa) {
        int da = dst >>> 24;
        if (da == 0) return (src & 0x00FFFFFF) | (sa << 24);
        int na = Math.max(da, sa);
        int dw = (da * (255 - sa)) / 255;
        int tot = sa + dw;
        if (tot <= 0) return dst;
        int r = (((src >> 16) & 0xFF) * sa + ((dst >> 16) & 0xFF) * dw) / tot;
        int g = (((src >> 8) & 0xFF) * sa + ((dst >> 8) & 0xFF) * dw) / tot;
        int b = ((src & 0xFF) * sa + (dst & 0xFF) * dw) / tot;
        return (na << 24) | (r << 16) | (g << 8) | b;
    }

    /**
     * v8.57: LA forma de poner una capa (color src, alfa ya con opacidad sa) sobre lo de abajo con
     * su modo. La usan la pantalla, las miniaturas, la vista previa de filtros y el PNG: dan igual.
     * "Sobreexponer brillo" y "Anadir brillo": aproximacion propia (ver adentro).
     */
    public static int blend(int dst, int src, int mode, int sa) {
        if (sa <= 0) return dst;
        if (mode == Layer.MODE_NORMAL) return over(dst, src, sa);
        if (mode != Layer.MODE_GLOW_DODGE && mode != Layer.MODE_ADD_GLOW) return over(dst, mixMode(dst, src, mode), sa);
        // Aproximacion propia de los modos "brillo": misma cuenta que Sobreexponer color / Anadir,
        // pero la opacidad pesa con una curva que sube rapido (1-(1-a)^2): en lo semitransparente
        // (bordes de un aerografo) el brillo es mas intenso; con opacidad llena es igual.
        if ((dst >>> 24) == 0) return over(dst, src, sa);   // nada abajo: como Normal
        int g = 255 - (255 - sa) * (255 - sa) / 255;
        return over(dst, mixMode(dst, src, mode), g);
    }

    /** Pone src con alfa sa encima de dst. Todo sin premultiplicar. */
    public static int over(int dst, int src, int sa) {
        if (sa >= 255) return (src & 0x00FFFFFF) | 0xFF000000;
        int da = dst >>> 24;
        if (da == 0) return (src & 0x00FFFFFF) | (sa << 24);
        int oa = sa + (da * (255 - sa)) / 255;
        if (oa == 0) return 0;
        int dw = (da * (255 - sa)) / 255;
        int r = (((src >> 16) & 0xFF) * sa + ((dst >> 16) & 0xFF) * dw) / oa;
        int g = (((src >> 8) & 0xFF) * sa + ((dst >> 8) & 0xFF) * dw) / oa;
        int b = ((src & 0xFF) * sa + (dst & 0xFF) * dw) / oa;
        return (oa << 24) | (r << 16) | (g << 8) | b;
    }

    public boolean hasSelection() {
        for (byte b : selection) if (b != 0) return true;
        return false;
    }

    public void clearSelection() {
        Arrays.fill(selection, (byte) 0);
    }

    public Rect fullRect() {
        return new Rect(0, 0, w, h);
    }

    public Rect selectionBounds() {
        return HoleFill.bounds(selection, w, h);
    }

    /** Imagen reducida de todo junto, para miniaturas de la galeria. */
    public Bitmap previewBitmap(int maxSide) {
        return previewBitmap(maxSide, null);
    }

    /**
     * v8.39: miniatura sobre el fondo que el usuario dejo para mirar (verde, negro, cuadros...).
     * bg = {color1, color2} de cuadros; null = blanco como antes. Solo la miniatura: el PNG
     * exportado sigue transparente.
     */
    public Bitmap previewBitmap(int maxSide, int[] bg) {
        int m = Math.max(w, h);
        float sc = m > maxSide ? (float) maxSide / m : 1f;
        int tw = Math.max(1, Math.round(w * sc)), th = Math.max(1, Math.round(h * sc));
        Bitmap b = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
        int[] row = new int[tw];
        List<Layer> ls = new ArrayList<Layer>(layers);
        ColorAdjust[] adjs = new ColorAdjust[ls.size()];
        for (int k = 0; k < adjs.length; k++) adjs[k] = ls.get(k).adjuster();
        for (int y = 0; y < th; y++) {
            int sy = Math.min(h - 1, y * h / th);
            for (int x = 0; x < tw; x++) {
                int sx = Math.min(w - 1, x * w / tw);
                // sobre blanco (o el fondo de vista de la obra), para que se vea en la galeria
                int c = bg == null ? 0xFFFFFFFF : bg[(((x / 10) + (y / 10)) & 1) == 0 ? 0 : 1];
                int baseA = -1;
                boolean baseHidden = false;
                for (int li = 0; li < ls.size(); li++) {
                    Layer l = ls.get(li);
                    boolean clipped = l.clip && baseA >= 0;
                    if (clipped && baseHidden) continue;
                    if (!clipped) baseHidden = !l.visible || l.opacity <= 0;
                    if (!l.visible || l.opacity <= 0) {
                        if (!clipped) baseA = 0;
                        continue;
                    }
                    int v = l.at(sx, sy, w);
                    if (adjs[li] != null) v = adjs[li].apply(v);
                    int ca = v >>> 24;
                    if (clipped) ca = ca * baseA / 255;
                    else baseA = ca;
                    int sa = (ca * l.opacity) / 255;
                    if (sa > 0) c = blend(c, v, l.mode, sa);
                }
                row[x] = c;
            }
            b.setPixels(row, 0, tw, 0, y, tw, 1);
        }
        return b;
    }

    // ---------------- girar y voltear todo junto ----------------

    public void rotate90(boolean cw) {
        int ow = w, oh = h;
        for (int k = 0; k < layers.size(); k++) {
            Layer l = layers.get(k);
            boolean wasPacked = l.isPacked();
            l.setPx(rotInts(l.px(), ow, oh, cw));
            if (wasPacked && k != active) l.pack(oh, ow);
        }
        selection = rotBytes(selection, ow, oh, cw);
        if (protect != null) protect = rotBytes(protect, ow, oh, cw);
        geomVersion++;
        dropRestore();
        barrier = null;
        ref = null;
        w = oh;
        h = ow;
        markDirty();
    }

    /**
     * Agranda el lienzo agregando margenes transparentes (v8.25). Sirve, por
     * ejemplo, para enderezar con Marioneta un personaje que al quedar de pie
     * es mas alto que la imagen original. Las capas no se reescalan.
     */
    public void enlarge(int left, int top, int right, int bottom) {
        left = Math.max(0, left); top = Math.max(0, top);
        right = Math.max(0, right); bottom = Math.max(0, bottom);
        if (left + top + right + bottom == 0) return;
        int ow = w, oh = h, nw = w + left + right, nh = h + top + bottom;
        for (int k = 0; k < layers.size(); k++) {
            Layer l = layers.get(k);
            boolean wasPacked = l.isPacked();
            int[] src = l.px();
            int[] dst = new int[nw * nh];
            for (int y = 0; y < oh; y++) System.arraycopy(src, y * ow, dst, (y + top) * nw + left, ow);
            l.setPx(dst);
            if (wasPacked && k != active) l.pack(nw, nh);
        }
        byte[] ns = new byte[nw * nh];
        if (selection != null)
            for (int y = 0; y < oh; y++) System.arraycopy(selection, y * ow, ns, (y + top) * nw + left, ow);
        selection = ns;
        if (protect != null) {
            byte[] np = new byte[nw * nh];
            for (int y = 0; y < oh; y++) System.arraycopy(protect, y * ow, np, (y + top) * nw + left, ow);
            protect = np;
        }
        geomVersion++;
        dropRestore();
        barrier = null;
        ref = null;
        w = nw;
        h = nh;
        markDirty();
    }

    /**
     * v8.27: lo contrario de enlarge (para Deshacer "Ampliar lienzo"): quita esos
     * margenes. Solo se usa al deshacer, cuando los margenes ya quedaron como estaban.
     */
    public void crop(int left, int top, int right, int bottom) {
        left = Math.max(0, left); top = Math.max(0, top);
        right = Math.max(0, right); bottom = Math.max(0, bottom);
        if (left + top + right + bottom == 0) return;
        int ow = w, nw = w - left - right, nh = h - top - bottom;
        if (nw <= 0 || nh <= 0) return;
        for (int k = 0; k < layers.size(); k++) {
            Layer l = layers.get(k);
            boolean wasPacked = l.isPacked();
            int[] src = l.px();
            int[] dst = new int[nw * nh];
            for (int y = 0; y < nh; y++) System.arraycopy(src, (y + top) * ow + left, dst, y * nw, nw);
            l.setPx(dst);
            if (wasPacked && k != active) l.pack(nw, nh);
        }
        byte[] ns = new byte[nw * nh];
        if (selection != null)
            for (int y = 0; y < nh; y++) System.arraycopy(selection, (y + top) * ow + left, ns, y * nw, nw);
        selection = ns;
        if (protect != null) {
            byte[] np = new byte[nw * nh];
            for (int y = 0; y < nh; y++) System.arraycopy(protect, (y + top) * ow + left, np, y * nw, nw);
            protect = np;
        }
        geomVersion++;
        dropRestore();
        barrier = null;
        ref = null;
        w = nw;
        h = nh;
        markDirty();
    }

    /**
     * v8.42 (Mejorar imagen): toda la obra pasa a nw x nh. px[k] = pixeles nuevos de la capa k
     * (null = capa vacia). La seleccion, las zonas protegidas y las de Color por zonas se escalan.
     */
    public void rescale(int nw, int nh, int[][] px) {
        int ow = w, oh = h;
        for (int k = 0; k < layers.size(); k++) {
            Layer l = layers.get(k);
            if (px[k] == null) l.clearTo(nw, nh);
            else {
                l.setPx(px[k]);
                if (k != active) l.pack(nw, nh);
            }
        }
        selection = scaleMask(selection, ow, oh, nw, nh);
        if (selection == null) selection = new byte[nw * nh];
        protect = scaleMask(protect, ow, oh, nw, nh);
        java.util.List<ZoneTone.Zone> nz = new java.util.ArrayList<ZoneTone.Zone>();
        for (ZoneTone.Zone z : zones) {
            int x0 = (int) ((long) z.x * nw / ow), y0 = (int) ((long) z.y * nh / oh);
            int x1 = (int) (((long) (z.x + z.w) * nw + ow - 1) / ow), y1 = (int) (((long) (z.y + z.h) * nh + oh - 1) / oh);
            int zw = Math.max(1, Math.min(nw, x1) - x0), zh = Math.max(1, Math.min(nh, y1) - y0);
            byte[] m = new byte[zw * zh];
            for (int y = 0; y < zh; y++) {
                int sy = Math.min(z.h - 1, Math.max(0, (int) ((long) (y0 + y) * oh / nh) - z.y));
                for (int x = 0; x < zw; x++) {
                    int sx = Math.min(z.w - 1, Math.max(0, (int) ((long) (x0 + x) * ow / nw) - z.x));
                    m[y * zw + x] = z.m[sy * z.w + sx];
                }
            }
            nz.add(new ZoneTone.Zone(x0, y0, zw, zh, m, z.s));
        }
        zones = nz;
        sizeChanged(nw, nh);
    }

    /** Despues de cambiar el tamano: caches fuera. */
    public void sizeChanged(int nw, int nh) {
        geomVersion++;
        dropRestore();
        barrier = null;
        ref = null;
        w = nw;
        h = nh;
        markDirty();
    }

    private static byte[] scaleMask(byte[] m, int ow, int oh, int nw, int nh) {
        if (m == null) return null;
        byte[] r = new byte[nw * nh];
        for (int y = 0; y < nh; y++) {
            int so = (int) ((long) y * oh / nh) * ow, d = y * nw;
            for (int x = 0; x < nw; x++) r[d + x] = m[so + (int) ((long) x * ow / nw)];
        }
        return r;
    }

    public void flip(boolean horizontal) {
        for (int k = 0; k < layers.size(); k++) {
            Layer l = layers.get(k);
            boolean wasPacked = l.isPacked();
            l.setPx(flipInts(l.px(), w, h, horizontal));
            if (wasPacked && k != active) l.pack(w, h);
        }
        selection = flipBytes(selection, w, h, horizontal);
        if (protect != null) protect = flipBytes(protect, w, h, horizontal);
        geomVersion++;
        dropRestore();
        barrier = null;
        markDirty();
    }

    /** Empaca las capas que no se estan usando para liberar memoria. */
    public void packInactive() {
        for (int k = 0; k < layers.size(); k++) {
            if (k == active) continue;
            Layer l = layers.get(k);
            if (!l.isPacked()) l.pack(w, h);
        }
    }

    /** Memoria que ocupan las capas ahora (aprox). */
    public long layersMemory() {
        long s = 0;
        for (Layer l : layers) s += l.javaMemory();
        return s;
    }

    private static int[] rotInts(int[] s, int w, int h, boolean cw) {
        int[] d = new int[s.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int nx = cw ? h - 1 - y : y, ny = cw ? x : w - 1 - x;
                d[ny * h + nx] = s[y * w + x];
            }
        }
        return d;
    }

    private static byte[] rotBytes(byte[] s, int w, int h, boolean cw) {
        byte[] d = new byte[s.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int nx = cw ? h - 1 - y : y, ny = cw ? x : w - 1 - x;
                d[ny * h + nx] = s[y * w + x];
            }
        }
        return d;
    }

    public static int[] flipInts(int[] s, int w, int h, boolean hor) {
        int[] d = new int[s.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int nx = hor ? w - 1 - x : x, ny = hor ? y : h - 1 - y;
                d[ny * w + nx] = s[y * w + x];
            }
        }
        return d;
    }

    private static byte[] flipBytes(byte[] s, int w, int h, boolean hor) {
        byte[] d = new byte[s.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int nx = hor ? w - 1 - x : x, ny = hor ? y : h - 1 - y;
                d[ny * w + nx] = s[y * w + x];
            }
        }
        return d;
    }
}
