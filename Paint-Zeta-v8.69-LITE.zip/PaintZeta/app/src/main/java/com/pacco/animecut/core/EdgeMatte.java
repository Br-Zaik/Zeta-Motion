package com.pacco.animecut.core;

/**
 * v8.28: borde del recorte de "Separar y quitar fondo" (rayas).
 *
 * Antes la mascara del personaje se suavizaba 1 px a ciegas (MaskOps.feather): el limite del
 * relleno por cuencas caia a veces EN MEDIO de la linea negra (se perdia su mitad de afuera) y
 * el filo mezclado con el fondo quedaba con el color del fondo (halo).
 *
 * Ahora:
 *  1) la linea del contorno pegada al personaje (hasta 4 px) se RESCATA: es del personaje;
 *  2) en la franja de 1 px a cada lado del limite, el alfa sale de mezclar el color del fondo
 *     cercano (B) con el del personaje cercano (F): a = proyeccion de C sobre B->F;
 *  3) ese filo se DESCONTAMINA: C' = (C - (1-a)*B) / a  (sin color del fondo viejo).
 *  Si el fondo y el personaje tienen casi el mismo color, el borde queda duro (sin mezcla).
 */
public final class EdgeMatte {
    private EdgeMatte() { }

    /**
     * @param px    colores de la capa (ARGB)
     * @param keep  255 = personaje, 0 = fondo; se actualiza (lineas rescatadas)
     * @param lines 255 donde hay linea (puede ser null)
     * @return pares {indice, (alfa 0-255 relativo << 24) | rgb} para los pixeles del filo
     */
    public static int[] refine(int[] px, int w, int h, byte[] keep, byte[] lines, int maxRescue) {
        int n = w * h;
        // 1) rescatar la linea pegada al personaje (BFS por niveles)
        if (lines != null && maxRescue > 0) {
            int[] cur = new int[1024], nxt = new int[1024];
            int nc = 0;
            for (int y = 1; y < h - 1; y++) {
                for (int x = 1; x < w - 1; x++) {
                    int i = y * w + x;
                    if (keep[i] != 0) continue;
                    if (lines[i] == 0) continue;
                    if (keep[i - 1] != 0 || keep[i + 1] != 0 || keep[i - w] != 0 || keep[i + w] != 0) {
                        if (nc == cur.length) cur = grow(cur);
                        cur[nc++] = i;
                    }
                }
            }
            for (int lvl = 0; lvl < maxRescue && nc > 0; lvl++) {
                int nn = 0;
                for (int k = 0; k < nc; k++) keep[cur[k]] = (byte) 255;
                for (int k = 0; k < nc; k++) {
                    int i = cur[k], y = i / w, x = i - y * w;
                    if (x <= 0 || y <= 0 || x >= w - 1 || y >= h - 1) continue;
                    int[] nb = {i - 1, i + 1, i - w, i + w};
                    for (int j : nb) {
                        if (keep[j] != 0 || lines[j] == 0) continue;
                        keep[j] = (byte) 254; // marcado para el siguiente nivel
                        if (nn == nxt.length) nxt = grow(nxt);
                        nxt[nn++] = j;
                    }
                }
                int[] t = cur; cur = nxt; nxt = t; nc = nn;
            }
            for (int k = 0; k < nc; k++) keep[cur[k]] = 0;
            for (int i = 0; i < n; i++) if ((keep[i] & 0xFF) == 254) keep[i] = (byte) 255;
        }
        // 2) franja del limite
        byte[] band = new byte[n];
        int bandN = 0;
        for (int y = 1; y < h - 1; y++) {
            for (int x = 1; x < w - 1; x++) {
                int i = y * w + x;
                boolean k = keep[i] != 0;
                boolean edge = (keep[i - 1] != 0) != k || (keep[i + 1] != 0) != k
                        || (keep[i - w] != 0) != k || (keep[i + w] != 0) != k;
                if (edge) { band[i] = 1; bandN++; }
            }
        }
        int[] out = new int[Math.max(2, bandN * 2)];
        int no = 0;
        for (int y = 3; y < h - 3; y++) {
            for (int x = 3; x < w - 3; x++) {
                int i = y * w + x;
                if (band[i] == 0) continue;
                long fr = 0, fg = 0, fb = 0, br = 0, bg = 0, bb = 0;
                int fn = 0, bn = 0;
                for (int dy = -3; dy <= 3; dy++) {
                    int row = (y + dy) * w;
                    for (int dx = -3; dx <= 3; dx++) {
                        int j = row + x + dx;
                        if (band[j] != 0) continue;
                        int c = px[j];
                        if ((c >>> 24) < 200) continue;
                        if (keep[j] != 0) { fr += (c >> 16) & 255; fg += (c >> 8) & 255; fb += c & 255; fn++; }
                        else { br += (c >> 16) & 255; bg += (c >> 8) & 255; bb += c & 255; bn++; }
                    }
                }
                boolean k = keep[i] != 0;
                int c = px[i];
                int a;
                int rgb = c & 0xFFFFFF;
                if (fn == 0 || bn == 0) {
                    a = k ? 255 : 0;
                } else {
                    float Fr = fr / (float) fn, Fg = fg / (float) fn, Fb = fb / (float) fn;
                    float Br = br / (float) bn, Bg = bg / (float) bn, Bb = bb / (float) bn;
                    float dr = Fr - Br, dg = Fg - Bg, db = Fb - Bb;
                    float l2 = dr * dr + dg * dg + db * db;
                    if (l2 < 30f * 30f) {
                        a = k ? 255 : 0;   // colores parecidos: borde duro
                    } else {
                        int cr = (c >> 16) & 255, cg = (c >> 8) & 255, cb = c & 255;
                        float t = ((cr - Br) * dr + (cg - Bg) * dg + (cb - Bb) * db) / l2;
                        t = Math.max(0f, Math.min(1f, t));
                        // el lado del personaje no baja de la mitad; el del fondo no sube de la mitad
                        if (k) t = Math.max(t, 0.5f); else t = Math.min(t, 0.5f);
                        a = Math.round(t * 255f);
                        if (a > 0 && a < 255) {
                            float inv = 1f / t, q = 1f - t;
                            int nr = clamp(Math.round((cr - q * Br) * inv));
                            int ng = clamp(Math.round((cg - q * Bg) * inv));
                            int nb2 = clamp(Math.round((cb - q * Bb) * inv));
                            rgb = (nr << 16) | (ng << 8) | nb2;
                        }
                    }
                }
                if (no + 2 > out.length) out = grow(out);
                out[no++] = i;
                out[no++] = (a << 24) | rgb;
            }
        }
        int[] r = new int[no];
        System.arraycopy(out, 0, r, 0, no);
        return r;
    }

    private static int clamp(int v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

    private static int[] grow(int[] a) {
        int[] b = new int[a.length * 2];
        System.arraycopy(a, 0, b, 0, a.length);
        return b;
    }
}
