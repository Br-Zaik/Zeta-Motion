package com.pacco.animecut.core;

import android.graphics.Bitmap;
import android.graphics.Rect;

import java.util.Arrays;

/**
 * Una capa de verdad, como en Ibis: tiene sus propios pixeles con
 * transparencia. Los pixeles van en ARGB sin premultiplicar.
 *
 * Memoria: solo la capa elegida esta "abierta" como arreglo de Java para
 * pintar rapido. Las demas se guardan "empacadas": solo el rectangulo con
 * dibujo, dentro de un Bitmap. Desde Android 8 los Bitmap viven en la memoria
 * grande del telefono (no en la de Java, que es chica), asi que se pueden
 * tener muchas capas sin que la app se quede sin memoria.
 */
public class Layer {

    /** Recorte con contenido: rectangulo x,y,w,h dentro del lienzo pw x ph. Nunca se modifica. */
    public static final class Packed {
        public final int x, y, w, h, pw, ph;
        /** null si la capa esta vacia. No premultiplicado. */
        public final Bitmap bmp;

        Packed(int x, int y, int w, int h, int pw, int ph, Bitmap bmp) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.pw = pw;
            this.ph = ph;
            this.bmp = bmp;
        }

        public boolean empty() {
            return bmp == null || w <= 0 || h <= 0;
        }

        /** Pixel suelto (lento: solo para miniaturas). */
        public int at(int sx, int sy) {
            if (empty()) return 0;
            int lx = sx - x, ly = sy - y;
            if (lx < 0 || ly < 0 || lx >= w || ly >= h) return 0;
            return bmp.getPixel(lx, ly);
        }

        /** Llena buf[0..w) con la fila sy de la imagen (sy dentro del recorte). */
        public void row(int sy, int[] buf) {
            bmp.getPixels(buf, 0, w, 0, sy - y, w, 1);
        }
    }

    public String name;
    public boolean visible = true;
    /** 0 a 255. */
    public int opacity = 255;

    // ---- como Ibis: modo de mezcla, recorte y bloqueo de alfa ----
    public static final int MODE_NORMAL = 0, MODE_MULTIPLY = 1, MODE_SCREEN = 2, MODE_ADD = 3, MODE_OVERLAY = 4;
    /** v8.26: "Color" (W3C): tono y saturacion de esta capa, luminosidad de lo de abajo. */
    public static final int MODE_COLOR = 5;
    /**
     * v8.52: los demas modos de Ibis / Procreate. Los numeros quedan fijos (se guardan en la obra).
     */
    public static final int MODE_DARKEN = 6, MODE_COLOR_BURN = 7, MODE_LINEAR_BURN = 8, MODE_LIGHTEN = 9,
            MODE_COLOR_DODGE = 10, MODE_SOFT_LIGHT = 11, MODE_HARD_LIGHT = 12, MODE_LINEAR_LIGHT = 13,
            MODE_PIN_LIGHT = 14, MODE_HARD_MIX = 15, MODE_DIFFERENCE = 16, MODE_EXCLUSION = 17,
            MODE_SUBTRACT = 18, MODE_DIVIDE = 19, MODE_HUE = 20, MODE_SATURATION = 21, MODE_LUMINOSITY = 22,
            MODE_VIVID_LIGHT = 23;
    /**
     * v8.57: los 4 que faltaban para tener los 28 de Clip Studio. "Sobreexponer brillo" y
     * "Anadir brillo" son una APROXIMACION propia (Clip Studio no publica su formula): en los
     * bordes suaves de un pincel el brillo pega mas fuerte que en Sobreexponer color / Anadir.
     */
    public static final int MODE_DARKER_COLOR = 24, MODE_LIGHTER_COLOR = 25, MODE_GLOW_DODGE = 26, MODE_ADD_GLOW = 27;
    /** Nombres como en Clip Studio Paint en espanol. El numero de cada modo NO cambia (se guarda en la obra). */
    public static final String[] MODE_NAMES = {"Normal", "Multiplicar", "Trama", "Añadir", "Superponer", "Color",
            "Oscurecer", "Subexponer color", "Subexponer lineal", "Aclarar",
            "Sobreexponer color", "Luz suave", "Luz fuerte", "Luz lineal",
            "Luz focal", "Mezcla definida", "Diferencia", "Exclusión",
            "Sustraer", "Dividir", "Tono", "Saturación", "Brillo",
            "Luz intensa", "Color más oscuro", "Color más claro", "Sobreexponer brillo", "Añadir brillo"};
    /** Orden de la rueda (el de Clip Studio). */
    public static final int[] MODE_ORDER = {MODE_NORMAL, MODE_DARKEN, MODE_MULTIPLY, MODE_COLOR_BURN, MODE_LINEAR_BURN,
            MODE_SUBTRACT, MODE_LIGHTEN, MODE_SCREEN, MODE_COLOR_DODGE, MODE_GLOW_DODGE, MODE_ADD, MODE_ADD_GLOW,
            MODE_OVERLAY, MODE_SOFT_LIGHT, MODE_HARD_LIGHT, MODE_DIFFERENCE, MODE_DARKER_COLOR, MODE_LIGHTER_COLOR,
            MODE_VIVID_LIGHT, MODE_LINEAR_LIGHT, MODE_PIN_LIGHT, MODE_HARD_MIX, MODE_EXCLUSION, MODE_HUE,
            MODE_SATURATION, MODE_COLOR, MODE_LUMINOSITY, MODE_DIVIDE};
    /** Modo de mezcla con lo de abajo. */
    public int mode = MODE_NORMAL;
    /** Recorte: solo se ve donde la capa de abajo (la base) tiene dibujo. */
    public boolean clip;
    /** Bloquear alfa: se pinta solo donde ya hay dibujo en esta capa. */
    public boolean alphaLock;
    /** v8.24: el balde toma los contornos de las capas marcadas como referencia. */
    public boolean reference;
    /**
     * v8.26 Bloqueo total: no se puede pintar, borrar, rellenar, mover ni deformar
     * (distinto de alphaLock, que si deja pintar sobre lo que ya hay).
     */
    public boolean locked;

    /** v8.26: papel de la capa en "Colorear manga" (sirve aunque el usuario la renombre). */
    public static final int ROLE_NONE = 0, ROLE_INK = 1, ROLE_BASE = 2, ROLE_SHADOW = 3, ROLE_LIGHT = 4, ROLE_SHINE = 5;
    /**
     * v8.27: capa de color AUTOMATICA del balde ("Capa de color automatica"). Se crea
     * una sola vez y se reutiliza para todos los rellenos, este donde este en la lista.
     * Se reconoce por este papel (no por el nombre ni por estar justo encima).
     */
    public static final int ROLE_COLOR = 6;
    /**
     * v8.40 "Color por zonas": capa de las zonas (mapa de degradado), capa del brillo de
     * contorno y capa del fondo degradado. Las maneja la app (se rehacen desde las zonas).
     */
    public static final int ROLE_TONE = 7, ROLE_RIM = 8, ROLE_GRAD = 9;
    /** v8.46: capa de Luz y ambiente (cielo, sol, contraluz...): se rehace al cambiar el ambiente. */
    public static final int ROLE_ATMOS = 10;
    /** v8.48: capa de Estilo de edicion (arriba de todo). */
    public static final int ROLE_LOOK = 11;
    /** v8.52: capa de Toques suaves (rubor, sombra o luz a mano que se difumina sola al soltar). */
    public static final int ROLE_SOFT = 12;
    public static final int ROLE_MAX = 12;
    public int role = ROLE_NONE;

    /**
     * v8.26 "Cambiar color" NO destructivo: tono (-180..180 grados), saturacion y
     * luminosidad (-100..100). Los pixeles guardados no cambian; se aplica al mostrar,
     * al exportar y al combinar. Todo en 0 = sin ajuste.
     */
    public int hue, sat, lit;

    public boolean hasAdjust() {
        return hue != 0 || sat != 0 || lit != 0;
    }

    /** Un ajustador nuevo (con su propia cache; uno por hilo) o null si no hay ajuste. */
    public ColorAdjust adjuster() {
        return hasAdjust() ? new ColorAdjust(hue, sat, lit) : null;
    }

    private volatile int[] dense;
    private volatile Packed packed;

    public Layer(String name, int[] px) {
        this.name = name;
        this.dense = px;
    }

    /** Capa vacia que no gasta memoria hasta que se pinta. */
    public Layer(String name, int w, int h) {
        this.name = name;
        this.packed = new Packed(0, 0, 0, 0, w, h, null);
    }

    private Layer(String name, Packed p) {
        this.name = name;
        this.packed = p;
    }

    /** Capa creada desde un recorte en arreglo (copiar a capa, separar). */
    public static Layer fromCrop(String name, int x, int y, int w, int h, int pw, int ph, int[] crop) {
        if (w <= 0 || h <= 0) return new Layer(name, pw, ph);
        Bitmap b = newBitmap(w, h);
        b.setPixels(crop, 0, w, 0, 0, w, h);
        return new Layer(name, new Packed(x, y, w, h, pw, ph, b));
    }

    /** Capa creada desde un Bitmap ya recortado (al abrir obras). Debe estar sin premultiplicar. */
    public static Layer fromBitmap(String name, int x, int y, Bitmap b, int pw, int ph) {
        return new Layer(name, new Packed(x, y, b.getWidth(), b.getHeight(), pw, ph, b));
    }

    public static Bitmap newBitmap(int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        b.setPremultiplied(false);
        return b;
    }

    /** Los pixeles de todo el lienzo para editar. Si estaba empacada, la abre. */
    public int[] px() {
        int[] d = dense;
        if (d != null) return d;
        synchronized (this) {
            d = dense;
            if (d != null) return d;
            Packed p = packed;
            d = new int[p.pw * p.ph];
            if (!p.empty()) p.bmp.getPixels(d, p.y * p.pw + p.x, p.pw, 0, 0, p.w, p.h);
            dense = d;
            packed = null;
            return d;
        }
    }

    /** Reemplaza todos los pixeles (girar, voltear). */
    public synchronized void setPx(int[] px) {
        dense = px;
        packed = null;
    }

    /** v8.42: el contenido tal cual (denso o empacado), para Deshacer un cambio de tamano de la obra. */
    public synchronized Object content() {
        return dense != null ? dense : packed;
    }

    /** v8.42: vuelve a poner un contenido tomado con content(). */
    public synchronized void setContent(Object c) {
        if (c instanceof int[]) { dense = (int[]) c; packed = null; }
        else { packed = (Packed) c; dense = null; }
    }

    /** v8.42: memoria aproximada de un contenido tomado con content(). */
    public static long contentBytes(Object c) {
        if (c instanceof int[]) return ((int[]) c).length * 4L;
        if (c instanceof Packed && ((Packed) c).bmp != null) return ((Packed) c).bmp.getAllocationByteCount();
        return 64;
    }

    /** v8.42: true si la capa no tiene nada dibujado y esta empacada (no gasta memoria). */
    public synchronized boolean isEmptyPacked() {
        return dense == null && packed != null && packed.empty();
    }

    /** v8.42: la capa queda vacia de ese tamano, sin gastar memoria. */
    public synchronized void clearTo(int w, int h) {
        packed = new Packed(0, 0, 0, 0, w, h, null);
        dense = null;
    }

    public boolean isPacked() {
        return dense == null;
    }

    /** Empaca la capa: pasa solo el rectangulo con dibujo a un Bitmap. */
    public synchronized void pack(int w, int h) {
        int[] d = dense;
        if (d == null || d.length != w * h) return;
        Packed p = crop(d, w, h);
        packed = p;
        dense = null;
    }

    private static Packed crop(int[] d, int w, int h) {
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            int row = y * w, first = -1, last = -1;
            for (int x = 0; x < w; x++) {
                if ((d[row + x] >>> 24) != 0) {
                    first = x;
                    break;
                }
            }
            if (first < 0) continue;
            for (int x = w - 1; x >= first; x--) {
                if ((d[row + x] >>> 24) != 0) {
                    last = x;
                    break;
                }
            }
            if (first < minX) minX = first;
            if (last > maxX) maxX = last;
            if (y < minY) minY = y;
            maxY = y;
        }
        if (maxX < 0) return new Packed(0, 0, 0, 0, w, h, null);
        int cw = maxX - minX + 1, ch = maxY - minY + 1;
        Bitmap b = newBitmap(cw, ch);
        b.setPixels(d, minY * w + minX, w, 0, 0, cw, ch);
        return new Packed(minX, minY, cw, ch, w, h, b);
    }

    /**
     * Foto del contenido para leer sin cambiar la capa (sirve desde otro hilo,
     * por ejemplo al guardar). Si la capa esta abierta, hace un recorte nuevo.
     */
    public Packed snapshot(int w, int h) {
        int[] d = dense;
        if (d != null && d.length == w * h) return crop(d, w, h);
        Packed p = packed;
        if (p != null) return p;
        d = dense;
        if (d != null && d.length == w * h) return crop(d, w, h);
        return new Packed(0, 0, 0, 0, w, h, null);
    }

    public int[] denseOrNull() {
        return dense;
    }

    public Packed packedOrNull() {
        return packed;
    }

    /** Lee un pixel sin abrir la capa (lento si esta empacada). */
    public int at(int x, int y, int w) {
        int[] d = dense;
        if (d != null) return d[y * w + x];
        Packed p = packed;
        if (p != null) return p.at(x, y);
        d = dense;
        return d == null ? 0 : d[y * w + x];
    }

    /** Copia el rectangulo (rx,ry,rw,rh) del lienzo a out, sin abrir la capa. */
    public void read(int rx, int ry, int rw, int rh, int[] out, int w, int h) {
        int[] d = dense;
        if (d != null && d.length == w * h) {
            for (int yy = 0; yy < rh; yy++) System.arraycopy(d, (ry + yy) * w + rx, out, yy * rw, rw);
            return;
        }
        Arrays.fill(out, 0, rw * rh, 0);
        Packed p = snapshot(w, h);
        if (p.empty()) return;
        int ix0 = Math.max(rx, p.x), iy0 = Math.max(ry, p.y);
        int ix1 = Math.min(rx + rw, p.x + p.w), iy1 = Math.min(ry + rh, p.y + p.h);
        if (ix0 >= ix1 || iy0 >= iy1) return;
        p.bmp.getPixels(out, (iy0 - ry) * rw + (ix0 - rx), rw, ix0 - p.x, iy0 - p.y, ix1 - ix0, iy1 - iy0);
    }

    /** Copia todo el lienzo a out (tamano w*h) sin abrir la capa. */
    public void copyTo(int[] out, int w, int h) {
        read(0, 0, w, h, out, w, h);
    }

    /**
     * Rectangulo con contenido (null si esta vacia).
     *
     * Importante: si la capa esta abierta NO usamos snapshot(), porque snapshot()
     * crea un Bitmap recortado. Transformar consulta los limites al empezar y una
     * copia temporal de una imagen grande podia gastar decenas de MB y provocar un
     * cierre antes de que la herramienta llegara a responder.
     */
    public Rect bounds(int w, int h) {
        int[] d = dense;
        if (d != null && d.length == w * h) {
            int minX = w, minY = h, maxX = -1, maxY = -1;
            for (int y = 0; y < h; y++) {
                int row = y * w;
                int first = -1, last = -1;
                for (int x = 0; x < w; x++) {
                    if ((d[row + x] >>> 24) != 0) { first = x; break; }
                }
                if (first < 0) continue;
                for (int x = w - 1; x >= first; x--) {
                    if ((d[row + x] >>> 24) != 0) { last = x; break; }
                }
                if (first < minX) minX = first;
                if (last > maxX) maxX = last;
                if (y < minY) minY = y;
                maxY = y;
            }
            return maxX < 0 ? null : new Rect(minX, minY, maxX + 1, maxY + 1);
        }
        Packed p = packed;
        if (p == null || p.empty()) return null;
        return new Rect(p.x, p.y, p.x + p.w, p.y + p.h);
    }

    /** Memoria aproximada que esta capa mantiene viva (arreglo o Bitmap empacado). */
    public long memoryBytes() {
        int[] d = dense;
        if (d != null) return (long) d.length * 4L;
        Packed p = packed;
        if (p != null && p.bmp != null && !p.bmp.isRecycled()) {
            try { return p.bmp.getAllocationByteCount(); } catch (Throwable ignored) {
                return (long) p.w * p.h * 4L;
            }
        }
        return 0L;
    }

    /** Compatibilidad con el calculo antiguo de memoria Java. */
    public long javaMemory() {
        int[] d = dense;
        return d == null ? 0 : (long) d.length * 4L;
    }

    /** Copia empacada: comparte el recorte, casi no gasta memoria. */
    public Layer copy(String newName, int w, int h) {
        Layer l = new Layer(newName, snapshot(w, h));
        l.visible = visible;
        l.opacity = opacity;
        l.mode = mode;
        l.clip = clip;
        l.alphaLock = alphaLock;
        l.reference = reference;
        l.locked = false; // la copia se puede editar
        l.role = ROLE_NONE; // una copia no reemplaza a la Tinta ni al Color base del preset
        l.hue = hue;
        l.sat = sat;
        l.lit = lit;
        return l;
    }
}
