package com.pacco.animecut.ai;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtException;
import ai.onnxruntime.OrtSession;

import java.io.File;
import java.nio.FloatBuffer;
import java.util.Collections;

/**
 * v8.41: la IA de "Mejorar imagen" (Real-ESRGAN anime, ONNX con tamano libre) con ONNX Runtime.
 * Una sesion por trabajo; close() la suelta. cancel() corta el pedazo en curso.
 */
public final class SrModel implements Upscaler.Model, AutoCloseable {
    private final OrtEnvironment env;
    private final OrtSession session;
    private volatile OrtSession.RunOptions running;
    private volatile boolean cancelled;

    public SrModel(File model, int threads) throws OrtException {
        env = OrtEnvironment.getEnvironment();
        OrtSession.SessionOptions so = new OrtSession.SessionOptions();
        try {
            so.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT);
            so.setIntraOpNumThreads(Math.max(1, threads));
            so.setInterOpNumThreads(1);
            so.setCPUArenaAllocator(false);      // la memoria vuelve al sistema entre pedazos
            so.setMemoryPatternOptimization(false);
            session = env.createSession(model.getAbsolutePath(), so);
        } finally {
            so.close();
        }
    }

    @Override
    public float[] run(float[] chw, int h, int w) throws Exception {
        if (cancelled) throw new InterruptedException("cancelado");
        OrtSession.RunOptions ro = new OrtSession.RunOptions();
        running = ro;
        try (OnnxTensor t = OnnxTensor.createTensor(env, FloatBuffer.wrap(chw), new long[]{1, 3, h, w});
             OrtSession.Result r = session.run(Collections.singletonMap("input", t), ro)) {
            if (cancelled) throw new InterruptedException("cancelado");
            FloatBuffer fb = ((OnnxTensor) r.get(0)).getFloatBuffer();
            float[] out = new float[fb.remaining()];
            fb.get(out);
            return out;
        } finally {
            running = null;
            ro.close();
        }
    }

    public void cancel() {
        cancelled = true;
        OrtSession.RunOptions ro = running;
        if (ro != null) try { ro.setTerminate(true); } catch (Throwable ignored) { }
    }

    @Override
    public void close() {
        try { session.close(); } catch (Throwable ignored) { }
    }
}
