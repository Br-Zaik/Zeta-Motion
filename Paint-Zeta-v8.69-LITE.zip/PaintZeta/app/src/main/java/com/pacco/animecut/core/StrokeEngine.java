package com.pacco.animecut.core;

/**
 * Recorrido del dedo para Brocha, Goma y los demas pinceles (v8.23).
 * Sin dependencias de Android (probado en JVM).
 *
 * 1. Estabilizador: media movil de los ultimos N puntos. Al levantar el dedo se
 *    "vacia": el trazo SIEMPRE llega a donde quedo el dedo (el suavizado
 *    exponencial anterior se quedaba atras para siempre).
 * 2. Curva Catmull-Rom centripeta entre los puntos: las curvas rapidas no salen
 *    como poligonos. Centripeta (alfa 0,5) no forma lazos en giros bruscos.
 *    Cuesta un punto de retraso, que se dibuja al soltar.
 * 3. Estampas a distancia CONSTANTE a lo largo del recorrido, guardando el resto
 *    entre eventos: el resultado no depende de cuantos eventos entregue Android.
 */
public final class StrokeEngine {
    public interface Sink {
        /** Distancia entre estampas (px de imagen) en esa longitud de trazo. */
        float spacing(float arc);
        void stamp(float x, float y, float arc);
    }

    /** Distancia minima entre puntos de control (evita parametros degenerados). */
    private static final float MIN_POINT_DIST = .35f;

    private boolean curve = true;
    private int stabN = 1;
    private float[] winX = new float[1], winY = new float[1];
    private int winCount, winHead;
    private float lastRawX, lastRawY;

    // Puntos de control ya suavizados: q[k-1], q[k], q[k+1] y el nuevo.
    private final float[] qx = new float[3], qy = new float[3];
    private int qn;

    private float anchorX, anchorY, carry, arc;
    private boolean active;

    /** Estampas emitidas (diagnostico). */
    public int stamps;

    public void setCurve(boolean on) { curve = on; }

    /**
     * Estabilizador 0..1 (0 = apagado). Se traduce a una ventana de 1 a 25 puntos.
     */
    public static int windowFor(float stabilizer) {
        float s = Math.max(0f, Math.min(1f, stabilizer));
        return 1 + Math.round(s * s * 24f);
    }

    /** Empieza en (x, y). La primera estampa (arc = 0) la pone quien llama. */
    public void begin(float x, float y, float stabilizer) {
        stabN = windowFor(stabilizer);
        if (winX.length < stabN) { winX = new float[stabN]; winY = new float[stabN]; }
        winCount = 0;
        winHead = 0;
        pushWindow(x, y);
        lastRawX = x; lastRawY = y;
        qx[0] = x; qy[0] = y;
        qn = 1;
        anchorX = x; anchorY = y;
        carry = 0f;
        arc = 0f;
        stamps = 0;
        active = true;
    }

    public boolean isActive() { return active; }
    public float arc() { return arc; }

    public void add(float x, float y, Sink sink) {
        if (!active || !Float.isFinite(x) || !Float.isFinite(y)) return;
        lastRawX = x; lastRawY = y;
        pushWindow(x, y);
        float sx = 0f, sy = 0f;
        for (int i = 0; i < winCount; i++) { sx += winX[i]; sy += winY[i]; }
        addPoint(sx / winCount, sy / winCount, sink);
    }

    /** Levantar el dedo: vaciar el estabilizador y dibujar el ultimo tramo. */
    public void finish(Sink sink) {
        if (!active) return;
        // El estabilizador converge al punto real del dedo sin saltos.
        for (int k = 1; k < winCount; k++) {
            pushWindow(lastRawX, lastRawY);
            float sx = 0f, sy = 0f;
            for (int i = 0; i < winCount; i++) { sx += winX[i]; sy += winY[i]; }
            addPoint(sx / winCount, sy / winCount, sink);
        }
        addPoint(lastRawX, lastRawY, sink);
        // Ultimo tramo de la curva (q[n-2] -> q[n-1]) con el extremo repetido.
        if (qn >= 2) {
            int a = qn - 2, b = qn - 1;
            float p0x = a > 0 ? qx[a - 1] : qx[a], p0y = a > 0 ? qy[a - 1] : qy[a];
            segment(p0x, p0y, qx[a], qy[a], qx[b], qy[b], qx[b], qy[b], sink);
        }
        active = false;
    }

    /** Cancelar (segundo dedo): no se dibuja nada mas. */
    public void cancel() { active = false; }

    private void pushWindow(float x, float y) {
        winX[winHead] = x;
        winY[winHead] = y;
        winHead = (winHead + 1) % stabN;
        if (winCount < stabN) winCount++;
    }

    private void addPoint(float x, float y, Sink sink) {
        float lx = qx[qn - 1], ly = qy[qn - 1];
        float d = (float) Math.hypot(x - lx, y - ly);
        if (d < MIN_POINT_DIST) return;
        if (!curve) {
            line(lx, ly, x, y, sink);
            qx[0] = x; qy[0] = y; qn = 1;
            return;
        }
        if (qn < 3) {
            qx[qn] = x; qy[qn] = y; qn++;
            if (qn == 3) {
                // Primer tramo q0 -> q1 (q0 repetido como punto anterior).
                segment(qx[0], qy[0], qx[0], qy[0], qx[1], qy[1], qx[2], qy[2], sink);
            }
            return;
        }
        // Tramo q1 -> q2 con q0 antes y el nuevo punto despues.
        segment(qx[0], qy[0], qx[1], qy[1], qx[2], qy[2], x, y, sink);
        qx[0] = qx[1]; qy[0] = qy[1];
        qx[1] = qx[2]; qy[1] = qy[2];
        qx[2] = x; qy[2] = y;
    }

    /** Catmull-Rom centripeta (Barry-Goldman) de p1 a p2, recorrida en trozos cortos. */
    private void segment(float p0x, float p0y, float p1x, float p1y, float p2x, float p2y,
            float p3x, float p3y, Sink sink) {
        float len = (float) Math.hypot(p2x - p1x, p2y - p1y);
        int n = Math.max(1, Math.min(256, (int) Math.ceil(len / .75f)));
        float px = p1x, py = p1y;
        float[] c = new float[2];
        for (int i = 1; i <= n; i++) {
            centripetal(p0x, p0y, p1x, p1y, p2x, p2y, p3x, p3y, i / (float) n, c);
            line(px, py, c[0], c[1], sink);
            px = c[0]; py = c[1];
        }
    }

    /**
     * Punto u (0..1) del tramo p1 -&gt; p2 de una Catmull-Rom CENTRIPETA. No forma
     * lazos ni ganchos aunque los puntos esten a distancias muy distintas. Si p0
     * o p3 repiten a su vecino (extremo de la linea), se refleja para que la
     * tangente sea la del tramo. Lo usan Brocha/Goma y la herramienta Curva.
     */
    public static void centripetal(float p0x, float p0y, float p1x, float p1y, float p2x, float p2y,
            float p3x, float p3y, float u, float[] out) {
        float d01 = (float) Math.sqrt(Math.max(1e-6, Math.hypot(p1x - p0x, p1y - p0y)));
        float d12 = (float) Math.sqrt(Math.max(1e-6, Math.hypot(p2x - p1x, p2y - p1y)));
        float d23 = (float) Math.sqrt(Math.max(1e-6, Math.hypot(p3x - p2x, p3y - p2y)));
        if (Math.hypot(p1x - p0x, p1y - p0y) < 1e-3) { p0x = 2 * p1x - p2x; p0y = 2 * p1y - p2y; d01 = d12; }
        if (Math.hypot(p3x - p2x, p3y - p2y) < 1e-3) { p3x = 2 * p2x - p1x; p3y = 2 * p2y - p1y; d23 = d12; }
        if (u >= 1f) { out[0] = p2x; out[1] = p2y; return; }
        if (u <= 0f) { out[0] = p1x; out[1] = p1y; return; }
        float t0 = 0f, t1 = d01, t2 = t1 + d12, t3 = t2 + d23;
        float t = t1 + (t2 - t1) * u;
        float a1x = lerp(p0x, p1x, t0, t1, t), a1y = lerp(p0y, p1y, t0, t1, t);
        float a2x = lerp(p1x, p2x, t1, t2, t), a2y = lerp(p1y, p2y, t1, t2, t);
        float a3x = lerp(p2x, p3x, t2, t3, t), a3y = lerp(p2y, p3y, t2, t3, t);
        float b1x = lerp(a1x, a2x, t0, t2, t), b1y = lerp(a1y, a2y, t0, t2, t);
        float b2x = lerp(a2x, a3x, t1, t3, t), b2y = lerp(a2y, a3y, t1, t3, t);
        out[0] = lerp(b1x, b2x, t1, t2, t);
        out[1] = lerp(b1y, b2y, t1, t2, t);
    }

    private static float lerp(float a, float b, float ta, float tb, float t) {
        float d = tb - ta;
        if (Math.abs(d) < 1e-9f) return a;
        return a + (b - a) * (t - ta) / d;
    }

    /** Recorre un tramo recto colocando estampas a distancia constante (con resto). */
    private void line(float x0, float y0, float x1, float y1, Sink sink) {
        float dx = x1 - x0, dy = y1 - y0;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len <= 0f) return;
        float pos = 0f;
        while (true) {
            float step = Math.max(.25f, sink.spacing(arc));
            float need = step - carry;
            if (pos + need > len) break;
            pos += need;
            carry = 0f;
            float t = pos / len;
            float sx = x0 + dx * t, sy = y0 + dy * t;
            arc += (float) Math.hypot(sx - anchorX, sy - anchorY);
            anchorX = sx; anchorY = sy;
            stamps++;
            sink.stamp(sx, sy, arc);
        }
        carry += len - pos;
    }
}
