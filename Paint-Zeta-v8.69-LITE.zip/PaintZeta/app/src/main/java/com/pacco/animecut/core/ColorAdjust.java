package com.pacco.animecut.core;

/**
 * v8.26 "Cambiar color" no destructivo: gira el tono y sube/baja saturacion y
 * luminosidad (modelo HSL). El alfa no cambia nunca.
 *
 * Una capa de color base casi siempre tiene pocos colores distintos, por eso se
 * guarda una cache chica (4096 entradas). Cada hilo debe usar su propia instancia
 * (Layer.adjuster() crea una nueva cada vez).
 */
public final class ColorAdjust {
    public final int hue, sat, lit;
    private final int[] keys = new int[4096];
    private final int[] vals = new int[4096];

    public ColorAdjust(int hue, int sat, int lit) {
        this.hue = Math.max(-180, Math.min(180, hue));
        this.sat = Math.max(-100, Math.min(100, sat));
        this.lit = Math.max(-100, Math.min(100, lit));
    }

    /** ARGB sin premultiplicar -> ARGB ajustado (mismo alfa). */
    public int apply(int c) {
        int a = c & 0xFF000000;
        if (a == 0) return c;
        int rgb = c & 0x00FFFFFF;
        int k = (rgb ^ (rgb >>> 12) ^ (rgb >>> 7)) & 4095;
        int key = rgb | 0x01000000; // marca: entrada ocupada
        if (keys[k] == key) return a | vals[k];
        int out = adjustRgb(rgb, hue, sat, lit);
        keys[k] = key;
        vals[k] = out;
        return a | out;
    }

    /** El calculo sin cache (para pruebas y para "fijar" el ajuste en los pixeles). */
    public static int adjustRgb(int rgb, int hue, int sat, int lit) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        float l = (max + min) / 2f, h = 0f, s = 0f;
        float d = max - min;
        if (d > 1e-6f) {
            s = l > .5f ? d / (2f - max - min) : d / (max + min);
            if (max == r) h = (g - b) / d + (g < b ? 6f : 0f);
            else if (max == g) h = (b - r) / d + 2f;
            else h = (r - g) / d + 4f;
            h /= 6f;
        }
        h += hue / 360f;
        h -= (float) Math.floor(h);
        if (sat > 0) s += (1f - s) * sat / 100f;
        else if (sat < 0) s *= 1f + sat / 100f;
        if (lit > 0) l += (1f - l) * lit / 100f;
        else if (lit < 0) l *= 1f + lit / 100f;
        s = Math.max(0f, Math.min(1f, s));
        l = Math.max(0f, Math.min(1f, l));
        float nr, ng, nb;
        if (s <= 1e-6f) {
            nr = ng = nb = l;
        } else {
            float q = l < .5f ? l * (1f + s) : l + s - l * s;
            float p = 2f * l - q;
            nr = hue2rgb(p, q, h + 1f / 3f);
            ng = hue2rgb(p, q, h);
            nb = hue2rgb(p, q, h - 1f / 3f);
        }
        int ir = Math.round(nr * 255f), ig = Math.round(ng * 255f), ib = Math.round(nb * 255f);
        return (clamp(ir) << 16) | (clamp(ig) << 8) | clamp(ib);
    }

    private static int clamp(int v) {
        return v < 0 ? 0 : v > 255 ? 255 : v;
    }

    private static float hue2rgb(float p, float q, float t) {
        if (t < 0f) t += 1f;
        if (t > 1f) t -= 1f;
        if (t < 1f / 6f) return p + (q - p) * 6f * t;
        if (t < .5f) return q;
        if (t < 2f / 3f) return p + (q - p) * (2f / 3f - t) * 6f;
        return p;
    }
}
