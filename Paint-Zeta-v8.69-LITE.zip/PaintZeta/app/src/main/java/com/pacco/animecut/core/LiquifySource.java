package com.pacco.animecut.core;

/**
 * Imagen ORIGINAL de la capa durante una sesion de Especial, guardada por
 * bloques de 64x64 la primera vez que se necesitan. Nunca se vuelve a leer un
 * pixel ya deformado: la deformacion siempre se calcula desde aqui, por lo que
 * no hay borrosidad acumulada entre trazos.
 *
 * Regla de seguridad (hilos): un bloque se captura ANTES de que el resultado de
 * ese mismo bloque pueda escribirse en la capa. Lo garantiza LiquifySession
 * capturando el bloque propio antes de renderizarlo.
 */
public final class LiquifySource {
    public static final int TILE = 64, SHIFT = 6, MASK = 63;

    private final int[] layerPx;
    public final int width, height, tilesX, tilesY;
    private final int[][] base;
    private int captured;

    public LiquifySource(int[] layerPx, int width, int height) {
        if (layerPx == null || layerPx.length < width * height) throw new IllegalArgumentException();
        this.layerPx = layerPx;
        this.width = width;
        this.height = height;
        this.tilesX = (width + TILE - 1) / TILE;
        this.tilesY = (height + TILE - 1) / TILE;
        this.base = new int[tilesX * tilesY][];
    }

    public int[] layerPixels() { return layerPx; }

    public int capturedTiles() { return captured; }

    public boolean isCaptured(int key) { return base[key] != null; }

    /** Bloque original (stride 64), capturado si hace falta. */
    public int[] tile(int key) {
        int[] t = base[key];
        if (t != null) return t;
        int tx = key % tilesX, ty = key / tilesX;
        int left = tx * TILE, top = ty * TILE;
        int tw = Math.min(TILE, width - left), th = Math.min(TILE, height - top);
        t = new int[TILE * TILE];
        for (int y = 0; y < th; y++)
            System.arraycopy(layerPx, (top + y) * width + left, t, y * TILE, tw);
        base[key] = t;
        captured++;
        return t;
    }

    /** Bloque que contiene el pixel (x, y), capturado si hace falta. */
    public int[] tileAt(int x, int y) {
        int key = (y >> SHIFT) * tilesX + (x >> SHIFT);
        int[] t = base[key];
        return t != null ? t : tile(key);
    }

    /** Pixel original; x, y deben estar dentro del lienzo. */
    public int fetch(int x, int y) {
        int key = (y >> SHIFT) * tilesX + (x >> SHIFT);
        int[] t = base[key];
        if (t == null) t = tile(key);
        return t[((y & MASK) << SHIFT) | (x & MASK)];
    }
}
