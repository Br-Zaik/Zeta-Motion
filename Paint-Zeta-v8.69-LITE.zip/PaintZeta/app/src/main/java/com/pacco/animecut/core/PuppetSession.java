package com.pacco.animecut.core;

import java.util.ArrayList;

/**
 * Estado de una sesion de Marioneta (sin Android): malla de silueta, pines,
 * solver ARAP, historial interno de pines y medidas de calidad.
 *
 * Coordenadas: los pines y las posiciones deformadas estan en el LIENZO; la
 * malla en reposo esta en coordenadas locales de la imagen apartada, cuyo
 * pixel (0,0) esta en (originX, originY) del lienzo.
 */
public final class PuppetSession {

    public static final class Pin {
        /** Posicion en reposo (local) y donde esta en la malla. */
        public float rx, ry;
        public int tri;
        public final float[] b = new float[3];
        /** Posicion actual en el lienzo. */
        public float x, y;
        public boolean fixed;
        /** Zona rigida alrededor (cara, manos). */
        public boolean stiff;
        /** Giro alrededor del pin (radianes) y si el giro esta activo. */
        public float rot;
        public boolean rotOn;

        Pin copy() {
            Pin p = new Pin();
            p.rx = rx; p.ry = ry; p.tri = tri;
            p.b[0] = b[0]; p.b[1] = b[1]; p.b[2] = b[2];
            p.x = x; p.y = y; p.fixed = fixed; p.stiff = stiff; p.rot = rot; p.rotOn = rotOn;
            return p;
        }
    }

    public final int width, height;
    public final float originX, originY;
    private final PixelTiles.Reader reader;

    private PuppetMesh mesh;
    private ArapSolver solver;
    private final ArrayList<Pin> pins = new ArrayList<Pin>();
    private float[] pos;          // deformadas, lienzo
    private float[] local;        // deformadas, locales (salida del solver)
    private boolean structureDirty = true;

    private int rigidity = ArapSolver.NORMAL;
    private int density = 1;
    private int expansion = 2;
    /** v8.27: alfa util para la malla (8 = 3 %: ignora restos invisibles del recorte). */
    private int minAlpha = 8;
    private float stiffRadiusCells = 3f;
    /** Por partes: un punto mueve solo su parte; lo lejano (por la malla) se queda quieto. */
    private boolean byParts = true;
    /** Fuerza del ancla lejos de los puntos (1 = tan fuerte como una arista). */
    public static float ANCHOR_MAX = 1f;
    /**
     * Forma a la que tiran las anclas: la forma que habia al empezar el gesto
     * (no el reposo). Asi, por partes, lo lejano se queda DONDE ESTA ahora y
     * los giros grandes hechos antes no se deshacen.
     */
    private float[] anchorTo;
    private float reachCells = 12f;
    private boolean foldGuard = false;
    private int invertedNow;
    /** Ultimo arrastre fue recortado para no plegar la malla. */
    public boolean lastMoveLimited;

    private final ArrayList<Snap> undo = new ArrayList<Snap>();
    private final ArrayList<Snap> redo = new ArrayList<Snap>();
    private static final int MAX_HISTORY = 80;

    public long lastBuildNanos;

    public PuppetSession(PixelTiles.Reader reader, int width, int height, float originX, float originY) {
        this.reader = reader;
        this.width = width;
        this.height = height;
        this.originX = originX;
        this.originY = originY;
    }

    // ------------------------------------------------------------------
    // Malla
    // ------------------------------------------------------------------

    /** Construye la malla (lento en imagenes grandes: llamar fuera del hilo de la interfaz). */
    public synchronized void buildMesh() {
        long t0 = System.nanoTime();
        PixelTiles tiles = new PixelTiles(reader, width, height, 192);
        int[] bb = alphaBounds(tiles);
        int sw = bb == null ? width : bb[2] - bb[0], sh = bb == null ? height : bb[3] - bb[1];
        int sp = PuppetMesh.spacingFor(sw, sh, density);
        PuppetMesh m = PuppetMesh.build(tiles, sp, expansion, minAlpha);
        mesh = m;
        anchorTo = null;
        vertTri = null;
        lockCache = null;
        lockKey = null;
        solver = new ArapSolver(m);
        pos = new float[m.vertCount * 2];
        local = new float[m.vertCount * 2];
        // Los pines existentes se vuelven a ubicar en la malla nueva.
        for (Pin p : pins) relocate(p);
        structureDirty = true;
        resolve();
        lastBuildNanos = System.nanoTime() - t0;
    }

    private int[] alphaBounds(PixelTiles t) {
        int x0 = width, y0 = height, x1 = -1, y1 = -1;
        int step = Math.max(1, Math.min(width, height) / 400);
        for (int y = 0; y < height; y += step)
            for (int x = 0; x < width; x += step)
                if (t.alpha(x, y) >= minAlpha) {
                    if (x < x0) x0 = x;
                    if (y < y0) y0 = y;
                    if (x > x1) x1 = x;
                    if (y > y1) y1 = y;
                }
        if (x1 < 0) return null;
        return new int[]{x0, y0, x1 + 1, y1 + 1};
    }

    public synchronized boolean hasMesh() { return mesh != null; }
    public synchronized PuppetMesh mesh() { return mesh; }

    public synchronized void setDensity(int d) {
        d = Math.max(0, Math.min(2, d));
        if (d == density && mesh != null) return;
        density = d;
        if (mesh != null) buildMesh();
    }

    public synchronized void setExpansion(int e) {
        e = Math.max(0, Math.min(20, e));
        if (e == expansion && mesh != null) return;
        expansion = e;
        if (mesh != null) buildMesh();
    }

    public int getDensity() { return density; }

    /** v8.27: 8 de fabrica; 1 = incluir hasta lo casi invisible (como v8.26). Rehace la malla. */
    public synchronized void setMinAlpha(int a) {
        a = Math.max(1, Math.min(128, a));
        if (a == minAlpha && mesh != null) return;
        minAlpha = a;
        if (mesh != null) buildMesh();
    }

    public int getMinAlpha() { return minAlpha; }
    public int getExpansion() { return expansion; }

    public synchronized void setRigidity(int r) {
        rigidity = Math.max(0, Math.min(2, r));
        resolve();
    }

    public int getRigidity() { return rigidity; }

    public void setFoldGuard(boolean on) { foldGuard = on; }
    public boolean isFoldGuard() { return foldGuard; }

    public synchronized void setStiffRadiusCells(float c) {
        stiffRadiusCells = Math.max(1f, Math.min(8f, c));
        structureDirty = true;
        resolve();
    }

    public float getStiffRadiusCells() { return stiffRadiusCells; }

    // ------------------------------------------------------------------
    // Pines
    // ------------------------------------------------------------------

    public synchronized int pinCount() { return pins.size(); }

    public synchronized Pin pin(int i) { return pins.get(i); }

    /** v8.61: copia de los puntos (para dibujar mientras el calculo sigue en otro hilo). */
    public synchronized Pin[] pinsCopy() {
        Pin[] a = new Pin[pins.size()];
        for (int i = 0; i < a.length; i++) a[i] = pins.get(i).copy();
        return a;
    }

    /** Pin mas cercano a (x,y) del lienzo dentro de radio, o -1. */
    public synchronized int findPin(float x, float y, float radius) {
        int best = -1;
        float bd = radius * radius;
        for (int i = 0; i < pins.size(); i++) {
            Pin p = pins.get(i);
            float dx = p.x - x, dy = p.y - y, d = dx * dx + dy * dy;
            if (d <= bd) { bd = d; best = i; }
        }
        return best;
    }

    /**
     * Agrega un pin donde se toca (sobre la imagen ya deformada). Devuelve su
     * indice o -1 si el toque no cae sobre el dibujo.
     */
    public synchronized int addPin(float x, float y, boolean fixed) {
        if (mesh == null) return -1;
        float[] bc = new float[3];
        int t = mesh.locateDeformed(local, x - originX, y - originY, bc);
        Pin p = new Pin();
        if (t >= 0) {
            float rx = 0, ry = 0;
            for (int k = 0; k < 3; k++) {
                int v = mesh.tri[t * 3 + k];
                rx += bc[k] * mesh.rest[v * 2];
                ry += bc[k] * mesh.rest[v * 2 + 1];
            }
            p.rx = rx; p.ry = ry;
        } else if (pins.isEmpty() || isIdentity()) {
            // Sin deformar: se busca la parte mas cercana (toque en el borde).
            p.rx = x - originX;
            p.ry = y - originY;
        } else {
            return -1;
        }
        if (!relocate(p)) return -1;
        // Se coloca exactamente donde esta ese punto de la malla ahora.
        float cx = 0, cy = 0;
        for (int k = 0; k < 3; k++) {
            int v = mesh.tri[p.tri * 3 + k];
            cx += p.b[k] * local[v * 2];
            cy += p.b[k] * local[v * 2 + 1];
        }
        p.x = cx + originX;
        p.y = cy + originY;
        p.fixed = fixed;
        pushHistory();
        pins.add(p);
        structureDirty = true;
        resolve();
        return pins.size() - 1;
    }

    private boolean isIdentity() {
        for (int i = 0; i < local.length; i++) if (Math.abs(local[i] - mesh.rest[i]) > 1e-3f) return false;
        return true;
    }

    /** Ubica el pin (rx,ry) en la malla actual. */
    private boolean relocate(Pin p) {
        float reach = Math.max(12f, mesh.spacing * .75f);
        int piece = mesh.pieceForPoint(p.rx, p.ry, reach);
        if (piece < 0) return false;
        p.tri = mesh.locateInPiece(piece, p.rx, p.ry, p.b);
        return p.tri >= 0;
    }

    public synchronized void removePin(int i) {
        if (i < 0 || i >= pins.size()) return;
        pushHistory();
        pins.remove(i);
        structureDirty = true;
        resolve();
    }

    public synchronized void clearPins() {
        if (pins.isEmpty()) return;
        pushHistory();
        pins.clear();
        structureDirty = true;
        resolve();
    }

    public synchronized void setFixed(int i, boolean fixed) {
        if (i < 0 || i >= pins.size()) return;
        if (pins.get(i).fixed == fixed) return;
        pushHistory();
        pins.get(i).fixed = fixed;
        structureDirty = true;
        resolve();
    }

    public synchronized void setStiff(int i, boolean stiff) {
        if (i < 0 || i >= pins.size()) return;
        if (pins.get(i).stiff == stiff) return;
        pushHistory();
        pins.get(i).stiff = stiff;
        structureDirty = true;
        resolve();
    }

    /** Llamar al empezar a arrastrar o girar (una entrada de Deshacer por gesto). */
    public synchronized void beginGesture() {
        pushHistory();
        if (local != null) anchorTo = local.clone();
        invertedNow = mesh == null ? 0 : mesh.invertedCount(local);
    }

    /**
     * Mueve el pin i hacia (x,y). Con el control de pliegues encendido, si el
     * movimiento invertiria triangulos, el pin se detiene en la ultima
     * posicion valida (busqueda por biseccion). Devuelve true si se movio.
     */
    public synchronized boolean movePin(int i, float x, float y) {
        if (mesh == null || i < 0 || i >= pins.size()) return false;
        Pin p = pins.get(i);
        if (p.fixed) return false;
        float sx = p.x, sy = p.y;
        p.x = x; p.y = y;
        resolve();
        lastMoveLimited = false;
        if (!foldGuard) return true;
        int inv = mesh.invertedCount(local);
        // v8.67: un par de triangulitos doblados en el borde no se notan: no frenan el dedo
        // (antes 1 solo triangulo detenia el punto y parecia trabado)
        final int tol = invertedNow + Math.max(2, mesh.triCount / 300);
        if (inv <= tol) return true;
        float lo = 0f, hi = 1f;
        // v8.61: 4 pasos (1/16 del tramo) en vez de 7: casi igual de preciso y la mitad de calculos
        for (int it = 0; it < 4; it++) {
            float mid = (lo + hi) * .5f;
            p.x = sx + (x - sx) * mid;
            p.y = sy + (y - sy) * mid;
            resolve();
            if (mesh.invertedCount(local) <= tol) lo = mid; else hi = mid;
        }
        p.x = sx + (x - sx) * lo;
        p.y = sy + (y - sy) * lo;
        resolve();
        lastMoveLimited = true;
        return lo > 0f;
    }

    /** Gira el pin i (activa el giro la primera vez). */
    public synchronized void rotatePin(int i, float radians) {
        if (mesh == null || i < 0 || i >= pins.size()) return;
        Pin p = pins.get(i);
        if (!p.rotOn) {
            p.rotOn = true;
            structureDirty = true;
        }
        p.rot = radians;
        resolve();
    }

    /** Estado guardado: puntos + forma actual (la forma es a donde tiran las anclas). */
    public static final class Snap {
        final Pin[] pins;
        final float[] shape;
        Snap(Pin[] p, float[] s) { pins = p; shape = s; }
        public int size() { return pins.length; }
        public Pin pin(int i) { return pins[i]; }
    }

    public synchronized Snap snapshot() {
        Pin[] s = new Pin[pins.size()];
        for (int i = 0; i < s.length; i++) s[i] = pins.get(i).copy();
        return new Snap(s, anchorTo == null ? null : anchorTo.clone());
    }

    /** Restaura un estado guardado (por ejemplo al detectar un segundo dedo). */
    public synchronized void restore(Snap s) {
        pins.clear();
        for (Pin p : s.pins) pins.add(p.copy());
        anchorTo = s.shape == null ? null : s.shape.clone();
        structureDirty = true;
        resolve();
    }

    /**
     * v8.27: el mismo estado con los puntos corridos (dx, dy) en el lienzo. La forma y
     * la malla estan en coordenadas locales: sirven igual si la imagen apartada se corrio
     * lo mismo (Ampliar lienzo y aplicar).
     */
    public static Snap shifted(Snap s, float dx, float dy) {
        Pin[] p = new Pin[s.pins.length];
        for (int i = 0; i < p.length; i++) {
            p[i] = s.pins[i].copy();
            p[i].x += dx;
            p[i].y += dy;
        }
        return new Snap(p, s.shape == null ? null : s.shape.clone());
    }

    /**
     * v8.27 "Mover dentro del lienzo": corre TODO el resultado (puntos y forma) sin
     * deformarlo (ARAP no cambia con una traslacion). Se puede deshacer.
     */
    public synchronized void translateAll(float dx, float dy) {
        if (mesh == null || (dx == 0f && dy == 0f)) return;
        pushHistory();
        for (Pin p : pins) {
            p.x += dx;
            p.y += dy;
        }
        if (anchorTo == null && local != null) anchorTo = local.clone();
        if (anchorTo != null) {
            for (int i = 0; i < anchorTo.length; i += 2) {
                anchorTo[i] += dx;
                anchorTo[i + 1] += dy;
            }
        }
        resolve();
    }

    /** Quita la ultima entrada de historial (gesto descartado). */
    public synchronized void dropLastHistory() {
        if (!undo.isEmpty()) undo.remove(undo.size() - 1);
    }

    private void pushHistory() {
        undo.add(snapshot());
        if (undo.size() > MAX_HISTORY) undo.remove(0);
        redo.clear();
        // Desde ahora las anclas tiran hacia la forma actual (nada salta).
        if (local != null && mesh != null && local.length == mesh.vertCount * 2) anchorTo = local.clone();
    }

    public synchronized boolean canUndo() { return !undo.isEmpty(); }
    public synchronized boolean canRedo() { return !redo.isEmpty(); }

    public synchronized boolean undo() {
        if (undo.isEmpty()) return false;
        redo.add(snapshot());
        Snap s = undo.remove(undo.size() - 1);
        restore(s);
        return true;
    }

    public synchronized boolean redo() {
        if (redo.isEmpty()) return false;
        undo.add(snapshot());
        Snap s = redo.remove(redo.size() - 1);
        restore(s);
        return true;
    }

    // ------------------------------------------------------------------
    // Resolver
    // ------------------------------------------------------------------

    /** Recalcula las posiciones deformadas. */
    public synchronized void resolve() {
        if (mesh == null) return;
        int n = pins.size();
        // Restricciones: 1 por pin + 2 virtuales por pin con giro.
        int extra = 0;
        for (Pin p : pins) if (p.rotOn) extra += 2;
        // Un punto FIJO sujeta tambien los vertices de su zona (2 celdas): asi
        // los pies quedan exactamente donde estaban, no solo su centro.
        int[] lockV = lockedVertices();
        int nc = n + extra + lockV.length / 2;
        int[] tri = new int[nc];
        float[] bary = new float[nc * 3];
        float[] target = new float[nc * 2];
        float d = mesh.spacing;
        int c = 0;
        float[] tmp = new float[3];
        for (Pin p : pins) {
            tri[c] = p.tri;
            bary[c * 3] = p.b[0]; bary[c * 3 + 1] = p.b[1]; bary[c * 3 + 2] = p.b[2];
            target[c * 2] = p.x - originX;
            target[c * 2 + 1] = p.y - originY;
            c++;
        }
        for (Pin p : pins) {
            if (!p.rotOn) continue;
            float cs = (float) Math.cos(p.rot), sn = (float) Math.sin(p.rot);
            int piece = mesh.triPiece[p.tri];
            int comp = mesh.vertComp[mesh.tri[p.tri * 3]];
            for (int k = 0; k < 2; k++) {
                float ox = k == 0 ? d : 0, oy = k == 0 ? 0 : d;
                // Punto virtual a una celda del pin, en la misma pieza conectada.
                int pc = mesh.pieceForPoint(p.rx + ox, p.ry + oy, d * .5f);
                if (pc < 0 || mesh.vertComp[mesh.pieceVerts[pc * 4]] != comp) {
                    ox = -ox; oy = -oy;
                    pc = mesh.pieceForPoint(p.rx + ox, p.ry + oy, d * .5f);
                    if (pc < 0 || mesh.vertComp[mesh.pieceVerts[pc * 4]] != comp) pc = piece;
                }
                int t = mesh.locateInPiece(pc, p.rx + ox, p.ry + oy, tmp);
                // La posicion en reposo real del punto virtual (recortada al cuadro)
                float vx = 0, vy = 0;
                for (int q = 0; q < 3; q++) {
                    int v = mesh.tri[t * 3 + q];
                    vx += tmp[q] * mesh.rest[v * 2];
                    vy += tmp[q] * mesh.rest[v * 2 + 1];
                }
                float rx = vx - p.rx, ry = vy - p.ry;
                tri[c] = t;
                bary[c * 3] = tmp[0]; bary[c * 3 + 1] = tmp[1]; bary[c * 3 + 2] = tmp[2];
                target[c * 2] = p.x - originX + rx * cs - ry * sn;
                target[c * 2 + 1] = p.y - originY + rx * sn + ry * cs;
                c++;
            }
        }
        for (int q = 0; q < lockV.length; q += 2) {
            int v = lockV[q];
            Pin p = pins.get(lockV[q + 1]);
            tri[c] = vertTri[v];
            for (int k = 0; k < 3; k++) bary[c * 3 + k] = mesh.tri[vertTri[v] * 3 + k] == v ? 1f : 0f;
            target[c * 2] = mesh.rest[v * 2] + (p.x - originX - p.rx);
            target[c * 2 + 1] = mesh.rest[v * 2 + 1] + (p.y - originY - p.ry);
            c++;
        }
        if (structureDirty) {
            int ns = 0;
            for (Pin p : pins) if (p.stiff) ns++;
            float[] stiff = new float[ns * 4];
            int k = 0;
            for (Pin p : pins) {
                if (!p.stiff) continue;
                stiff[k * 4] = p.rx; stiff[k * 4 + 1] = p.ry;
                stiff[k * 4 + 2] = mesh.spacing * stiffRadiusCells; stiff[k * 4 + 3] = 8f;
                k++;
            }
            solver.setup(tri, bary, nc, stiff, ns, byParts ? anchorWeights() : null);
            structureDirty = false;
        }
        solver.solve(target, rigidity, local, anchorTo);
        // Lo que practicamente no se movio (menos de 1/20 de pixel) queda EXACTO:
        // asi las zonas quietas (pies fijos, la otra pierna) no se re-muestrean.
        for (int i = 0; i < local.length; i += 2) {
            if (Math.abs(local[i] - mesh.rest[i]) < .05f && Math.abs(local[i + 1] - mesh.rest[i + 1]) < .05f) {
                local[i] = mesh.rest[i];
                local[i + 1] = mesh.rest[i + 1];
            }
        }
        for (int i = 0; i < local.length; i += 2) {
            pos[i] = local[i] + originX;
            pos[i + 1] = local[i + 1] + originY;
        }
    }

    private int[] vertTri;
    private int[] lockCache;
    private String lockKey;

    /** Pares (vertice, pin) de los vertices sujetos por puntos fijos. */
    private int[] lockedVertices() {
        StringBuilder key = new StringBuilder();
        for (int i = 0; i < pins.size(); i++) {
            Pin p = pins.get(i);
            if (p.fixed) key.append(i).append(':').append(p.rx).append(',').append(p.ry).append(';');
        }
        String k = key.toString();
        if (lockCache != null && k.equals(lockKey)) return lockCache;
        if (vertTri == null || vertTri.length != mesh.vertCount) {
            vertTri = new int[mesh.vertCount];
            for (int t = 0; t < mesh.triCount; t++)
                for (int q = 0; q < 3; q++) vertTri[mesh.tri[t * 3 + q]] = t;
        }
        java.util.ArrayList<Integer> out = new java.util.ArrayList<Integer>();
        boolean[] used = new boolean[mesh.vertCount];
        float r = mesh.spacing * 2f, r2 = r * r;
        for (int i = 0; i < pins.size(); i++) {
            Pin p = pins.get(i);
            if (!p.fixed) continue;
            int comp = mesh.vertComp[mesh.tri[p.tri * 3]];
            for (int v = 0; v < mesh.vertCount; v++) {
                if (used[v] || mesh.vertComp[v] != comp) continue;
                float dx = mesh.rest[v * 2] - p.rx, dy = mesh.rest[v * 2 + 1] - p.ry;
                if (dx * dx + dy * dy <= r2) { used[v] = true; out.add(v); out.add(i); }
            }
        }
        int[] a = new int[out.size()];
        for (int i = 0; i < a.length; i++) a[i] = out.get(i);
        lockCache = a;
        lockKey = k;
        return a;
    }

    public synchronized void setByParts(boolean on) {
        if (byParts == on) return;
        byParts = on;
        structureDirty = true;
        resolve();
    }

    public boolean isByParts() { return byParts; }

    public synchronized void setReachCells(float c) {
        reachCells = Math.max(2f, Math.min(30f, c));
        structureDirty = true;
        resolve();
    }

    public float getReachCells() { return reachCells; }

    /**
     * Peso de ancla por vertice: 0 cerca de los puntos (libre), 1 lejos (quieto).
     * La distancia se mide POR LA MALLA (no en linea recta): la punta de la
     * corbata esta cerca de la corbata, pero lejos del pantalon aunque se vean
     * juntos en la imagen.
     */
    private float[] anchorWeights() {
        int nv = mesh.vertCount;
        // adyacencia por aristas de triangulos
        int[] deg = new int[nv];
        for (int t = 0; t < mesh.triCount; t++) for (int k = 0; k < 3; k++) deg[mesh.tri[t * 3 + k]] += 2;
        int[] start = new int[nv + 1];
        for (int v = 0; v < nv; v++) start[v + 1] = start[v] + deg[v];
        int[] adj = new int[start[nv]];
        int[] fill = java.util.Arrays.copyOf(start, nv);
        for (int t = 0; t < mesh.triCount; t++)
            for (int k = 0; k < 3; k++) {
                int a = mesh.tri[t * 3 + k], b = mesh.tri[t * 3 + (k + 1) % 3];
                adj[fill[a]++] = b;
                adj[fill[b]++] = a;
            }
        double[] dist = new double[nv];
        java.util.Arrays.fill(dist, Double.MAX_VALUE);
        java.util.PriorityQueue<double[]> q = new java.util.PriorityQueue<double[]>(64, new java.util.Comparator<double[]>() {
            @Override public int compare(double[] x, double[] y) { return Double.compare(x[0], y[0]); }
        });
        for (Pin p : pins) {
            for (int k = 0; k < 3; k++) {
                int v = mesh.tri[p.tri * 3 + k];
                double d = Math.hypot(mesh.rest[v * 2] - p.rx, mesh.rest[v * 2 + 1] - p.ry);
                if (d < dist[v]) { dist[v] = d; q.add(new double[]{d, v}); }
            }
        }
        while (!q.isEmpty()) {
            double[] e = q.poll();
            int v = (int) e[1];
            if (e[0] > dist[v]) continue;
            for (int i = start[v]; i < start[v + 1]; i++) {
                int u = adj[i];
                double nd = e[0] + Math.hypot(mesh.rest[u * 2] - mesh.rest[v * 2], mesh.rest[u * 2 + 1] - mesh.rest[v * 2 + 1]);
                if (nd < dist[u]) { dist[u] = nd; q.add(new double[]{nd, u}); }
            }
        }
        float L = mesh.spacing * reachCells;
        float[] w = new float[nv];
        // Una parte con puntos AZULES funciona como Photoshop (lo azul sujeta y
        // el resto se acomoda, por ejemplo un brazo gira entero desde el hombro).
        // Solo las partes SIN puntos azules usan anclas "por partes".
        boolean[] hasFixed = new boolean[mesh.compCount];
        for (Pin p : pins) if (p.fixed) hasFixed[mesh.vertComp[mesh.tri[p.tri * 3]]] = true;
        boolean any = false;
        for (int v = 0; v < nv; v++) if (!hasFixed[mesh.vertComp[v]]) { any = true; break; }
        if (!any) return null;
        for (int v = 0; v < nv; v++) {
            if (hasFixed[mesh.vertComp[v]]) { w[v] = 0f; continue; }
            if (dist[v] == Double.MAX_VALUE) { w[v] = 1f; continue; }
            double g = dist[v] / L;
            w[v] = (float) (ANCHOR_MAX * (1 - Math.exp(-g * g)));
        }
        return w;
    }

    /** Copia de las posiciones deformadas en el lienzo. */
    public synchronized float[] positionsCopy() {
        return pos == null ? null : pos.clone();
    }

    public synchronized float[] positions() { return pos; }

    public synchronized int invertedCount() {
        return mesh == null ? 0 : mesh.invertedCount(local);
    }

    /** Rectangulo [l, t, r, b] del lienzo que ocupa la malla deformada. */
    public synchronized float[] deformedBounds() {
        if (pos == null || pos.length == 0) return null;
        float l = Float.MAX_VALUE, t = Float.MAX_VALUE, r = -Float.MAX_VALUE, b = -Float.MAX_VALUE;
        for (int i = 0; i < pos.length; i += 2) {
            l = Math.min(l, pos[i]); r = Math.max(r, pos[i]);
            t = Math.min(t, pos[i + 1]); b = Math.max(b, pos[i + 1]);
        }
        return new float[]{l, t, r, b};
    }

    public long lastFactorNanos() { return solver == null ? 0 : solver.lastFactorNanos; }
    public long lastSolveNanos() { return solver == null ? 0 : solver.lastSolveNanos; }

    /**
     * Pinta la imagen deformada en out (buffer de ow x oh cuyo origen esta en
     * (ox, oy) del lienzo, escala px de buffer por px de lienzo).
     */
    public static long render(PuppetMesh m, float[] canvasPos, PixelTiles src,
            int ox, int oy, int ow, int oh, float scale, int[] out) {
        return TriWarp.render(src, 0, 0, m.rest, canvasPos, m.tri, m.triCount, m.triPiece, m, ox, oy, ow, oh, scale, out);
    }

    /** v8.33: vista previa rapida mientras se arrastra (una muestra por pixel). */
    public static long renderFast(PuppetMesh m, float[] canvasPos, PixelTiles src,
            int ox, int oy, int ow, int oh, float scale, int[] out) {
        return TriWarp.render(src, 0, 0, m.rest, canvasPos, m.tri, m.triCount, m.triPiece, m, ox, oy, ow, oh, scale, out, true);
    }

    /** Lo mismo pero las posiciones en reposo se desplazan al lienzo (para TriWarp). */
    public PixelTiles newTiles(int maxTiles) {
        return new PixelTiles(reader, width, height, maxTiles);
    }

    // ------------------------------------------------------------------
    // Medidas de calidad (pruebas y aviso en pantalla)
    // ------------------------------------------------------------------

    /**
     * Valores singulares del mapa reposo-&gt;deformado de cada triangulo.
     * out[t*2] = sigma mayor, out[t*2+1] = sigma menor (negativo si invertido).
     */
    public static void singularValues(PuppetMesh m, float[] localPos, float[] out) {
        for (int t = 0; t < m.triCount; t++) {
            int a = m.tri[t * 3], b = m.tri[t * 3 + 1], c = m.tri[t * 3 + 2];
            double e1x = m.rest[b * 2] - m.rest[a * 2], e1y = m.rest[b * 2 + 1] - m.rest[a * 2 + 1];
            double e2x = m.rest[c * 2] - m.rest[a * 2], e2y = m.rest[c * 2 + 1] - m.rest[a * 2 + 1];
            double f1x = localPos[b * 2] - localPos[a * 2], f1y = localPos[b * 2 + 1] - localPos[a * 2 + 1];
            double f2x = localPos[c * 2] - localPos[a * 2], f2y = localPos[c * 2 + 1] - localPos[a * 2 + 1];
            double det = e1x * e2y - e2x * e1y;
            if (Math.abs(det) < 1e-12) { out[t * 2] = 1; out[t * 2 + 1] = 1; continue; }
            // J = F * E^-1
            double i00 = e2y / det, i01 = -e2x / det, i10 = -e1y / det, i11 = e1x / det;
            double j00 = f1x * i00 + f2x * i10, j01 = f1x * i01 + f2x * i11;
            double j10 = f1y * i00 + f2y * i10, j11 = f1y * i01 + f2y * i11;
            double E = (j00 + j11) * .5, F = (j00 - j11) * .5, G = (j10 + j01) * .5, H = (j10 - j01) * .5;
            double Q = Math.sqrt(E * E + H * H), R = Math.sqrt(F * F + G * G);
            double s1 = Q + R, s2 = Q - R;
            double dj = j00 * j11 - j01 * j10;
            out[t * 2] = (float) s1;
            out[t * 2 + 1] = (float) (dj < 0 ? -Math.abs(s2) : s2);
        }
    }

    public synchronized float[] localPositionsCopy() {
        return local == null ? null : local.clone();
    }
}
