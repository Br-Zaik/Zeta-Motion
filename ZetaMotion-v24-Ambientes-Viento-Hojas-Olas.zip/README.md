# Zeta Motion v24

Proyecto fuente Android de Zeta Motion para animar fondos de anime, manga, manhwa e ilustraciones.

La v24 añade una biblioteca rápida de ambientes y estilos de **viento, hojas, agua, lluvia y nieve**, incluyendo hojas verdes, secas, de otoño y Navidad, además de olas suaves/fuertes y presets de clima. Mantiene las mejoras de v23 de carga rápida y timeline libre.

Consulta `README_V24.md` para los cambios de esta versión. Compila el APK con el workflow incluido en `.github/workflows/build.yml`.
