# Zeta Motion v18 — Importación desde Archivos

Cambio solicitado sobre la base v17.

## Importación nueva
- El botón **Importar** ya no depende de una sola ruta.
- Al tocarlo se muestran dos opciones:
  - **Galería**: selector de fotos del sistema.
  - **Archivos**: selector SAF de Android (`OpenDocument`) para abrir imágenes desde Descargas, carpetas y proveedores de archivos.
- La opción **Archivos** no requiere permiso general de almacenamiento.
- Después de elegir la imagen se mantiene el cuadro de duración del vídeo de v17 (4, 6, 10, 15, 30 s o personalizado 2–60 s).
- La imagen seleccionada se copia al proyecto, así que no depende de que el permiso al archivo siga vivo después.

## Se mantiene de v17
- Efectos repetibles e independientes.
- Varios efectos en el mismo segundo.
- Clips movibles en la línea de tiempo.
- Duración editable del proyecto.
- Exportación y resto del editor sin cambios fuera de esta corrección.
