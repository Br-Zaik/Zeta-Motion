package com.zeta.fondo.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EffectTimelineTest {
    @Test fun repeatedBlocksCanLiveAtDifferentSeconds() {
        val clips = listOf(
            EffectClip(1, "gust", 0f, 2f),
            EffectClip(2, "gust", 5f, 2f),
            EffectClip(3, "gust", 9f, 1f)
        )
        assertTrue(EffectTimeline.sample(clips, 1f / 12f, 12f).gate > .9f)
        assertEquals(0f, EffectTimeline.sample(clips, 3.5f / 12f, 12f).gate, .0001f)
        assertTrue(EffectTimeline.sample(clips, 6f / 12f, 12f).gate > .9f)
        assertTrue(EffectTimeline.sample(clips, 9.5f / 12f, 12f).gate > .9f)
    }

    @Test fun wholeVideoAndExtraCopyStackInsteadOfReplacingEachOther() {
        val clips = listOf(
            EffectClip(1, "gust", 0f, 12f),
            EffectClip(2, "gust", 4f, 2f)
        )
        val base = EffectTimeline.sample(clips, 2f / 12f, 12f).gate
        val stacked = EffectTimeline.sample(clips, 5f / 12f, 12f).gate
        assertEquals(1f, base, .0001f)
        assertTrue(stacked > 1.8f)
    }

    @Test fun normalizedClipNeverLeavesVideo() {
        val c = EffectTimeline.normalized(EffectClip(8, "impact", 59.99f, 10f), 60f)
        assertTrue(c.startSec >= 0f)
        assertTrue(c.endSec <= 60.0001f)
        assertTrue(c.durationSec >= .04f)
    }
}
