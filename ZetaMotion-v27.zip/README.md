# Zeta Motion v27

Editor Android para animar fondos e ilustraciones de anime, manga y manhwa.

Esta versión hace el cuadro de exportación compacto y corrige el recorte de los bloques cuando están pegados al inicio o al final de la timeline.

Ver `README_V27.md`.
