# Zeta Motion v20 — Timeline tipo CapCut

Cambios de esta versión:

- Un toque en un efecto crea **un solo bloque**. Si ya existe, solo lo selecciona.
- El mismo efecto **no se duplica por tocar otra vez la tarjeta**.
- El botón **+** es la acción explícita para añadir otra copia del mismo efecto.
- **Todo el vídeo** extiende el bloque seleccionado a toda la duración; ya no crea otra copia encima.
- En la línea de tiempo, toca un bloque para seleccionarlo.
- Mantén pulsado el centro del bloque y arrastra para moverlo al segundo deseado.
- Arrastra el tirador izquierdo para cambiar el inicio.
- Arrastra el tirador derecho para acortar o alargar la duración.
- Los cambios de movimiento/redimensionado usan estado visual local y preview limitado a ~30 fps para mantener el gesto fluido.
- Los clips que no se solapan comparten la misma pista. Solo se crean pistas extra cuando hay efectos simultáneos.
- Se conserva: duración personalizada, importación desde Archivos, efectos repetibles, varios efectos en el mismo segundo y exportación existente.

VersionCode: 20
VersionName: 20.0.0
