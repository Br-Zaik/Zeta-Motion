# Zeta Motion

Código fuente Android de Zeta Motion v30. Aplicación especializada en animar fondos e ilustraciones de anime, manga y manhwa.

Consulta `README_V30.md` para los cambios de esta versión.
